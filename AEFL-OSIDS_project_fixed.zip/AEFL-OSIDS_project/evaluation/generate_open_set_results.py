"""
AEFL-OSIDS Publication Open-Set Results Generator

Reads:
    results/final_open_set/final_open_set_results.json

Generates:
    results/paper_results/open_set_results_publication.csv
    results/paper_results/open_set_metrics.png
    results/paper_results/open_set_detection_summary.txt

No model training or inference is performed.
"""

from pathlib import Path
import json

import matplotlib.pyplot as plt
import pandas as pd


# ----------------------------------------------------------------------
# PATHS
# ----------------------------------------------------------------------

PROJECT_ROOT = Path(__file__).resolve().parents[1]

INPUT_FILE = (
    PROJECT_ROOT
    / "results"
    / "final_open_set"
    / "final_open_set_results.json"
)

OUTPUT_DIR = PROJECT_ROOT / "results" / "paper_results"

OUTPUT_DIR.mkdir(parents=True, exist_ok=True)


# ----------------------------------------------------------------------
# LOAD RESULTS
# ----------------------------------------------------------------------

def load_results():
    if not INPUT_FILE.exists():
        raise FileNotFoundError(
            f"\nFinal open-set results file not found:\n{INPUT_FILE}\n"
        )

    with INPUT_FILE.open("r", encoding="utf-8") as f:
        results = json.load(f)

    required_top_level = [
        "scenario",
        "locked_threshold",
        "test_samples",
        "unknown_families",
        "unknown_detection",
        "known_class_performance",
        "open_set_auroc",
    ]

    missing = [
        key for key in required_top_level
        if key not in results
    ]

    if missing:
        raise ValueError(
            "Missing required fields in final_open_set_results.json: "
            + ", ".join(missing)
        )

    return results


# ----------------------------------------------------------------------
# CREATE PUBLICATION DATA
# ----------------------------------------------------------------------

def create_publication_dataframe(results):
    unknown = results["unknown_detection"]
    known = results["known_class_performance"]

    data = {
        "Metric": [
            "Unknown Precision",
            "Unknown Recall",
            "Unknown F1",
            "Known FPR",
            "Open-set AUROC",
            "Known Accuracy",
            "Known Macro Precision",
            "Known Macro Recall",
            "Known Macro F1",
        ],
        "Value": [
            unknown["precision"] * 100,
            unknown["recall"] * 100,
            unknown["f1"] * 100,
            unknown["known_fpr"] * 100,
            results["open_set_auroc"] * 100,
            known["accuracy"] * 100,
            known["macro_precision"] * 100,
            known["macro_recall"] * 100,
            known["macro_f1"] * 100,
        ],
    }

    return pd.DataFrame(data)


# ----------------------------------------------------------------------
# SAVE CSV
# ----------------------------------------------------------------------

def save_csv(df):
    path = OUTPUT_DIR / "open_set_results_publication.csv"

    df.to_csv(
        path,
        index=False,
        encoding="utf-8-sig",
    )

    return path


# ----------------------------------------------------------------------
# OPEN-SET METRICS PLOT
# ----------------------------------------------------------------------

def generate_plot(df, threshold):
    plot_df = df[
        df["Metric"].isin(
            [
                "Unknown Precision",
                "Unknown Recall",
                "Unknown F1",
                "Known FPR",
                "Open-set AUROC",
            ]
        )
    ].copy()

    plt.figure(figsize=(10, 6))

    bars = plt.bar(
        plot_df["Metric"],
        plot_df["Value"],
    )

    plt.ylabel("Percentage (%)")
    plt.xlabel("Metric")

    plt.title(
        "Open-Set Intrusion Detection Performance"
    )

    plt.ylim(0, 100)

    plt.xticks(
        rotation=15,
        ha="right",
    )

    plt.grid(
        axis="y",
        alpha=0.25,
    )

    for bar, value in zip(
        bars,
        plot_df["Value"],
    ):
        plt.text(
            bar.get_x()
            + bar.get_width() / 2,
            value + 1.0,
            f"{value:.2f}%",
            ha="center",
            va="bottom",
            fontsize=9,
        )

    plt.figtext(
        0.5,
        0.01,
        f"Locked open-set threshold = {threshold:.6f}",
        ha="center",
        fontsize=9,
    )

    plt.tight_layout(
        rect=[0, 0.04, 1, 1]
    )

    path = (
        OUTPUT_DIR
        / "open_set_metrics.png"
    )

    plt.savefig(
        path,
        dpi=300,
        bbox_inches="tight",
    )

    plt.close()

    return path


# ----------------------------------------------------------------------
# SAVE SUMMARY
# ----------------------------------------------------------------------

def save_summary(results):
    unknown = results["unknown_detection"]
    known = results["known_class_performance"]

    threshold = results["locked_threshold"]

    unknown_families = results.get(
        "unknown_families",
        [],
    )

    lines = [
        "AEFL-OSIDS OPEN-SET EVALUATION SUMMARY",
        "=" * 72,
        "",
        f"Scenario              : {results['scenario']}",
        f"Test samples          : {results['test_samples']}",
        f"Locked threshold      : {threshold:.6f}",
        "",
        "UNKNOWN ATTACK DETECTION",
        "-" * 72,
        f"Unknown precision     : "
        f"{unknown['precision'] * 100:.2f}%",
        f"Unknown recall        : "
        f"{unknown['recall'] * 100:.2f}%",
        f"Unknown F1            : "
        f"{unknown['f1'] * 100:.2f}%",
        f"Known FPR             : "
        f"{unknown['known_fpr'] * 100:.2f}%",
        "",
        "OPEN-SET PERFORMANCE",
        "-" * 72,
        f"Open-set AUROC        : "
        f"{results['open_set_auroc'] * 100:.2f}%",
        "",
        "KNOWN-CLASS PERFORMANCE",
        "-" * 72,
        f"Accuracy              : "
        f"{known['accuracy'] * 100:.2f}%",
        f"Macro Precision       : "
        f"{known['macro_precision'] * 100:.2f}%",
        f"Macro Recall          : "
        f"{known['macro_recall'] * 100:.2f}%",
        f"Macro F1              : "
        f"{known['macro_f1'] * 100:.2f}%",
        "",
        "UNKNOWN FAMILIES",
        "-" * 72,
    ]

    if unknown_families:
        for family in unknown_families:
            lines.append(f"- {family}")
    else:
        lines.append("None specified.")

    lines.extend(
        [
            "",
            "CONFUSION-MATRIX COUNTS",
            "-" * 72,
            f"True Positive         : "
            f"{unknown['true_positive']}",
            f"True Negative         : "
            f"{unknown['true_negative']}",
            f"False Positive        : "
            f"{unknown['false_positive']}",
            f"False Negative        : "
            f"{unknown['false_negative']}",
            "",
            "SOURCE",
            "-" * 72,
            str(INPUT_FILE),
            "",
            "No model training or inference was performed.",
            "All reported values were read from the completed "
            "final open-set evaluation.",
        ]
    )

    path = (
        OUTPUT_DIR
        / "open_set_detection_summary.txt"
    )

    path.write_text(
        "\n".join(lines),
        encoding="utf-8",
    )

    return path


# ----------------------------------------------------------------------
# MAIN
# ----------------------------------------------------------------------

def main():
    print("=" * 70)
    print("AEFL-OSIDS PUBLICATION OPEN-SET RESULTS")
    print("=" * 70)
    print()

    print(f"Input : {INPUT_FILE}")
    print(f"Output: {OUTPUT_DIR}")
    print()

    # Load actual final results.
    results = load_results()

    print("[1/3] Loading final open-set results...")
    print("      Final results loaded successfully.")

    print()
    print("[2/3] Creating publication outputs...")

    df = create_publication_dataframe(
        results
    )

    csv_path = save_csv(df)

    plot_path = generate_plot(
        df,
        results["locked_threshold"],
    )

    summary_path = save_summary(
        results
    )

    print(f"      Saved: {csv_path}")
    print(f"      Saved: {plot_path}")
    print(f"      Saved: {summary_path}")

    print()
    print("Key open-set results:")
    print(
        f"  Locked threshold : "
        f"{results['locked_threshold']:.6f}"
    )
    print(
        f"  Unknown Precision : "
        f"{results['unknown_detection']['precision'] * 100:.2f}%"
    )
    print(
        f"  Unknown Recall    : "
        f"{results['unknown_detection']['recall'] * 100:.2f}%"
    )
    print(
        f"  Unknown F1        : "
        f"{results['unknown_detection']['f1'] * 100:.2f}%"
    )
    print(
        f"  Known FPR         : "
        f"{results['unknown_detection']['known_fpr'] * 100:.2f}%"
    )
    print(
        f"  Open-set AUROC    : "
        f"{results['open_set_auroc'] * 100:.2f}%"
    )

    print()
    print("[3/3] Verification...")
    print("      Publication data generated from actual results.")

    print()
    print("=" * 70)
    print("OPEN-SET RESULTS GENERATED SUCCESSFULLY")
    print("=" * 70)


if __name__ == "__main__":
    main()