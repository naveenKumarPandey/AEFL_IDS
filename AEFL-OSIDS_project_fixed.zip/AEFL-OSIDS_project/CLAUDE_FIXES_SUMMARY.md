# Fixes applied (why your results were weak/inconsistent)

This pass did not touch data, features, or the overall project structure. It
fixed five concrete, verifiable problems that were capping every method's
accuracy and specifically undermining the proposed method's contribution.

## 1. Every method was drastically under-trained

- `training/centralized_trainer.py` read its total epoch count from
  `config["training"]["local_epochs"]` -- a key meant for federated
  per-round local epochs, not total training length. On the full dataset,
  the centralized baseline was training for only **3 epochs**.
- `federated/fedavg.py` hardcoded `FL_ROUNDS = 5` and `LOCAL_EPOCHS = 1`
  as module constants (5 epoch-equivalents total).
- `configs/config.yaml`'s `proposed_training` was `rounds: 5, local_epochs: 1`
  (5 epoch-equivalents total).

None of these come close to converging on CICIoT2023 Scenario C with 5
imbalanced classes. Fix: added a dedicated `training.epochs` key (40),
raised `federated_training.rounds` to 30 and `proposed_training.rounds` to
30 with `local_epochs: 3`, and added real early stopping (on validation
Macro-F1, best checkpoint always kept) to all three trainers so they don't
under- or over-train.

## 2. `federated/fedavg.py` never read `configs/config.yaml` at all

It imported `load_config` but never called it. Every hyperparameter was a
hardcoded module constant. Editing the config file had **zero effect** on
your FedAvg baseline, which is a very plausible source of "inconsistent"
results (you change a setting, rerun, nothing changes). Fixed: it now reads
rounds/local_epochs/batch_size/learning_rate/weight_decay/seed/early-stopping
patience from config, matching how `robust_adaptive_fedprox.py` already
worked.

## 3. BatchNorm averaged across non-IID federated clients

`models/intrusion_model.py` used `BatchNorm1d`, whose running mean/variance
get averaged across the 5 Dirichlet(alpha=0.5)-partitioned clients during
aggregation. Each client's local batch statistics reflect a very different
class mix under that partition, so averaging them is a well-documented cause
of unstable/degraded federated accuracy (this is why "FedBN"-style fixes
exist in the literature). This is a plausible reason the proposed method
only barely beat FedAvg (68.69% vs 67.04% macro-F1 -- within noise).
Fixed: replaced `BatchNorm1d` with `GroupNorm`, which has no running
statistics to aggregate (its only trainable parameters are affine
weight/bias, aggregated the same way as every other layer). This also
removes an unrelated footgun: BatchNorm1d in train mode requires batch
size > 1, which is awkward for live single-flow inference.

## 4. The proposed method's own headline components were switched off

- `class_aware_mix: 0.00` fully disabled the per-class classifier-row
  aggregation that the README lists as one of the method's defining
  components -- it contributed nothing to the reported numbers.
  Set to `0.15`.
- `fedprox_mu: 0.0` disabled FedProx regularization entirely, in a method
  literally named "Robust Class-Balanced **FedProx**." Set to `0.01`
  (a standard starting point for Dirichlet alpha=0.5 non-IID splits).

## 5. Duplicated model architecture (drift risk)

`live_detection/ml_detector.py` hardcoded its own copy of the network
architecture (with `dropout=0.2`, vs. `0.30` in the real model) instead of
importing `models/intrusion_model.py`. This was harmless by coincidence
(dropout is disabled in eval mode) but would have silently broken once the
GroupNorm fix landed, since the duplicated class still used `BatchNorm1d`.
Fixed: renamed it to `LegacyAdaptiveFedAvgV2Model` and kept it ONLY as a
fallback for loading old BatchNorm checkpoints; the proposed checkpoint is
now loaded through the same canonical `models.intrusion_model.create_model`
used for training, so the two can't drift apart again.

## What you need to do next

The GroupNorm change makes existing `.pt` checkpoints for the proposed
model **incompatible by design** (that incompatibility is the fix -- old
checkpoints were trained with the bug). You'll need to retrain:

```powershell
python main.py train-proposed
python main.py evaluate
python main.py explain
python main.py dashboard
```

or simply:

```powershell
python main.py experiment
```

Expect this run to take noticeably longer than before (30 rounds x 3 local
epochs instead of 5 rounds x 1, for both FedAvg and the proposed method; 40
epochs instead of 3 for centralized) -- that's the point. Early stopping
will cut it short automatically once validation Macro-F1 stops improving.

Nothing in `data/`, `preprocessing/`, `federated/client_partition.py`, the
dashboard UI, or the SHAP/open-set evaluation logic was touched, so your
existing processed data and client partitions remain valid.
