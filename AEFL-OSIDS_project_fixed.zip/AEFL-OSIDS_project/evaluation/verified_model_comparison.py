"""Recompute every model on the same validation and independent test data."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Dict, List, Tuple

import numpy as np
import pandas as pd
import torch
import torch.nn.functional as F
from sklearn.metrics import (
    accuracy_score,
    confusion_matrix,
    f1_score,
    precision_recall_fscore_support,
    precision_score,
    recall_score,
)

from data_loader.cic_iot_dataset import create_dataset
from models.intrusion_model import create_model
from utils.config import load_config


PROJECT_ROOT = Path(__file__).resolve().parents[1]
RESULTS_DIR = PROJECT_ROOT / "results" / "verified_comparison"
CLASS_NAMES = ["BENIGN", "DDoS", "DoS", "Mirai", "Recon"]
MODELS = [
    ("Centralized Baseline", PROJECT_ROOT / "data" / "models" / "centralized_baseline.pt"),
    ("FedAvg", PROJECT_ROOT / "data" / "models" / "fedavg_global.pt"),
    ("Adaptive FedAvg v2 (legacy)", PROJECT_ROOT / "data" / "models" / "adaptive_fedavg_v2_global.pt"),
    (
        "Robust Class-Balanced FedProx (proposed)",
        PROJECT_ROOT / "data" / "models" / "robust_adaptive_fedprox_global.pt",
    ),
]


def load_split(scenario: str, split: str) -> Tuple[np.ndarray, np.ndarray]:
    dataset = create_dataset(scenario, split)
    features: List[np.ndarray] = []
    labels: List[np.ndarray] = []
    for path in dataset.files:
        with np.load(path, allow_pickle=False) as data:
            X = np.asarray(data["X"], dtype=np.float32)
            y = np.asarray(data["y"], dtype=np.int64)
            known = (y >= 0) & (y < len(CLASS_NAMES))
            features.append(X[known])
            labels.append(y[known])
    return np.concatenate(features), np.concatenate(labels)


def evaluate(model: torch.nn.Module, X: np.ndarray, y: np.ndarray) -> Dict[str, object]:
    model.eval()
    predictions = []
    loss = 0.0
    with torch.no_grad():
        for start in range(0, len(y), 4096):
            features = torch.from_numpy(X[start : start + 4096])
            targets = torch.from_numpy(y[start : start + 4096])
            logits = model(features)
            loss += float(F.cross_entropy(logits, targets, reduction="sum").item())
            predictions.extend(logits.argmax(dim=1).numpy().tolist())
    predicted = np.asarray(predictions, dtype=np.int64)
    class_ids = list(range(len(CLASS_NAMES)))
    per_precision, per_recall, per_class, support = precision_recall_fscore_support(
        y, predicted, labels=class_ids, zero_division=0
    )
    return {
        "samples": int(len(y)),
        "loss": loss / len(y),
        "accuracy": float(accuracy_score(y, predicted)),
        "macro_precision": float(
            precision_score(y, predicted, labels=class_ids, average="macro", zero_division=0)
        ),
        "macro_recall": float(
            recall_score(y, predicted, labels=class_ids, average="macro", zero_division=0)
        ),
        "macro_f1": float(
            f1_score(y, predicted, labels=class_ids, average="macro", zero_division=0)
        ),
        "weighted_f1": float(
            f1_score(y, predicted, labels=class_ids, average="weighted", zero_division=0)
        ),
        "per_class_f1": {
            name: float(value) for name, value in zip(CLASS_NAMES, per_class)
        },
        "per_class": [
            {
                "Class": name,
                "Precision": float(class_precision),
                "Recall": float(class_recall),
                "F1": float(class_f1),
                "Support": int(class_support),
            }
            for name, class_precision, class_recall, class_f1, class_support in zip(
                CLASS_NAMES, per_precision, per_recall, per_class, support
            )
        ],
        "confusion_matrix": confusion_matrix(
            y, predicted, labels=class_ids
        ).astype(int).tolist(),
    }


def main() -> None:
    config = load_config()
    scenario = config["openset"]["primary_scenario"]
    arrays = {
        "validation": load_split(scenario, "validation"),
        "independent_test_known": load_split(scenario, "test"),
    }
    all_results = []
    rows = []
    for method, path in MODELS:
        if not path.exists():
            continue
        checkpoint = torch.load(path, map_location="cpu")
        state = checkpoint.get("model_state_dict", checkpoint)
        model = create_model(input_features=39, num_classes=len(CLASS_NAMES))
        model.load_state_dict(state, strict=True)
        for split, (X, y) in arrays.items():
            metrics = evaluate(model, X, y)
            all_results.append(
                {
                    "method": method,
                    "checkpoint": str(path.relative_to(PROJECT_ROOT)),
                    "evaluation_split": split,
                    "metrics": metrics,
                }
            )
            rows.append(
                {
                    "Method": method,
                    "Evaluation Split": split,
                    "Samples": metrics["samples"],
                    "Accuracy": metrics["accuracy"],
                    "Macro Precision": metrics["macro_precision"],
                    "Macro Recall": metrics["macro_recall"],
                    "Macro F1": metrics["macro_f1"],
                    "Weighted F1": metrics["weighted_f1"],
                    **{
                        f"{name} F1": value
                        for name, value in metrics["per_class_f1"].items()
                    },
                }
            )

    RESULTS_DIR.mkdir(parents=True, exist_ok=True)
    frame = pd.DataFrame(rows)
    frame.to_csv(RESULTS_DIR / "all_splits_comparison.csv", index=False)
    test_frame = frame[frame["Evaluation Split"] == "independent_test_known"].copy()
    test_frame.to_csv(RESULTS_DIR / "publication_test_comparison.csv", index=False)
    proposed_result = next(
        (
            item
            for item in all_results
            if "proposed" in item["method"].lower()
            and item["evaluation_split"] == "independent_test_known"
        ),
        None,
    )
    if proposed_result is not None:
        pd.DataFrame(proposed_result["metrics"]["per_class"]).to_csv(
            RESULTS_DIR / "proposed_per_class_test.csv", index=False
        )
    integrity_path = PROJECT_ROOT / "results" / "data_integrity" / f"{scenario}_audit.json"
    integrity = json.loads(integrity_path.read_text(encoding="utf-8")) if integrity_path.exists() else None
    payload = {
        "scenario": scenario,
        "primary_evaluation_split": "independent_test_known",
        "results": all_results,
        "dataset_integrity": integrity,
        "warning": (
            "Current processed data failed the duplicate/source metadata audit. "
            "Treat these scores as preliminary until preprocessing is regenerated."
            if integrity and integrity.get("status") != "PASS"
            else None
        ),
    }
    (RESULTS_DIR / "verified_model_comparison.json").write_text(
        json.dumps(payload, indent=2), encoding="utf-8"
    )

    print("=" * 110)
    print("INDEPENDENT KNOWN-CLASS TEST COMPARISON")
    print("=" * 110)
    print(
        test_frame[
            ["Method", "Accuracy", "Macro Precision", "Macro Recall", "Macro F1", "Weighted F1"]
        ].to_string(index=False)
    )
    if payload["warning"]:
        print(f"\nWARNING: {payload['warning']}")
    print(f"\nResults: {RESULTS_DIR}")


if __name__ == "__main__":
    main()
