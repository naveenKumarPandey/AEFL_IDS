"""
AEFL-OSIDS
Real-Time Machine Learning Detector

Pipeline:

    39 live features
          |
          v
    Existing Scenario-C scaler
          |
          v
    Robust Class-Balanced FedProx (preferred)
    or legacy Adaptive FedAvg v2 (fallback)
    39 -> 128 -> 64 -> 32 -> 5
          |
          v
    Class probabilities
          |
          v
    Hybrid confidence + anomaly score
          |
          v
    Known class / UNKNOWN

This module ONLY performs inference.

It does NOT:
- train the model
- modify model weights
- modify the scaler
- modify stored experiment results
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any, Dict, Mapping, Optional

import joblib
import numpy as np
import torch
import torch.nn as nn

from models.intrusion_model import create_model as create_intrusion_model


# =====================================================================
# PATHS
# =====================================================================

PROJECT_ROOT = Path(__file__).resolve().parents[1]

LEGACY_MODEL_PATH = (
    PROJECT_ROOT
    / "data"
    / "models"
    / "adaptive_fedavg_v2_global.pt"
)

PROPOSED_MODEL_PATH = (
    PROJECT_ROOT
    / "data"
    / "models"
    / "robust_adaptive_fedprox_global.pt"
)

MODEL_PATH = (
    PROPOSED_MODEL_PATH
    if PROPOSED_MODEL_PATH.exists()
    else LEGACY_MODEL_PATH
)

OPEN_SET_ARTIFACT_PATH = (
    PROJECT_ROOT
    / "data"
    / "models"
    / "hybrid_open_set_detector.joblib"
)

SCALER_PATH = (
    PROJECT_ROOT
    / "data"
    / "processed"
    / "scenario_C_multiple"
    / "scaler.joblib"
)


# =====================================================================
# MODEL CONFIGURATION
# =====================================================================

INPUT_FEATURES = 39

HIDDEN_1 = 128
HIDDEN_2 = 64
HIDDEN_3 = 32

NUM_CLASSES = 5

CLASS_NAMES = [
    "BENIGN",
    "DDoS",
    "DoS",
    "Mirai",
    "Recon",
]


# =====================================================================
# OPEN-SET CONFIGURATION
# =====================================================================

# This is the already calibrated and locked threshold used by the
# existing Scenario-C open-set evaluation.
#
# Do not change this value here.
LOCKED_OPEN_SET_THRESHOLD = 0.5699575841426849


# =====================================================================
# LOGGING
# =====================================================================

logger = logging.getLogger(
    __name__
)


# =====================================================================
# MODEL ARCHITECTURE
# =====================================================================

class LegacyAdaptiveFedAvgV2Model(
    nn.Module
):
    """
    Exact architecture required by the OLD Adaptive FedAvg v2 checkpoint
    only (BatchNorm1d, dropout=0.2). Kept solely so that legacy checkpoints
    trained before the GroupNorm fix in models/intrusion_model.py can still
    be loaded as a fallback. Do NOT use this for the proposed checkpoint --
    see _load_model, which instantiates the real, single-source-of-truth
    architecture from models.intrusion_model for anything that isn't the
    legacy checkpoint.

    Architecture:

        39
         |
        128
         |
         64
         |
         32
         |
          5
    """

    def __init__(
        self,
        input_features: int = INPUT_FEATURES,
        num_classes: int = NUM_CLASSES,
    ) -> None:

        super().__init__()

        self.feature_extractor = nn.Sequential(

            nn.Linear(
                input_features,
                HIDDEN_1,
            ),

            nn.BatchNorm1d(
                HIDDEN_1
            ),

            nn.ReLU(),

            nn.Dropout(
                p=0.2
            ),

            nn.Linear(
                HIDDEN_1,
                HIDDEN_2,
            ),

            nn.BatchNorm1d(
                HIDDEN_2
            ),

            nn.ReLU(),

            nn.Dropout(
                p=0.2
            ),

            nn.Linear(
                HIDDEN_2,
                HIDDEN_3,
            ),

            nn.ReLU(),
        )

        self.classifier = nn.Linear(
            HIDDEN_3,
            num_classes,
        )

    def forward(
        self,
        x: torch.Tensor,
    ) -> torch.Tensor:

        x = self.feature_extractor(
            x
        )

        return self.classifier(
            x
        )


# =====================================================================
# ML DETECTOR
# =====================================================================

class MLDetector:
    """
    Real-time robust federated inference engine with open-set rejection.

    Input:
        Raw 39-feature live flow vector.

    Output:
        MLDetectionResult
    """

    def __init__(
        self,
        model_path: Path = MODEL_PATH,
        scaler_path: Path = SCALER_PATH,
        threshold: Optional[float] = None,
        open_set_artifact_path: Path = OPEN_SET_ARTIFACT_PATH,
        device: Optional[str] = None,
    ) -> None:

        self.model_path = Path(
            model_path
        )

        self.scaler_path = Path(
            scaler_path
        )

        self.open_set_artifact_path = Path(
            open_set_artifact_path
        )

        self._threshold_overridden = threshold is not None

        self.threshold = float(
            threshold
            if threshold is not None
            else LOCKED_OPEN_SET_THRESHOLD
        )

        if device is None:

            self.device = torch.device(
                "cuda"
                if torch.cuda.is_available()
                else "cpu"
            )

        else:

            self.device = torch.device(
                device
            )

        self.scaler = None

        self.model = None

        self.open_set_artifact = None

        self._load_scaler()

        self._load_model()

        self._load_open_set_artifact()

        logger.info(
            "MLDetector initialized."
        )

    # =================================================================
    # SCALER
    # =================================================================

    def _load_scaler(
        self,
    ) -> None:

        if not self.scaler_path.exists():

            raise FileNotFoundError(
                "Live-detection scaler not found:\n"
                f"{self.scaler_path}"
            )

        logger.info(
            "Loading live-detection scaler: %s",
            self.scaler_path,
        )

        self.scaler = joblib.load(
            self.scaler_path
        )

        # -------------------------------------------------------------
        # Verify scaler feature count when the scaler exposes it.
        # -------------------------------------------------------------

        scaler_features = getattr(
            self.scaler,
            "n_features_in_",
            None,
        )

        if (
            scaler_features is not None
            and int(scaler_features)
            != INPUT_FEATURES
        ):

            raise RuntimeError(
                "Scaler feature count mismatch.\n"
                f"Expected: {INPUT_FEATURES}\n"
                f"Found: {scaler_features}"
            )

        logger.info(
            "Scaler loaded successfully."
        )

    # =================================================================
    # MODEL
    # =================================================================

    def _load_model(
        self,
    ) -> None:

        if not self.model_path.exists():

            raise FileNotFoundError(
                "Intrusion model not found:\n"
                f"{self.model_path}"
            )

        logger.info(
            "Loading intrusion model: %s",
            self.model_path,
        )

        checkpoint = torch.load(
            self.model_path,
            map_location=self.device,
        )

        # -------------------------------------------------------------
        # Construct exact architecture.
        #
        # The proposed checkpoint is trained with the canonical model in
        # models/intrusion_model.py (GroupNorm, not BatchNorm -- see that
        # file for why). Only the legacy checkpoint, which predates that
        # fix and was trained with BatchNorm, needs the frozen fallback
        # class above.
        # -------------------------------------------------------------

        if self.model_path == PROPOSED_MODEL_PATH:

            self.model = create_intrusion_model(
                num_classes=NUM_CLASSES,
                input_features=INPUT_FEATURES,
            )

        else:

            self.model = LegacyAdaptiveFedAvgV2Model(
                input_features=INPUT_FEATURES,
                num_classes=NUM_CLASSES,
            )

        # -------------------------------------------------------------
        # Existing checkpoint format.
        # -------------------------------------------------------------

        if isinstance(
            checkpoint,
            dict
        ) and (
            "model_state_dict"
            in checkpoint
        ):

            state_dict = checkpoint[
                "model_state_dict"
            ]

        else:

            # Allow a raw state_dict checkpoint.
            state_dict = checkpoint

        if not isinstance(
            state_dict,
            dict
        ):

            raise RuntimeError(
                "Unsupported model checkpoint format."
            )

        # -------------------------------------------------------------
        # Strict loading is intentional.
        #
        # If the architecture changes, fail rather than silently
        # producing potentially invalid predictions.
        # -------------------------------------------------------------

        self.model.load_state_dict(
            state_dict,
            strict=True,
        )

        self.model.to(
            self.device
        )

        self.model.eval()

        logger.info(
            "Intrusion model loaded successfully."
        )

    # =================================================================
    # HYBRID OPEN-SET ARTIFACT
    # =================================================================

    def _load_open_set_artifact(self) -> None:

        if not self.open_set_artifact_path.exists():
            logger.warning(
                "Hybrid open-set artifact is unavailable; using legacy MSP threshold."
            )
            return

        artifact = joblib.load(
            self.open_set_artifact_path
        )

        required = {
            "isolation_forest",
            "confidence_weight",
            "anomaly_weight",
            "threshold",
            "confidence_scale",
            "anomaly_scale",
        }

        if not isinstance(artifact, dict) or not required.issubset(artifact):
            logger.warning(
                "Hybrid open-set artifact has an unsupported format; using MSP threshold."
            )
            return

        artifact_model = Path(
            str(artifact.get("model_path", ""))
        ).name

        if artifact_model and artifact_model != self.model_path.name:
            logger.warning(
                "Hybrid artifact was calibrated for %s, not %s; using MSP threshold.",
                artifact_model,
                self.model_path.name,
            )
            return

        self.open_set_artifact = artifact

        if not self._threshold_overridden:
            self.threshold = float(
                artifact["threshold"]
            )

        logger.info(
            "Hybrid open-set detector loaded successfully."
        )

    # =================================================================
    # INPUT VALIDATION
    # =================================================================

    @staticmethod
    def _validate_features(
        features: Any,
    ) -> np.ndarray:

        array = np.asarray(
            features,
            dtype=np.float32,
        )

        # -------------------------------------------------------------
        # Accept:
        #
        # (39,)
        #
        # or:
        #
        # (1, 39)
        # -------------------------------------------------------------

        if array.ndim == 1:

            if array.shape[0] != INPUT_FEATURES:

                raise ValueError(
                    "Invalid feature vector size.\n"
                    f"Expected: {INPUT_FEATURES}\n"
                    f"Received: {array.shape[0]}"
                )

            array = array.reshape(
                1,
                INPUT_FEATURES,
            )

        elif array.ndim == 2:

            if array.shape[1] != INPUT_FEATURES:

                raise ValueError(
                    "Invalid feature matrix shape.\n"
                    f"Expected second dimension: "
                    f"{INPUT_FEATURES}\n"
                    f"Received: {array.shape}"
                )

        else:

            raise ValueError(
                "Features must be a 1-D or 2-D array."
            )

        if not np.all(
            np.isfinite(array)
        ):

            raise ValueError(
                "Feature vector contains "
                "NaN or infinite values."
            )

        return array

    # =================================================================
    # SCALING
    # =================================================================

    def _scale(
        self,
        features: np.ndarray,
    ) -> np.ndarray:

        if self.scaler is None:

            raise RuntimeError(
                "Scaler has not been loaded."
            )

        scaled = self.scaler.transform(
            features
        )

        scaled = np.asarray(
            scaled,
            dtype=np.float32,
        )

        if not np.all(
            np.isfinite(scaled)
        ):

            raise ValueError(
                "Scaled features contain "
                "NaN or infinite values."
            )

        return scaled

    # =================================================================
    # PREDICTION
    # =================================================================

    def predict(
        self,
        features: Any,
    ) -> Dict[str, Any]:
        """
        Run ML inference on one or more 39-feature vectors.

        Returns a dictionary containing:

            predicted_class
            predicted_index
            confidence
            max_probability
            is_unknown
            probabilities
        """

        raw = self._validate_features(
            features
        )

        scaled = self._scale(
            raw
        )

        tensor = torch.from_numpy(
            scaled
        ).to(
            self.device
        )

        with torch.no_grad():

            logits = self.model(
                tensor
            )

            probabilities = torch.softmax(
                logits,
                dim=1,
            )

        probabilities_np = (
            probabilities
            .cpu()
            .numpy()
        )

        results = []

        anomaly_scores = None

        hybrid_scores = None

        if self.open_set_artifact is not None:

            detector = self.open_set_artifact[
                "isolation_forest"
            ]

            anomaly_scores = -detector.score_samples(
                scaled
            )

            confidence_unknown = 1.0 - np.max(
                probabilities_np,
                axis=1,
            )

            confidence_scale = self.open_set_artifact[
                "confidence_scale"
            ]

            anomaly_scale = self.open_set_artifact[
                "anomaly_scale"
            ]

            scaled_confidence = (
                confidence_unknown
                - float(confidence_scale["median"])
            ) / max(float(confidence_scale["iqr"]), 1e-8)

            scaled_anomaly = (
                anomaly_scores
                - float(anomaly_scale["median"])
            ) / max(float(anomaly_scale["iqr"]), 1e-8)

            hybrid_scores = (
                float(self.open_set_artifact["confidence_weight"])
                * scaled_confidence
                + float(self.open_set_artifact["anomaly_weight"])
                * scaled_anomaly
            )

        for row_index, row in enumerate(probabilities_np):

            predicted_index = int(
                np.argmax(row)
            )

            confidence = float(
                row[predicted_index]
            )

            if hybrid_scores is not None:

                unknown_score = float(
                    hybrid_scores[row_index]
                )

                is_unknown = (
                    unknown_score
                    > self.threshold
                )

                open_set_method = (
                    "hybrid_msp_isolation_forest"
                )

            else:

                unknown_score = float(
                    1.0 - confidence
                )

                is_unknown = (
                    confidence
                    < self.threshold
                )

                open_set_method = (
                    "legacy_msp_threshold"
                )

            if is_unknown:

                predicted_class = (
                    "UNKNOWN"
                )

            else:

                predicted_class = (
                    CLASS_NAMES[
                        predicted_index
                    ]
                )

            probability_dict = {
                CLASS_NAMES[index]:
                    float(row[index])
                for index in range(
                    NUM_CLASSES
                )
            }

            results.append(
                {
                    "predicted_class":
                        predicted_class,

                    "predicted_index":
                        predicted_index,

                    "confidence":
                        confidence,

                    "max_probability":
                        confidence,

                    "is_unknown":
                        bool(is_unknown),

                    "threshold":
                        self.threshold,

                    "unknown_score":
                        unknown_score,

                    "anomaly_score":
                        (
                            float(anomaly_scores[row_index])
                            if anomaly_scores is not None
                            else None
                        ),

                    "open_set_method":
                        open_set_method,

                    "probabilities":
                        probability_dict,
                }
            )

        # -------------------------------------------------------------
        # Preserve convenient single-flow API.
        # -------------------------------------------------------------

        if len(results) == 1:

            return results[0]

        return {
            "batch_size":
                len(results),

            "results":
                results,
        }

    # =================================================================
    # SINGLE FLOW
    # =================================================================

    def predict_flow(
        self,
        flow: Mapping[str, Any],
    ) -> Dict[str, Any]:
        """
        Build 39 features from a flow and run ML inference.

        This method imports flow_feature_builder lazily so that the
        detector remains independently testable.
        """

        from live_detection.flow_feature_builder import (
            build_live_features,
        )

        features = build_live_features(
            flow
        )

        result = self.predict(
            features
        )

        return result

    # =================================================================
    # INFORMATION
    # =================================================================

    def get_model_info(
        self,
    ) -> Dict[str, Any]:

        return {
            "model":
                str(self.model_path),

            "scaler":
                str(self.scaler_path),

            "device":
                str(self.device),

            "input_features":
                INPUT_FEATURES,

            "hidden_layers":
                [
                    HIDDEN_1,
                    HIDDEN_2,
                    HIDDEN_3,
                ],

            "output_classes":
                NUM_CLASSES,

            "class_names":
                list(CLASS_NAMES),

            "open_set_threshold":
                self.threshold,

            "open_set_method":
                (
                    "hybrid_msp_isolation_forest"
                    if self.open_set_artifact is not None
                    else "legacy_msp_threshold"
                ),

            "open_set_artifact":
                (
                    str(self.open_set_artifact_path)
                    if self.open_set_artifact is not None
                    else None
                ),
        }


# =====================================================================
# CONVENIENCE API
# =====================================================================

_default_detector: Optional[
    MLDetector
] = None


def get_ml_detector() -> MLDetector:

    global _default_detector

    if _default_detector is None:

        _default_detector = MLDetector()

    return _default_detector


def predict_live_flow(
    flow: Mapping[str, Any],
) -> Dict[str, Any]:

    return get_ml_detector().predict_flow(
        flow
    )


# =====================================================================
# SELF TEST
# =====================================================================

def _create_test_features() -> np.ndarray:
    """
    Synthetic 39-feature vector matching the feature-builder test.
    """

    return np.asarray(
        [
            40.0,       # Header_Length
            6.0,        # Protocol Type
            64.0,       # Time_To_Live
            15.0,       # Rate
            0.0,        # fin_flag_number
            1.0,        # syn_flag_number
            0.0,        # rst_flag_number
            0.0,        # psh_flag_number
            1.0,        # ack_flag_number
            0.0,        # ece_flag_number
            0.0,        # cwr_flag_number
            2.0,        # ack_count
            1.0,        # syn_count
            0.0,        # fin_count
            0.0,        # rst_count
            1.0,        # HTTP
            0.0,        # HTTPS
            0.0,        # DNS
            0.0,        # Telnet
            0.0,        # SMTP
            0.0,        # SSH
            0.0,        # IRC
            1.0,        # TCP
            0.0,        # UDP
            0.0,        # DHCP
            0.0,        # ARP
            0.0,        # ICMP
            0.0,        # IGMP
            1.0,        # IPv
            0.0,        # LLC
            300.0,      # Tot sum
            54.0,       # Min
            68.0,       # Max
            60.0,       # AVG
            6.0,        # Std
            300.0,      # Tot size
            0.1,        # IAT
            3.0,        # Number
            36.0,       # Variance
        ],
        dtype=np.float32,
    )


def main() -> None:

    logging.basicConfig(
        level=logging.INFO,
        format=(
            "%(asctime)s - "
            "%(levelname)s - "
            "%(message)s"
        ),
    )

    print("=" * 70)
    print(
        "AEFL-OSIDS LIVE ML DETECTOR TEST"
    )
    print("=" * 70)

    print()
    print(
        "Loading existing model and scaler..."
    )

    detector = MLDetector()

    print()
    print(
        "Model configuration:"
    )

    info = detector.get_model_info()

    print(
        f"  Input features : "
        f"{info['input_features']}"
    )

    print(
        f"  Hidden layers  : "
        f"{info['hidden_layers']}"
    )

    print(
        f"  Output classes : "
        f"{info['output_classes']}"
    )

    print(
        f"  Device         : "
        f"{info['device']}"
    )

    print(
        f"  Open-set threshold : "
        f"{info['open_set_threshold']:.6f}"
    )

    print()
    print(
        "Running synthetic-flow inference..."
    )

    features = _create_test_features()

    result = detector.predict(
        features
    )

    print()
    print(
        "ML RESULT"
    )
    print("-" * 70)

    print(
        f"Predicted class : "
        f"{result['predicted_class']}"
    )

    print(
        f"Predicted index : "
        f"{result['predicted_index']}"
    )

    print(
        f"Confidence      : "
        f"{result['confidence']:.6f}"
    )

    print(
        f"Threshold       : "
        f"{result['threshold']:.6f}"
    )

    print(
        f"Unknown         : "
        f"{result['is_unknown']}"
    )

    print()
    print(
        "Class probabilities:"
    )

    for name, probability in (
        result["probabilities"].items()
    ):

        print(
            f"  {name:<10} "
            f"{probability:.6f}"
        )

    print()
    print("=" * 70)
    print(
        "LIVE ML DETECTOR TEST SUCCESSFUL"
    )
    print("=" * 70)


if __name__ == "__main__":
    main()
