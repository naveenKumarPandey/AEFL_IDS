from __future__ import annotations

import unittest

import numpy as np
import torch
import torch.nn.functional as F

from evaluation.dataset_integrity_audit import _feature_hashes
from evaluation.hybrid_open_set_evaluation import _unknown_metrics
from federated.robust_adaptive_fedprox import (
    ClassBalancedFocalLoss,
    _cap_normalized_weights,
    aggregate_client_updates,
    calculate_server_weights,
    class_balanced_weights,
    client_class_balanced_weights,
)


class RobustTrainingTests(unittest.TestCase):
    def test_class_balancing_favors_rare_classes(self) -> None:
        weights = class_balanced_weights([100, 10_000, 2_000, 5_000, 50])
        self.assertTrue(np.isfinite(weights).all())
        self.assertAlmostEqual(float(weights.mean()), 1.0, places=6)
        self.assertGreater(float(weights[4]), float(weights[1]))

    def test_focal_loss_is_finite_and_differentiable(self) -> None:
        logits = torch.tensor(
            [[3.0, 0.1, -0.2], [0.2, 0.3, 1.4]], requires_grad=True
        )
        criterion = ClassBalancedFocalLoss(torch.ones(3), gamma=1.5)
        loss = criterion(logits, torch.tensor([0, 2]))
        loss.backward()
        self.assertTrue(torch.isfinite(loss))
        self.assertIsNotNone(logits.grad)

    def test_gamma_zero_matches_weighted_cross_entropy(self) -> None:
        logits = torch.tensor(
            [[2.0, 0.2, -0.3], [0.1, 1.7, 0.4], [0.3, 0.5, 1.4]],
            requires_grad=True,
        )
        targets = torch.tensor([0, 1, 2])
        weights = torch.tensor([0.2, 1.0, 3.0])
        actual = ClassBalancedFocalLoss(weights, gamma=0.0)(logits, targets)
        expected = F.cross_entropy(logits, targets, weight=weights)
        self.assertTrue(torch.allclose(actual, expected, atol=1e-7))

    def test_client_weights_equalize_present_class_contributions(self) -> None:
        counts = np.asarray([10, 100, 1_000, 5_000, 50])
        weights = client_class_balanced_weights(counts, power=1.0)
        contributions = counts * weights
        self.assertTrue(np.allclose(contributions, contributions[0], rtol=1e-6))

    def test_server_weights_remain_fedavg_anchored(self) -> None:
        samples = np.asarray([100, 250, 600, 200, 150])
        counts = np.tile(np.asarray([1, 2, 3, 4, 5]), (5, 1))
        reliability = np.asarray([0.4, 0.8, 0.7, 0.5, 0.75])
        actual, _ = calculate_server_weights(
            samples,
            counts,
            reliability,
            maximum_weight=0.50,
            sample_weight_power=1.0,
            reliability_mix=0.10,
        )
        fedavg = samples / samples.sum()
        self.assertAlmostEqual(float(actual.sum()), 1.0, places=10)
        self.assertLess(float(np.max(np.abs(actual - fedavg))), 0.01)

    def test_weight_cap_is_normalized(self) -> None:
        weights = _cap_normalized_weights([100, 5, 4, 3, 2], maximum=0.35)
        self.assertAlmostEqual(float(weights.sum()), 1.0, places=10)
        self.assertLessEqual(float(weights.max()), 0.35 + 1e-10)

    def test_infeasible_weight_cap_is_rejected(self) -> None:
        with self.assertRaises(ValueError):
            _cap_normalized_weights([1, 1, 1], maximum=0.2)

    def test_classifier_rows_use_class_support(self) -> None:
        global_state = {
            "feature.weight": torch.zeros((1, 1)),
            "classifier.weight": torch.zeros((5, 1)),
            "classifier.bias": torch.zeros(5),
        }
        first = {name: value.clone() for name, value in global_state.items()}
        second = {name: value.clone() for name, value in global_state.items()}
        first["classifier.weight"] += 1.0
        second["classifier.weight"] += 3.0
        first["classifier.bias"] += 1.0
        second["classifier.bias"] += 3.0
        first["feature.weight"] += 2.0
        second["feature.weight"] += 4.0
        class_counts = np.asarray(
            [[100, 1, 100, 1, 100], [1, 100, 1, 100, 1]], dtype=float
        )
        aggregated, _ = aggregate_client_updates(
            global_state,
            [first, second],
            shared_weights=[0.5, 0.5],
            class_counts=class_counts,
            reliability=[1.0, 1.0],
            clip_factor=100.0,
        )
        self.assertLess(
            float(aggregated["classifier.weight"][0]),
            float(aggregated["classifier.weight"][1]),
        )

    def test_zero_class_mix_keeps_shared_classifier_weights(self) -> None:
        global_state = {
            "classifier.weight": torch.zeros((5, 1)),
            "classifier.bias": torch.zeros(5),
        }
        first = {name: value.clone() + 1.0 for name, value in global_state.items()}
        second = {name: value.clone() + 3.0 for name, value in global_state.items()}
        counts = np.asarray(
            [[100, 1, 100, 1, 100], [1, 100, 1, 100, 1]], dtype=float
        )
        aggregated, _ = aggregate_client_updates(
            global_state,
            [first, second],
            shared_weights=[0.75, 0.25],
            class_counts=counts,
            reliability=[1.0, 1.0],
            clip_factor=100.0,
            class_aware_mix=0.0,
        )
        self.assertTrue(
            torch.allclose(aggregated["classifier.weight"], torch.full((5, 1), 1.5))
        )


class EvaluationTests(unittest.TestCase):
    def test_unknown_metrics_confusion_counts(self) -> None:
        truth = np.asarray([True, True, False, False])
        prediction = np.asarray([True, False, True, False])
        metrics = _unknown_metrics(truth, prediction)
        self.assertEqual(metrics["true_positive"], 1)
        self.assertEqual(metrics["false_positive"], 1)
        self.assertAlmostEqual(float(metrics["f1"]), 0.5)
        self.assertAlmostEqual(float(metrics["known_fpr"]), 0.5)

    def test_feature_hashes_detect_exact_duplicates(self) -> None:
        rows = np.asarray([[1.0, 2.0], [1.0, 2.0], [2.0, 1.0]], dtype=np.float32)
        hashes = _feature_hashes(rows)
        self.assertEqual(int(hashes[0]), int(hashes[1]))
        self.assertNotEqual(int(hashes[0]), int(hashes[2]))


if __name__ == "__main__":
    unittest.main()
