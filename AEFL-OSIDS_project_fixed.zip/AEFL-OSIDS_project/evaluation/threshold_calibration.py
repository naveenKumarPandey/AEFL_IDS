from pathlib import Path
import json

import numpy as np
import torch
from torch.utils.data import DataLoader

from models.intrusion_model import create_model
from data_loader.cic_iot_dataset import create_dataset


# ============================================================
# AEFL-OSIDS
# VALIDATION-BASED OPEN-SET THRESHOLD CALIBRATION
# ============================================================

PROJECT_ROOT = Path(__file__).resolve().parents[1]

SCENARIO_NAME = "scenario_C_multiple"

MODEL_PATH = (
    PROJECT_ROOT
    / "data"
    / "models"
    / "adaptive_fedavg_v2_global.pt"
)

OUTPUT_DIR = (
    PROJECT_ROOT
    / "results"
    / "threshold_calibration"
)

INPUT_FEATURES = 39
NUM_CLASSES = 5

BATCH_SIZE = 512


# ============================================================
# DEVICE
# ============================================================

def get_device():

    if torch.cuda.is_available():

        return torch.device("cuda")

    return torch.device("cpu")


# ============================================================
# LOAD MODEL
# ============================================================

def load_model(device):

    if not MODEL_PATH.exists():

        raise FileNotFoundError(
            f"Model not found:\n{MODEL_PATH}"
        )

    checkpoint = torch.load(
        MODEL_PATH,
        map_location=device,
        weights_only=False,
    )

    model = create_model(
        input_features=INPUT_FEATURES,
        num_classes=NUM_CLASSES,
    )

    if (
        isinstance(checkpoint, dict)
        and "model_state_dict" in checkpoint
    ):

        state_dict = checkpoint[
            "model_state_dict"
        ]

    else:

        state_dict = checkpoint

    model.load_state_dict(
        state_dict
    )

    model.to(device)

    model.eval()

    return model


# ============================================================
# COLLECT VALIDATION CONFIDENCE
# ============================================================

def collect_confidence(
    model,
    dataset,
    device,
):

    loader = DataLoader(
        dataset,
        batch_size=BATCH_SIZE,
        shuffle=False,
        num_workers=0,
    )

    confidence_values = []

    with torch.no_grad():

        for X, _ in loader:

            X = X.to(device)

            logits = model(X)

            probabilities = torch.softmax(
                logits,
                dim=1,
            )

            confidence, _ = torch.max(
                probabilities,
                dim=1,
            )

            confidence_values.extend(
                confidence.cpu()
                .numpy()
                .tolist()
            )

    return np.asarray(
        confidence_values,
        dtype=np.float64,
    )


# ============================================================
# FALSE POSITIVE THRESHOLD
# ============================================================

def threshold_for_fpr(
    confidence,
    target_fpr,
):

    # A sample is rejected as UNKNOWN when:
    #
    # confidence < threshold
    #
    # Therefore, to keep only target_fpr
    # of known samples below threshold,
    # use the corresponding percentile.

    percentile = (
        target_fpr * 100.0
    )

    threshold = np.percentile(
        confidence,
        percentile,
    )

    actual_fpr = np.mean(
        confidence < threshold
    )

    return (
        float(threshold),
        float(actual_fpr),
    )


# ============================================================
# THRESHOLD TABLE
# ============================================================

def build_threshold_table(
    confidence,
):

    targets = [
        0.01,
        0.02,
        0.03,
        0.05,
        0.10,
    ]

    results = []

    for target in targets:

        (
            threshold,
            actual_fpr,
        ) = threshold_for_fpr(
            confidence,
            target,
        )

        accepted_rate = (
            1.0 - actual_fpr
        )

        results.append({

            "target_fpr":
                float(target),

            "threshold":
                float(threshold),

            "actual_validation_fpr":
                float(actual_fpr),

            "known_acceptance_rate":
                float(accepted_rate),
        })

    return results


# ============================================================
# MAIN
# ============================================================

def main():

    print(
        "=" * 70
    )

    print(
        "AEFL-OSIDS VALIDATION-BASED "
        "OPEN-SET THRESHOLD CALIBRATION"
    )

    print(
        "=" * 70
    )

    device = get_device()

    print()

    print(
        f"Device  : {device}"
    )

    print(
        f"Scenario: {SCENARIO_NAME}"
    )

    print()

    # --------------------------------------------------------
    # LOAD MODEL
    # --------------------------------------------------------

    print(
        "Loading trained adaptive model..."
    )

    model = load_model(
        device
    )

    print(
        "Model loaded successfully."
    )

    # --------------------------------------------------------
    # LOAD VALIDATION
    # --------------------------------------------------------

    print()

    print(
        "Loading validation dataset..."
    )

    validation_dataset = create_dataset(
        SCENARIO_NAME,
        "validation",
    )

    print(
        f"Validation samples: "
        f"{len(validation_dataset):,}"
    )

    # --------------------------------------------------------
    # CONFIDENCE
    # --------------------------------------------------------

    print()

    print(
        "Collecting validation confidence..."
    )

    confidence = collect_confidence(
        model,
        validation_dataset,
        device,
    )

    print(
        "Confidence collection complete."
    )

    # --------------------------------------------------------
    # BASIC STATISTICS
    # --------------------------------------------------------

    print()

    print(
        "=" * 70
    )

    print(
        "VALIDATION CONFIDENCE DISTRIBUTION"
    )

    print(
        "=" * 70
    )

    print()

    print(
        f"Mean       : "
        f"{np.mean(confidence):.6f}"
    )

    print(
        f"Median     : "
        f"{np.median(confidence):.6f}"
    )

    print(
        f"Minimum    : "
        f"{np.min(confidence):.6f}"
    )

    print(
        f"Maximum    : "
        f"{np.max(confidence):.6f}"
    )

    print(
        f"Std        : "
        f"{np.std(confidence):.6f}"
    )

    # --------------------------------------------------------
    # THRESHOLD TABLE
    # --------------------------------------------------------

    results = build_threshold_table(
        confidence
    )

    print()

    print(
        "=" * 70
    )

    print(
        "CALIBRATED THRESHOLDS"
    )

    print(
        "=" * 70
    )

    print()

    print(
        f"{'Target FPR':<15}"
        f"{'Threshold':<15}"
        f"{'Actual FPR':<15}"
        f"{'Known Accept':<15}"
    )

    print(
        "-" * 60
    )

    for item in results:

        print(
            f"{item['target_fpr']:<15.2%}"
            f"{item['threshold']:<15.6f}"
            f"{item['actual_validation_fpr']:<15.4%}"
            f"{item['known_acceptance_rate']:<15.4%}"
        )

    # --------------------------------------------------------
    # SELECT PRIMARY OPERATING POINT
    # --------------------------------------------------------

    # Primary deployment target:
    # maximum 5% validation FPR.

    selected = None

    for item in results:

        if (
            abs(
                item["target_fpr"]
                - 0.05
            )
            < 1e-12
        ):

            selected = item
            break

    if selected is None:

        raise RuntimeError(
            "5% FPR operating point "
            "was not generated."
        )

    print()

    print(
        "=" * 70
    )

    print(
        "SELECTED OPERATING POINT"
    )

    print(
        "=" * 70
    )

    print()

    print(
        "Target validation FPR : 5%"
    )

    print(
        f"Selected threshold    : "
        f"{selected['threshold']:.6f}"
    )

    print(
        f"Actual validation FPR : "
        f"{selected['actual_validation_fpr']:.6f}"
    )

    print(
        f"Known acceptance rate : "
        f"{selected['known_acceptance_rate']:.6f}"
    )

    # --------------------------------------------------------
    # SAVE
    # --------------------------------------------------------

    output = {

        "scenario":
            SCENARIO_NAME,

        "model":
            str(MODEL_PATH),

        "validation_samples":
            int(len(confidence)),

        "confidence_statistics": {

            "mean":
                float(np.mean(confidence)),

            "median":
                float(np.median(confidence)),

            "minimum":
                float(np.min(confidence)),

            "maximum":
                float(np.max(confidence)),

            "std":
                float(np.std(confidence)),
        },

        "thresholds":
            results,

        "selected_operating_point":
            selected,

        "selection_policy":
            "5% maximum validation false-positive rate",

        "test_data_used_for_selection":
            False,
    }

    OUTPUT_DIR.mkdir(
        parents=True,
        exist_ok=True,
    )

    output_path = (
        OUTPUT_DIR
        / "threshold_calibration.json"
    )

    with open(
        output_path,
        "w",
        encoding="utf-8",
    ) as file:

        json.dump(
            output,
            file,
            indent=4,
        )

    # --------------------------------------------------------
    # FINAL
    # --------------------------------------------------------

    print()

    print(
        "Calibration result saved:"
    )

    print(
        output_path
    )

    print()

    print(
        "=" * 70
    )

    print(
        "THRESHOLD CALIBRATION COMPLETE"
    )

    print(
        "=" * 70
    )


if __name__ == "__main__":

    main()