from typing import Dict, List, Set


# ============================================================
# ATTACK FAMILIES
# ============================================================

ATTACK_FAMILIES: List[str] = [
    "BENIGN",
    "DDoS",
    "DoS",
    "Mirai",
    "Recon",
    "Spoofing",
    "Web-based",
    "BruteForce",
]


# ============================================================
# OPEN-SET SCENARIOS
# ============================================================

OPEN_SET_SCENARIOS: Dict[str, Set[str]] = {

    "scenario_A_bruteforce": {
        "BruteForce",
    },

    "scenario_C_multiple": {
        "BruteForce",
        "Spoofing",
        "Web-based",
    },
}


# ============================================================
# LABEL MAPPINGS
# ============================================================

def build_label_mapping(
    unknown_families: Set[str],
) -> Dict[str, int]:
    """
    Build deterministic label mapping for known classes.

    Unknown families are deliberately excluded from the
    supervised classification label space.
    """

    known_families = [
        family
        for family in ATTACK_FAMILIES
        if family not in unknown_families
    ]

    return {
        family: index
        for index, family in enumerate(
            known_families
        )
    }


def get_unknown_label() -> int:
    """
    Special label used internally for unknown traffic.
    """

    return -1


# ============================================================
# TEST
# ============================================================

if __name__ == "__main__":

    print("=" * 60)
    print("AEFL-OSIDS LABEL CONFIGURATION")
    print("=" * 60)

    for scenario, unknown in OPEN_SET_SCENARIOS.items():

        mapping = build_label_mapping(
            unknown
        )

        print(f"\n{scenario}")

        print(
            f"Unknown families: "
            f"{sorted(unknown)}"
        )

        print("Known label mapping:")

        for family, label in mapping.items():
            print(
                f"  {label} -> {family}"
            )

        print(
            f"  {get_unknown_label()} -> UNKNOWN"
        )