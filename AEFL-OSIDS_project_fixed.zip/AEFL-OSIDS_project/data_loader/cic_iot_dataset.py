from pathlib import Path
from typing import Iterator, List, Tuple, Optional

import numpy as np
import torch
from torch.utils.data import Dataset, DataLoader, Sampler


# ============================================================
# PROJECT ROOT
# ============================================================

PROJECT_ROOT = (
    Path(__file__).resolve().parents[1]
)


# ============================================================
# DATASET
# ============================================================

class CICIoTDataset(Dataset):
    """
    Efficient lazy-loading dataset for processed
    CICIoT2023 .npz files.

    Each NPZ file contains:

        X              -> shape (N, 39)
        y              -> shape (N,)
        attack_family  -> shape (N,)
        attack_label   -> shape (N,)
        source_file    -> shape (N,)

    IMPORTANT:
        __getitem__() intentionally continues returning
        only (X, y), preserving compatibility with the
        existing training and evaluation code.

    Metadata can be accessed through:

        get_attack_families()
        get_attack_labels()
        get_source_files()

    The complete feature dataset is NOT loaded into RAM.
    Individual NPZ files are cached while samples are accessed.
    """

    def __init__(
        self,
        split_dir: Path,
    ):
        super().__init__()

        self.split_dir = Path(
            split_dir
        )

        if not self.split_dir.exists():
            raise FileNotFoundError(
                f"Dataset directory not found:\n"
                f"{self.split_dir}"
            )

        # ----------------------------------------------------
        # Find processed NPZ files
        # ----------------------------------------------------

        self.files = sorted(
            self.split_dir.rglob(
                "*.npz"
            )
        )

        if not self.files:
            raise FileNotFoundError(
                f"No .npz files found in:\n"
                f"{self.split_dir}"
            )

        # ----------------------------------------------------
        # File metadata
        # ----------------------------------------------------

        self.file_sizes: List[int] = []

        self.cumulative_sizes = []

        total = 0

        for file_path in self.files:

            with np.load(
                file_path,
                allow_pickle=True,
            ) as data:

                # --------------------------------------------
                # Required feature and target arrays
                # --------------------------------------------

                if "X" not in data.files:
                    raise ValueError(
                        f"Missing X array:\n"
                        f"{file_path}"
                    )

                if "y" not in data.files:
                    raise ValueError(
                        f"Missing y array:\n"
                        f"{file_path}"
                    )

                X = data["X"]
                y = data["y"]

                if X.ndim != 2:
                    raise ValueError(
                        f"Invalid X dimensions:\n"
                        f"{file_path}"
                    )

                if X.shape[1] != 39:
                    raise ValueError(
                        f"Expected 39 features but "
                        f"found {X.shape[1]}:\n"
                        f"{file_path}"
                    )

                if len(X) != len(y):
                    raise ValueError(
                        f"X/y length mismatch:\n"
                        f"{file_path}"
                    )

                # --------------------------------------------
                # Metadata validation
                # --------------------------------------------

                metadata_fields = [
                    "attack_family",
                    "attack_label",
                    "source_file",
                ]

                for field in metadata_fields:

                    if field in data.files:

                        if len(data[field]) != len(X):

                            raise ValueError(
                                f"{field}/X length mismatch:\n"
                                f"{file_path}"
                            )

                size = len(X)

            self.file_sizes.append(
                size
            )

            total += size

            self.cumulative_sizes.append(
                total
            )

        self.total_samples = total

        # ----------------------------------------------------
        # Determine metadata availability
        # ----------------------------------------------------

        self.has_attack_family = (
            self._check_metadata_field(
                "attack_family"
            )
        )

        self.has_attack_label = (
            self._check_metadata_field(
                "attack_label"
            )
        )

        self.has_source_file = (
            self._check_metadata_field(
                "source_file"
            )
        )

        # ----------------------------------------------------
        # Lazy cache
        # ----------------------------------------------------

        self._cached_file_index = None

        self._cached_X = None

        self._cached_y = None

        self._cached_attack_family = None

        self._cached_attack_label = None

        self._cached_source_file = None

    # ========================================================
    # METADATA AVAILABILITY
    # ========================================================

    def _check_metadata_field(
        self,
        field_name: str,
    ) -> bool:

        for file_path in self.files:

            with np.load(
                file_path,
                allow_pickle=False,
            ) as data:

                if field_name not in data.files:
                    return False

        return True

    # ========================================================
    # LENGTH
    # ========================================================

    def __len__(
        self,
    ) -> int:

        return self.total_samples

    # ========================================================
    # FIND FILE
    # ========================================================

    def _find_file(
        self,
        sample_index: int,
    ) -> Tuple[int, int]:

        if sample_index < 0:
            sample_index += (
                self.total_samples
            )

        if (
            sample_index < 0
            or sample_index
            >= self.total_samples
        ):
            raise IndexError(
                "Dataset index out of range."
            )

        # Binary search over cumulative sizes.
        file_index = (
            np.searchsorted(
                self.cumulative_sizes,
                sample_index,
                side="right",
            )
        )

        previous_end = 0

        if file_index > 0:

            previous_end = (
                self.cumulative_sizes[
                    file_index - 1
                ]
            )

        row_index = (
            sample_index
            - previous_end
        )

        return (
            int(file_index),
            int(row_index),
        )

    # ========================================================
    # LOAD FILE
    # ========================================================

    def _load_file(
        self,
        file_index: int,
    ):

        if (
            self._cached_file_index
            == file_index
        ):
            return

        file_path = self.files[
            file_index
        ]

        with np.load(
            file_path,
            allow_pickle=False,
        ) as data:

            # --------------------------------------------
            # Required arrays
            # --------------------------------------------

            X = data[
                "X"
            ].copy()

            y = data[
                "y"
            ].copy()

        self._cached_file_index = (
            file_index
        )

        self._cached_X = X

        self._cached_y = y

        # Metadata is intentionally loaded only when a metadata accessor
        # requests it. Training uses only X/y, so decompressing three large
        # string arrays for every feature batch wastes substantial I/O.
        self._cached_attack_family = None
        self._cached_attack_label = None
        self._cached_source_file = None

    def _load_metadata_field(
        self,
        file_index: int,
        field_name: str,
    ) -> None:
        """Load one optional metadata array for the currently cached file."""

        self._load_file(
            file_index
        )

        attribute_name = (
            f"_cached_{field_name}"
        )

        if getattr(
            self,
            attribute_name,
        ) is not None:
            return

        file_path = self.files[
            file_index
        ]

        with np.load(
            file_path,
            allow_pickle=True,
        ) as data:

            if field_name not in data.files:
                raise RuntimeError(
                    f"{field_name} metadata is unavailable in:\n"
                    f"{file_path}"
                )

            values = data[
                field_name
            ].copy()

        setattr(
            self,
            attribute_name,
            values,
        )

    # ========================================================
    # GET ITEM
    # ========================================================

    def __getitem__(
        self,
        index: int,
    ):

        file_index, row_index = (
            self._find_file(
                index
            )
        )

        self._load_file(
            file_index
        )

        X = self._cached_X[
            row_index
        ]

        y = self._cached_y[
            row_index
        ]

        # IMPORTANT:
        # Keep the original API unchanged.
        return (
            torch.from_numpy(
                X
            ).float(),

            torch.tensor(
                int(y),
                dtype=torch.long,
            ),
        )

    # ========================================================
    # GET ATTACK FAMILY
    # ========================================================

    def get_attack_family(
        self,
        index: int,
    ) -> str:

        if not self.has_attack_family:

            raise RuntimeError(
                "attack_family metadata is not "
                "available in all NPZ files."
            )

        file_index, row_index = (
            self._find_file(
                index
            )
        )

        self._load_metadata_field(
            file_index,
            "attack_family",
        )

        value = (
            self._cached_attack_family[
                row_index
            ]
        )

        return str(
            value
        )

    # ========================================================
    # GET ATTACK FAMILIES
    # ========================================================

    def get_attack_families(
        self,
    ) -> np.ndarray:

        if not self.has_attack_family:

            raise RuntimeError(
                "attack_family metadata is not "
                "available in all NPZ files."
            )

        families = []

        for file_path in self.files:

            with np.load(
                file_path,
                allow_pickle=True,
            ) as data:

                values = (
                    data[
                        "attack_family"
                    ]
                )

                families.append(
                    values.astype(str)
                )

        return np.concatenate(
            families
        )

    # ========================================================
    # GET ATTACK LABELS
    # ========================================================

    def get_attack_labels(
        self,
    ) -> np.ndarray:

        if not self.has_attack_label:

            raise RuntimeError(
                "attack_label metadata is not "
                "available in all NPZ files."
            )

        labels = []

        for file_path in self.files:

            with np.load(
                file_path,
                allow_pickle=True,
            ) as data:

                labels.append(
                    data[
                        "attack_label"
                    ].copy()
                )

        return np.concatenate(
            labels
        )

    # ========================================================
    # GET SOURCE FILES
    # ========================================================

    def get_source_files(
        self,
    ) -> np.ndarray:

        if not self.has_source_file:

            raise RuntimeError(
                "source_file metadata is not "
                "available in all NPZ files."
            )

        sources = []

        for file_path in self.files:

            with np.load(
                file_path,
                allow_pickle=True,
            ) as data:

                values = (
                    data[
                        "source_file"
                    ]
                )

                sources.append(
                    values.astype(str)
                )

        return np.concatenate(
            sources
        )

    # ========================================================
    # METADATA STATUS
    # ========================================================

    def metadata_available(
        self,
    ) -> dict:

        return {
            "attack_family":
                self.has_attack_family,

            "attack_label":
                self.has_attack_label,

            "source_file":
                self.has_source_file,
        }

    # ========================================================
    # GET FILE COUNT
    # ========================================================

    def get_file_count(
        self,
    ) -> int:

        return len(
            self.files
        )

    # ========================================================
    # GET FEATURE COUNT
    # ========================================================

    def get_feature_count(
        self,
    ) -> int:

        return 39

    # ========================================================
    # GET FILE SIZES
    # ========================================================

    def get_file_sizes(
        self,
    ) -> List[int]:

        return self.file_sizes


# ============================================================
# CACHE-FRIENDLY SHUFFLING
# ============================================================

class FileGroupedRandomSampler(Sampler[int]):
    """
    Shuffle files and rows reproducibly while keeping rows from the same
    compressed NPZ file adjacent.

    A global RandomSampler makes a one-file cache ineffective: nearly every
    sample can select a different archive and force another decompression.
    This sampler preserves stochastic training but opens each archive only
    once per epoch (apart from a possible batch boundary).
    """

    def __init__(
        self,
        dataset: Dataset,
        seed: int = 42,
    ) -> None:

        if not hasattr(dataset, "file_sizes"):
            raise TypeError(
                "FileGroupedRandomSampler requires dataset.file_sizes."
            )

        self.dataset = dataset
        self.seed = int(seed)
        self.epoch = 0
        self.file_sizes = [
            int(size)
            for size in dataset.file_sizes
        ]

        cumulative = np.asarray(
            dataset.cumulative_sizes,
            dtype=np.int64,
        )

        self.file_starts = np.concatenate(
            (
                np.zeros(1, dtype=np.int64),
                cumulative[:-1],
            )
        )

        self.local_positions_by_file = None

        # FederatedClientDataset positions refer to a shuffled subset of
        # global rows. Group those local positions by their underlying file.
        if hasattr(dataset, "global_indices"):
            global_indices = np.asarray(
                dataset.global_indices,
                dtype=np.int64,
            )

            file_ids = np.searchsorted(
                cumulative,
                global_indices,
                side="right",
            )

            order = np.argsort(
                file_ids,
                kind="stable",
            )
            sorted_file_ids = file_ids[order]
            boundaries = np.searchsorted(
                sorted_file_ids,
                np.arange(
                    len(self.file_sizes) + 1,
                    dtype=np.int64,
                ),
                side="left",
            )

            self.local_positions_by_file = [
                order[
                    boundaries[file_index]:
                    boundaries[file_index + 1]
                ]
                for file_index in range(
                    len(self.file_sizes)
                )
            ]

    def __len__(self) -> int:
        return len(self.dataset)

    def __iter__(self) -> Iterator[int]:
        rng = np.random.default_rng(
            self.seed + self.epoch
        )
        self.epoch += 1

        file_order = rng.permutation(
            len(self.file_sizes)
        )

        for file_index_value in file_order:
            file_index = int(
                file_index_value
            )

            if self.local_positions_by_file is None:
                start = int(
                    self.file_starts[file_index]
                )
                size = self.file_sizes[
                    file_index
                ]

                for row in rng.permutation(size):
                    yield start + int(row)
            else:
                positions = self.local_positions_by_file[
                    file_index
                ]

                if len(positions) == 0:
                    continue

                for offset in rng.permutation(
                    len(positions)
                ):
                    yield int(
                        positions[int(offset)]
                    )


# ============================================================
# DATASET FACTORY
# ============================================================

def create_dataset(
    scenario_name: str,
    split_name: str,
) -> CICIoTDataset:

    dataset_dir = (
        PROJECT_ROOT
        / "data"
        / "processed"
        / scenario_name
        / split_name
    )

    return CICIoTDataset(
        dataset_dir
    )


# ============================================================
# DATALOADER FACTORY
# ============================================================

def create_dataloader(
    dataset: Dataset,
    batch_size: int = 256,
    shuffle: bool = False,
) -> DataLoader:

    sampler = None

    if (
        shuffle
        and hasattr(dataset, "file_sizes")
        and hasattr(dataset, "cumulative_sizes")
    ):
        sampler = FileGroupedRandomSampler(
            dataset,
            seed=42,
        )

    return DataLoader(
        dataset,
        batch_size=batch_size,
        shuffle=(shuffle and sampler is None),
        sampler=sampler,
        num_workers=0,
        pin_memory=torch.cuda.is_available(),
        persistent_workers=False,
    )


# ============================================================
# LABEL DISTRIBUTION
# ============================================================

def calculate_label_distribution(
    dataset: CICIoTDataset,
) -> dict:

    distribution = {}

    for file_path in dataset.files:

        with np.load(
            file_path,
            allow_pickle=False,
        ) as data:

            labels = data["y"]

            unique, counts = np.unique(
                labels,
                return_counts=True,
            )

            for label, count in zip(
                unique,
                counts,
            ):

                label = int(label)

                distribution[label] = (
                    distribution.get(
                        label,
                        0,
                    )
                    + int(count)
                )

    return distribution


# ============================================================
# ATTACK FAMILY DISTRIBUTION
# ============================================================

def calculate_attack_family_distribution(
    dataset: CICIoTDataset,
) -> dict:

    if not dataset.has_attack_family:

        raise RuntimeError(
            "attack_family metadata is unavailable."
        )

    distribution = {}

    families = (
        dataset.get_attack_families()
    )

    unique, counts = np.unique(
        families,
        return_counts=True,
    )

    for family, count in zip(
        unique,
        counts,
    ):

        distribution[
            str(family)
        ] = int(count)

    return distribution


# ============================================================
# DATASET INFORMATION
# ============================================================

def print_dataset_info(
    dataset: CICIoTDataset,
    name: str,
) -> None:

    print()

    print(
        f"{name} dataset:"
    )

    print(
        f"  Files: "
        f"{dataset.get_file_count()}"
    )

    print(
        f"  Samples: "
        f"{len(dataset):,}"
    )

    print(
        f"  Features: "
        f"{dataset.get_feature_count()}"
    )

    print(
        f"  Attack family metadata: "
        f"{dataset.has_attack_family}"
    )

    print(
        f"  Attack label metadata: "
        f"{dataset.has_attack_label}"
    )

    print(
        f"  Source file metadata: "
        f"{dataset.has_source_file}"
    )


# ============================================================
# STANDALONE TEST
# ============================================================

def main():

    print("=" * 70)

    print(
        "AEFL-OSIDS OPTIMIZED DATASET/DATALOADER TEST"
    )

    print("=" * 70)

    scenario_name = (
        "scenario_C_multiple"
    )

    # --------------------------------------------------------
    # TRAIN
    # --------------------------------------------------------

    train_dataset = create_dataset(
        scenario_name,
        "train",
    )

    print_dataset_info(
        train_dataset,
        "TRAIN",
    )

    # --------------------------------------------------------
    # VALIDATION
    # --------------------------------------------------------

    validation_dataset = create_dataset(
        scenario_name,
        "validation",
    )

    print_dataset_info(
        validation_dataset,
        "VALIDATION",
    )

    # --------------------------------------------------------
    # TEST
    # --------------------------------------------------------

    test_dataset = create_dataset(
        scenario_name,
        "test",
    )

    print_dataset_info(
        test_dataset,
        "TEST",
    )

    # --------------------------------------------------------
    # SINGLE SAMPLE
    # --------------------------------------------------------

    X, y = train_dataset[0]

    print()

    print(
        "Single sample:"
    )

    print(
        f"X shape: "
        f"{tuple(X.shape)}"
    )

    print(
        f"X dtype: "
        f"{X.dtype}"
    )

    print(
        f"y: "
        f"{y.item()}"
    )

    print(
        f"y dtype: "
        f"{y.dtype}"
    )

    # --------------------------------------------------------
    # TEST METADATA
    # --------------------------------------------------------

    if test_dataset.has_attack_family:

        print()

        print(
            "Testing attack-family metadata..."
        )

        family = (
            test_dataset.get_attack_family(
                0
            )
        )

        print(
            f"First test family: "
            f"{family}"
        )

        families = (
            test_dataset.get_attack_families()
        )

        print(
            f"Family entries: "
            f"{len(families):,}"
        )

        distribution = (
            calculate_attack_family_distribution(
                test_dataset
            )
        )

        print()

        print(
            "Test attack-family distribution:"
        )

        for family in sorted(
            distribution
        ):

            print(
                f"  {family}: "
                f"{distribution[family]:,}"
            )

    # --------------------------------------------------------
    # DATALOADER
    # --------------------------------------------------------

    train_loader = create_dataloader(
        train_dataset,
        batch_size=256,
        shuffle=True,
    )

    print()

    print(
        "Testing first batch..."
    )

    X_batch, y_batch = next(
        iter(train_loader)
    )

    print(
        f"X batch shape: "
        f"{tuple(X_batch.shape)}"
    )

    print(
        f"y batch shape: "
        f"{tuple(y_batch.shape)}"
    )

    print(
        f"X batch dtype: "
        f"{X_batch.dtype}"
    )

    print(
        f"y batch dtype: "
        f"{y_batch.dtype}"
    )

    # --------------------------------------------------------
    # LABEL DISTRIBUTION
    # --------------------------------------------------------

    print()

    print(
        "Train label distribution:"
    )

    distribution = (
        calculate_label_distribution(
            train_dataset
        )
    )

    for label in sorted(
        distribution
    ):

        print(
            f"  Label {label}: "
            f"{distribution[label]:,}"
        )

    # --------------------------------------------------------
    # BASIC CHECKS
    # --------------------------------------------------------

    checks = []

    checks.append(
        X.shape == (39,)
    )

    checks.append(
        X_batch.shape
        == (256, 39)
    )

    checks.append(
        y_batch.shape
        == (256,)
    )

    checks.append(
        X_batch.dtype
        == torch.float32
    )

    checks.append(
        y_batch.dtype
        == torch.int64
    )

    checks.append(
        len(train_dataset)
        == 411602
    )

    checks.append(
        len(validation_dataset)
        == 87995
    )

    checks.append(
        len(test_dataset)
        == 117190
    )

    # --------------------------------------------------------
    # FINAL
    # --------------------------------------------------------

    print()

    print("=" * 70)

    if all(checks):

        print(
            "OPTIMIZED DATASET/DATALOADER "
            "TEST SUCCESSFUL"
        )

    else:

        print(
            "OPTIMIZED DATASET/DATALOADER "
            "TEST FAILED"
        )

    print("=" * 70)


# ============================================================
# ENTRY POINT
# ============================================================

if __name__ == "__main__":
    main()
