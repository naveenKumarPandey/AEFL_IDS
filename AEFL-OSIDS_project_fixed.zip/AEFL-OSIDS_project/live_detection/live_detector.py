"""
AEFL-OSIDS
Real-Time Hybrid Live Detector

Pipeline:

    Packet Capture
          |
          v
       Flow Manager
          |
          v
    Completed Flow
          |
          +----------------------+
          |                      |
          v                      v
    39 Feature Builder      Rule Engine
          |                      |
          v                      |
       ML Model                  |
          |                      |
          +----------+-----------+
                     |
                     v
              Hybrid Detector
                     |
                     v
             Real-Time Decision

Modes:

    --test
        Runs the complete detection pipeline on synthetic flows.

    --demo
        Runs a continuous synthetic-flow demonstration.

    --live
        Captures packets from the configured interface.

This module does NOT:

- train the model
- modify model weights
- modify the scaler
- modify research results
"""

from __future__ import annotations

import argparse
import logging
import signal
import sys
import time
from typing import Any, Dict, Optional

import numpy as np

from live_detection.hybrid_detector import (
    HybridDetectionResult,
    HybridDetector,
)

from live_detection.flow_feature_builder import (
    FEATURE_NAMES,
    build_live_features,
)


# =====================================================================
# LOGGING
# =====================================================================

logger = logging.getLogger(__name__)


# =====================================================================
# GLOBAL SHUTDOWN STATE
# =====================================================================

_shutdown_requested = False

_capture_instance = None


# =====================================================================
# LIVE DETECTOR
# =====================================================================

class LiveDetector:
    """
    Top-level runtime for real-time intrusion detection.

    Receives completed flows and sends them through:

        Feature Builder
              |
              v
          ML Detector
              |
              +------ Rule Engine
              |
              v
        Hybrid Detector
              |
              v
          Final Decision
    """

    def __init__(
        self,
        hybrid_detector: Optional[HybridDetector] = None,
        debug_features: bool = False,
    ) -> None:

        self.hybrid_detector = (
            hybrid_detector
            if hybrid_detector is not None
            else HybridDetector()
        )

        self.running = False

        self.debug_features = bool(
            debug_features
        )

        self.total_flows = 0
        self.benign_count = 0
        self.suspicious_count = 0
        self.intrusion_count = 0
        self.unknown_count = 0

        logger.info(
            "LiveDetector initialized."
        )

    # =================================================================
    # FLOW PROCESSING
    # =================================================================

    def process_flow(
        self,
        flow: Dict[str, Any],
    ) -> HybridDetectionResult:
        """
        Process one completed flow.

        Returns:
            Complete hybrid detection result.
        """

        global _shutdown_requested

        # IMPORTANT: PacketCapture.stop() can synchronously flush
        # completed FlowRecord objects after Ctrl+C.  During that
        # flush _shutdown_requested is True, but these flows are already
        # captured and must still be analyzed.  Do not reject them here.
        # The live capture loop itself is stopped by PacketCapture.stop().

        self.total_flows += 1

        if self.debug_features:

            self._print_live_features(
                flow
            )

        result = (
            self.hybrid_detector
            .analyze_flow(
                flow
            )
        )

        self._update_counters(
            result
        )

        self._print_detection(
            flow,
            result,
        )

        return result

    # =================================================================
    # LIVE FEATURE DEBUG
    # =================================================================

    @staticmethod
    def _print_live_features(
        flow: Dict[str, Any],
    ) -> None:
        """
        Print the exact unscaled 39-feature vector
        used by live ML.
        """

        try:

            vector = np.asarray(
                build_live_features(flow),
                dtype=np.float32,
            ).reshape(-1)

            print()
            print("=" * 70)
            print("LIVE 39-FEATURE DEBUG")
            print("-" * 70)

            print(
                f"Feature count : {vector.size}"
            )

            print(
                f"Vector shape  : {tuple(vector.shape)}"
            )

            print()

            for index, (
                name,
                value,
            ) in enumerate(
                zip(
                    FEATURE_NAMES,
                    vector,
                ),
                start=1,
            ):

                print(
                    f"{index:02d}. "
                    f"{name:<24} "
                    f"{float(value):.8f}"
                )

            print("-" * 70)

            print(
                "Finite values : "
                f"{bool(np.all(np.isfinite(vector)))}"
            )

            print(
                "Min           : "
                f"{float(np.min(vector)):.8f}"
            )

            print(
                "Max           : "
                f"{float(np.max(vector)):.8f}"
            )

            print("=" * 70)

        except Exception as exc:

            logger.exception(
                "Live feature debug failed: %s",
                exc,
            )

    # =================================================================
    # COUNTERS
    # =================================================================

    def _update_counters(
        self,
        result: HybridDetectionResult,
    ) -> None:

        if result.decision == "BENIGN":

            self.benign_count += 1

        elif result.decision == "SUSPICIOUS":

            self.suspicious_count += 1

        elif result.decision == "INTRUSION":

            self.intrusion_count += 1

        elif result.decision == "UNKNOWN":

            self.unknown_count += 1

    # =================================================================
    # PRINT RESULT
    # =================================================================

    @staticmethod
    def _print_detection(
        flow: Dict[str, Any],
        result: HybridDetectionResult,
    ) -> None:

        source = flow.get(
            "src_ip",
            flow.get(
                "source_ip",
                "?",
            ),
        )

        destination = flow.get(
            "dst_ip",
            flow.get(
                "destination_ip",
                "?",
            ),
        )

        src_port = flow.get(
            "src_port",
            flow.get(
                "source_port",
                "?",
            ),
        )

        dst_port = flow.get(
            "dst_port",
            flow.get(
                "destination_port",
                "?",
            ),
        )

        protocol = flow.get(
            "protocol",
            flow.get(
                "protocol_type",
                "?",
            ),
        )

        print()
        print("=" * 70)
        print("LIVE FLOW DETECTION")
        print("-" * 70)

        print(
            f"Flow          : "
            f"{source}:{src_port} -> "
            f"{destination}:{dst_port}"
        )

        print(
            f"Protocol      : {protocol}"
        )

        print(
            f"Packets       : "
            f"{flow.get('packet_count', flow.get('packets', '?'))}"
        )

        print(
            f"Bytes         : "
            f"{flow.get('byte_count', flow.get('bytes', '?'))}"
        )

        print(
            f"Duration      : "
            f"{flow.get('duration', '?')}"
        )

        print(
            f"Packet rate   : "
            f"{flow.get('packets_per_second', flow.get('packet_rate', '?'))}"
        )

        print()

        print("ML ANALYSIS")

        print(
            f"  Class       : "
            f"{result.ml_class}"
        )

        print(
            f"  Confidence  : "
            f"{result.ml_confidence:.4f}"
        )

        print(
            f"  Unknown     : "
            f"{result.ml_unknown}"
        )

        print()

        print("RULE ANALYSIS")

        print(
            f"  Risk        : "
            f"{result.rule_risk_score:.2f}/100"
        )

        print(
            f"  Severity    : "
            f"{result.rule_severity}"
        )

        print(
            f"  Rules       : "
            f"{result.rule_count}"
        )

        print()

        print("HYBRID DECISION")

        print(
            f"  Decision    : "
            f"{result.decision}"
        )

        print(
            f"  Risk score  : "
            f"{result.risk_score:.2f}/100"
        )

        print(
            f"  Explanation : "
            f"{result.explanation}"
        )

        print("=" * 70)

    # =================================================================
    # STATISTICS
    # =================================================================

    def get_statistics(
        self,
    ) -> Dict[str, int]:

        return {
            "total_flows":
                self.total_flows,

            "benign":
                self.benign_count,

            "suspicious":
                self.suspicious_count,

            "intrusion":
                self.intrusion_count,

            "unknown":
                self.unknown_count,
        }

    # =================================================================
    # SUMMARY
    # =================================================================

    def print_summary(
        self,
    ) -> None:

        stats = (
            self.get_statistics()
        )

        print()
        print("=" * 70)
        print("LIVE DETECTION SUMMARY")
        print("-" * 70)

        print(
            f"Total flows    : "
            f"{stats['total_flows']}"
        )

        print(
            f"BENIGN         : "
            f"{stats['benign']}"
        )

        print(
            f"SUSPICIOUS     : "
            f"{stats['suspicious']}"
        )

        print(
            f"INTRUSION      : "
            f"{stats['intrusion']}"
        )

        print(
            f"UNKNOWN        : "
            f"{stats['unknown']}"
        )

        print("=" * 70)

    # =================================================================
    # SYNTHETIC NORMAL FLOW
    # =================================================================

    @staticmethod
    def create_normal_flow() -> Dict[str, Any]:

        return {
            "src_ip":
                "192.168.1.10",

            "dst_ip":
                "192.168.1.20",

            "src_port":
                50000,

            "dst_port":
                80,

            "protocol":
                6,

            "packets":
                3,

            "bytes":
                300,

            "duration":
                0.2,

            "packet_rate":
                15.0,

            "syn_count":
                1,

            "ack_count":
                2,

            "fin_count":
                0,

            "rst_count":
                0,
        }

    # =================================================================
    # SYN FLOOD FLOW
    # =================================================================

    @staticmethod
    def create_syn_flood_flow() -> Dict[str, Any]:

        return {
            "src_ip":
                "10.0.0.50",

            "dst_ip":
                "10.0.0.10",

            "src_port":
                45000,

            "dst_port":
                80,

            "protocol":
                6,

            "packets":
                100,

            "bytes":
                10000,

            "duration":
                0.1,

            "packet_rate":
                1000.0,

            "syn_count":
                95,

            "ack_count":
                2,

            "fin_count":
                0,

            "rst_count":
                0,
        }

    # =================================================================
    # HIGH RATE FLOW
    # =================================================================

    @staticmethod
    def create_high_rate_flow() -> Dict[str, Any]:

        return {
            "src_ip":
                "10.0.0.60",

            "dst_ip":
                "192.168.1.20",

            "src_port":
                42000,

            "dst_port":
                443,

            "protocol":
                6,

            "packets":
                200,

            "bytes":
                250000,

            "duration":
                0.2,

            "packet_rate":
                1000.0,

            "syn_count":
                5,

            "ack_count":
                190,

            "fin_count":
                2,

            "rst_count":
                1,
        }

    # =================================================================
    # TEST MODE
    # =================================================================

    def run_test(
        self,
    ) -> None:

        print("=" * 70)
        print(
            "AEFL-OSIDS COMPLETE LIVE PIPELINE TEST"
        )
        print("=" * 70)

        print()
        print(
            "This test uses synthetic flows."
        )

        print(
            "No packets will be captured."
        )

        print(
            "No model training will occur."
        )

        print(
            "Existing model weights will not be modified."
        )

        print()
        print(
            "TEST 1/3: Normal TCP flow"
        )

        self.process_flow(
            self.create_normal_flow()
        )

        print()
        print(
            "TEST 2/3: SYN flood-like flow"
        )

        self.process_flow(
            self.create_syn_flood_flow()
        )

        print()
        print(
            "TEST 3/3: High-rate flow"
        )

        self.process_flow(
            self.create_high_rate_flow()
        )

        self.print_summary()

        if self.total_flows != 3:

            raise RuntimeError(
                "Expected exactly 3 test flows."
            )

        if self.intrusion_count <= 0:

            raise RuntimeError(
                "No intrusion was detected in "
                "the SYN-flood test."
            )

        print()
        print("=" * 70)
        print(
            "COMPLETE LIVE PIPELINE TEST SUCCESSFUL"
        )
        print("=" * 70)

    # =================================================================
    # DEMO MODE
    # =================================================================

    def run_demo(
        self,
        interval: float = 2.0,
    ) -> None:

        global _shutdown_requested

        print("=" * 70)
        print(
            "AEFL-OSIDS LIVE DETECTION DEMO"
        )
        print("=" * 70)

        print()
        print(
            "Synthetic flows are being generated."
        )

        print(
            "Press Ctrl+C to stop."
        )

        print()

        _shutdown_requested = False
        self.running = True

        flows = [
            self.create_normal_flow,
            self.create_normal_flow,
            self.create_syn_flood_flow,
            self.create_normal_flow,
            self.create_high_rate_flow,
        ]

        index = 0

        try:

            while (
                self.running
                and not _shutdown_requested
            ):

                flow_factory = (
                    flows[
                        index
                        % len(flows)
                    ]
                )

                flow = flow_factory()

                flow["src_port"] = (
                    50000 + index
                )

                self.process_flow(
                    flow
                )

                index += 1

                # Sleep in small intervals so Ctrl+C
                # is handled quickly.
                remaining = max(
                    0.0,
                    float(interval),
                )

                while (
                    remaining > 0
                    and self.running
                    and not _shutdown_requested
                ):

                    step = min(
                        0.1,
                        remaining,
                    )

                    time.sleep(
                        step
                    )

                    remaining -= step

        except KeyboardInterrupt:

            _shutdown_requested = True

            print()
            print(
                "Stopping live demonstration..."
            )

        finally:

            self.running = False

            self.print_summary()

    # =================================================================
    # LIVE MODE
    # =================================================================

    def run_live(
        self,
        interface: Optional[str] = None,
    ) -> None:
        """
        Start actual packet capture.

        Shutdown is explicitly coordinated with PacketCapture.
        """

        global _shutdown_requested
        global _capture_instance

        print("=" * 70)
        print(
            "AEFL-OSIDS REAL-TIME NETWORK DETECTION"
        )
        print("=" * 70)

        print()
        print(
            "Mode: LIVE NETWORK CAPTURE"
        )

        print(
            "Press Ctrl+C to stop."
        )

        print()

        try:

            from live_detection.packet_capture import (
                PacketCapture,
            )

        except ImportError as exc:

            raise RuntimeError(
                "Could not import packet capture module.\n"
                "Make sure live_detection.packet_capture "
                "is available."
            ) from exc

        _shutdown_requested = False

        # -------------------------------------------------------------
        # Create capture
        # -------------------------------------------------------------

        try:

            capture = PacketCapture(
                interface=interface,
                flow_callback=self._packet_callback,
            )

        except TypeError:

            # Compatibility with older API.

            try:

                capture = PacketCapture(
                    interface=interface
                )

            except TypeError:

                capture = PacketCapture()

            if hasattr(
                capture,
                "flow_callback",
            ):

                capture.flow_callback = (
                    self._packet_callback
                )

        _capture_instance = capture

        self.running = True

        print()
        print(
            "Starting packet capture..."
        )

        print(
            "Press Ctrl+C to stop."
        )

        print()

        try:

            capture.start(
                blocking=True
            )

        except KeyboardInterrupt:

            # Some Scapy/Windows configurations propagate
            # KeyboardInterrupt directly.

            logger.info(
                "Keyboard interrupt received."
            )

        except Exception as exc:

            # If shutdown was requested, do not treat the
            # shutdown-related exception as a capture failure.

            if not _shutdown_requested:

                logger.exception(
                    "Live packet capture failed."
                )

                raise RuntimeError(
                    f"Live packet capture failed: {exc}"
                ) from exc

        finally:

            self.running = False

            # ---------------------------------------------------------
            # Explicitly stop PacketCapture.
            # ---------------------------------------------------------

            if capture is not None:

                try:

                    if getattr(
                        capture,
                        "running",
                        False,
                    ):

                        capture.stop()

                except Exception as exc:

                    logger.warning(
                        "Packet capture stop failed: %s",
                        exc,
                    )

            _capture_instance = None

            _shutdown_requested = False

        self.print_summary()

    # =================================================================
    # PACKET CALLBACK
    # =================================================================

    def _packet_callback(
        self,
        packet: Any,
    ) -> None:
        """
        Callback used by PacketCapture.

        PacketCapture normally emits FlowRecord objects.
        """

        global _shutdown_requested

        # -------------------------------------------------------------
        # Shutdown handling
        #
        # PacketCapture may flush completed flows after Ctrl+C. Those
        # already-completed flows must still be processed. Only reject
        # callbacks when the detector is no longer running AND shutdown
        # has not been requested.
        # -------------------------------------------------------------

        if not self.running and not _shutdown_requested:

            return

        if packet is None:

            return

        # -------------------------------------------------------------
        # FlowRecord
        # -------------------------------------------------------------

        if (
            hasattr(packet, "to_dict")
            and callable(packet.to_dict)
        ):

            try:

                self.process_flow(
                    packet.to_dict()
                )

            except Exception:

                logger.exception(
                    "Failed to process completed FlowRecord."
                )

            return

        # -------------------------------------------------------------
        # Single dictionary
        # -------------------------------------------------------------

        if isinstance(
            packet,
            dict,
        ):

            try:

                self.process_flow(
                    packet
                )

            except Exception:

                logger.exception(
                    "Failed to process flow dictionary."
                )

            return

        # -------------------------------------------------------------
        # Multiple flows
        # -------------------------------------------------------------

        if isinstance(
            packet,
            (
                list,
                tuple,
            ),
        ):

            for flow in packet:

                # A shutdown flush may deliver several completed flows
                # at once. Process every already-completed flow.

                if (
                    hasattr(
                        flow,
                        "to_dict",
                    )
                    and callable(
                        flow.to_dict
                    )
                ):

                    try:

                        self.process_flow(
                            flow.to_dict()
                        )

                    except Exception:

                        logger.exception(
                            "Failed to process FlowRecord."
                        )

                elif isinstance(
                    flow,
                    dict,
                ):

                    try:

                        self.process_flow(
                            flow
                        )

                    except Exception:

                        logger.exception(
                            "Failed to process flow dictionary."
                        )

            return

        logger.debug(
            "Flow callback received unsupported "
            "object type: %s",
            type(packet).__name__,
        )


# =====================================================================
# SIGNAL HANDLING
# =====================================================================

_detector_instance: Optional[
    LiveDetector
] = None


def _handle_signal(
    signum: int,
    frame: Any,
) -> None:
    """
    Handle Ctrl+C.

    The important part is stopping PacketCapture itself.
    """

    del signum
    del frame

    global _shutdown_requested
    global _capture_instance
    global _detector_instance

    # -------------------------------------------------------------
    # Prevent repeated Ctrl+C from creating repeated output.
    # -------------------------------------------------------------

    if _shutdown_requested:

        print(
            "\nShutdown already requested..."
        )

        return

    _shutdown_requested = True

    print()
    print(
        "Stopping AEFL-OSIDS live detection..."
    )

    # IMPORTANT:
    # Do not set _detector_instance.running = False here.
    #
    # PacketCapture.stop() may flush completed FlowRecord objects.
    # Those flows must still reach _packet_callback() and be analyzed
    # before run_live() finishes shutdown.

    # -------------------------------------------------------------
    # IMPORTANT:
    # Stop the actual PacketCapture object.
    # -------------------------------------------------------------

    capture = _capture_instance

    if capture is not None:

        try:

            if getattr(
                capture,
                "running",
                False,
            ):

                capture.stop()

        except Exception as exc:

            logger.warning(
                "Error while stopping packet capture: %s",
                exc,
            )


# =====================================================================
# ARGUMENT PARSER
# =====================================================================

def build_parser() -> argparse.ArgumentParser:

    parser = argparse.ArgumentParser(
        description=(
            "AEFL-OSIDS real-time "
            "ML + rule-based intrusion detector."
        )
    )

    mode = parser.add_mutually_exclusive_group(
        required=True
    )

    mode.add_argument(
        "--test",
        action="store_true",
        help=(
            "Run complete synthetic "
            "pipeline test."
        ),
    )

    mode.add_argument(
        "--demo",
        action="store_true",
        help=(
            "Run continuous synthetic "
            "live-detection demonstration."
        ),
    )

    mode.add_argument(
        "--live",
        action="store_true",
        help=(
            "Capture and analyze live "
            "network traffic."
        ),
    )

    parser.add_argument(
        "--interface",
        type=str,
        default=None,
        help=(
            "Network interface for live "
            "capture."
        ),
    )

    parser.add_argument(
        "--interval",
        type=float,
        default=2.0,
        help=(
            "Synthetic demo interval in seconds."
        ),
    )

    parser.add_argument(
        "--debug-features",
        action="store_true",
        help=(
            "Print the unscaled 39-feature vector "
            "for every processed flow."
        ),
    )

    return parser


# =====================================================================
# MAIN
# =====================================================================

def main() -> None:

    global _detector_instance

    logging.basicConfig(
        level=logging.INFO,
        format=(
            "%(asctime)s - "
            "%(levelname)s - "
            "%(message)s"
        ),
    )

    parser = build_parser()

    args = parser.parse_args()

    signal.signal(
        signal.SIGINT,
        _handle_signal,
    )

    _detector_instance = (
        LiveDetector(
            debug_features=args.debug_features
        )
    )

    # -----------------------------------------------------------------
    # TEST
    # -----------------------------------------------------------------

    if args.test:

        _detector_instance.run_test()

        return

    # -----------------------------------------------------------------
    # DEMO
    # -----------------------------------------------------------------

    if args.demo:

        interval = max(
            0.1,
            float(args.interval),
        )

        _detector_instance.run_demo(
            interval=interval
        )

        return

    # -----------------------------------------------------------------
    # LIVE
    # -----------------------------------------------------------------

    if args.live:

        try:

            _detector_instance.run_live(
                interface=args.interface
            )

        except KeyboardInterrupt:

            # Final fallback.
            print()
            print(
                "Live detection stopped."
            )

        except Exception as exc:

            print()
            print("=" * 70)
            print("LIVE CAPTURE ERROR")
            print("=" * 70)

            print(
                str(exc)
            )

            print()
            print(
                "The ML and rule engines remain "
                "available independently."
            )

            sys.exit(1)

        return


# =====================================================================
# ENTRY POINT
# =====================================================================

if __name__ == "__main__":

    main()