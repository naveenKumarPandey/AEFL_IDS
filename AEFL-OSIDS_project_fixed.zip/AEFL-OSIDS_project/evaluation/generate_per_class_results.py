"""
AEFL-OSIDS
Adaptive FedAvg v2 Per-Class Test Evaluation

Purpose
-------
Evaluate the EXISTING Adaptive FedAvg v2 model on the existing
Scenario-C test dataset and generate publication-ready per-class
classification results.

NO TRAINING IS PERFORMED.
NO MODEL WEIGHTS ARE MODIFIED.

Known classes in Scenario C:

    0 -> BENIGN
    1 -> DDoS
    2 -> DoS
    3 -> Mirai
    4 -> Recon

Unknown families:

    BruteForce
    Spoofing
    Web-based
"""

from __future__ import annotations

import json
import shutil
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import torch

from sklearn.metrics import (
    accuracy_score,
    classification_report,
    confusion_matrix,
)


# ============================================================
# PROJECT CONFIGURATION
# ============================================================

PROJECT_ROOT = Path(__file__).resolve().parents[1]

SCENARIO = "scenario_C_multiple"

MODEL_PATH = (
    PROJECT_ROOT
    / "data"
    / "models"
    / "adaptive_fedavg_v2_global.pt"
)

RESULTS_ROOT = (
    PROJECT_ROOT
    / "results"
)

OUTPUT_DIR = (
    RESULTS_ROOT
    / "per_class_results"
)

PAPER_RESULTS_DIR = (
    RESULTS_ROOT
    / "paper_results"
)

CLASS_NAMES = [
    "BENIGN",
    "DDoS",
    "DoS",
    "Mirai",
    "Recon",
]

NUM_CLASSES = 5

KNOWN_FAMILIES = {
    "BENIGN",
    "DDoS",
    "DoS",
    "Mirai",
    "Recon",
}

UNKNOWN_FAMILIES = {
    "BruteForce",
    "Spoofing",
    "Web-based",
}

BATCH_SIZE = 4096


# ============================================================
# DATASET IMPORT
# ============================================================

try:

    from data_loader.cic_iot_dataset import (
        create_dataset,
        create_dataloader,
    )

except Exception as exc:

    raise ImportError(
        "Could not import the CICIoT dataset loader.\n"
        "Make sure the command is executed from the project root "
        "with PYTHONPATH configured.\n\n"
        f"Original error: {exc}"
    )


# ============================================================
# MODEL IMPORT
# ============================================================

MODEL_CLASS = None


def find_model_class():

    """
    Locate the model architecture used by Adaptive FedAvg v2.

    The project may use a model class from the models package.
    We inspect common project modules without modifying anything.
    """

    candidates = [

        (
            "models.intrusion_detection_model",
            "IntrusionDetectionModel",
        ),

        (
            "models.model",
            "IntrusionDetectionModel",
        ),

        (
            "models.mlp",
            "MLPClassifier",
        ),

        (
            "models.mlp",
            "MLP",
        ),

        (
            "models.network",
            "IntrusionDetectionModel",
        ),

    ]

    for module_name, class_name in candidates:

        try:

            module = __import__(
                module_name,
                fromlist=[class_name],
            )

            if hasattr(module, class_name):

                return getattr(
                    module,
                    class_name,
                )

        except Exception:

            continue

    return None


# ============================================================
# MODEL LOADING
# ============================================================

def load_model(
    device: torch.device,
) -> torch.nn.Module:

    if not MODEL_PATH.exists():

        raise FileNotFoundError(
            f"Adaptive FedAvg v2 model not found:\n"
            f"{MODEL_PATH}"
        )

    print(
        f"Model: {MODEL_PATH}"
    )

    checkpoint = torch.load(
        MODEL_PATH,
        map_location=device,
    )

    # --------------------------------------------------------
    # Case 1: complete serialized model
    # --------------------------------------------------------

    if isinstance(
        checkpoint,
        torch.nn.Module,
    ):

        model = checkpoint

        model.to(device)

        model.eval()

        return model

    # --------------------------------------------------------
    # Case 2: checkpoint dictionary
    # --------------------------------------------------------

    if not isinstance(
        checkpoint,
        dict,
    ):

        raise RuntimeError(
            "Unsupported model checkpoint format."
        )

    state_dict = checkpoint.get(
        "model_state_dict"
    )

    if state_dict is None:

        state_dict = checkpoint.get(
            "state_dict"
        )

    if state_dict is None:

        raise RuntimeError(
            "Could not find model_state_dict "
            "or state_dict in checkpoint."
        )

    input_features = int(
        checkpoint.get(
            "input_features",
            39,
        )
    )

    num_classes = int(
        checkpoint.get(
            "num_classes",
            NUM_CLASSES,
        )
    )

    # --------------------------------------------------------
    # Try to locate project model class.
    # --------------------------------------------------------

    model_class = find_model_class()

    if model_class is not None:

        constructors = [

            {
                "input_features": input_features,
                "num_classes": num_classes,
            },

            {
                "input_dim": input_features,
                "num_classes": num_classes,
            },

            {
                "input_size": input_features,
                "num_classes": num_classes,
            },

        ]

        for kwargs in constructors:

            try:

                model = model_class(
                    **kwargs
                )

                model.load_state_dict(
                    state_dict
                )

                model.to(device)

                model.eval()

                return model

            except Exception:

                continue

    # --------------------------------------------------------
    # Fallback architecture.
    #
    # This is only used if the project's original class
    # cannot be imported.
    # --------------------------------------------------------

    model = build_fallback_model(
        state_dict=state_dict,
        input_features=input_features,
        num_classes=num_classes,
    )

    model.to(device)

    model.eval()

    return model


# ============================================================
# FALLBACK MODEL
# ============================================================

def build_fallback_model(
    state_dict: Dict[str, torch.Tensor],
    input_features: int,
    num_classes: int,
) -> torch.nn.Module:

    """
    Reconstruct the exact Adaptive FedAvg v2 architecture
    from the checkpoint structure.

    Existing checkpoint structure:

        feature_extractor.0 -> Linear
        feature_extractor.1 -> BatchNorm1d
        feature_extractor.2 -> ReLU
        feature_extractor.3 -> Dropout
        feature_extractor.4 -> Linear
        feature_extractor.5 -> BatchNorm1d
        feature_extractor.6 -> ReLU
        feature_extractor.7 -> Dropout
        feature_extractor.8 -> Linear

        classifier -> Linear

    No training is performed.
    """

    required_keys = [
        "feature_extractor.0.weight",
        "feature_extractor.0.bias",

        "feature_extractor.1.weight",
        "feature_extractor.1.bias",
        "feature_extractor.1.running_mean",
        "feature_extractor.1.running_var",

        "feature_extractor.4.weight",
        "feature_extractor.4.bias",

        "feature_extractor.5.weight",
        "feature_extractor.5.bias",
        "feature_extractor.5.running_mean",
        "feature_extractor.5.running_var",

        "feature_extractor.8.weight",
        "feature_extractor.8.bias",

        "classifier.weight",
        "classifier.bias",
    ]

    missing = [
        key
        for key in required_keys
        if key not in state_dict
    ]

    if missing:

        raise RuntimeError(
            "The Adaptive FedAvg v2 checkpoint does not contain "
            "the expected architecture keys.\n\n"
            "Missing keys:\n"
            + "\n".join(missing)
        )

    # --------------------------------------------------------
    # Recover layer dimensions directly from the checkpoint.
    # --------------------------------------------------------

    layer0_weight = state_dict[
        "feature_extractor.0.weight"
    ]

    layer4_weight = state_dict[
        "feature_extractor.4.weight"
    ]

    layer8_weight = state_dict[
        "feature_extractor.8.weight"
    ]

    classifier_weight = state_dict[
        "classifier.weight"
    ]

    input_dim = int(
        layer0_weight.shape[1]
    )

    hidden1 = int(
        layer0_weight.shape[0]
    )

    hidden2 = int(
        layer4_weight.shape[0]
    )

    hidden3 = int(
        layer8_weight.shape[0]
    )

    classifier_in = int(
        classifier_weight.shape[1]
    )

    checkpoint_classes = int(
        classifier_weight.shape[0]
    )

    print()
    print(
        "Reconstructing Adaptive FedAvg v2 architecture..."
    )

    print(
        f"  Input features       : {input_dim}"
    )

    print(
        f"  Hidden layer 1       : {hidden1}"
    )

    print(
        f"  Hidden layer 2       : {hidden2}"
    )

    print(
        f"  Hidden layer 3       : {hidden3}"
    )

    print(
        f"  Classifier input     : {classifier_in}"
    )

    print(
        f"  Output classes       : {checkpoint_classes}"
    )

    # --------------------------------------------------------
    # Validate dimensions.
    # --------------------------------------------------------

    if input_dim != input_features:

        print(
            "[WARNING] Checkpoint input dimension "
            f"({input_dim}) differs from configured "
            f"input_features ({input_features}). "
            "Using checkpoint dimension."
        )

        input_features = input_dim

    if (
        classifier_in
        != hidden3
    ):

        raise RuntimeError(
            "Checkpoint architecture is inconsistent:\n"
            f"feature_extractor.8 outputs {hidden3}, "
            f"but classifier expects {classifier_in}."
        )

    if (
        checkpoint_classes
        != num_classes
    ):

        print(
            "[WARNING] Checkpoint class count "
            f"({checkpoint_classes}) differs from configured "
            f"num_classes ({num_classes}). "
            "Using checkpoint class count."
        )

        num_classes = checkpoint_classes

    # --------------------------------------------------------
    # IMPORTANT:
    #
    # BatchNorm layers require the exact number of features.
    # --------------------------------------------------------

    bn1_features = int(
        state_dict[
            "feature_extractor.1.weight"
        ].shape[0]
    )

    bn2_features = int(
        state_dict[
            "feature_extractor.5.weight"
        ].shape[0]
    )

    if bn1_features != hidden1:

        raise RuntimeError(
            "First BatchNorm dimension does not match "
            "the first Linear layer."
        )

    if bn2_features != hidden2:

        raise RuntimeError(
            "Second BatchNorm dimension does not match "
            "the second Linear layer."
        )

    # --------------------------------------------------------
    # Recreate exact module names.
    # --------------------------------------------------------

    feature_extractor = torch.nn.Sequential(

        torch.nn.Linear(
            input_features,
            hidden1,
        ),

        torch.nn.BatchNorm1d(
            hidden1,
        ),

        torch.nn.ReLU(),

        torch.nn.Dropout(),

        torch.nn.Linear(
            hidden1,
            hidden2,
        ),

        torch.nn.BatchNorm1d(
            hidden2,
        ),

        torch.nn.ReLU(),

        torch.nn.Dropout(),

        torch.nn.Linear(
            hidden2,
            hidden3,
        ),
    )

    classifier = torch.nn.Linear(
        hidden3,
        num_classes,
    )

    class AdaptiveFedAvgV2Architecture(
        torch.nn.Module
    ):

        def __init__(self):

            super().__init__()

            self.feature_extractor = (
                feature_extractor
            )

            self.classifier = (
                classifier
            )

        def forward(
            self,
            x,
        ):

            features = (
                self.feature_extractor(
                    x
                )
            )

            logits = (
                self.classifier(
                    features
                )
            )

            return logits

    model = (
        AdaptiveFedAvgV2Architecture()
    )

    # --------------------------------------------------------
    # Load the EXISTING trained weights.
    # --------------------------------------------------------

    model.load_state_dict(
        state_dict,
        strict=True,
    )

    print(
        "Exact Adaptive FedAvg v2 architecture "
        "reconstructed successfully."
    )

    return model


# ============================================================
# ATTACK FAMILY EXTRACTION
# ============================================================

def extract_attack_family_array(
    dataset,
) -> Optional[np.ndarray]:

    """
    Read attack_family metadata directly from NPZ files.

    Metadata is NOT loaded through __getitem__ because the normal
    Dataset API returns only X and y.
    """

    families = []

    for file_path in dataset.files:

        with np.load(
            file_path,
            allow_pickle=True,
        ) as data:

            if "attack_family" not in data.files:

                return None

            values = data[
                "attack_family"
            ]

            values = np.asarray(
                values
            )

            for value in values:

                if isinstance(
                    value,
                    bytes,
                ):

                    value = value.decode(
                        "utf-8",
                        errors="replace",
                    )

                families.append(
                    str(value)
                )

    return np.asarray(
        families,
        dtype=object,
    )


# ============================================================
# FAMILY -> CLASS
# ============================================================

def family_to_class(
    family: str,
) -> Optional[int]:

    mapping = {

        "BENIGN": 0,

        "DDoS": 1,

        "DoS": 2,

        "Mirai": 3,

        "Recon": 4,

    }

    return mapping.get(
        family
    )


# ============================================================
# INFERENCE
# ============================================================

def run_inference(
    model: torch.nn.Module,
    dataset,
    device: torch.device,
) -> Tuple[
    np.ndarray,
    np.ndarray,
]:

    loader = create_dataloader(
        dataset,
        batch_size=BATCH_SIZE,
        shuffle=False,
    )

    true_labels = []

    predicted_labels = []

    processed = 0

    print()
    print(
        "Running inference..."
    )

    with torch.no_grad():

        for X, y in loader:

            X = X.to(
                device,
                non_blocking=True,
            )

            logits = model(
                X
            )

            if isinstance(
                logits,
                tuple,
            ):

                logits = logits[0]

            predictions = torch.argmax(
                logits,
                dim=1,
            )

            true_labels.extend(
                y.cpu()
                .numpy()
                .tolist()
            )

            predicted_labels.extend(
                predictions.cpu()
                .numpy()
                .tolist()
            )

            processed += len(
                y
            )

            if (
                processed
                % 40960
                == 0
            ):

                print(
                    f"  Processed "
                    f"{processed:,} samples"
                )

    print(
        "Inference complete."
    )

    return (
        np.asarray(
            true_labels,
            dtype=int,
        ),
        np.asarray(
            predicted_labels,
            dtype=int,
        ),
    )


# ============================================================
# CLOSED-SET EVALUATION
# ============================================================

def calculate_closed_set_results(
    y_true: np.ndarray,
    y_pred: np.ndarray,
    families: np.ndarray,
):

    known_mask = np.isin(
        families,
        list(
            KNOWN_FAMILIES
        ),
    )

    known_true = y_true[
        known_mask
    ]

    known_pred = y_pred[
        known_mask
    ]

    report = classification_report(
        known_true,
        known_pred,
        labels=list(
            range(NUM_CLASSES)
        ),
        target_names=CLASS_NAMES,
        output_dict=True,
        zero_division=0,
    )

    records = []

    for class_name in CLASS_NAMES:

        values = report[
            class_name
        ]

        records.append(
            {
                "Class": class_name,
                "Precision": float(
                    values[
                        "precision"
                    ]
                    * 100
                ),
                "Recall": float(
                    values[
                        "recall"
                    ]
                    * 100
                ),
                "F1": float(
                    values[
                        "f1-score"
                    ]
                    * 100
                ),
                "Support": int(
                    values[
                        "support"
                    ]
                ),
            }
        )

    accuracy = accuracy_score(
        known_true,
        known_pred,
    )

    weighted_f1 = report[
        "weighted avg"
    ][
        "f1-score"
    ]

    return (
        records,
        known_true,
        known_pred,
        float(
            accuracy
        ),
        float(
            weighted_f1
        ),
    )


# ============================================================
# CONFUSION MATRIX
# ============================================================

def calculate_confusion_matrix(
    known_true: np.ndarray,
    known_pred: np.ndarray,
) -> np.ndarray:

    return confusion_matrix(
        known_true,
        known_pred,
        labels=list(
            range(NUM_CLASSES)
        ),
    )


# ============================================================
# SAVE PER-CLASS CSV
# ============================================================

def save_per_class_csv(
    records: List[Dict[str, Any]],
) -> Path:

    path = (
        OUTPUT_DIR
        / "adaptive_fedavg_v2_per_class.csv"
    )

    df = pd.DataFrame(
        records
    )

    df.to_csv(
        path,
        index=False,
        encoding="utf-8-sig",
    )

    return path


# ============================================================
# SAVE CONFUSION MATRIX CSV
# ============================================================

def save_confusion_matrix_csv(
    cm: np.ndarray,
) -> Path:

    path = (
        OUTPUT_DIR
        / "adaptive_fedavg_v2_confusion_matrix.csv"
    )

    df = pd.DataFrame(
        cm,
        index=CLASS_NAMES,
        columns=CLASS_NAMES,
    )

    df.index.name = (
        "True / Predicted"
    )

    df.to_csv(
        path,
        encoding="utf-8-sig",
    )

    return path


# ============================================================
# SAVE JSON
# ============================================================

def save_json_results(
    records: List[Dict[str, Any]],
    cm: np.ndarray,
    accuracy: float,
    weighted_f1: float,
    test_samples: int,
    known_samples: int,
    unknown_samples: int,
) -> Path:

    data = {

        "experiment":
            "Adaptive FedAvg v2 Per-Class Test Evaluation",

        "scenario":
            SCENARIO,

        "source":
            "Direct evaluation using existing Adaptive FedAvg v2 "
            "model and existing Scenario-C test dataset",

        "test_samples":
            int(test_samples),

        "known_samples":
            int(known_samples),

        "unknown_samples":
            int(unknown_samples),

        "accuracy":
            float(accuracy),

        "weighted_f1":
            float(weighted_f1),

        "classes":
            CLASS_NAMES,

        "per_class":
            records,

        "confusion_matrix":
            {
                "labels":
                    CLASS_NAMES,

                "matrix":
                    cm.astype(
                        int
                    ).tolist(),
            },
    }

    path = (
        OUTPUT_DIR
        / "adaptive_fedavg_v2_per_class.json"
    )

    with path.open(
        "w",
        encoding="utf-8",
    ) as f:

        json.dump(
            data,
            f,
            indent=4,
        )

    return path


# ============================================================
# SAVE SUMMARY TXT
# ============================================================

def save_summary(
    records: List[Dict[str, Any]],
    accuracy: float,
    weighted_f1: float,
    test_samples: int,
    known_samples: int,
    unknown_samples: int,
) -> Path:

    macro_precision = np.mean(
        [
            row[
                "Precision"
            ]
            for row in records
        ]
    )

    macro_recall = np.mean(
        [
            row[
                "Recall"
            ]
            for row in records
        ]
    )

    macro_f1 = np.mean(
        [
            row[
                "F1"
            ]
            for row in records
        ]
    )

    lines = [

        "AEFL-OSIDS ADAPTIVE FEDAVG V2 PER-CLASS TEST RESULTS",

        "=" * 72,

        f"Scenario             : {SCENARIO}",

        f"Test samples         : {test_samples:,}",

        f"Known samples        : {known_samples:,}",

        f"Unknown samples      : {unknown_samples:,}",

        "",

        "KNOWN-FAMILY CLOSED-SET PERFORMANCE",

        "-" * 72,

        (
            f"{'Class':<15}"
            f"{'Precision':>12}"
            f"{'Recall':>12}"
            f"{'F1':>12}"
            f"{'Support':>14}"
        ),

        "-" * 72,
    ]

    for row in records:

        lines.append(
            f"{row['Class']:<15}"
            f"{row['Precision']:>11.2f}%"
            f"{row['Recall']:>11.2f}%"
            f"{row['F1']:>11.2f}%"
            f"{row['Support']:>14,}"
        )

    lines.extend(

        [

            "-" * 72,

            (
                f"{'Macro Average':<15}"
                f"{macro_precision:>11.2f}%"
                f"{macro_recall:>11.2f}%"
                f"{macro_f1:>11.2f}%"
            ),

            "",

            f"Closed-set Accuracy : {accuracy * 100:.4f}%",

            f"Weighted F1         : {weighted_f1 * 100:.4f}%",

            "",

            "INTERPRETATION",

            "-" * 72,

            "The overall accuracy is dominated by the large",

            "DDoS and Mirai classes in the test distribution.",

            "",

            "Macro-F1 is substantially lower because BENIGN",

            "and DoS have weak recall while Recon has low precision.",

            "",

            "These per-class results explain the difference",

            "between high overall accuracy and lower Macro-F1.",

            "",

            "No model retraining was performed.",

            "No model weights were modified.",

            "No dataset preprocessing was performed.",

            "Results were generated from the existing trained model.",

        ]

    )

    path = (
        OUTPUT_DIR
        / "adaptive_fedavg_v2_per_class_summary.txt"
    )

    path.write_text(
        "\n".join(
            lines
        ),
        encoding="utf-8",
    )

    return path


# ============================================================
# PER-CLASS F1 PLOT
# ============================================================

def generate_f1_plot(
    records: List[Dict[str, Any]],
) -> Path:

    df = pd.DataFrame(
        records
    )

    plt.figure(
        figsize=(9, 6)
    )

    plt.bar(
        df["Class"],
        df["F1"],
    )

    plt.xlabel(
        "Attack Class"
    )

    plt.ylabel(
        "F1 Score (%)"
    )

    plt.title(
        "Adaptive FedAvg v2 Per-Class F1 Score"
    )

    plt.ylim(
        0,
        100,
    )

    plt.grid(
        True,
        axis="y",
        alpha=0.25,
    )

    for i, value in enumerate(
        df["F1"]
    ):

        plt.text(
            i,
            value + 1.5,
            f"{value:.2f}%",
            ha="center",
        )

    plt.tight_layout()

    path = (
        OUTPUT_DIR
        / "adaptive_fedavg_v2_per_class_f1.png"
    )

    plt.savefig(
        path,
        dpi=300,
        bbox_inches="tight",
    )

    plt.close()

    return path


# ============================================================
# CONFUSION MATRIX PLOT
# ============================================================

def generate_confusion_matrix_plot(
    cm: np.ndarray,
) -> Path:

    plt.figure(
        figsize=(8, 7)
    )

    plt.imshow(
        cm,
        aspect="auto",
    )

    plt.colorbar(
        label="Number of Samples"
    )

    plt.xticks(
        range(NUM_CLASSES),
        CLASS_NAMES,
        rotation=30,
        ha="right",
    )

    plt.yticks(
        range(NUM_CLASSES),
        CLASS_NAMES,
    )

    plt.xlabel(
        "Predicted Class"
    )

    plt.ylabel(
        "True Class"
    )

    plt.title(
        "Adaptive FedAvg v2 Confusion Matrix"
    )

    for i in range(
        NUM_CLASSES
    ):

        for j in range(
            NUM_CLASSES
        ):

            plt.text(
                j,
                i,
                f"{cm[i, j]:,}",
                ha="center",
                va="center",
            )

    plt.tight_layout()

    path = (
        OUTPUT_DIR
        / "adaptive_fedavg_v2_confusion_matrix.png"
    )

    plt.savefig(
        path,
        dpi=300,
        bbox_inches="tight",
    )

    plt.close()

    return path


# ============================================================
# UNKNOWN FAMILY SUMMARY
# ============================================================

def save_unknown_family_summary(
    families: np.ndarray,
    y_pred: np.ndarray,
) -> Path:

    rows = []

    for family in sorted(
        UNKNOWN_FAMILIES
    ):

        mask = (
            families
            == family
        )

        support = int(
            mask.sum()
        )

        if support == 0:

            continue

        detected_unknown = 0

        # A prediction is considered UNKNOWN here when it does
        # not correspond to a known family. Since the classifier
        # itself outputs one of the five known classes, this value
        # is not inferred from argmax alone.
        #
        # Therefore this file only records family support.
        rows.append(
            {
                "Unknown Family":
                    family,

                "Samples":
                    support,
            }
        )

    path = (
        OUTPUT_DIR
        / "unknown_family_support.csv"
    )

    pd.DataFrame(
        rows
    ).to_csv(
        path,
        index=False,
        encoding="utf-8-sig",
    )

    return path


# ============================================================
# COPY PUBLICATION OUTPUTS
# ============================================================

def copy_to_paper_results(
    paths: List[Path],
) -> List[Path]:

    PAPER_RESULTS_DIR.mkdir(
        parents=True,
        exist_ok=True,
    )

    copied = []

    for source in paths:

        if (
            source is None
            or not source.exists()
            or not source.is_file()
        ):

            continue

        destination = (
            PAPER_RESULTS_DIR
            / source.name
        )

        shutil.copy2(
            source,
            destination,
        )

        copied.append(
            destination
        )

    return copied


# ============================================================
# MAIN
# ============================================================

def main():

    OUTPUT_DIR.mkdir(
        parents=True,
        exist_ok=True,
    )

    PAPER_RESULTS_DIR.mkdir(
        parents=True,
        exist_ok=True,
    )

    device = torch.device(
        "cuda"
        if torch.cuda.is_available()
        else "cpu"
    )

    print()
    print(
        "=" * 70
    )

    print(
        "AEFL-OSIDS ADAPTIVE FEDAVG V2 PER-CLASS TEST EVALUATION"
    )

    print(
        "=" * 70
    )

    print(
        f"Scenario : {SCENARIO}"
    )

    print(
        f"Model    : {MODEL_PATH}"
    )

    print(
        f"Device   : {device}"
    )

    # --------------------------------------------------------
    # MODEL
    # --------------------------------------------------------

    print()
    print(
        "Loading Adaptive FedAvg v2 model..."
    )

    model = load_model(
        device
    )

    print(
        "Model loaded successfully."
    )

    # --------------------------------------------------------
    # DATASET
    # --------------------------------------------------------

    print()
    print(
        "Loading Scenario-C test dataset..."
    )

    dataset = create_dataset(
        SCENARIO,
        "test",
    )

    print(
        f"Test samples: {len(dataset):,}"
    )

    # --------------------------------------------------------
    # FAMILY METADATA
    # --------------------------------------------------------

    print()
    print(
        "Loading attack-family metadata..."
    )

    families = (
        extract_attack_family_array(
            dataset
        )
    )

    if families is None:

        raise RuntimeError(
            "Attack-family metadata is not available "
            "in the Scenario-C test NPZ files."
        )

    if len(families) != len(
        dataset
    ):

        raise RuntimeError(
            "Attack-family metadata length does not "
            "match the test dataset."
        )

    print(
        f"Attack-family entries: "
        f"{len(families):,}"
    )

    print()
    print(
        "Test attack-family distribution:"
    )

    unique, counts = np.unique(
        families,
        return_counts=True,
    )

    family_distribution = dict(
        zip(
            unique.tolist(),
            counts.tolist(),
        )
    )

    for family in sorted(
        family_distribution
    ):

        print(
            f"  {family:<18}"
            f"{family_distribution[family]:>10,}"
        )

    # --------------------------------------------------------
    # INFERENCE
    # --------------------------------------------------------

    y_true, y_pred = run_inference(
        model,
        dataset,
        device,
    )

    # --------------------------------------------------------
    # CLOSED SET
    # --------------------------------------------------------

    print()
    print(
        "=" * 70
    )

    print(
        "CLOSED-SET KNOWN-FAMILY EVALUATION"
    )

    print(
        "=" * 70
    )

    (
        records,
        known_true,
        known_pred,
        accuracy,
        weighted_f1,
    ) = calculate_closed_set_results(
        y_true,
        y_pred,
        families,
    )

    print()
    print(
        f"Known samples: {len(known_true):,}"
    )

    print()

    print(
        f"{'Class':<15}"
        f"{'Precision':>12}"
        f"{'Recall':>12}"
        f"{'F1':>12}"
        f"{'Support':>14}"
    )

    print(
        "-" * 63
    )

    for row in records:

        print(
            f"{row['Class']:<15}"
            f"{row['Precision']:>11.2f}%"
            f"{row['Recall']:>11.2f}%"
            f"{row['F1']:>11.2f}%"
            f"{row['Support']:>14,}"
        )

    macro_precision = np.mean(
        [
            row["Precision"]
            for row in records
        ]
    )

    macro_recall = np.mean(
        [
            row["Recall"]
            for row in records
        ]
    )

    macro_f1 = np.mean(
        [
            row["F1"]
            for row in records
        ]
    )

    print(
        "-" * 63
    )

    print(
        f"{'Macro Average':<15}"
        f"{macro_precision:>11.2f}%"
        f"{macro_recall:>11.2f}%"
        f"{macro_f1:>11.2f}%"
    )

    print()

    print(
        f"Closed-set Accuracy: "
        f"{accuracy * 100:.4f}%"
    )

    print(
        f"Weighted F1: "
        f"{weighted_f1 * 100:.4f}%"
    )

    # --------------------------------------------------------
    # CONFUSION MATRIX
    # --------------------------------------------------------

    cm = calculate_confusion_matrix(
        known_true,
        known_pred,
    )

    # --------------------------------------------------------
    # UNKNOWN SUPPORT
    # --------------------------------------------------------

    unknown_mask = np.isin(
        families,
        list(
            UNKNOWN_FAMILIES
        ),
    )

    unknown_samples = int(
        unknown_mask.sum()
    )

    known_samples = int(
        (~unknown_mask).sum()
    )

    # --------------------------------------------------------
    # SAVE
    # --------------------------------------------------------

    print()
    print(
        "Saving results..."
    )

    per_class_csv = save_per_class_csv(
        records
    )

    cm_csv = save_confusion_matrix_csv(
        cm
    )

    json_path = save_json_results(
        records=records,
        cm=cm,
        accuracy=accuracy,
        weighted_f1=weighted_f1,
        test_samples=len(dataset),
        known_samples=known_samples,
        unknown_samples=unknown_samples,
    )

    summary_path = save_summary(
        records=records,
        accuracy=accuracy,
        weighted_f1=weighted_f1,
        test_samples=len(dataset),
        known_samples=known_samples,
        unknown_samples=unknown_samples,
    )

    f1_plot = generate_f1_plot(
        records
    )

    cm_plot = generate_confusion_matrix_plot(
        cm
    )

    unknown_support = save_unknown_family_summary(
        families,
        y_pred,
    )

    # --------------------------------------------------------
    # COPY TO PAPER RESULTS
    # --------------------------------------------------------

    publication_files = copy_to_paper_results(
        [
            per_class_csv,
            cm_csv,
            json_path,
            summary_path,
            f1_plot,
            cm_plot,
            unknown_support,
        ]
    )

    # --------------------------------------------------------
    # FINAL
    # --------------------------------------------------------

    print()
    print(
        "=" * 70
    )

    print(
        "PER-CLASS RESULTS GENERATION COMPLETE"
    )

    print(
        "=" * 70
    )

    print()
    print(
        "Important:"
    )

    print(
        "The model was NOT retrained."
    )

    print(
        "The model weights were NOT modified."
    )

    print(
        "The existing Scenario-C test data was used."
    )

    print()

    print(
        f"Closed-set Accuracy : "
        f"{accuracy * 100:.4f}%"
    )

    print(
        f"Macro Precision     : "
        f"{macro_precision:.4f}%"
    )

    print(
        f"Macro Recall        : "
        f"{macro_recall:.4f}%"
    )

    print(
        f"Macro F1            : "
        f"{macro_f1:.4f}%"
    )

    print(
        f"Weighted F1         : "
        f"{weighted_f1 * 100:.4f}%"
    )

    print()

    print(
        "Saved to:"
    )

    print(
        f"  {OUTPUT_DIR}"
    )

    print()

    print(
        "Publication copies:"
    )

    for path in publication_files:

        print(
            f"  {path.name}"
        )

    print(
        "=" * 70
    )


# ============================================================
# ENTRY POINT
# ============================================================

if __name__ == "__main__":

    main()