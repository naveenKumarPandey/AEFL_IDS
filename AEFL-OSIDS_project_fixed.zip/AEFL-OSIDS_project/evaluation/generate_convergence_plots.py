"""
AEFL-OSIDS
Adaptive FedAvg v2 Convergence Plot Generator

Purpose:
    Generate publication-ready convergence plots from the
    EXISTING Adaptive FedAvg v2 round_history.json.

IMPORTANT:
    - No model training
    - No dataset processing
    - No modification of model weights
    - No fabricated values

Input:
    results/adaptive_fedavg_v2/round_history.json

Output:
    results/paper_results/
"""

from __future__ import annotations

import json
from pathlib import Path

import matplotlib.pyplot as plt
import pandas as pd


# ============================================================
# PATHS
# ============================================================

PROJECT_ROOT = Path(__file__).resolve().parents[1]

HISTORY_PATH = (
    PROJECT_ROOT
    / "results"
    / "adaptive_fedavg_v2"
    / "round_history.json"
)

OUTPUT_DIR = (
    PROJECT_ROOT
    / "results"
    / "paper_results"
)


# ============================================================
# CONFIGURATION
# ============================================================

METHOD_NAME = "Adaptive FedAvg v2"


# ============================================================
# LOAD HISTORY
# ============================================================

def load_history() -> list:
    """
    Load the actual completed FL round history.
    """

    if not HISTORY_PATH.exists():
        raise FileNotFoundError(
            f"Round history not found:\n{HISTORY_PATH}"
        )

    with HISTORY_PATH.open(
        "r",
        encoding="utf-8",
    ) as file:

        data = json.load(file)

    if not isinstance(data, list):
        raise ValueError(
            "Expected round_history.json to contain a list."
        )

    if not data:
        raise ValueError(
            "round_history.json is empty."
        )

    return data


# ============================================================
# EXTRACT VALIDATION HISTORY
# ============================================================

def extract_validation_history(
    history: list,
) -> pd.DataFrame:
    """
    Extract:

        round
        validation loss
        validation accuracy
        validation macro precision
        validation macro recall
        validation macro F1
        validation weighted F1

    The actual JSON structure is:

        {
            "round": 1,
            "validation": {
                "loss": ...,
                "accuracy": ...,
                "precision_macro": ...,
                "recall_macro": ...,
                "f1_macro": ...,
                "f1_weighted": ...
            }
        }
    """

    records = []

    for item in history:

        if not isinstance(item, dict):
            continue

        round_number = item.get(
            "round"
        )

        validation = item.get(
            "validation"
        )

        if round_number is None:
            continue

        if not isinstance(validation, dict):
            continue

        required = [
            "loss",
            "accuracy",
            "precision_macro",
            "recall_macro",
            "f1_macro",
            "f1_weighted",
        ]

        missing = [
            key
            for key in required
            if key not in validation
        ]

        if missing:
            raise KeyError(
                f"Round {round_number} is missing "
                f"validation fields: {missing}"
            )

        records.append(
            {
                "Method": METHOD_NAME,
                "Round": int(round_number),

                "Validation Loss":
                    float(
                        validation["loss"]
                    ),

                "Validation Accuracy":
                    float(
                        validation["accuracy"]
                    ),

                "Validation Macro Precision":
                    float(
                        validation[
                            "precision_macro"
                        ]
                    ),

                "Validation Macro Recall":
                    float(
                        validation[
                            "recall_macro"
                        ]
                    ),

                "Validation Macro F1":
                    float(
                        validation[
                            "f1_macro"
                        ]
                    ),

                "Validation Weighted F1":
                    float(
                        validation[
                            "f1_weighted"
                        ]
                    ),
            }
        )

    if not records:
        raise RuntimeError(
            "No valid validation records were found."
        )

    df = pd.DataFrame(
        records
    )

    df = df.sort_values(
        "Round"
    ).reset_index(
        drop=True
    )

    return df


# ============================================================
# SAVE CSV
# ============================================================

def save_convergence_csv(
    df: pd.DataFrame,
) -> Path:

    OUTPUT_DIR.mkdir(
        parents=True,
        exist_ok=True,
    )

    output_path = (
        OUTPUT_DIR
        / "adaptive_fedavg_v2_convergence_data.csv"
    )

    df.to_csv(
        output_path,
        index=False,
        encoding="utf-8-sig",
    )

    return output_path


# ============================================================
# PLOT HELPER
# ============================================================

def create_plot(
    df: pd.DataFrame,
    metric_column: str,
    ylabel: str,
    title: str,
    filename: str,
    percentage: bool = False,
):
    """
    Generate one publication-quality plot.
    """

    plt.figure(
        figsize=(8, 5)
    )

    values = (
        df[metric_column]
        * 100.0
        if percentage
        else df[metric_column]
    )

    plt.plot(
        df["Round"],
        values,
        marker="o",
        linewidth=2,
        label=METHOD_NAME,
    )

    plt.xlabel(
        "Federated Learning Round"
    )

    plt.ylabel(
        ylabel
    )

    plt.title(
        title
    )

    plt.xticks(
        df["Round"]
    )

    plt.grid(
        True,
        alpha=0.25,
    )

    plt.legend()

    plt.tight_layout()

    output_path = (
        OUTPUT_DIR
        / filename
    )

    plt.savefig(
        output_path,
        dpi=300,
        bbox_inches="tight",
    )

    plt.close()

    return output_path


# ============================================================
# GENERATE ALL PLOTS
# ============================================================

def generate_plots(
    df: pd.DataFrame,
):
    """
    Generate:

        1. Validation Accuracy
        2. Validation Macro-F1
        3. Validation Loss
    """

    accuracy_path = create_plot(
        df=df,
        metric_column="Validation Accuracy",
        ylabel="Validation Accuracy (%)",
        title="Adaptive FedAvg v2 Validation Accuracy",
        filename="fl_convergence_accuracy.png",
        percentage=True,
    )

    macro_f1_path = create_plot(
        df=df,
        metric_column="Validation Macro F1",
        ylabel="Validation Macro F1 (%)",
        title="Adaptive FedAvg v2 Macro-F1 Convergence",
        filename="fl_convergence_macro_f1.png",
        percentage=True,
    )

    loss_path = create_plot(
        df=df,
        metric_column="Validation Loss",
        ylabel="Validation Loss",
        title="Adaptive FedAvg v2 Validation Loss",
        filename="fl_convergence_loss.png",
        percentage=False,
    )

    return (
        accuracy_path,
        macro_f1_path,
        loss_path,
    )


# ============================================================
# SUMMARY
# ============================================================

def generate_summary(
    df: pd.DataFrame,
) -> Path:
    """
    Generate a text summary using only actual values.
    """

    first = df.iloc[0]
    last = df.iloc[-1]

    accuracy_change = (
        last["Validation Accuracy"]
        - first["Validation Accuracy"]
    ) * 100.0

    macro_f1_change = (
        last["Validation Macro F1"]
        - first["Validation Macro F1"]
    ) * 100.0

    loss_change = (
        last["Validation Loss"]
        - first["Validation Loss"]
    )

    best_accuracy_row = df.loc[
        df["Validation Accuracy"].idxmax()
    ]

    best_macro_f1_row = df.loc[
        df["Validation Macro F1"].idxmax()
    ]

    lowest_loss_row = df.loc[
        df["Validation Loss"].idxmin()
    ]

    lines = [

        "AEFL-OSIDS ADAPTIVE FEDAVG V2 CONVERGENCE SUMMARY",
        "=" * 72,

        "",
        "SOURCE",
        "-" * 72,

        f"Input file: {HISTORY_PATH}",
        f"Method: {METHOD_NAME}",
        f"Completed rounds: {len(df)}",

        "",
        "ROUND-WISE VALIDATION RESULTS",
        "-" * 72,

        (
            "Round | Accuracy (%) | Macro Precision (%) | "
            "Macro Recall (%) | Macro F1 (%) | Weighted F1 (%) | Loss"
        ),

    ]

    for _, row in df.iterrows():

        lines.append(
            f"{int(row['Round']):5d} | "
            f"{row['Validation Accuracy'] * 100:12.4f} | "
            f"{row['Validation Macro Precision'] * 100:19.4f} | "
            f"{row['Validation Macro Recall'] * 100:17.4f} | "
            f"{row['Validation Macro F1'] * 100:13.4f} | "
            f"{row['Validation Weighted F1'] * 100:16.4f} | "
            f"{row['Validation Loss']:.6f}"
        )

    lines.extend(

        [

            "",
            "CONVERGENCE CHANGE",
            "-" * 72,

            (
                f"Accuracy change R1 -> R{int(last['Round'])}: "
                f"{accuracy_change:+.4f} percentage points"
            ),

            (
                f"Macro-F1 change R1 -> R{int(last['Round'])}: "
                f"{macro_f1_change:+.4f} percentage points"
            ),

            (
                f"Loss change R1 -> R{int(last['Round'])}: "
                f"{loss_change:+.6f}"
            ),

            "",
            "BEST OBSERVED VALUES",
            "-" * 72,

            (
                f"Best validation accuracy : "
                f"{best_accuracy_row['Validation Accuracy'] * 100:.4f}% "
                f"(Round {int(best_accuracy_row['Round'])})"
            ),

            (
                f"Best validation Macro-F1 : "
                f"{best_macro_f1_row['Validation Macro F1'] * 100:.4f}% "
                f"(Round {int(best_macro_f1_row['Round'])})"
            ),

            (
                f"Lowest validation loss    : "
                f"{lowest_loss_row['Validation Loss']:.6f} "
                f"(Round {int(lowest_loss_row['Round'])})"
            ),

            "",
            "FINAL ROUND",
            "-" * 72,

            (
                f"Final validation accuracy : "
                f"{last['Validation Accuracy'] * 100:.4f}%"
            ),

            (
                f"Final validation macro-F1 : "
                f"{last['Validation Macro F1'] * 100:.4f}%"
            ),

            (
                f"Final validation loss     : "
                f"{last['Validation Loss']:.6f}"
            ),

            (
                f"Final weighted F1         : "
                f"{last['Validation Weighted F1'] * 100:.4f}%"
            ),

            "",
            "IMPORTANT",
            "-" * 72,

            (
                "These convergence values are the actual validation "
                "metrics stored in round_history.json."
            ),

            (
                "No model training, test-set evaluation, or metric "
                "fabrication was performed by this script."
            ),

        ]

    )

    output_path = (
        OUTPUT_DIR
        / "adaptive_fedavg_v2_convergence_summary.txt"
    )

    output_path.write_text(
        "\n".join(lines),
        encoding="utf-8",
    )

    return output_path


# ============================================================
# PRINT TABLE
# ============================================================

def print_results(
    df: pd.DataFrame,
):
    print()
    print(
        "=" * 72
    )

    print(
        "ROUND-WISE VALIDATION RESULTS"
    )

    print(
        "=" * 72
    )

    for _, row in df.iterrows():

        print(
            f"Round {int(row['Round'])}:"
        )

        print(
            f"  Accuracy      : "
            f"{row['Validation Accuracy'] * 100:.4f}%"
        )

        print(
            f"  Macro Precision: "
            f"{row['Validation Macro Precision'] * 100:.4f}%"
        )

        print(
            f"  Macro Recall  : "
            f"{row['Validation Macro Recall'] * 100:.4f}%"
        )

        print(
            f"  Macro F1      : "
            f"{row['Validation Macro F1'] * 100:.4f}%"
        )

        print(
            f"  Weighted F1   : "
            f"{row['Validation Weighted F1'] * 100:.4f}%"
        )

        print(
            f"  Loss          : "
            f"{row['Validation Loss']:.6f}"
        )

        print()


# ============================================================
# MAIN
# ============================================================

def main():

    print(
        "=" * 70
    )

    print(
        "AEFL-OSIDS ADAPTIVE FEDAVG V2 CONVERGENCE PLOTS"
    )

    print(
        "=" * 70
    )

    print()
    print(
        "Using actual completed round-history results."
    )

    print(
        "No model training will be performed."
    )

    print(
        f"Input: {HISTORY_PATH}"
    )

    print(
        f"Output: {OUTPUT_DIR}"
    )

    # --------------------------------------------------------
    # LOAD
    # --------------------------------------------------------

    history = load_history()

    # --------------------------------------------------------
    # EXTRACT
    # --------------------------------------------------------

    df = extract_validation_history(
        history
    )

    # --------------------------------------------------------
    # PRINT
    # --------------------------------------------------------

    print_results(
        df
    )

    # --------------------------------------------------------
    # SAVE CSV
    # --------------------------------------------------------

    csv_path = save_convergence_csv(
        df
    )

    # --------------------------------------------------------
    # PLOTS
    # --------------------------------------------------------

    (
        accuracy_path,
        macro_f1_path,
        loss_path,
    ) = generate_plots(
        df
    )

    # --------------------------------------------------------
    # SUMMARY
    # --------------------------------------------------------

    summary_path = generate_summary(
        df
    )

    # --------------------------------------------------------
    # FINAL
    # --------------------------------------------------------

    print(
        "=" * 70
    )

    print(
        "CONVERGENCE PLOTS GENERATED SUCCESSFULLY"
    )

    print(
        "=" * 70
    )

    print()
    print(
        f"Rounds used: {len(df)}"
    )

    print(
        f"CSV     : {csv_path}"
    )

    print(
        f"Accuracy: {accuracy_path}"
    )

    print(
        f"Macro-F1: {macro_f1_path}"
    )

    print(
        f"Loss    : {loss_path}"
    )

    print(
        f"Summary : {summary_path}"
    )

    print(
        "=" * 70
    )


# ============================================================
# ENTRY POINT
# ============================================================

if __name__ == "__main__":
    main()