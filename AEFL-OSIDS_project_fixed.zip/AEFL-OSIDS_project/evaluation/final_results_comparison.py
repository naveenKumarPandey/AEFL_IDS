"""
AEFL-OSIDS FINAL RESULTS COMPARISON
===================================

Reads the existing experiment result files and creates:
    results/final_comparison/final_comparison.json
    results/final_comparison/classification_comparison.csv
    results/final_comparison/summary.txt

IMPORTANT:
This script does NOT train, evaluate, or modify any model.
It only reads already-generated result JSON files.

The final open-set JSON has nested structures:
    unknown_detection
    known_class_performance

This version explicitly handles those structures.
"""

from pathlib import Path
import json
import csv


ROOT = Path(__file__).resolve().parents[1]
RESULTS = ROOT / "results"
OUT = RESULTS / "final_comparison"
OUT.mkdir(parents=True, exist_ok=True)


def read_json(path):
    if not path.exists():
        return None
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def first_file(directory, names):
    for name in names:
        data = read_json(directory / name)
        if data is not None:
            return data
    return None


def get_metric(data, *names):
    """Read a metric from common result layouts."""
    if not isinstance(data, dict):
        return None

    # Direct level
    for name in names:
        if name in data:
            return data[name]

    # Common nested containers
    for container_name in (
        "metrics",
        "final_metrics",
        "validation_metrics",
        "results",
    ):
        container = data.get(container_name)
        if isinstance(container, dict):
            for name in names:
                if name in container:
                    return container[name]

    return None


def classification_metrics(data):
    return {
        "accuracy": get_metric(data, "accuracy", "val_accuracy"),
        "macro_precision": get_metric(
            data, "macro_precision", "precision_macro"
        ),
        "macro_recall": get_metric(
            data, "macro_recall", "recall_macro"
        ),
        "macro_f1": get_metric(data, "macro_f1", "f1_macro"),
        "weighted_f1": get_metric(
            data, "weighted_f1", "f1_weighted"
        ),
        "loss": get_metric(
            data, "loss", "validation_loss", "val_loss"
        ),
    }


def extract_open_set(data):
    """
    Exact structure of final_open_set_results.json:

    {
        "locked_threshold": ...,
        "unknown_detection": {
            "precision": ...,
            "recall": ...,
            "f1": ...,
            "known_fpr": ...
        },
        "known_class_performance": {
            "accuracy": ...,
            "macro_precision": ...,
            "macro_recall": ...,
            "macro_f1": ...
        },
        "open_set_auroc": ...
    }
    """
    if not isinstance(data, dict):
        return {
            "locked_threshold": None,
            "unknown_precision": None,
            "unknown_recall": None,
            "unknown_f1": None,
            "known_fpr": None,
            "known_accuracy": None,
            "known_macro_precision": None,
            "known_macro_recall": None,
            "known_macro_f1": None,
            "open_set_auroc": None,
            "test_samples": None,
            "unknown_families": [],
        }

    unknown = data.get("unknown_detection") or {}
    known = data.get("known_class_performance") or {}

    return {
        "locked_threshold": data.get("locked_threshold"),
        "unknown_precision": unknown.get("precision"),
        "unknown_recall": unknown.get("recall"),
        "unknown_f1": unknown.get("f1"),
        "known_fpr": unknown.get("known_fpr"),
        "known_accuracy": known.get("accuracy"),
        "known_macro_precision": known.get("macro_precision"),
        "known_macro_recall": known.get("macro_recall"),
        "known_macro_f1": known.get("macro_f1"),
        "open_set_auroc": data.get("open_set_auroc"),
        "test_samples": data.get("test_samples"),
        "unknown_families": data.get("unknown_families", []),
    }


def percent(value):
    if value is None:
        return "N/A"
    return f"{float(value) * 100:.2f}%"


def number(value):
    if value is None:
        return "N/A"
    return f"{float(value):.6f}"


def build_classification_results():
    locations = {
        "Centralized Baseline": RESULTS / "centralized_baseline",
        "FedAvg": RESULTS / "fedavg",
        "Adaptive FedAvg (v1)": RESULTS / "adaptive_fedavg",
        "Adaptive FedAvg (v2)": RESULTS / "adaptive_fedavg_v2",
    }

    file_candidates = [
        "final_metrics.json",
        "validation_metrics.json",
    ]

    rows = []
    status = {}

    for method, directory in locations.items():
        data = first_file(directory, file_candidates)
        status[method] = data is not None

        metrics = classification_metrics(data)

        rows.append({
            "Method": method,
            "Accuracy": metrics["accuracy"],
            "Macro Precision": metrics["macro_precision"],
            "Macro Recall": metrics["macro_recall"],
            "Macro F1": metrics["macro_f1"],
            "Weighted F1": metrics["weighted_f1"],
            "Loss": metrics["loss"],
        })

    return rows, status


def write_csv(rows):
    path = OUT / "classification_comparison.csv"

    fields = [
        "Method",
        "Accuracy",
        "Macro Precision",
        "Macro Recall",
        "Macro F1",
        "Weighted F1",
        "Loss",
    ]

    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)

    return path


def write_summary(rows, open_set, shap):
    path = OUT / "summary.txt"

    lines = [
        "AEFL-OSIDS FINAL EXPERIMENT SUMMARY",
        "=" * 70,
        "Scenario: scenario_C_multiple",
        "",
        "KNOWN-CLASS CLASSIFICATION COMPARISON",
        "-" * 70,
        f"{'Method':30s}{'Acc':>9s}{'Macro-P':>11s}"
        f"{'Macro-R':>11s}{'Macro-F1':>11s}{'Weighted-F1':>14s}",
        "-" * 70,
    ]

    for row in rows:
        lines.append(
            f"{row['Method']:30s}"
            f"{percent(row['Accuracy']):>9s}"
            f"{percent(row['Macro Precision']):>11s}"
            f"{percent(row['Macro Recall']):>11s}"
            f"{percent(row['Macro F1']):>11s}"
            f"{percent(row['Weighted F1']):>14s}"
        )

    lines += [
        "",
        "FINAL OPEN-SET EVALUATION",
        "-" * 70,
        f"Locked threshold         : {number(open_set['locked_threshold'])}",
        f"Unknown precision        : {percent(open_set['unknown_precision'])}",
        f"Unknown recall           : {percent(open_set['unknown_recall'])}",
        f"Unknown F1               : {percent(open_set['unknown_f1'])}",
        f"Known FPR                : {percent(open_set['known_fpr'])}",
        f"Open-set AUROC           : {percent(open_set['open_set_auroc'])}",
        f"Known accuracy           : {percent(open_set['known_accuracy'])}",
        f"Known macro precision    : {percent(open_set['known_macro_precision'])}",
        f"Known macro recall       : {percent(open_set['known_macro_recall'])}",
        f"Known macro F1           : {percent(open_set['known_macro_f1'])}",
        f"Test samples             : {open_set['test_samples'] if open_set['test_samples'] is not None else 'N/A'}",
        "Unknown families         : "
        + (", ".join(open_set["unknown_families"])
           if open_set["unknown_families"] else "N/A"),
        "",
        "SHAP CONFIGURATION",
        "-" * 70,
    ]

    if isinstance(shap, dict):
        feature_count = shap.get("feature_count", shap.get("features", 39))
        explained = shap.get(
            "explanation_samples",
            shap.get("samples_explained", 100),
        )
        background = shap.get("background_samples", 50)
    else:
        feature_count = 39
        explained = 100
        background = 50

    lines += [
        f"Features                 : {feature_count}",
        f"Samples explained        : {explained}",
        f"Background samples      : {background}",
        "",
    ]

    path.write_text("\n".join(lines), encoding="utf-8")
    return path


def main():
    print("=" * 70)
    print("AEFL-OSIDS FINAL RESULTS COMPARISON")
    print("=" * 70)

    rows, status = build_classification_results()

    for method, found in status.items():
        print(f"{method:<30}: {'FOUND' if found else 'MISSING'}")

    # Read the exact final open-set result file.
    open_set_path = (
        RESULTS / "final_open_set" / "final_open_set_results.json"
    )
    open_set_raw = read_json(open_set_path)
    open_set = extract_open_set(open_set_raw)

    if open_set_raw is None:
        print("WARNING: final_open_set_results.json was not found.")
    else:
        print("Final open-set results   : FOUND")

    # Read SHAP metadata if available.
    shap_path = (
        RESULTS / "shap" / "scenario_C_multiple" / "shap_metadata.json"
    )
    shap = read_json(shap_path)

    csv_path = write_csv(rows)

    consolidated = {
        "scenario": "scenario_C_multiple",
        "classification_comparison": rows,
        "open_set_evaluation": open_set,
        "shap_configuration": {
            "feature_count": (
                shap.get("feature_count", 39)
                if isinstance(shap, dict)
                else 39
            ),
            "samples_explained": (
                shap.get("explanation_samples", 100)
                if isinstance(shap, dict)
                else 100
            ),
            "background_samples": (
                shap.get("background_samples", 50)
                if isinstance(shap, dict)
                else 50
            ),
        },
    }

    json_path = OUT / "final_comparison.json"
    with json_path.open("w", encoding="utf-8") as f:
        json.dump(consolidated, f, indent=4)

    summary_path = write_summary(rows, open_set, shap)

    print()
    print("=" * 70)
    print("FINAL COMPARISON COMPLETE")
    print("=" * 70)
    print(f"JSON : {json_path}")
    print(f"CSV  : {csv_path}")
    print(f"Report: {summary_path}")
    print("=" * 70)


if __name__ == "__main__":
    main()
