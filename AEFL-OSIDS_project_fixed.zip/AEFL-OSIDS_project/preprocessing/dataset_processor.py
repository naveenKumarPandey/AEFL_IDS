from pathlib import Path
from typing import Dict, Optional

import joblib
import numpy as np
import pandas as pd
import shutil
from sklearn.preprocessing import StandardScaler

from utils.config import load_config

from preprocessing.data_loader import (
    DATASET_DIR,
    EXPECTED_FEATURE_COUNT,
)

from preprocessing.preprocessor import (
    FEATURE_COLUMNS,
    clean_dataframe,
)

from configs.labels import (
    OPEN_SET_SCENARIOS,
    build_label_mapping,
    get_unknown_label,
)


# ============================================================
# PROJECT PATHS
# ============================================================

PROJECT_ROOT = (
    Path(__file__).resolve().parents[1]
)

MANIFEST_DIR = (
    PROJECT_ROOT
    / "data"
    / "splits"
)

OUTPUT_DIR = (
    PROJECT_ROOT
    / "data"
    / "processed"
)


# ============================================================
# CONFIGURATION
# ============================================================

CONFIG = load_config()

EXPERIMENT_MODE = (
    CONFIG["experiment"]["mode"]
)

CHUNK_SIZE = (
    CONFIG["preprocessing"]["chunk_size"]
)

DEV_MAX_ROWS_PER_FILE = (
    CONFIG["experiment"]
    ["development"]
    ["max_rows_per_file"]
)

DEFAULT_SCENARIO = (
    CONFIG["openset"]
    ["primary_scenario"]
)


# ============================================================
# CONFIGURATION VALIDATION
# ============================================================

def validate_configuration() -> None:
    """
    Validate the important preprocessing configuration.
    """

    if EXPERIMENT_MODE not in {
        "development",
        "full",
    }:
        raise ValueError(
            "experiment.mode must be either "
            "'development' or 'full'. "
            f"Found: {EXPERIMENT_MODE}"
        )

    if CHUNK_SIZE <= 0:
        raise ValueError(
            "preprocessing.chunk_size must "
            "be greater than zero."
        )

    if (
        EXPERIMENT_MODE == "development"
        and DEV_MAX_ROWS_PER_FILE <= 0
    ):
        raise ValueError(
            "development.max_rows_per_file "
            "must be greater than zero."
        )

    if DEFAULT_SCENARIO not in (
        OPEN_SET_SCENARIOS
    ):
        raise ValueError(
            f"Primary scenario "
            f"'{DEFAULT_SCENARIO}' is not "
            f"defined in OPEN_SET_SCENARIOS."
        )


# ============================================================
# MANIFEST LOADER
# ============================================================

def load_manifest(
    scenario_name: str,
) -> pd.DataFrame:
    """
    Load an already generated split manifest.
    """

    manifest_path = (
        MANIFEST_DIR
        / f"{scenario_name}.csv"
    )

    if not manifest_path.exists():
        raise FileNotFoundError(
            f"Manifest not found:\n"
            f"{manifest_path}\n\n"
            f"Run split_manifest.py first."
        )

    manifest = pd.read_csv(
        manifest_path
    )

    required_columns = {
        "file_path",
        "detailed_label",
        "attack_family",
        "split",
        "known_unknown",
        "scenario",
    }

    missing_columns = (
        required_columns
        - set(manifest.columns)
    )

    if missing_columns:
        raise ValueError(
            "Manifest is missing columns: "
            f"{sorted(missing_columns)}"
        )

    if manifest.empty:
        raise ValueError(
            f"Manifest is empty:\n"
            f"{manifest_path}"
        )

    return manifest


# ============================================================
# DEVELOPMENT ROW LIMIT
# ============================================================

def get_max_rows_per_file() -> Optional[int]:
    """
    Return the maximum number of rows to process
    from each CSV file.

    Development:
        limited rows

    Full:
        None
    """

    if EXPERIMENT_MODE == "development":
        return DEV_MAX_ROWS_PER_FILE

    return None


# ============================================================
# CSV CHUNK LOADER
# ============================================================

def load_clean_chunks(
    csv_path: Path,
    max_rows: Optional[int] = None,
):
    """
    Read and clean one CSV file chunk-by-chunk.

    Parameters
    ----------
    csv_path:
        Path of the source CSV.

    max_rows:
        Maximum number of rows to process from
        this CSV.

        None means the complete CSV is processed.
    """

    if not csv_path.exists():
        raise FileNotFoundError(
            f"CSV file not found:\n"
            f"{csv_path}"
        )

    rows_seen = 0

    for chunk in pd.read_csv(
        csv_path,
        chunksize=CHUNK_SIZE,
    ):

        # ----------------------------------------------------
        # Development limit
        # ----------------------------------------------------

        if max_rows is not None:

            remaining = (
                max_rows - rows_seen
            )

            if remaining <= 0:
                break

            if len(chunk) > remaining:

                chunk = chunk.iloc[
                    :remaining
                ].copy()

        # ----------------------------------------------------
        # Feature-count validation
        # ----------------------------------------------------

        if len(chunk.columns) != (
            EXPECTED_FEATURE_COUNT
        ):
            raise ValueError(
                f"\nInvalid feature count in:"
                f"\n{csv_path}"
                f"\nExpected: "
                f"{EXPECTED_FEATURE_COUNT}"
                f"\nFound: "
                f"{len(chunk.columns)}"
            )

        # ----------------------------------------------------
        # Determine detailed attack label
        # ----------------------------------------------------

        raw_label = (
            csv_path.parent.name
        )

        if raw_label == "Benign_Final":
            raw_label = "BENIGN"

        chunk["attack_label"] = (
            raw_label
        )

        chunk["source_file"] = (
            csv_path.name
        )

        # ----------------------------------------------------
        # Cleaning
        # ----------------------------------------------------

        cleaned = clean_dataframe(
            chunk,
            remove_duplicates=True,
        )

        if cleaned.empty:
            continue

        rows_seen += len(cleaned)

        yield cleaned

        # ----------------------------------------------------
        # Development limit
        # ----------------------------------------------------

        if (
            max_rows is not None
            and rows_seen >= max_rows
        ):
            break


# ============================================================
# FEATURE EXTRACTION
# ============================================================

def extract_features(
    df: pd.DataFrame,
) -> np.ndarray:
    """
    Extract the 39 network-flow features.
    """

    missing_features = [
        feature
        for feature in FEATURE_COLUMNS
        if feature not in df.columns
    ]

    if missing_features:
        raise ValueError(
            "Missing feature columns: "
            f"{missing_features}"
        )

    X = (
        df[FEATURE_COLUMNS]
        .to_numpy(
            dtype=np.float64
        )
    )

    # Replace infinity with NaN.
    X[
        ~np.isfinite(X)
    ] = np.nan

    return X


# ============================================================
# LABEL ENCODING
# ============================================================

def encode_labels(
    df: pd.DataFrame,
    label_mapping: Dict[str, int],
    unknown_label: int,
) -> np.ndarray:
    """
    Convert attack families into integer labels.

    Known families:
        0, 1, 2, ...

    Unknown families:
        -1
    """

    labels = []

    for family in df[
        "attack_family"
    ]:

        labels.append(
            label_mapping.get(
                family,
                unknown_label,
            )
        )

    return np.asarray(
        labels,
        dtype=np.int64,
    )


# ============================================================
# SCALER FITTING
# ============================================================

def fit_scaler(
    manifest: pd.DataFrame,
) -> StandardScaler:
    """
    Fit StandardScaler using TRAIN data only.

    IMPORTANT:
        Validation and test data are never
        used for fitting.
    """

    scaler = StandardScaler()

    train_manifest = manifest[
        manifest["split"] == "train"
    ]

    if train_manifest.empty:
        raise RuntimeError(
            "Training manifest is empty."
        )

    max_rows = (
        get_max_rows_per_file()
    )

    print()
    print("=" * 70)
    print("FITTING TRAIN-ONLY SCALER")
    print("=" * 70)

    print(
        f"\nExperiment mode: "
        f"{EXPERIMENT_MODE}"
    )

    if max_rows is None:

        print(
            "Rows per file: ALL"
        )

    else:

        print(
            f"Rows per file: "
            f"maximum {max_rows:,}"
        )

    total_rows = 0

    for index, (_, record) in enumerate(
        train_manifest.iterrows(),
        start=1,
    ):

        csv_path = (
            DATASET_DIR
            / record["file_path"]
        )

        print()
        print(
            f"[{index}/"
            f"{len(train_manifest)}] "
            f"{record['file_path']}"
        )

        for chunk in load_clean_chunks(
            csv_path,
            max_rows=max_rows,
        ):

            X = extract_features(
                chunk
            )

            valid_rows = np.isfinite(
                X
            ).all(axis=1)

            X = X[
                valid_rows
            ]

            if len(X) == 0:
                continue

            scaler.partial_fit(
                X
            )

            total_rows += len(X)

    if total_rows == 0:
        raise RuntimeError(
            "No valid training rows were "
            "found while fitting scaler."
        )

    print()
    print(
        f"Total rows used for scaler: "
        f"{total_rows:,}"
    )

    return scaler


# ============================================================
# SAVE PROCESSED CHUNK
# ============================================================

def save_chunk(
    X,
    y,
    output_path,
    attack_family=None,
    attack_label=None,
    source_file=None,
):
    """
    Save a processed chunk.

    Core training data:
        X
        y

    Metadata:
        attack_family
        attack_label
        source_file
    """

    data = {
        "X": X.astype(np.float32),
        "y": y.astype(np.int64),
    }

    if attack_family is not None:
        data["attack_family"] = np.asarray(
            attack_family
        )

    if attack_label is not None:
        data["attack_label"] = np.asarray(
            attack_label
        )

    if source_file is not None:
        data["source_file"] = np.asarray(
            source_file
        )

    np.savez_compressed(
        output_path,
        **data,
    )


# ============================================================
# PROCESS ONE CSV FILE
# ============================================================

def process_file(
    csv_path: Path,
    split_name: str,
    scaler: StandardScaler,
    label_mapping: Dict[str, int],
    unknown_label: int,
    output_dir: Path,
    file_index: int,
    seen_feature_hashes: set[int],
) -> int:
    """
    Process one CSV file chunk-by-chunk.

    The complete CSV is never accumulated
    in memory.
    """

    file_stem = (
        csv_path.stem
    )

    file_output_dir = (
        output_dir
        / split_name
        / file_stem
    )

    file_output_dir.mkdir(
        parents=True,
        exist_ok=True,
    )

    total_rows = 0
    chunk_index = 0

    max_rows = (
        get_max_rows_per_file()
    )

    for chunk in load_clean_chunks(
        csv_path,
        max_rows=max_rows,
    ):

        # ----------------------------------------------------
        # Features
        # ----------------------------------------------------

        X = extract_features(chunk)
        y = encode_labels(chunk, label_mapping, unknown_label)

        # ------------------------------------------------------------
        # METADATA
        # ------------------------------------------------------------

        attack_family = (
            chunk["attack_family"]
            .astype(str)
            .to_numpy()
        )

        attack_label = (
            chunk["attack_label"]
            .astype(str)
            .to_numpy()
        )

        # ``dtype=str`` creates NumPy's one-character ``<U1`` dtype for
        # np.full, truncating every filename to its first letter. Preserve the
        # complete source identity because leakage audits and file-level
        # evaluation depend on it.
        source_name = str(csv_path.name)
        source_file = np.full(
            len(chunk),
            source_name,
            dtype=f"<U{max(1, len(source_name))}",
        )

        # ------------------------------------------------------------
        # VALID ROW FILTER
        # ------------------------------------------------------------

        valid_rows = np.isfinite(X).all(axis=1)

        X = X[valid_rows]
        y = y[valid_rows]

        attack_family = attack_family[valid_rows]
        attack_label = attack_label[valid_rows]
        source_file = source_file[valid_rows]

        if len(X) == 0:
            continue

        X_scaled = scaler.transform(X).astype(np.float32, copy=False)

        # Deduplicate globally, not only within a CSV chunk. Processing order is
        # train -> validation -> test, so a feature row can belong to exactly
        # one split and evaluation cannot contain a verbatim training example.
        # Hash the exact float32 representation that will be saved and audited.
        feature_hashes = pd.util.hash_pandas_object(
            pd.DataFrame(np.ascontiguousarray(X_scaled)), index=False
        ).to_numpy(dtype=np.uint64)
        # Membership against the global set alone is insufficient because that
        # set is updated only after the mask is built. Track hashes observed in
        # this chunk as well so repeated float32 rows in the same chunk retain
        # only their first occurrence.
        unseen = np.empty(len(feature_hashes), dtype=bool)
        chunk_feature_hashes: set[int] = set()
        for row_index, value in enumerate(feature_hashes):
            feature_hash = int(value)
            keep_row = (
                feature_hash not in seen_feature_hashes
                and feature_hash not in chunk_feature_hashes
            )
            unseen[row_index] = keep_row
            if keep_row:
                chunk_feature_hashes.add(feature_hash)
        seen_feature_hashes.update(chunk_feature_hashes)
        X = X[unseen]
        X_scaled = X_scaled[unseen]
        y = y[unseen]
        attack_family = attack_family[unseen]
        attack_label = attack_label[unseen]
        source_file = source_file[unseen]

        if len(X) == 0:
            continue

        # ----------------------------------------------------
        # Output filename
        # ----------------------------------------------------

        output_file = (
            file_output_dir
            / f"chunk_{chunk_index:05d}.npz"
        )

        save_chunk(
            X_scaled,
            y,
            output_file,
            attack_family=attack_family,
            attack_label=attack_label,
            source_file=source_file,
        )

        total_rows += len(X)

        print(
            f"    chunk "
            f"{chunk_index:05d}: "
            f"{len(X):,} rows"
        )

        chunk_index += 1

    print(
        f"    File total: "
        f"{total_rows:,} rows"
    )

    return total_rows


# ============================================================
# PROCESS ONE SPLIT
# ============================================================

def process_split(
    manifest: pd.DataFrame,
    split_name: str,
    scaler: StandardScaler,
    label_mapping: Dict[str, int],
    unknown_label: int,
    output_dir: Path,
    seen_feature_hashes: set[int],
) -> pd.DataFrame:
    """
    Process all files belonging to one split.
    """

    split_manifest = manifest[
        manifest["split"] == split_name
    ]

    if split_manifest.empty:
        raise RuntimeError(
            f"No files found for "
            f"{split_name} split."
        )

    summary = []

    print()
    print("=" * 70)
    print(
        f"PROCESSING "
        f"{split_name.upper()}"
    )
    print("=" * 70)

    for file_index, (_, record) in enumerate(
        split_manifest.iterrows(),
        start=1,
    ):

        csv_path = (
            DATASET_DIR
            / record["file_path"]
        )

        print()
        print(
            f"[{file_index}/"
            f"{len(split_manifest)}] "
            f"{record['file_path']}"
        )

        rows = process_file(
            csv_path=csv_path,
            split_name=split_name,
            scaler=scaler,
            label_mapping=label_mapping,
            unknown_label=unknown_label,
            output_dir=output_dir,
            file_index=file_index,
            seen_feature_hashes=seen_feature_hashes,
        )

        summary.append(
            {
                "file_path": record[
                    "file_path"
                ],
                "detailed_label": record[
                    "detailed_label"
                ],
                "attack_family": record[
                    "attack_family"
                ],
                "split": split_name,
                "known_unknown": record[
                    "known_unknown"
                ],
                "rows": rows,
            }
        )

    summary_df = pd.DataFrame(
        summary
    )

    summary_file = (
        output_dir
        / f"{split_name}_summary.csv"
    )

    summary_df.to_csv(
        summary_file,
        index=False,
    )

    print()
    print(
        "Summary saved:"
    )
    print(summary_file)

    return summary_df


# ============================================================
# VALIDATE PROCESSED OUTPUT
# ============================================================

def validate_processed_summary(
    summary_df: pd.DataFrame,
    split_name: str,
) -> None:
    """
    Basic sanity checks for a processed split.
    """

    if summary_df.empty:
        raise RuntimeError(
            f"{split_name} produced "
            "an empty summary."
        )

    if (
        summary_df["rows"] <= 0
    ).all():
        raise RuntimeError(
            f"{split_name} contains "
            "no processed rows."
        )

    total_rows = (
        summary_df["rows"]
        .sum()
    )

    print()
    print(
        f"{split_name.capitalize()} "
        f"processed rows: "
        f"{total_rows:,}"
    )


# ============================================================
# MAIN
# ============================================================

def main(
    scenario_name: str = DEFAULT_SCENARIO,
):
    """
    Main dataset-processing pipeline.
    """

    print("=" * 70)
    print(
        "AEFL-OSIDS "
        "MEMORY-SAFE DATASET PROCESSOR"
    )
    print("=" * 70)

    # --------------------------------------------------------
    # Validate configuration
    # --------------------------------------------------------

    validate_configuration()

    # --------------------------------------------------------
    # Scenario validation
    # --------------------------------------------------------

    if scenario_name not in (
        OPEN_SET_SCENARIOS
    ):
        raise ValueError(
            f"Unknown scenario: "
            f"{scenario_name}"
        )

    unknown_families = (
        OPEN_SET_SCENARIOS[
            scenario_name
        ]
    )

    print()
    print(
        f"Scenario: "
        f"{scenario_name}"
    )

    print(
        f"Unknown families: "
        f"{sorted(unknown_families)}"
    )

    print(
        f"Experiment mode: "
        f"{EXPERIMENT_MODE}"
    )

    if EXPERIMENT_MODE == "development":

        print(
            f"Maximum rows per file: "
            f"{DEV_MAX_ROWS_PER_FILE:,}"
        )

    else:

        print(
            "Maximum rows per file: ALL"
        )

    # --------------------------------------------------------
    # Load manifest
    # --------------------------------------------------------

    manifest = load_manifest(
        scenario_name
    )

    print()
    print(
        f"Manifest files: "
        f"{len(manifest)}"
    )

    # --------------------------------------------------------
    # Label mapping
    # --------------------------------------------------------

    label_mapping = (
        build_label_mapping(
            unknown_families
        )
    )

    unknown_label = (
        get_unknown_label()
    )

    print()
    print("Label mapping:")

    for family, label in (
        label_mapping.items()
    ):

        print(
            f"  {label} -> {family}"
        )

    print(
        f"  {unknown_label} -> UNKNOWN"
    )

    # --------------------------------------------------------
    # Scenario output directory
    # --------------------------------------------------------

    scenario_output = (
        OUTPUT_DIR
        / scenario_name
    )

    staging_output = OUTPUT_DIR / f".{scenario_name}_staging"
    if staging_output.exists():
        shutil.rmtree(staging_output)
    staging_output.mkdir(
        parents=True,
        exist_ok=True,
    )

    # --------------------------------------------------------
    # Fit scaler using TRAIN only
    # --------------------------------------------------------

    scaler = fit_scaler(
        manifest
    )

    scaler_path = (
        staging_output
        / "scaler.joblib"
    )

    joblib.dump(
        scaler,
        scaler_path,
    )

    print()
    print(
        "Scaler saved:"
    )
    print(scaler_path)

    # --------------------------------------------------------
    # Save label mapping
    # --------------------------------------------------------

    mapping_file = (
        staging_output
        / "label_mapping.csv"
    )

    mapping_df = pd.DataFrame(
        [
            {
                "family": family,
                "label": label,
            }
            for family, label
            in label_mapping.items()
        ]
    )

    mapping_df.to_csv(
        mapping_file,
        index=False,
    )

    print(
        "Label mapping saved:"
    )
    print(mapping_file)

    # --------------------------------------------------------
    # Process TRAIN
    # --------------------------------------------------------

    seen_feature_hashes: set[int] = set()

    train_summary = process_split(
        manifest=manifest,
        split_name="train",
        scaler=scaler,
        label_mapping=label_mapping,
        unknown_label=unknown_label,
        output_dir=staging_output,
        seen_feature_hashes=seen_feature_hashes,
    )

    validate_processed_summary(
        train_summary,
        "train",
    )

    # --------------------------------------------------------
    # Process VALIDATION
    # --------------------------------------------------------

    validation_summary = process_split(
        manifest=manifest,
        split_name="validation",
        scaler=scaler,
        label_mapping=label_mapping,
        unknown_label=unknown_label,
        output_dir=staging_output,
        seen_feature_hashes=seen_feature_hashes,
    )

    validate_processed_summary(
        validation_summary,
        "validation",
    )

    # --------------------------------------------------------
    # Process TEST
    # --------------------------------------------------------

    test_summary = process_split(
        manifest=manifest,
        split_name="test",
        scaler=scaler,
        label_mapping=label_mapping,
        unknown_label=unknown_label,
        output_dir=staging_output,
        seen_feature_hashes=seen_feature_hashes,
    )

    validate_processed_summary(
        test_summary,
        "test",
    )

    # --------------------------------------------------------
    # Final summary
    # --------------------------------------------------------

    train_rows = int(
        train_summary["rows"].sum()
    )

    validation_rows = int(
        validation_summary["rows"].sum()
    )

    test_rows = int(
        test_summary["rows"].sum()
    )

    # Publish only after every split succeeds, preventing a failed run from
    # leaving a half-written dataset active.
    if scenario_output.exists():
        shutil.rmtree(scenario_output)
    staging_output.replace(scenario_output)

    print()
    print("=" * 70)
    print(
        "PROCESSING COMPLETE"
    )
    print("=" * 70)

    print()
    print(
        f"Train rows      : "
        f"{train_rows:,}"
    )

    print(
        f"Validation rows : "
        f"{validation_rows:,}"
    )

    print(
        f"Test rows       : "
        f"{test_rows:,}"
    )

    print()
    print(
        "Processed data:"
    )

    print(
        scenario_output
    )

    print()
    print("=" * 70)
    print(
        "DATASET PROCESSOR SUCCESSFUL"
    )
    print("=" * 70)


# ============================================================
# ENTRY POINT
# ============================================================

if __name__ == "__main__":
    main()
