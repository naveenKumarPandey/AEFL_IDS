"""
AEFL-OSIDS
FINAL RESULTS VERIFICATION

Purpose
-------
Verify whether the stored Adaptive FedAvg v2 results are reproduced
by the currently saved model and the current Scenario-C test dataset.

This script:
    1. Loads the existing Adaptive FedAvg v2 model.
    2. Loads the existing Scenario-C test dataset.
    3. Runs five-class inference.
    4. Calculates known-class metrics.
    5. Calculates open-set metrics using the calibrated threshold.
    6. Compares the newly calculated values with the stored results.
    7. Reports PASS/FAIL for each metric.

IMPORTANT
---------
No training is performed.
No model weights are modified.
No dataset files are modified.

Run:
    python -m evaluation.verify_final_results
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, Optional

import numpy as np
import torch
from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    roc_auc_score,
    confusion_matrix,
)
from torch.utils.data import DataLoader


# ============================================================
# PROJECT PATHS
# ============================================================

PROJECT_ROOT = (
    Path(__file__).resolve().parents[1]
)

RESULTS_ROOT = (
    PROJECT_ROOT / "results"
)

SCENARIO = (
    "scenario_C_multiple"
)

MODEL_PATH = (
    PROJECT_ROOT
    / "data"
    / "models"
    / "adaptive_fedavg_v2_global.pt"
)

CALIBRATION_PATH = (
    RESULTS_ROOT
    / "threshold_calibration"
    / "threshold_calibration.json"
)

STORED_FINAL_METRICS = (
    RESULTS_ROOT
    / "adaptive_fedavg_v2"
    / "final_metrics.json"
)

STORED_OPEN_SET = (
    RESULTS_ROOT
    / "final_open_set"
    / "final_open_set_results.json"
)

OUTPUT_DIR = (
    RESULTS_ROOT
    / "verification"
)

OUTPUT_JSON = (
    OUTPUT_DIR
    / "final_results_verification.json"
)

OUTPUT_TXT = (
    OUTPUT_DIR
    / "final_results_verification.txt"
)


# ============================================================
# CONFIGURATION
# ============================================================

CLASS_NAMES = [
    "BENIGN",
    "DDoS",
    "DoS",
    "Mirai",
    "Recon",
]

KNOWN_FAMILIES = set(
    CLASS_NAMES
)

UNKNOWN_FAMILIES = {
    "BruteForce",
    "Spoofing",
    "Web-based",
}

NUM_CLASSES = 5

BATCH_SIZE = 4096

# Numerical tolerance used when comparing metrics.
TOLERANCE = 1e-4


# ============================================================
# PRINTING
# ============================================================

def header(
    title: str,
) -> None:

    print()
    print("=" * 70)
    print(title)
    print("=" * 70)


# ============================================================
# JSON
# ============================================================

def load_json(
    path: Path,
) -> Dict[str, Any]:

    if not path.exists():

        raise FileNotFoundError(
            f"Required JSON file not found:\n"
            f"{path}"
        )

    with path.open(
        "r",
        encoding="utf-8",
    ) as f:

        return json.load(f)


def save_json(
    data: Dict[str, Any],
    path: Path,
) -> None:

    path.parent.mkdir(
        parents=True,
        exist_ok=True,
    )

    with path.open(
        "w",
        encoding="utf-8",
    ) as f:

        json.dump(
            data,
            f,
            indent=4,
        )


# ============================================================
# THRESHOLD LOADING
# ============================================================

def load_threshold() -> float:

    print(
        "Loading calibrated threshold..."
    )

    data = load_json(
        CALIBRATION_PATH
    )

    # --------------------------------------------------------
    # Preferred structure used by your calibration output
    # --------------------------------------------------------

    selected = (
        data.get(
            "selected_operating_point"
        )
    )

    if isinstance(
        selected,
        dict,
    ):

        for key in (
            "threshold",
            "selected_threshold",
            "locked_threshold",
        ):

            if key in selected:

                threshold = float(
                    selected[key]
                )

                print(
                    f"Locked threshold: "
                    f"{threshold:.6f}"
                )

                return threshold

    # --------------------------------------------------------
    # Direct fields
    # --------------------------------------------------------

    for key in (
        "selected_threshold",
        "locked_threshold",
        "threshold",
    ):

        if key in data:

            threshold = float(
                data[key]
            )

            print(
                f"Locked threshold: "
                f"{threshold:.6f}"
            )

            return threshold

    # --------------------------------------------------------
    # Search threshold records
    # --------------------------------------------------------

    thresholds = (
        data.get(
            "thresholds"
        )
    )

    if isinstance(
        thresholds,
        list,
    ):

        for item in thresholds:

            if not isinstance(
                item,
                dict,
            ):
                continue

            for key in (
                "selected",
                "is_selected",
                "chosen",
            ):

                if item.get(key) is True:

                    if (
                        "threshold"
                        in item
                    ):

                        threshold = float(
                            item[
                                "threshold"
                            ]
                        )

                        print(
                            f"Locked threshold: "
                            f"{threshold:.6f}"
                        )

                        return threshold

    raise KeyError(
        "Could not find calibrated threshold in:\n"
        f"{CALIBRATION_PATH}"
    )


# ============================================================
# MODEL CREATION
# ============================================================

def load_model(
    device: torch.device,
):

    print()
    print(
        "Loading Adaptive FedAvg v2 model..."
    )

    print(
        f"Model: {MODEL_PATH}"
    )

    if not MODEL_PATH.exists():

        raise FileNotFoundError(
            f"Model not found:\n"
            f"{MODEL_PATH}"
        )

    from models.intrusion_model import (
        create_model,
    )

    model = create_model()

    checkpoint = torch.load(
        MODEL_PATH,
        map_location=device,
    )

    # --------------------------------------------------------
    # Support common checkpoint formats
    # --------------------------------------------------------

    if isinstance(
        checkpoint,
        dict,
    ):

        if (
            "state_dict"
            in checkpoint
        ):

            state_dict = (
                checkpoint[
                    "state_dict"
                ]
            )

        elif (
            "model_state_dict"
            in checkpoint
        ):

            state_dict = (
                checkpoint[
                    "model_state_dict"
                ]
            )

        else:

            state_dict = checkpoint

    else:

        state_dict = checkpoint

    model.load_state_dict(
        state_dict,
        strict=True,
    )

    model.to(
        device
    )

    model.eval()

    print(
        "Model loaded successfully."
    )

    return model


# ============================================================
# DATASET
# ============================================================

def load_test_dataset():

    print()
    print(
        "Loading Scenario-C test dataset..."
    )

    from data_loader.cic_iot_dataset import (
        create_dataset,
    )

    dataset = create_dataset(
        SCENARIO,
        "test",
    )

    print(
        f"Test samples: "
        f"{len(dataset):,}"
    )

    return dataset


# ============================================================
# ATTACK FAMILY EXTRACTION
# ============================================================

def extract_attack_families(
    dataset,
) -> np.ndarray:

    print()
    print(
        "Loading attack-family metadata..."
    )

    families = []

    for file_path in dataset.files:

        with np.load(
            file_path,
            allow_pickle=True,
        ) as data:

            if (
                "attack_family"
                not in data.files
            ):

                raise KeyError(
                    "attack_family metadata missing from:\n"
                    f"{file_path}"
                )

            values = (
                data[
                    "attack_family"
                ]
            )

            families.extend(
                [
                    str(x)
                    for x in values
                ]
            )

    families = np.asarray(
        families,
        dtype=str,
    )

    if len(families) != len(dataset):

        raise ValueError(
            "Attack-family metadata length mismatch.\n"
            f"Metadata: {len(families):,}\n"
            f"Dataset : {len(dataset):,}"
        )

    print(
        f"Attack-family entries: "
        f"{len(families):,}"
    )

    unique, counts = np.unique(
        families,
        return_counts=True,
    )

    print()
    print(
        "Attack-family distribution:"
    )

    for family, count in zip(
        unique,
        counts,
    ):

        print(
            f"  {family:<15} "
            f"{int(count):,}"
        )

    return families


# ============================================================
# INFERENCE
# ============================================================

def run_inference(
    model,
    dataset,
    device,
):

    print()
    print("=" * 70)
    print(
        "RUNNING MODEL INFERENCE"
    )
    print("=" * 70)

    print(
        f"Batch size: {BATCH_SIZE}"
    )

    loader = DataLoader(
        dataset,
        batch_size=BATCH_SIZE,
        shuffle=False,
        num_workers=0,
        pin_memory=False,
    )

    all_true = []
    all_pred = []
    all_confidence = []
    all_probabilities = []

    processed = 0

    with torch.no_grad():

        for X, y in loader:

            X = X.to(
                device
            )

            logits = model(
                X
            )

            probabilities = (
                torch.softmax(
                    logits,
                    dim=1,
                )
            )

            confidence, predictions = (
                torch.max(
                    probabilities,
                    dim=1,
                )
            )

            all_true.extend(
                y.cpu()
                .numpy()
                .tolist()
            )

            all_pred.extend(
                predictions.cpu()
                .numpy()
                .tolist()
            )

            all_confidence.extend(
                confidence.cpu()
                .numpy()
                .tolist()
            )

            all_probabilities.append(
                probabilities.cpu()
                .numpy()
            )

            processed += len(y)

            if (
                processed % 40960
                < BATCH_SIZE
            ):

                print(
                    f"  Processed "
                    f"{processed:,} samples"
                )

    y_true = np.asarray(
        all_true,
        dtype=int,
    )

    y_pred = np.asarray(
        all_pred,
        dtype=int,
    )

    confidence = np.asarray(
        all_confidence,
        dtype=float,
    )

    probabilities = np.concatenate(
        all_probabilities,
        axis=0,
    )

    print()
    print(
        "Inference complete."
    )

    print(
        f"Samples evaluated: "
        f"{len(y_true):,}"
    )

    return (
        y_true,
        y_pred,
        confidence,
        probabilities,
    )


# ============================================================
# VALIDATION METRICS
# ============================================================

def calculate_validation_metrics(
    y_true: np.ndarray,
    y_pred: np.ndarray,
) -> Dict[str, float]:

    return {
        "accuracy": float(
            accuracy_score(y_true, y_pred)
        ),
        "precision_macro": float(
            precision_score(
                y_true, y_pred,
                labels=list(range(NUM_CLASSES)),
                average="macro",
                zero_division=0,
            )
        ),
        "recall_macro": float(
            recall_score(
                y_true, y_pred,
                labels=list(range(NUM_CLASSES)),
                average="macro",
                zero_division=0,
            )
        ),
        "f1_macro": float(
            f1_score(
                y_true, y_pred,
                labels=list(range(NUM_CLASSES)),
                average="macro",
                zero_division=0,
            )
        ),
        "f1_weighted": float(
            f1_score(
                y_true, y_pred,
                labels=list(range(NUM_CLASSES)),
                average="weighted",
                zero_division=0,
            )
        ),
    }


# ============================================================
# KNOWN-CLASS METRICS
# ============================================================

def calculate_known_metrics(
    y_true: np.ndarray,
    y_pred: np.ndarray,
    families: np.ndarray,
) -> Dict[str, float]:

    # Only genuinely known families are included.
    known_mask = np.isin(
        families,
        list(
            KNOWN_FAMILIES
        ),
    )

    known_true = (
        y_true[
            known_mask
        ]
    )

    known_pred = (
        y_pred[
            known_mask
        ]
    )

    # --------------------------------------------------------
    # IMPORTANT
    #
    # Metrics are calculated on the known-family test subset.
    # --------------------------------------------------------

    accuracy = accuracy_score(
        known_true,
        known_pred,
    )

    precision = precision_score(
        known_true,
        known_pred,
        labels=list(
            range(NUM_CLASSES)
        ),
        average="macro",
        zero_division=0,
    )

    recall = recall_score(
        known_true,
        known_pred,
        labels=list(
            range(NUM_CLASSES)
        ),
        average="macro",
        zero_division=0,
    )

    f1 = f1_score(
        known_true,
        known_pred,
        labels=list(
            range(NUM_CLASSES)
        ),
        average="macro",
        zero_division=0,
    )

    weighted_f1 = f1_score(
        known_true,
        known_pred,
        labels=list(
            range(NUM_CLASSES)
        ),
        average="weighted",
        zero_division=0,
    )

    return {
        "known_samples": int(
            known_mask.sum()
        ),
        "accuracy": float(
            accuracy
        ),
        "macro_precision": float(
            precision
        ),
        "macro_recall": float(
            recall
        ),
        "macro_f1": float(
            f1
        ),
        "weighted_f1": float(
            weighted_f1
        ),
    }


# ============================================================
# OPEN-SET METRICS
# ============================================================

def calculate_open_set_metrics(
    y_true: np.ndarray,
    y_pred: np.ndarray,
    confidence: np.ndarray,
    probabilities: np.ndarray,
    families: np.ndarray,
    threshold: float,
):

    # --------------------------------------------------------
    # Ground-truth unknown
    # --------------------------------------------------------

    true_unknown = (
        ~np.isin(
            families,
            list(
                KNOWN_FAMILIES
            ),
        )
    )

    # --------------------------------------------------------
    # Open-set decision
    #
    # Low maximum probability -> UNKNOWN
    # --------------------------------------------------------

    predicted_unknown = (
        confidence
        < threshold
    )

    # --------------------------------------------------------
    # Binary unknown detection
    # --------------------------------------------------------

    tp = int(
        np.sum(
            true_unknown
            & predicted_unknown
        )
    )

    tn = int(
        np.sum(
            (~true_unknown)
            & (~predicted_unknown)
        )
    )

    fp = int(
        np.sum(
            (~true_unknown)
            & predicted_unknown
        )
    )

    fn = int(
        np.sum(
            true_unknown
            & (~predicted_unknown)
        )
    )

    precision = (
        tp / (tp + fp)
        if (tp + fp) > 0
        else 0.0
    )

    recall = (
        tp / (tp + fn)
        if (tp + fn) > 0
        else 0.0
    )

    f1 = (
        2
        * precision
        * recall
        / (precision + recall)
        if (precision + recall) > 0
        else 0.0
    )

    known_fpr = (
        fp
        / (
            fp + tn
        )
        if (fp + tn) > 0
        else 0.0
    )

    # --------------------------------------------------------
    # AUROC
    #
    # Higher value means more likely unknown.
    # Therefore use 1 - confidence.
    # --------------------------------------------------------

    unknown_score = (
        1.0
        - confidence
    )

    try:

        auroc = roc_auc_score(
            true_unknown.astype(int),
            unknown_score,
        )

    except Exception:

        auroc = float(
            "nan"
        )

    # --------------------------------------------------------
    # Known subset after open-set decision
    # --------------------------------------------------------

    known_mask = (
        ~true_unknown
    )

    known_final_mask = (
        known_mask
        & (~predicted_unknown)
    )

    known_true = (
        y_true[
            known_final_mask
        ]
    )

    known_pred = (
        y_pred[
            known_final_mask
        ]
    )

    if len(
        known_true
    ) > 0:

        known_accuracy = (
            accuracy_score(
                known_true,
                known_pred,
            )
        )

        known_macro_precision = (
            precision_score(
                known_true,
                known_pred,
                labels=list(
                    range(
                        NUM_CLASSES
                    )
                ),
                average="macro",
                zero_division=0,
            )
        )

        known_macro_recall = (
            recall_score(
                known_true,
                known_pred,
                labels=list(
                    range(
                        NUM_CLASSES
                    )
                ),
                average="macro",
                zero_division=0,
            )
        )

        known_macro_f1 = (
            f1_score(
                known_true,
                known_pred,
                labels=list(
                    range(
                        NUM_CLASSES
                    )
                ),
                average="macro",
                zero_division=0,
            )
        )

    else:

        known_accuracy = 0.0
        known_macro_precision = 0.0
        known_macro_recall = 0.0
        known_macro_f1 = 0.0

    return {
        "threshold": float(
            threshold
        ),
        "test_samples": int(
            len(y_true)
        ),
        "true_unknown_samples": int(
            true_unknown.sum()
        ),
        "predicted_unknown_samples": int(
            predicted_unknown.sum()
        ),
        "true_known_samples": int(
            known_mask.sum()
        ),
        "unknown_detection": {
            "true_positive": tp,
            "true_negative": tn,
            "false_positive": fp,
            "false_negative": fn,
            "precision": float(
                precision
            ),
            "recall": float(
                recall
            ),
            "f1": float(
                f1
            ),
            "known_fpr": float(
                known_fpr
            ),
        },
        "open_set_auroc": float(
            auroc
        ),
        "known_after_open_set": {
            "samples": int(
                len(known_true)
            ),
            "accuracy": float(
                known_accuracy
            ),
            "macro_precision": float(
                known_macro_precision
            ),
            "macro_recall": float(
                known_macro_recall
            ),
            "macro_f1": float(
                known_macro_f1
            ),
        },
        "true_unknown_by_family": {
            family: int(
                np.sum(
                    families
                    == family
                )
            )
            for family in sorted(
                UNKNOWN_FAMILIES
            )
        },
        "detected_unknown_by_family": {
            family: int(
                np.sum(
                    (families == family)
                    & predicted_unknown
                )
            )
            for family in sorted(
                UNKNOWN_FAMILIES
            )
        },
    }


# ============================================================
# OPEN-SET CONFUSION MATRIX
# ============================================================

def create_open_set_predictions(
    y_pred: np.ndarray,
    confidence: np.ndarray,
    threshold: float,
) -> np.ndarray:

    final_predictions = (
        y_pred.copy()
    )

    final_predictions[
        confidence < threshold
    ] = NUM_CLASSES

    return final_predictions


def create_open_set_confusion_matrix(
    y_true: np.ndarray,
    y_pred: np.ndarray,
    families: np.ndarray,
    confidence: np.ndarray,
    threshold: float,
):

    # Ground-truth:
    #
    # known family -> 0..4
    # unknown       -> 5
    #

    final_true = np.full(
        len(y_true),
        NUM_CLASSES,
        dtype=int,
    )

    for index, family in enumerate(
        families
    ):

        if family in KNOWN_FAMILIES:

            final_true[
                index
            ] = y_true[
                index
            ]

    final_pred = (
        create_open_set_predictions(
            y_pred,
            confidence,
            threshold,
        )
    )

    labels = list(
        range(
            NUM_CLASSES + 1
        )
    )

    matrix = confusion_matrix(
        final_true,
        final_pred,
        labels=labels,
    )

    return matrix


# ============================================================
# COMPARISON
# ============================================================

def compare_metric(
    name: str,
    actual: Optional[float],
    expected: Optional[float],
) -> Dict[str, Any]:

    if (
        actual is None
        or expected is None
    ):

        return {
            "metric": name,
            "actual": actual,
            "expected": expected,
            "difference": None,
            "pass": False,
        }

    difference = (
        float(actual)
        - float(expected)
    )

    passed = (
        abs(difference)
        <= TOLERANCE
    )

    return {
        "metric": name,
        "actual": float(actual),
        "expected": float(expected),
        "difference": float(
            difference
        ),
        "pass": bool(
            passed
        ),
    }


# ============================================================
# PRINT COMPARISON
# ============================================================

def print_comparison(
    comparisons,
):

    print()
    print("=" * 70)
    print(
        "RESULT COMPARISON"
    )
    print("=" * 70)

    print()

    print(
        f"{'Metric':<28}"
        f"{'Actual':>14}"
        f"{'Stored':>14}"
        f"{'Diff':>14}"
        f"{'Status':>10}"
    )

    print(
        "-" * 80
    )

    for item in comparisons:

        actual = item[
            "actual"
        ]

        expected = item[
            "expected"
        ]

        difference = item[
            "difference"
        ]

        if (
            actual is None
            or expected is None
        ):

            actual_text = "N/A"
            expected_text = "N/A"
            difference_text = "N/A"

        else:

            actual_text = (
                f"{actual * 100:.4f}%"
            )

            expected_text = (
                f"{expected * 100:.4f}%"
            )

            difference_text = (
                f"{difference * 100:+.4f}%"
            )

        status = (
            "PASS"
            if item["pass"]
            else "FAIL"
        )

        print(
            f"{item['metric']:<28}"
            f"{actual_text:>14}"
            f"{expected_text:>14}"
            f"{difference_text:>14}"
            f"{status:>10}"
        )


# ============================================================
# SAVE TEXT REPORT
# ============================================================

def save_text_report(
    result: Dict[str, Any],
):

    lines = [
        "AEFL-OSIDS FINAL RESULTS VERIFICATION",
        "=" * 70,
        "",
        f"Scenario: {SCENARIO}",
        "",
        "PURPOSE",
        "-" * 70,
        (
            "Verify whether the stored Adaptive FedAvg v2 "
            "metrics are reproduced by the currently saved "
            "model and test dataset."
        ),
        "",
        "No training was performed.",
        "No model weights were modified.",
        "",
        "RESULT COMPARISON",
        "-" * 70,
    ]

    for item in result[
        "comparisons"
    ]:

        actual = item[
            "actual"
        ]

        expected = item[
            "expected"
        ]

        difference = item[
            "difference"
        ]

        status = (
            "PASS"
            if item["pass"]
            else "FAIL"
        )

        if (
            actual is not None
            and expected is not None
        ):

            lines.append(
                f"{item['metric']}: "
                f"actual={actual:.8f}, "
                f"stored={expected:.8f}, "
                f"difference={difference:+.8f}, "
                f"{status}"
            )

        else:

            lines.append(
                f"{item['metric']}: "
                f"{status}"
            )

    lines.extend(
        [
            "",
            "DATASET INFORMATION",
            "-" * 70,
            (
                f"Test samples: "
                f"{result['dataset']['test_samples']:,}"
            ),
            (
                f"Known samples: "
                f"{result['dataset']['known_samples']:,}"
            ),
            (
                f"Unknown samples: "
                f"{result['dataset']['unknown_samples']:,}"
            ),
            "",
            "UNKNOWN FAMILY DISTRIBUTION",
            "-" * 70,
        ]
    )

    for family, count in (
        result[
            "dataset"
        ][
            "unknown_family_distribution"
        ].items()
    ):

        lines.append(
            f"{family}: {count:,}"
        )

    lines.extend(
        [
            "",
            "OPEN-SET RESULTS",
            "-" * 70,
        ]
    )

    open_set = result[
        "actual_open_set"
    ]

    unknown = open_set[
        "unknown_detection"
    ]

    lines.extend(
        [
            (
                f"Threshold: "
                f"{open_set['threshold']:.6f}"
            ),
            (
                f"Unknown TP: "
                f"{unknown['true_positive']:,}"
            ),
            (
                f"Unknown TN: "
                f"{unknown['true_negative']:,}"
            ),
            (
                f"Unknown FP: "
                f"{unknown['false_positive']:,}"
            ),
            (
                f"Unknown FN: "
                f"{unknown['false_negative']:,}"
            ),
            (
                f"Unknown Precision: "
                f"{unknown['precision'] * 100:.4f}%"
            ),
            (
                f"Unknown Recall: "
                f"{unknown['recall'] * 100:.4f}%"
            ),
            (
                f"Unknown F1: "
                f"{unknown['f1'] * 100:.4f}%"
            ),
            (
                f"Known FPR: "
                f"{unknown['known_fpr'] * 100:.4f}%"
            ),
            (
                f"Open-set AUROC: "
                f"{open_set['open_set_auroc'] * 100:.4f}%"
            ),
        ]
    )

    lines.extend(
        [
            "",
            "OPEN-SET CONFUSION MATRIX",
            "-" * 70,
        ]
    )

    labels = (
        CLASS_NAMES
        + ["UNKNOWN"]
    )

    matrix = np.asarray(
        result[
            "open_set_confusion_matrix"
        ]
    )

    lines.append(
        "Rows = True, Columns = Predicted"
    )

    lines.append(
        ""
    )

    lines.append(
        f"{'':<15}"
        + "".join(
            f"{label:>12}"
            for label in labels
        )
    )

    for i, label in enumerate(
        labels
    ):

        lines.append(
            f"{label:<15}"
            + "".join(
                f"{int(value):>12,}"
                for value in matrix[i]
            )
        )

    lines.extend(
        [
            "",
            "CONCLUSION",
            "-" * 70,
            result[
                "conclusion"
            ],
        ]
    )

    OUTPUT_TXT.write_text(
        "\n".join(lines),
        encoding="utf-8",
    )


# ============================================================
# MAIN
# ============================================================

def main():

    header(
        "AEFL-OSIDS FINAL RESULTS VERIFICATION"
    )

    print(f"Scenario : {SCENARIO}")
    print(f"Model    : {MODEL_PATH}")
    print(
        "Evaluation: validation reproduction + "
        "test open-set verification"
    )

    device = torch.device(
        "cuda" if torch.cuda.is_available() else "cpu"
    )
    print(f"Device   : {device}")

    # --------------------------------------------------------
    # Stored results
    # --------------------------------------------------------

    print()
    print("Loading stored experiment results...")

    stored_metrics = load_json(STORED_FINAL_METRICS)
    stored_open_set = load_json(STORED_OPEN_SET)

    print("Stored results loaded.")

    threshold = load_threshold()
    model = load_model(device)

    # ========================================================
    # 1. ROUND-5 VALIDATION REPRODUCTION
    #
    # final_metrics.json contains the final ROUND-5 VALIDATION
    # metrics. It must therefore be compared with validation,
    # NOT with the Scenario-C test split.
    # ========================================================

    header("ROUND-5 VALIDATION REPRODUCTION")

    from data_loader.cic_iot_dataset import create_dataset

    validation_dataset = create_dataset(
        SCENARIO,
        "validation",
    )

    print(
        f"Validation samples: "
        f"{len(validation_dataset):,}"
    )

    (
        validation_true,
        validation_pred,
        _validation_confidence,
        _validation_probabilities,
    ) = run_inference(
        model,
        validation_dataset,
        device,
    )

    validation_metrics = calculate_validation_metrics(
        validation_true,
        validation_pred,
    )

    print()
    print("Reproduced validation metrics:")
    print(
        f"  Accuracy       : "
        f"{validation_metrics['accuracy'] * 100:.4f}%"
    )
    print(
        f"  Macro Precision: "
        f"{validation_metrics['precision_macro'] * 100:.4f}%"
    )
    print(
        f"  Macro Recall   : "
        f"{validation_metrics['recall_macro'] * 100:.4f}%"
    )
    print(
        f"  Macro F1       : "
        f"{validation_metrics['f1_macro'] * 100:.4f}%"
    )
    print(
        f"  Weighted F1    : "
        f"{validation_metrics['f1_weighted'] * 100:.4f}%"
    )

    stored_accuracy = float(stored_metrics["accuracy"])
    stored_precision = float(stored_metrics["precision_macro"])
    stored_recall = float(stored_metrics["recall_macro"])
    stored_f1 = float(stored_metrics["f1_macro"])
    stored_weighted_f1 = float(stored_metrics["f1_weighted"])

    validation_comparisons = [
        compare_metric(
            "Validation accuracy",
            validation_metrics["accuracy"],
            stored_accuracy,
        ),
        compare_metric(
            "Validation macro precision",
            validation_metrics["precision_macro"],
            stored_precision,
        ),
        compare_metric(
            "Validation macro recall",
            validation_metrics["recall_macro"],
            stored_recall,
        ),
        compare_metric(
            "Validation macro F1",
            validation_metrics["f1_macro"],
            stored_f1,
        ),
        compare_metric(
            "Validation weighted F1",
            validation_metrics["f1_weighted"],
            stored_weighted_f1,
        ),
    ]

    print_comparison(validation_comparisons)

    # ========================================================
    # 2. SCENARIO-C TEST / OPEN-SET EVALUATION
    # ========================================================

    header("SCENARIO-C TEST / OPEN-SET EVALUATION")

    dataset = load_test_dataset()
    families = extract_attack_families(dataset)

    (
        y_true,
        y_pred,
        confidence,
        probabilities,
    ) = run_inference(
        model,
        dataset,
        device,
    )

    if len(y_true) != len(families):
        raise RuntimeError(
            "Prediction/family length mismatch."
        )

    known_metrics = calculate_known_metrics(
        y_true,
        y_pred,
        families,
    )

    print()
    print(
        "Current Scenario-C closed-set test metrics "
        "(reported independently):"
    )
    print(
        f"  Known samples   : "
        f"{known_metrics['known_samples']:,}"
    )
    print(
        f"  Accuracy        : "
        f"{known_metrics['accuracy'] * 100:.4f}%"
    )
    print(
        f"  Macro Precision : "
        f"{known_metrics['macro_precision'] * 100:.4f}%"
    )
    print(
        f"  Macro Recall    : "
        f"{known_metrics['macro_recall'] * 100:.4f}%"
    )
    print(
        f"  Macro F1        : "
        f"{known_metrics['macro_f1'] * 100:.4f}%"
    )
    print(
        f"  Weighted F1     : "
        f"{known_metrics['weighted_f1'] * 100:.4f}%"
    )

    open_set_metrics = calculate_open_set_metrics(
        y_true,
        y_pred,
        confidence,
        probabilities,
        families,
        threshold,
    )

    open_set_cm = create_open_set_confusion_matrix(
        y_true,
        y_pred,
        families,
        confidence,
        threshold,
    )

    stored_unknown = stored_open_set["unknown_detection"]
    stored_known = stored_open_set["known_class_performance"]
    stored_auroc = float(
        stored_open_set["open_set_auroc"]
    )

    open_set_comparisons = [
        compare_metric(
            "Open-set unknown precision",
            open_set_metrics["unknown_detection"]["precision"],
            float(stored_unknown["precision"]),
        ),
        compare_metric(
            "Open-set unknown recall",
            open_set_metrics["unknown_detection"]["recall"],
            float(stored_unknown["recall"]),
        ),
        compare_metric(
            "Open-set unknown F1",
            open_set_metrics["unknown_detection"]["f1"],
            float(stored_unknown["f1"]),
        ),
        compare_metric(
            "Open-set known FPR",
            open_set_metrics["unknown_detection"]["known_fpr"],
            float(stored_unknown["known_fpr"]),
        ),
        compare_metric(
            "Open-set AUROC",
            open_set_metrics["open_set_auroc"],
            stored_auroc,
        ),
        compare_metric(
            "Known accuracy after open-set",
            open_set_metrics["known_after_open_set"]["accuracy"],
            float(stored_known["accuracy"]),
        ),
        compare_metric(
            "Known macro precision after open-set",
            open_set_metrics["known_after_open_set"]["macro_precision"],
            float(stored_known["macro_precision"]),
        ),
        compare_metric(
            "Known macro recall after open-set",
            open_set_metrics["known_after_open_set"]["macro_recall"],
            float(stored_known["macro_recall"]),
        ),
        compare_metric(
            "Known macro F1 after open-set",
            open_set_metrics["known_after_open_set"]["macro_f1"],
            float(stored_known["macro_f1"]),
        ),
    ]

    print()
    print(
        "Open-set comparison against stored final open-set results:"
    )
    print_comparison(open_set_comparisons)

    # --------------------------------------------------------
    # Dataset distribution
    # --------------------------------------------------------

    family_distribution = {}
    unique, counts = np.unique(
        families,
        return_counts=True,
    )

    for family, count in zip(unique, counts):
        family_distribution[str(family)] = int(count)

    unknown_samples = int(
        np.sum(
            ~np.isin(
                families,
                list(KNOWN_FAMILIES),
            )
        )
    )

    # --------------------------------------------------------
    # Overall status
    # --------------------------------------------------------

    comparisons = (
        validation_comparisons
        + open_set_comparisons
    )

    all_pass = all(
        item["pass"]
        for item in comparisons
    )

    if all_pass:
        conclusion = (
            "PASS: Round-5 validation metrics are reproduced "
            "from the validation split, and stored open-set "
            "test metrics are reproduced from the Scenario-C "
            "test split within tolerance. The previous "
            "validation-vs-test comparison is reconciled."
        )
    else:
        failed = [
            item["metric"]
            for item in comparisons
            if not item["pass"]
        ]
        conclusion = (
            "FAIL: One or more validation/open-set metrics "
            "are not reproduced: "
            + ", ".join(failed)
            + ". The model was not modified."
        )

    # --------------------------------------------------------
    # Result
    # --------------------------------------------------------

    result = {
        "experiment": (
            "Final Results Verification - Reconciled"
        ),
        "scenario": SCENARIO,
        "model": str(MODEL_PATH),
        "calibration": str(CALIBRATION_PATH),
        "threshold": float(threshold),

        "validation": {
            "split": "validation",
            "samples": int(len(validation_dataset)),
            "actual": validation_metrics,
            "stored_round5": {
                "accuracy": stored_accuracy,
                "precision_macro": stored_precision,
                "recall_macro": stored_recall,
                "f1_macro": stored_f1,
                "f1_weighted": stored_weighted_f1,
            },
            "comparisons": validation_comparisons,
        },

        "dataset": {
            "test_samples": int(len(dataset)),
            "known_samples": int(
                len(dataset) - unknown_samples
            ),
            "unknown_samples": int(unknown_samples),
            "unknown_family_distribution": {
                family: count
                for family, count in family_distribution.items()
                if family in UNKNOWN_FAMILIES
            },
        },

        "test_closed_set": {
            "note": (
                "Scenario-C test metrics are reported "
                "independently. final_metrics.json stores "
                "Round-5 validation metrics."
            ),
            "actual": known_metrics,
        },

        "actual_open_set": open_set_metrics,

        "open_set_confusion_matrix": (
            open_set_cm.astype(int).tolist()
        ),

        "stored_metrics": {
            "round5_validation": {
                "accuracy": stored_accuracy,
                "precision_macro": stored_precision,
                "recall_macro": stored_recall,
                "f1_macro": stored_f1,
                "f1_weighted": stored_weighted_f1,
            },
        },

        "stored_open_set": {
            "unknown_detection": stored_unknown,
            "known_class_performance": stored_known,
            "open_set_auroc": stored_auroc,
        },

        "comparisons": comparisons,
        "all_metrics_match": bool(all_pass),
        "conclusion": conclusion,
    }

    save_json(result, OUTPUT_JSON)
    save_text_report(result)

    print()
    print("=" * 70)
    print("VERIFICATION COMPLETE")
    print("=" * 70)
    print()
    print(f"JSON : {OUTPUT_JSON}")
    print(f"TXT  : {OUTPUT_TXT}")
    print()

    if all_pass:
        print("STATUS: PASS")
        print(
            "Validation and open-set stored results are reproduced."
        )
    else:
        print("STATUS: FAIL")
        print(
            "Some validation/open-set stored results are NOT reproduced."
        )
        print()
        print("Do NOT change the model yet.")
        print(
            "Reconcile the remaining evaluation differences first."
        )

    print("=" * 70)


# ============================================================
# ENTRY POINT
# ============================================================

if __name__ == "__main__":
    main()