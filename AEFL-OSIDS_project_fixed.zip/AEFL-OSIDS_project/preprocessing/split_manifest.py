from pathlib import Path
from collections import defaultdict

import pandas as pd
from sklearn.model_selection import train_test_split

from preprocessing.data_loader import (
    DATASET_DIR,
    find_csv_files,
)
from preprocessing.preprocessor import get_attack_family


# ============================================================
# CONFIGURATION
# ============================================================

RANDOM_SEED = 42

TRAIN_RATIO = 0.70
VALIDATION_RATIO = 0.15
TEST_RATIO = 0.15

# Open-set scenarios.
OPEN_SET_SCENARIOS = {
    "scenario_A_bruteforce": {
        "unknown_families": {
            "BruteForce",
        }
    },

    #"scenario_B_web_based": {
       # "unknown_families": {
       #     "Web-based",
       # }
    #},

    "scenario_C_multiple": {
        "unknown_families": {
            "Spoofing",
            "Web-based",
            "BruteForce",
        }
    },
}


PROJECT_ROOT = Path(__file__).resolve().parents[1]

OUTPUT_DIR = (
    PROJECT_ROOT
    / "data"
    / "splits"
)


# ============================================================
# FILE METADATA
# ============================================================

def build_file_metadata():
    """
    Build one metadata record per CSV file.

    No traffic rows are loaded.
    """

    csv_files = find_csv_files(DATASET_DIR)

    records = []

    for csv_file in csv_files:

        raw_label = csv_file.parent.name

        if raw_label == "Benign_Final":
            detailed_label = "BENIGN"
        else:
            detailed_label = raw_label

        family = get_attack_family(
            detailed_label
        )

        relative_path = csv_file.relative_to(
            DATASET_DIR
        )

        records.append(
            {
                "file_path": str(relative_path),
                "detailed_label": detailed_label,
                "attack_family": family,
            }
        )

    return pd.DataFrame(records)


# ============================================================
# FILE-LEVEL SPLITTING
# ============================================================

def split_known_files(
    files,
    train_ratio=TRAIN_RATIO,
    validation_ratio=VALIDATION_RATIO,
    test_ratio=TEST_RATIO,
):
    """
    Perform a robust file-level train/validation/test split.
    """

    n_files = len(files)

    if n_files < 3:
        raise ValueError(
            f"Cannot perform strict file-level splitting "
            f"with only {n_files} file(s)."
        )

    shuffled = list(files)

    import random

    rng = random.Random(RANDOM_SEED)
    rng.shuffle(shuffled)

    # --------------------------------------------------------
    # Exactly 3 files
    # --------------------------------------------------------

    if n_files == 3:
        return (
            shuffled[:1],
            shuffled[1:2],
            shuffled[2:3],
        )

    # --------------------------------------------------------
    # Exactly 4 files
    # --------------------------------------------------------

    if n_files == 4:
        return (
            shuffled[:2],
            shuffled[2:3],
            shuffled[3:4],
        )

    # --------------------------------------------------------
    # 5+ files
    # --------------------------------------------------------

    train_count = max(
        1,
        int(n_files * train_ratio)
    )

    validation_count = max(
        1,
        int(n_files * validation_ratio)
    )

    # Ensure at least one test file.
    test_count = (
        n_files
        - train_count
        - validation_count
    )

    if test_count < 1:

        validation_count -= 1

        test_count = (
            n_files
            - train_count
            - validation_count
        )

    train_files = shuffled[
        :train_count
    ]

    validation_files = shuffled[
        train_count:
        train_count + validation_count
    ]

    test_files = shuffled[
        train_count + validation_count:
    ]

    return (
        train_files,
        validation_files,
        test_files,
    )


# ============================================================
# BUILD ONE SCENARIO
# ============================================================

def build_scenario(
    metadata: pd.DataFrame,
    scenario_name: str,
    unknown_families: set[str],
):
    """
    Create train/validation/test file assignments
    for one open-set scenario.
    """

    records = []

    grouped = metadata.groupby(
        "attack_family"
    )

    for family, group in grouped:

        family_records = group.to_dict(
            orient="records"
        )

        # ----------------------------------------------------
        # UNKNOWN FAMILIES
        # ----------------------------------------------------

        if family in unknown_families:

            for record in family_records:

                records.append(
                    {
                        **record,
                        "split": "test",
                        "known_unknown": "UNKNOWN",
                        "scenario": scenario_name,
                    }
                )

            continue

        # ----------------------------------------------------
        # KNOWN FAMILIES
        # ----------------------------------------------------

        try:

            train_files, validation_files, test_files = (
                split_known_files(
                    family_records
                )
            )

        except ValueError as exc:

            raise ValueError(
                f"\nCannot create file-level split "
                f"for family '{family}'.\n"
                f"{exc}\n\n"
                f"Scenario: {scenario_name}\n"
                f"Family file count: "
                f"{len(family_records)}"
            ) from exc

        for record in train_files:

            records.append(
                {
                    **record,
                    "split": "train",
                    "known_unknown": "KNOWN",
                    "scenario": scenario_name,
                }
            )

        for record in validation_files:

            records.append(
                {
                    **record,
                    "split": "validation",
                    "known_unknown": "KNOWN",
                    "scenario": scenario_name,
                }
            )

        for record in test_files:

            records.append(
                {
                    **record,
                    "split": "test",
                    "known_unknown": "KNOWN",
                    "scenario": scenario_name,
                }
            )

    return pd.DataFrame(records)


# ============================================================
# VALIDATION
# ============================================================

def validate_scenario(
    split_df: pd.DataFrame,
    unknown_families: set[str],
):
    """
    Validate important open-set constraints.
    """

    # Unknown families must NEVER appear in training.
    train_unknown = split_df[
        (split_df["split"] == "train")
        & (
            split_df["attack_family"].isin(
                unknown_families
            )
        )
    ]

    if not train_unknown.empty:

        raise RuntimeError(
            "DATA LEAKAGE DETECTED: "
            "unknown family found in training."
        )

    # Unknown families must only appear in test.
    unknown_rows = split_df[
        split_df["attack_family"].isin(
            unknown_families
        )
    ]

    if not (
        unknown_rows["split"]
        .eq("test")
        .all()
    ):

        raise RuntimeError(
            "Unknown attack files are not "
            "restricted to the test split."
        )

    # Every file must have exactly one split.
    duplicate_files = (
        split_df["file_path"]
        .duplicated()
        .any()
    )

    if duplicate_files:

        raise RuntimeError(
            "A CSV file appears more than once "
            "in the split manifest."
        )


# ============================================================
# PRINT SCENARIO SUMMARY
# ============================================================

def print_summary(
    split_df: pd.DataFrame,
    unknown_families: set[str],
):
    """
    Print file-level split summary.
    """

    print("\n" + "=" * 80)
    print("OPEN-SET SPLIT SUMMARY")
    print("=" * 80)

    print(
        f"\nUnknown families: "
        f"{sorted(unknown_families)}"
    )

    print("\nFile counts:")
    print(
        split_df["split"]
        .value_counts()
        .sort_index()
        .to_string()
    )

    print("\nKnown / Unknown:")
    print(
        split_df["known_unknown"]
        .value_counts()
        .sort_index()
        .to_string()
    )

    print("\nFamily-wise split:")
    print(
        pd.crosstab(
            split_df["attack_family"],
            split_df["split"],
        ).to_string()
    )

    print("\nUnknown-family verification:")

    unknown_test = split_df[
        split_df["attack_family"].isin(
            unknown_families
        )
    ]

    print(
        unknown_test[
            [
                "attack_family",
                "split",
                "known_unknown",
            ]
        ]
        .value_counts()
        .to_string()
    )


# ============================================================
# MAIN
# ============================================================

def main():

    print("=" * 80)
    print("AEFL-OSIDS OPEN-SET SPLIT GENERATOR")
    print("=" * 80)

    OUTPUT_DIR.mkdir(
        parents=True,
        exist_ok=True,
    )

    metadata = build_file_metadata()

    print(
        f"\nCSV files discovered: "
        f"{len(metadata)}"
    )

    print(
        "\nFamilies discovered:"
    )

    print(
        metadata["attack_family"]
        .value_counts()
        .sort_index()
        .to_string()
    )

    for scenario_name, scenario_config in (
        OPEN_SET_SCENARIOS.items()
    ):

        print("\n")
        print("#" * 80)
        print(
            f"# BUILDING {scenario_name}"
        )
        print("#" * 80)

        unknown_families = (
            scenario_config[
                "unknown_families"
            ]
        )

        split_df = build_scenario(
            metadata=metadata,
            scenario_name=scenario_name,
            unknown_families=unknown_families,
        )

        validate_scenario(
            split_df=split_df,
            unknown_families=unknown_families,
        )

        print_summary(
            split_df=split_df,
            unknown_families=unknown_families,
        )

        output_file = (
            OUTPUT_DIR
            / f"{scenario_name}.csv"
        )

        split_df.to_csv(
            output_file,
            index=False,
        )

        print(
            f"\nManifest saved to:"
        )
        print(output_file)

    print("\n")
    print("=" * 80)
    print("ALL OPEN-SET MANIFESTS GENERATED")
    print("=" * 80)


if __name__ == "__main__":
    main()