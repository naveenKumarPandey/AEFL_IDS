from pathlib import Path
import json
import random
import time

import numpy as np
import torch
import torch.nn as nn

from torch.utils.data import DataLoader, TensorDataset

from federated.efficient_data import (
    load_federated_client_arrays,
    load_known_split_arrays,
)
from models.intrusion_model import create_model


# ============================================================
# AEFL-OSIDS
# CLASS-AWARE ADAPTIVE FEDERATED LEARNING
# ============================================================

PROJECT_ROOT = Path(__file__).resolve().parents[1]

SCENARIO_NAME = "scenario_C_multiple"

NUM_CLIENTS = 5
NUM_CLASSES = 5
INPUT_FEATURES = 39

# Same as FedAvg final experiment
FL_ROUNDS = 5
LOCAL_EPOCHS = 1
BATCH_SIZE = 512

LEARNING_RATE = 0.001
WEIGHT_DECAY = 0.00001

SEED = 42


# ============================================================
# ADAPTIVE COEFFICIENTS
# ============================================================

QUALITY_WEIGHT = 0.30
DIVERSITY_WEIGHT = 0.25
COVERAGE_WEIGHT = 0.25
RELIABILITY_WEIGHT = 0.20


CLASS_NAMES = [
    "BENIGN",
    "DDoS",
    "DoS",
    "Mirai",
    "Recon",
]


# ============================================================
# RANDOM SEED
# ============================================================

def set_seed(seed):

    random.seed(seed)

    np.random.seed(seed)

    torch.manual_seed(seed)

    if torch.cuda.is_available():

        torch.cuda.manual_seed_all(seed)


# ============================================================
# DEVICE
# ============================================================

def get_device():

    if torch.cuda.is_available():

        return torch.device("cuda")

    return torch.device("cpu")


# ============================================================
# MODEL
# ============================================================

def create_global_model(device):

    model = create_model(
        input_features=INPUT_FEATURES,
        num_classes=NUM_CLASSES,
    )

    model.to(device)

    return model


# ============================================================
# MODEL PARAMETERS
# ============================================================

def get_model_parameters(model):

    return {
        key: value.detach().cpu().clone()
        for key, value in model.state_dict().items()
    }


def set_model_parameters(
    model,
    parameters,
):

    model.load_state_dict(
        {
            key: value.clone()
            for key, value in parameters.items()
        }
    )


# ============================================================
# CLIENT TRAINING
# ============================================================

def train_client(
    global_parameters,
    client_id,
    X,
    y,
    device,
    seed,
):

    client_sample_count = int(
        len(y)
    )

    generator = torch.Generator().manual_seed(
        int(seed)
    )

    loader = DataLoader(
        TensorDataset(
            torch.from_numpy(X),
            torch.from_numpy(y),
        ),
        batch_size=BATCH_SIZE,
        shuffle=True,
        generator=generator,
        num_workers=0,
        pin_memory=torch.cuda.is_available(),
    )

    model = create_global_model(
        device
    )

    set_model_parameters(
        model,
        global_parameters
    )

    criterion = nn.CrossEntropyLoss()

    optimizer = torch.optim.Adam(
        model.parameters(),
        lr=LEARNING_RATE,
        weight_decay=WEIGHT_DECAY,
    )

    model.train()

    total_loss = 0.0
    total_correct = 0
    total_samples = 0

    start_time = time.time()

    for epoch in range(
        LOCAL_EPOCHS
    ):

        for X, y in loader:

            X = X.to(device)
            y = y.to(device)

            optimizer.zero_grad(
                set_to_none=True
            )

            logits = model(X)

            loss = criterion(
                logits,
                y
            )

            loss.backward()

            optimizer.step()

            batch_size = X.size(0)

            total_loss += (
                loss.item()
                * batch_size
            )

            predictions = torch.argmax(
                logits,
                dim=1
            )

            total_correct += (
                predictions == y
            ).sum().item()

            total_samples += batch_size

    loss_value = (
        total_loss / total_samples
    )

    accuracy = (
        total_correct / total_samples
    )

    training_time = (
        time.time() - start_time
    )

    return (
        get_model_parameters(model),
        client_sample_count,
        {
            "client_id": client_id,
            "samples": client_sample_count,
            "loss": float(loss_value),
            "accuracy": float(accuracy),
            "training_time_seconds":
                float(training_time),
        },
    )


# ============================================================
# NORMALIZE
# ============================================================

def normalize(values):

    values = np.asarray(
        values,
        dtype=np.float64
    )

    minimum = values.min()
    maximum = values.max()

    if (
        maximum - minimum
        < 1e-12
    ):

        return np.ones_like(
            values
        )

    return (
        values - minimum
    ) / (
        maximum - minimum
    )


# ============================================================
# CLASS STATISTICS
# ============================================================

def get_client_class_counts():

    statistics_path = (
        PROJECT_ROOT
        / "data"
        / "federated"
        / SCENARIO_NAME
        / "client_statistics.json"
    )

    if not statistics_path.exists():

        raise FileNotFoundError(
            f"Client statistics not found:\n"
            f"{statistics_path}"
        )

    with open(
        statistics_path,
        "r",
        encoding="utf-8",
    ) as file:

        data = json.load(file)

    if "clients" in data:

        clients = data["clients"]

    elif "client_statistics" in data:

        clients = data[
            "client_statistics"
        ]

    else:

        clients = list(
            data.values()
        )

    if isinstance(clients, dict):

        clients = list(
            clients.values()
        )

    all_counts = []

    for client in clients:

        counts = client.get(
            "class_counts"
        )

        if counts is None:

            raise ValueError(
                "class_counts missing "
                "from client statistics."
            )

        vector = np.zeros(
            NUM_CLASSES,
            dtype=np.float64
        )

        for i in range(
            NUM_CLASSES
        ):

            if str(i) in counts:

                vector[i] = float(
                    counts[str(i)]
                )

            elif CLASS_NAMES[i] in counts:

                vector[i] = float(
                    counts[
                        CLASS_NAMES[i]
                    ]
                )

        all_counts.append(
            vector
        )

    if len(all_counts) != NUM_CLIENTS:

        raise ValueError(
            f"Expected {NUM_CLIENTS} clients, "
            f"found {len(all_counts)}."
        )

    return all_counts


# ============================================================
# DIVERSITY
# ============================================================

def calculate_diversity(
    counts
):

    total = counts.sum()

    if total <= 0:

        return 0.0

    probabilities = (
        counts / total
    )

    probabilities = probabilities[
        probabilities > 0
    ]

    if len(probabilities) <= 1:

        return 0.0

    entropy = -np.sum(
        probabilities
        * np.log(probabilities)
    )

    max_entropy = np.log(
        NUM_CLASSES
    )

    return float(
        entropy / max_entropy
    )


# ============================================================
# COVERAGE
# ============================================================

def calculate_coverage(
    counts
):

    represented = np.sum(
        counts > 0
    )

    return float(
        represented / NUM_CLASSES
    )


# ============================================================
# ADAPTIVE WEIGHTS
# ============================================================

def calculate_adaptive_weights(
    client_metrics,
    class_counts,
):

    # --------------------------------------------------------
    # Local quality
    # --------------------------------------------------------

    accuracies = np.array(
        [
            item["accuracy"]
            for item
            in client_metrics
        ],
        dtype=np.float64
    )

    losses = np.array(
        [
            item["loss"]
            for item
            in client_metrics
        ],
        dtype=np.float64
    )

    # Quality combines local accuracy
    # and inverse loss.

    inverse_loss = (
        1.0 / (1.0 + losses)
    )

    quality_raw = (
        0.5 * accuracies
        +
        0.5 * inverse_loss
    )

    # --------------------------------------------------------
    # Diversity
    # --------------------------------------------------------

    diversity_raw = np.array(
        [
            calculate_diversity(
                counts
            )
            for counts
            in class_counts
        ],
        dtype=np.float64
    )

    # --------------------------------------------------------
    # Coverage
    # --------------------------------------------------------

    coverage_raw = np.array(
        [
            calculate_coverage(
                counts
            )
            for counts
            in class_counts
        ],
        dtype=np.float64
    )

    # --------------------------------------------------------
    # Reliability
    #
    # More stable distribution +
    # better local quality.
    # --------------------------------------------------------

    reliability_raw = (
        0.5 * diversity_raw
        +
        0.5 * quality_raw
    )

    # --------------------------------------------------------
    # Normalize
    # --------------------------------------------------------

    quality = normalize(
        quality_raw
    )

    diversity = normalize(
        diversity_raw
    )

    coverage = normalize(
        coverage_raw
    )

    reliability = normalize(
        reliability_raw
    )

    # --------------------------------------------------------
    # Adaptive score
    # --------------------------------------------------------

    scores = (
        QUALITY_WEIGHT
        * quality
        +
        DIVERSITY_WEIGHT
        * diversity
        +
        COVERAGE_WEIGHT
        * coverage
        +
        RELIABILITY_WEIGHT
        * reliability
    )

    # --------------------------------------------------------
    # Soft sample weighting
    # --------------------------------------------------------

    sample_counts = np.array(
        [
            item["samples"]
            for item
            in client_metrics
        ],
        dtype=np.float64
    )

    sample_factor = np.sqrt(
        sample_counts
    )

    raw_weights = (
        sample_factor
        * (scores + 1e-8)
    )

    weights = (
        raw_weights
        / raw_weights.sum()
    )

    return (
        weights,
        {
            "quality":
                quality.tolist(),

            "diversity":
                diversity.tolist(),

            "coverage":
                coverage.tolist(),

            "reliability":
                reliability.tolist(),

            "adaptive_scores":
                scores.tolist(),

            "sample_factor":
                sample_factor.tolist(),

            "final_weights":
                weights.tolist(),
        }
    )


# ============================================================
# FEDAVG WEIGHTS
# ============================================================

def calculate_fedavg_weights(
    sample_counts
):

    counts = np.asarray(
        sample_counts,
        dtype=np.float64
    )

    return (
        counts / counts.sum()
    )


# ============================================================
# AGGREGATION
# ============================================================

def adaptive_aggregate(
    client_parameters,
    weights,
):

    if len(client_parameters) != len(
        weights
    ):

        raise ValueError(
            "Number of models and "
            "weights do not match."
        )

    if abs(
        np.sum(weights) - 1.0
    ) > 1e-6:

        raise ValueError(
            "Aggregation weights "
            "must sum to 1."
        )

    aggregated = {}

    keys = client_parameters[0].keys()

    for key in keys:

        result = None

        for parameters, weight in zip(
            client_parameters,
            weights
        ):

            value = (
                parameters[key]
                .float()
            )

            contribution = (
                float(weight)
                * value
            )

            if result is None:

                result = contribution

            else:

                result += contribution

        aggregated[key] = result

    return aggregated


# ============================================================
# VALIDATION
# ============================================================

def evaluate_model(
    model,
    dataset,
    device,
):

    loader = DataLoader(
        dataset,
        batch_size=BATCH_SIZE,
        shuffle=False,
        num_workers=0,
    )

    model.eval()

    criterion = nn.CrossEntropyLoss()

    total_loss = 0.0
    total_samples = 0
    correct = 0

    y_true = []
    y_pred = []

    with torch.no_grad():

        for X, y in loader:

            X = X.to(device)
            y = y.to(device)

            logits = model(X)

            loss = criterion(
                logits,
                y
            )

            batch_size = X.size(0)

            total_loss += (
                loss.item()
                * batch_size
            )

            total_samples += batch_size

            predictions = torch.argmax(
                logits,
                dim=1
            )

            correct += (
                predictions == y
            ).sum().item()

            y_true.append(
                y.cpu().numpy()
            )

            y_pred.append(
                predictions.cpu()
                .numpy()
            )

    from sklearn.metrics import (
        precision_score,
        recall_score,
        f1_score,
    )

    y_true = np.concatenate(y_true)
    y_pred = np.concatenate(y_pred)

    return {

        "loss":
            float(
                total_loss
                / total_samples
            ),

        "accuracy":
            float(
                correct
                / total_samples
            ),

        "precision_macro":
            float(
                precision_score(
                    y_true,
                    y_pred,
                    average="macro",
                    zero_division=0,
                )
            ),

        "recall_macro":
            float(
                recall_score(
                    y_true,
                    y_pred,
                    average="macro",
                    zero_division=0,
                )
            ),

        "f1_macro":
            float(
                f1_score(
                    y_true,
                    y_pred,
                    average="macro",
                    zero_division=0,
                )
            ),

        "f1_weighted":
            float(
                f1_score(
                    y_true,
                    y_pred,
                    average="weighted",
                    zero_division=0,
                )
            ),
    }


# ============================================================
# SAVE JSON
# ============================================================

def save_json(
    data,
    path
):

    path.parent.mkdir(
        parents=True,
        exist_ok=True
    )

    with open(
        path,
        "w",
        encoding="utf-8",
    ) as file:

        json.dump(
            data,
            file,
            indent=4,
        )


# ============================================================
# MAIN
# ============================================================

def main():

    print(
        "=" * 70
    )

    print(
        "AEFL-OSIDS CLASS-AWARE "
        "ADAPTIVE FEDERATED LEARNING"
    )

    print(
        "=" * 70
    )

    set_seed(SEED)

    device = get_device()

    print()

    print(
        f"Device       : {device}"
    )

    print(
        f"Scenario     : {SCENARIO_NAME}"
    )

    print(
        f"Clients      : {NUM_CLIENTS}"
    )

    print(
        f"FL Rounds    : {FL_ROUNDS}"
    )

    print(
        f"Local Epochs : {LOCAL_EPOCHS}"
    )

    print(
        f"Batch Size   : {BATCH_SIZE}"
    )

    print()

    print(
        "Adaptive aggregation:"
    )

    print(
        "  Quality      = 0.30"
    )

    print(
        "  Diversity    = 0.25"
    )

    print(
        "  Coverage     = 0.25"
    )

    print(
        "  Reliability  = 0.20"
    )

    print(
        "  Sample factor = sqrt(n)"
    )

    # --------------------------------------------------------
    # Federated client and validation arrays
    # --------------------------------------------------------

    print()
    print(
        "Loading federated data efficiently..."
    )

    client_arrays = load_federated_client_arrays(
        scenario=SCENARIO_NAME,
        num_clients=NUM_CLIENTS,
        num_classes=NUM_CLASSES,
        input_features=INPUT_FEATURES,
    )

    validation_X, validation_y = load_known_split_arrays(
        scenario=SCENARIO_NAME,
        split_name="validation",
        num_classes=NUM_CLASSES,
        input_features=INPUT_FEATURES,
    )

    validation_dataset = TensorDataset(
        torch.from_numpy(validation_X),
        torch.from_numpy(validation_y),
    )

    print()

    print(
        f"Validation samples: "
        f"{len(validation_y):,}"
    )

    # --------------------------------------------------------
    # Client distributions
    # --------------------------------------------------------

    class_counts = (
        get_client_class_counts()
    )

    print()

    print(
        "Client class statistics loaded."
    )

    # --------------------------------------------------------
    # Global model
    # --------------------------------------------------------

    global_model = create_global_model(
        device
    )

    global_parameters = (
        get_model_parameters(
            global_model
        )
    )

    history = []

    best_validation_f1 = -1.0
    best_round = 0
    best_parameters = None

    experiment_start = time.time()

    # ========================================================
    # FEDERATED ROUNDS
    # ========================================================

    for round_number in range(
        1,
        FL_ROUNDS + 1
    ):

        print()

        print(
            "=" * 70
        )

        print(
            f"ADAPTIVE ROUND "
            f"{round_number}/{FL_ROUNDS}"
        )

        print(
            "=" * 70
        )

        round_start = time.time()

        client_parameters = []
        client_metrics = []

        # ----------------------------------------------------
        # Train clients
        # ----------------------------------------------------

        for client_id in range(
            NUM_CLIENTS
        ):

            print()

            print(
                f"[Client "
                f"{client_id + 1}/"
                f"{NUM_CLIENTS}] Training..."
            )

            client_X, client_y = client_arrays[
                client_id
            ]

            (
                parameters,
                samples,
                metrics,
            ) = train_client(
                global_parameters,
                client_id,
                client_X,
                client_y,
                device,
                SEED
                + round_number * 100
                + client_id,
            )

            client_parameters.append(
                parameters
            )

            client_metrics.append(
                metrics
            )

            print(
                f"  Samples : "
                f"{samples:,}"
            )

            print(
                f"  Loss    : "
                f"{metrics['loss']:.6f}"
            )

            print(
                f"  Accuracy: "
                f"{metrics['accuracy']:.6f}"
            )

            print(
                f"  Time    : "
                f"{metrics['training_time_seconds']:.2f}s"
            )

        # ----------------------------------------------------
        # Adaptive weights
        # ----------------------------------------------------

        (
            adaptive_weights,
            details
        ) = calculate_adaptive_weights(
            client_metrics,
            class_counts
        )

        sample_counts = [
            item["samples"]
            for item
            in client_metrics
        ]

        fedavg_weights = (
            calculate_fedavg_weights(
                sample_counts
            )
        )

        print()

        print(
            "Adaptive aggregation weights:"
        )

        for i, weight in enumerate(
            adaptive_weights
        ):

            print(
                f"  Client {i + 1}: "
                f"{weight:.6f}"
            )

        print()

        print(
            "FedAvg sample weights:"
        )

        for i, weight in enumerate(
            fedavg_weights
        ):

            print(
                f"  Client {i + 1}: "
                f"{weight:.6f}"
            )

        # ----------------------------------------------------
        # Aggregate
        # ----------------------------------------------------

        print()

        print(
            "Aggregating client models..."
        )

        global_parameters = (
            adaptive_aggregate(
                client_parameters,
                adaptive_weights
            )
        )

        set_model_parameters(
            global_model,
            global_parameters
        )

        # ----------------------------------------------------
        # Validation
        # ----------------------------------------------------

        print()

        print(
            "Evaluating global model..."
        )

        validation_metrics = (
            evaluate_model(
                global_model,
                validation_dataset,
                device
            )
        )

        round_time = (
            time.time()
            - round_start
        )

        record = {

            "round":
                round_number,

            "validation":
                validation_metrics,

            "client_metrics":
                client_metrics,

            "adaptive_weights":
                [
                    float(x)
                    for x
                    in adaptive_weights
                ],

            "fedavg_weights":
                [
                    float(x)
                    for x
                    in fedavg_weights
                ],

            "weight_details":
                details,

            "round_time_seconds":
                float(round_time),
        }

        history.append(record)

        current_f1 = float(
            validation_metrics["f1_macro"]
        )
        if current_f1 > best_validation_f1:
            best_validation_f1 = current_f1
            best_round = round_number
            best_parameters = {
                key: value.detach().cpu().clone()
                for key, value in global_parameters.items()
            }

        print()

        print(
            "-" * 70
        )

        print(
            f"Round {round_number} result:"
        )

        print(
            f"  Validation Loss     : "
            f"{validation_metrics['loss']:.6f}"
        )

        print(
            f"  Validation Accuracy : "
            f"{validation_metrics['accuracy']:.6f}"
        )

        print(
            f"  Macro Precision     : "
            f"{validation_metrics['precision_macro']:.6f}"
        )

        print(
            f"  Macro Recall        : "
            f"{validation_metrics['recall_macro']:.6f}"
        )

        print(
            f"  Macro F1            : "
            f"{validation_metrics['f1_macro']:.6f}"
        )

        print(
            f"  Weighted F1         : "
            f"{validation_metrics['f1_weighted']:.6f}"
        )

        print(
            f"  Round time          : "
            f"{round_time:.2f}s"
        )

    # ========================================================
    # SAVE
    # ========================================================

    if best_parameters is None:
        raise RuntimeError(
            "Adaptive FedAvg did not produce a valid global model."
        )

    global_parameters = best_parameters
    set_model_parameters(
        global_model,
        global_parameters,
    )

    results_dir = (
        PROJECT_ROOT
        / "results"
        / "adaptive_fedavg_v2"
    )

    model_dir = (
        PROJECT_ROOT
        / "data"
        / "models"
    )

    results_dir.mkdir(
        parents=True,
        exist_ok=True
    )

    model_dir.mkdir(
        parents=True,
        exist_ok=True
    )

    # --------------------------------------------------------
    # Model
    # --------------------------------------------------------

    model_path = (
        model_dir
        / "adaptive_fedavg_v2_global.pt"
    )

    torch.save(
        {
            "model_state_dict":
                global_model.state_dict(),

            "input_features":
                INPUT_FEATURES,

            "num_classes":
                NUM_CLASSES,

            "class_names":
                CLASS_NAMES,

            "scenario":
                SCENARIO_NAME,

            "rounds":
                FL_ROUNDS,

            "best_round":
                best_round,

            "best_validation_f1_macro":
                best_validation_f1,

            "local_epochs":
                LOCAL_EPOCHS,

            "batch_size":
                BATCH_SIZE,

            "learning_rate":
                LEARNING_RATE,

            "quality_weight":
                QUALITY_WEIGHT,

            "diversity_weight":
                DIVERSITY_WEIGHT,

            "coverage_weight":
                COVERAGE_WEIGHT,

            "reliability_weight":
                RELIABILITY_WEIGHT,

            "seed":
                SEED,
        },
        model_path
    )

    # --------------------------------------------------------
    # History
    # --------------------------------------------------------

    save_json(
        history,
        results_dir
        / "round_history.json"
    )

    # --------------------------------------------------------
    # Final metrics
    # --------------------------------------------------------

    final_metrics = (
        history[best_round - 1]["validation"]
    )

    save_json(
        final_metrics,
        results_dir
        / "final_metrics.json"
    )

    # --------------------------------------------------------
    # Metadata
    # --------------------------------------------------------

    metadata = {

        "scenario":
            SCENARIO_NAME,

        "clients":
            NUM_CLIENTS,

        "rounds":
            FL_ROUNDS,

        "local_epochs":
            LOCAL_EPOCHS,

        "batch_size":
            BATCH_SIZE,

        "learning_rate":
            LEARNING_RATE,

        "quality_weight":
            QUALITY_WEIGHT,

        "diversity_weight":
            DIVERSITY_WEIGHT,

        "coverage_weight":
            COVERAGE_WEIGHT,

        "reliability_weight":
            RELIABILITY_WEIGHT,

        "sample_weighting":
            "sqrt",

        "seed":
            SEED,

        "total_time_seconds":
            (
                time.time()
                - experiment_start
            ),

        "best_round":
            best_round,

        "best_validation_f1_macro":
            best_validation_f1,
    }

    save_json(
        metadata,
        results_dir
        / "metadata.json"
    )

    # ========================================================
    # FINAL OUTPUT
    # ========================================================

    print()

    print(
        "=" * 70
    )

    print(
        "CLASS-AWARE ADAPTIVE FL "
        "TRAINING COMPLETE"
    )

    print(
        "=" * 70
    )

    print()

    print(
        "Final validation metrics:"
    )

    for key, value in (
        final_metrics.items()
    ):

        print(
            f"  {key:<22}: "
            f"{value:.6f}"
        )

    print()

    print(
        f"Best round: {best_round} | "
        f"Validation Macro-F1: {best_validation_f1:.6f}"
    )

    print()

    print(
        "Global model:"
    )

    print(
        model_path
    )

    print()

    print(
        "Results:"
    )

    print(
        results_dir
    )

    print()

    print(
        "Total training time:"
    )

    print(
        f"{time.time() - experiment_start:.2f}s"
    )

    print()

    print(
        "=" * 70
    )


if __name__ == "__main__":

    main()
