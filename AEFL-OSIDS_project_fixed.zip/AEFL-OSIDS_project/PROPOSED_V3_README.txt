AEFL-OSIDS Proposed v3 Update
==============================

Why v3 is needed
----------------
Proposed v2 improved validation Macro-F1 from 0.7973 to 0.8130, but FedAvg
still achieved about 0.8661. The v2 server weights were already almost
identical to FedAvg, which isolated the remaining mismatch:

* FedAvg used inverse-frequency weights computed separately for every client.
* Proposed v2 used one global class-weight vector on every non-IID client.
* Proposed v2 replaced FedAvg classifier weights with class-support weights.

What v3 changes
---------------
1. Uses per-client inverse-frequency weighted cross-entropy, matching FedAvg.
2. Uses the same Adam optimizer as FedAvg for a controlled comparison.
3. Keeps FedAvg weights as 90% of classifier aggregation and blends only 10%
   class-specific support.
4. Retains a bounded 10% reliability correction, FedProx, update clipping,
   validation Macro-F1 selection, and full diagnostics.

Install from PowerShell at the project root
--------------------------------------------
Preserve the completed v2 ablation first:

Copy-Item ".\data\models\robust_adaptive_fedprox_global.pt" ".\data\models\robust_adaptive_fedprox_v2_ablation.pt"
Copy-Item ".\results\robust_adaptive_fedprox" ".\results\robust_adaptive_fedprox_v2_ablation" -Recurse -Force

Extract this ZIP over:
C:\Users\Naveen Pandey\Desktop\AEFL-OSIDS

Verify
------
python -m py_compile .\federated\robust_adaptive_fedprox.py .\tests\test_robust_components.py
python -m unittest tests.test_robust_components -v

Run
---
python main.py train-proposed

Confirm the startup line begins with:
Proposed v3: loss-scope=client

Evaluation rule
---------------
Compare best validation Macro-F1 with FedAvg (about 0.8661). Keep v1, v2,
and v3 as separate ablations. Do not inspect or tune on the test set.
