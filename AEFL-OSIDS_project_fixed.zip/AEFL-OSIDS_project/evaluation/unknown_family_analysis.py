"""
AEFL-OSIDS UNKNOWN FAMILY ANALYSIS

Publication-oriented analysis of unknown attack families using the
EXACT same dataset loader, model loader and test dataset used by
final_open_set_evaluation.py.

Known classes:
    0 = BENIGN
    1 = DDoS
    2 = DoS
    3 = Mirai
    4 = Recon

Unknown families:
    BruteForce
    Spoofing
    Web-based

No model training is performed.
No threshold is recalibrated.
No family labels are fabricated.
"""

from pathlib import Path
import json

import numpy as np
import pandas as pd

import torch
from torch.utils.data import DataLoader

from sklearn.metrics import (
    precision_score,
    recall_score,
    f1_score,
    confusion_matrix,
)

from models.intrusion_model import create_model
from data_loader.cic_iot_dataset import create_dataset


# ============================================================
# CONFIGURATION
# ============================================================

PROJECT_ROOT = Path(__file__).resolve().parents[1]

SCENARIO_NAME = "scenario_C_multiple"

MODEL_PATH = (
    PROJECT_ROOT
    / "data"
    / "models"
    / "adaptive_fedavg_v2_global.pt"
)

CALIBRATION_PATH = (
    PROJECT_ROOT
    / "results"
    / "threshold_calibration"
    / "threshold_calibration.json"
)

OUTPUT_DIR = (
    PROJECT_ROOT
    / "results"
    / "unknown_family_analysis"
)

OUTPUT_DIR.mkdir(
    parents=True,
    exist_ok=True,
)

BATCH_SIZE = 4096

KNOWN_CLASS_NAMES = [
    "BENIGN",
    "DDoS",
    "DoS",
    "Mirai",
    "Recon",
]

UNKNOWN_FAMILIES = [
    "BruteForce",
    "Spoofing",
    "Web-based",
]

UNKNOWN_LABEL = -1

DEVICE = torch.device(
    "cuda"
    if torch.cuda.is_available()
    else "cpu"
)


# ============================================================
# LOAD THRESHOLD
# ============================================================

def load_locked_threshold():
    """
    Load the selected threshold from the project's actual
    threshold_calibration.json structure.
    """

    if not CALIBRATION_PATH.exists():
        raise FileNotFoundError(
            f"Calibration file not found:\n"
            f"{CALIBRATION_PATH}"
        )

    with CALIBRATION_PATH.open(
        "r",
        encoding="utf-8",
    ) as file:
        data = json.load(file)

    # ============================================================
    # ACTUAL PROJECT STRUCTURE
    #
    # "selected_operating_point": {
    #     ...
    #     "threshold": 0.569957...
    # }
    # ============================================================

    selected = data.get(
        "selected_operating_point"
    )

    if isinstance(
        selected,
        dict,
    ):

        if "threshold" in selected:

            return float(
                selected["threshold"]
            )

        # Compatibility if the field is named differently.
        for key in [
            "selected_threshold",
            "locked_threshold",
            "operating_threshold",
        ]:

            if key in selected:

                return float(
                    selected[key]
                )

    # ============================================================
    # Compatibility with direct formats
    # ============================================================

    for key in [
        "selected_threshold",
        "locked_threshold",
        "threshold",
    ]:

        if key in data:

            value = data[key]

            if isinstance(
                value,
                (int, float),
            ):

                return float(value)

    # ============================================================
    # Helpful diagnostic
    # ============================================================

    raise KeyError(
        "Could not find calibrated threshold.\n"
        f"Calibration file:\n{CALIBRATION_PATH}\n\n"
        f"Top-level keys:\n{list(data.keys())}\n\n"
        "Expected threshold inside "
        "'selected_operating_point'."
    )


# ============================================================
# LOAD MODEL
# ============================================================

def load_global_model():

    if not MODEL_PATH.exists():

        raise FileNotFoundError(
            f"Global model not found:\n"
            f"{MODEL_PATH}"
        )

    print(
        "Loading Adaptive FedAvg v2 model..."
    )

    print(
        f"Model: {MODEL_PATH}"
    )

    model = create_model(
        num_classes=5
    )

    checkpoint = torch.load(
        MODEL_PATH,
        map_location=DEVICE,
    )

    # --------------------------------------------------------
    # Handle common checkpoint structures.
    # --------------------------------------------------------

    if isinstance(
        checkpoint,
        dict,
    ):

        if "model_state_dict" in checkpoint:

            state_dict = (
                checkpoint[
                    "model_state_dict"
                ]
            )

        elif "state_dict" in checkpoint:

            state_dict = (
                checkpoint[
                    "state_dict"
                ]
            )

        else:

            state_dict = checkpoint

    else:

        raise ValueError(
            "Unsupported global model checkpoint format."
        )

    model.load_state_dict(
        state_dict,
        strict=True,
    )

    model.to(
        DEVICE
    )

    model.eval()

    print(
        "Model loaded successfully."
    )

    return model


# ============================================================
# INFERENCE
# ============================================================

def run_inference(
    model,
    dataset,
):

    loader = DataLoader(
        dataset,
        batch_size=BATCH_SIZE,
        shuffle=False,
        num_workers=0,
    )

    true_labels = []
    predicted_labels = []
    confidence_values = []

    print(
        f"Running inference with "
        f"batch size {BATCH_SIZE}..."
    )

    with torch.no_grad():

        for X, y in loader:

            X = X.to(
                DEVICE,
                non_blocking=True,
            )

            logits = model(
                X
            )

            probabilities = (
                torch.softmax(
                    logits,
                    dim=1,
                )
            )

            confidence, predictions = (
                torch.max(
                    probabilities,
                    dim=1,
                )
            )

            true_labels.append(
                y.cpu().numpy()
            )

            predicted_labels.append(
                predictions.cpu().numpy()
            )

            confidence_values.append(
                confidence.cpu().numpy()
            )

    y_true = np.concatenate(
        true_labels
    )

    predictions = np.concatenate(
        predicted_labels
    )

    confidence = np.concatenate(
        confidence_values
    )

    return (
        y_true,
        predictions,
        confidence,
    )


# ============================================================
# EXTRACT ATTACK FAMILIES
# ============================================================

def extract_attack_families(dataset):
    """
    Extract attack-family metadata from the current
    CICIoTDataset implementation.

    The dataset loader exposes metadata through
    get_attack_families().
    """

    # --------------------------------------------------------
    # Preferred method: current CICIoTDataset API
    # --------------------------------------------------------

    if hasattr(
        dataset,
        "get_attack_families",
    ):

        try:

            families = (
                dataset.get_attack_families()
            )

            if families is not None:

                families = np.asarray(
                    families
                ).reshape(-1)

                if len(families) == len(dataset):

                    return families

        except Exception as exc:

            print(
                "Warning: get_attack_families() "
                f"failed: {exc}"
            )

    # --------------------------------------------------------
    # Compatibility with an older dataset implementation
    # --------------------------------------------------------

    if hasattr(
        dataset,
        "data",
    ):

        data = dataset.data

        if hasattr(
            data,
            "attack_family",
        ):

            families = (
                data.attack_family
            )

            families = np.asarray(
                families
            ).reshape(-1)

            if len(families) == len(dataset):

                return families

    # --------------------------------------------------------
    # Metadata unavailable
    # --------------------------------------------------------

    return None

# ============================================================
# NORMALIZE FAMILY NAMES
# ============================================================

def normalize_family_name(
    value,
):

    text = str(
        value
    ).strip()

    lower = text.lower()

    # --------------------------------------------------------
    # BruteForce
    # --------------------------------------------------------

    if (
        "bruteforce" in lower
        or "brute force" in lower
    ):

        return "BruteForce"

    # --------------------------------------------------------
    # Spoofing
    # --------------------------------------------------------

    if "spoof" in lower:

        return "Spoofing"

    # --------------------------------------------------------
    # Web-based
    # --------------------------------------------------------

    if (
        "web-based" in lower
        or "web based" in lower
        or "webbased" in lower
        or lower == "web"
    ):

        return "Web-based"

    return text


# ============================================================
# UNKNOWN FAMILY ANALYSIS
# ============================================================

def analyze_unknown_families(
    families,
    final_predictions,
    confidence,
    y_true,
    threshold,
):

    """
    Calculate family-level UNKNOWN detection performance.

    A sample is detected as UNKNOWN when:

        max(class probability) < threshold

    The supervised model itself does not output:
        BruteForce
        Spoofing
        Web-based

    Therefore the primary family-level metric is:

        Unknown Detection Recall

    i.e. percentage of samples from a family rejected as UNKNOWN.
    """

    if families is None:

        return None

    families = np.asarray(
        families
    ).reshape(-1)

    if len(families) != len(y_true):

        raise ValueError(
            "Attack-family metadata length does not match "
            "test dataset length.\n"
            f"Families : {len(families)}\n"
            f"Labels   : {len(y_true)}"
        )

    unknown_decision = (
        confidence < threshold
    )

    results = []

    print()
    print("=" * 70)
    print("UNKNOWN FAMILY PERFORMANCE")
    print("=" * 70)

    for family in UNKNOWN_FAMILIES:

        normalized = np.array(
            [
                normalize_family_name(
                    value
                )
                for value in families
            ],
            dtype=object,
        )

        family_mask = (
            normalized == family
        )

        sample_count = int(
            np.sum(
                family_mask
            )
        )

        if sample_count == 0:

            print()
            print(
                f"{family}: NO SAMPLES FOUND"
            )

            results.append(
                {
                    "family": family,
                    "samples": 0,
                    "detected_unknown": 0,
                    "not_detected_unknown": 0,
                    "unknown_detection_recall": None,
                    "mean_confidence": None,
                }
            )

            continue

        family_unknown = (
            unknown_decision[
                family_mask
            ]
        )

        detected_unknown = int(
            np.sum(
                family_unknown
            )
        )

        not_detected = (
            sample_count
            - detected_unknown
        )

        recall = (
            detected_unknown
            / sample_count
        )

        mean_confidence = float(
            np.mean(
                confidence[
                    family_mask
                ]
            )
        )

        print()
        print(
            f"{family}"
        )

        print(
            f"  Samples                : "
            f"{sample_count:,}"
        )

        print(
            f"  Detected as UNKNOWN    : "
            f"{detected_unknown:,}"
        )

        print(
            f"  Not detected           : "
            f"{not_detected:,}"
        )

        print(
            f"  Unknown detection recall: "
            f"{recall * 100:.2f}%"
        )

        print(
            f"  Mean confidence        : "
            f"{mean_confidence:.6f}"
        )

        results.append(
            {
                "family": family,
                "samples": sample_count,
                "detected_unknown": detected_unknown,
                "not_detected_unknown": not_detected,
                "unknown_detection_recall": recall,
                "mean_confidence": mean_confidence,
            }
        )

    return results


# ============================================================
# SAVE FAMILY RESULTS
# ============================================================

def save_results(
    family_results,
    threshold,
    total_samples,
    total_unknown,
):

    json_path = (
        OUTPUT_DIR
        / "unknown_family_analysis.json"
    )

    csv_path = (
        OUTPUT_DIR
        / "unknown_family_performance.csv"
    )

    summary_path = (
        OUTPUT_DIR
        / "unknown_family_analysis.txt"
    )

    json_data = {
        "experiment":
            "Unknown Family Analysis",

        "scenario":
            SCENARIO_NAME,

        "threshold":
            float(threshold),

        "test_samples":
            int(total_samples),

        "unknown_samples":
            int(total_unknown),

        "unknown_families":
            UNKNOWN_FAMILIES,

        "family_performance":
            family_results,
    }

    with json_path.open(
        "w",
        encoding="utf-8",
    ) as file:

        json.dump(
            json_data,
            file,
            indent=4,
        )

    dataframe = pd.DataFrame(
        family_results
    )

    dataframe.to_csv(
        csv_path,
        index=False,
        encoding="utf-8-sig",
    )

    lines = [
        "AEFL-OSIDS UNKNOWN FAMILY ANALYSIS",
        "=" * 70,
        "",
        f"Scenario          : {SCENARIO_NAME}",
        f"Locked threshold  : {threshold:.6f}",
        f"Test samples      : {total_samples:,}",
        f"Unknown samples   : {total_unknown:,}",
        "",
        "UNKNOWN FAMILY PERFORMANCE",
        "-" * 70,
        "",
    ]

    for result in family_results:

        lines.extend(
            [
                f"Family: {result['family']}",
                f"  Samples                 : "
                f"{result['samples']:,}",
                f"  Detected as UNKNOWN     : "
                f"{result['detected_unknown']:,}",
                f"  Not detected            : "
                f"{result['not_detected_unknown']:,}",
            ]
        )

        recall = (
            result[
                "unknown_detection_recall"
            ]
        )

        mean_confidence = (
            result[
                "mean_confidence"
            ]
        )

        if recall is not None:

            lines.append(
                f"  Unknown detection recall : "
                f"{recall * 100:.2f}%"
            )

        if mean_confidence is not None:

            lines.append(
                f"  Mean confidence         : "
                f"{mean_confidence:.6f}"
            )

        lines.append("")

    lines.extend(
        [
            "INTERPRETATION",
            "-" * 70,
            "",
            "The five-class model predicts only:",
            "BENIGN, DDoS, DoS, Mirai and Recon.",
            "",
            "BruteForce, Spoofing and Web-based are treated as",
            "unknown attack families.",
            "",
            "A sample is classified as UNKNOWN when its maximum",
            "known-class confidence is below the locked threshold.",
            "",
            "Family-level precision/F1 are not reported because",
            "the supervised model does not predict individual",
            "unknown-family identities.",
            "",
            "No family-level values were fabricated.",
        ]
    )

    summary_path.write_text(
        "\n".join(lines),
        encoding="utf-8",
    )

    print()
    print(
        f"JSON    : {json_path}"
    )

    print(
        f"CSV     : {csv_path}"
    )

    print(
        f"Summary : {summary_path}"
    )


# ============================================================
# MAIN
# ============================================================

def main():

    print("=" * 70)
    print("AEFL-OSIDS UNKNOWN FAMILY ANALYSIS")
    print("=" * 70)

    print()
    print(
        f"Device   : {DEVICE}"
    )

    print(
        f"Scenario : {SCENARIO_NAME}"
    )

    # --------------------------------------------------------
    # Threshold
    # --------------------------------------------------------

    print()
    print(
        "Loading calibrated threshold..."
    )

    threshold = load_locked_threshold()

    print(
        f"Locked threshold: {threshold:.6f}"
    )

    # --------------------------------------------------------
    # Model
    # --------------------------------------------------------

    print()

    model = load_global_model()

    # --------------------------------------------------------
    # Dataset
    # --------------------------------------------------------

    print()
    print(
        "Loading TEST dataset..."
    )

    test_dataset = create_dataset(
        SCENARIO_NAME,
        "test",
    )

    print(
        f"Test samples: "
        f"{len(test_dataset):,}"
    )

    # --------------------------------------------------------
    # Family metadata
    # --------------------------------------------------------

    print()
    print(
        "Extracting attack-family metadata..."
    )

    families = (
        extract_attack_families(
            test_dataset
        )
    )

    if families is None:

        print()
        print("=" * 70)
        print("ATTACK-FAMILY METADATA NOT AVAILABLE")
        print("=" * 70)

        print()
        print(
            "The dataset object does not expose "
            "data.attack_family."
        )

        print()
        print(
            "No family-level metrics will be fabricated."
        )

        output = {
            "experiment":
                "Unknown Family Analysis",

            "scenario":
                SCENARIO_NAME,

            "threshold":
                threshold,

            "status":
                "family_metadata_unavailable",

            "unknown_families":
                UNKNOWN_FAMILIES,

            "test_samples":
                int(len(test_dataset)),
        }

        output_path = (
            OUTPUT_DIR
            / "unknown_family_analysis.json"
        )

        with output_path.open(
            "w",
            encoding="utf-8",
        ) as file:

            json.dump(
                output,
                file,
                indent=4,
            )

        print(
            f"Saved: {output_path}"
        )

        return

    print(
        f"Attack-family entries: "
        f"{len(families):,}"
    )

    # --------------------------------------------------------
    # Inference
    # --------------------------------------------------------

    print()
    print(
        "=" * 70
    )
    print(
        "RUNNING TEST INFERENCE"
    )
    print(
        "=" * 70
    )

    (
        y_true,
        predictions,
        confidence,
    ) = run_inference(
        model,
        test_dataset,
    )

    print()
    print(
        "Inference complete."
    )

    # --------------------------------------------------------
    # Verify sizes
    # --------------------------------------------------------

    if len(families) != len(y_true):

        raise RuntimeError(
            "Family metadata and inference results have "
            "different lengths."
        )

    # --------------------------------------------------------
    # Unknown samples
    # --------------------------------------------------------

    unknown_ground_truth = (
        y_true == UNKNOWN_LABEL
    )

    total_unknown = int(
        np.sum(
            unknown_ground_truth
        )
    )

    unknown_detected = (
        confidence < threshold
    )

    # --------------------------------------------------------
    # Family analysis
    # --------------------------------------------------------

    family_results = (
        analyze_unknown_families(
            families,
            predictions,
            confidence,
            y_true,
            threshold,
        )
    )

    if family_results is None:
        return

    # --------------------------------------------------------
    # Save
    # --------------------------------------------------------

    save_results(
        family_results,
        threshold,
        len(y_true),
        total_unknown,
    )

    # --------------------------------------------------------
    # Final information
    # --------------------------------------------------------

    print()
    print("=" * 70)
    print("UNKNOWN FAMILY ANALYSIS COMPLETE")
    print("=" * 70)

    print()
    print(
        f"Threshold             : "
        f"{threshold:.6f}"
    )

    print(
        f"Test samples          : "
        f"{len(y_true):,}"
    )

    print(
        f"Ground-truth unknown  : "
        f"{total_unknown:,}"
    )

    print(
        f"Detected as UNKNOWN   : "
        f"{np.sum(unknown_detected):,}"
    )

    print()
    print(
        f"Results directory:"
    )

    print(
        OUTPUT_DIR
    )

    print("=" * 70)


if __name__ == "__main__":
    main()