from pathlib import Path
import copy
import json
import random
import time

import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import DataLoader, TensorDataset

from federated.efficient_data import (
    load_federated_client_arrays,
    load_known_split_arrays,
)

from models.intrusion_model import (
    create_model,
)

from utils.config import (
    load_config,
)


# ============================================================
# PROJECT ROOT
# ============================================================

PROJECT_ROOT = (
    Path(__file__).resolve().parents[1]
)


# ============================================================
# EXPERIMENT CONFIGURATION
# ============================================================

SCENARIO_NAME = (
    "scenario_C_multiple"
)

NUM_CLIENTS = 5

NUM_CLASSES = 5

INPUT_FEATURES = 39

CLIENTS_PER_ROUND = 5

# NOTE: these used to be hardcoded module constants, and `load_config()` was
# imported but never actually called anywhere in this file -- editing
# configs/config.yaml had ZERO effect on the FedAvg baseline. They are now
# read from config, with the previous hardcoded values kept only as a
# fallback for a config file that predates these keys.
_config = load_config()

FL_ROUNDS = int(
    _config.get("federated_training", {}).get("rounds", 5)
)

LOCAL_EPOCHS = int(
    _config.get("federated_training", {}).get(
        "local_epochs",
        _config.get("training", {}).get("local_epochs", 1),
    )
)

BATCH_SIZE = int(
    _config.get("training", {}).get("batch_size", 512)
)

LEARNING_RATE = float(
    _config.get("training", {}).get("learning_rate", 0.001)
)

WEIGHT_DECAY = float(
    _config.get("training", {}).get("weight_decay", 0.00001)
)

EARLY_STOPPING_PATIENCE = int(
    _config.get("federated_training", {}).get("early_stopping_patience", 6)
)

SEED = int(
    _config.get("reproducibility", {}).get("seed", 42)
)


CLASS_NAMES = [
    "BENIGN",
    "DDoS",
    "DoS",
    "Mirai",
    "Recon",
]


# ============================================================
# REPRODUCIBILITY
# ============================================================

def set_seed(
    seed: int,
) -> None:

    random.seed(
        seed
    )

    np.random.seed(
        seed
    )

    torch.manual_seed(
        seed
    )

    if torch.cuda.is_available():

        torch.cuda.manual_seed_all(
            seed
        )


# ============================================================
# DEVICE
# ============================================================

def get_device():

    if torch.cuda.is_available():

        return torch.device(
            "cuda"
        )

    return torch.device(
        "cpu"
    )


# ============================================================
# MODEL
# ============================================================

def create_global_model(
    device,
):

    model = create_model(
        input_features=INPUT_FEATURES,
        num_classes=NUM_CLASSES,
    )

    model.to(
        device
    )

    return model


# ============================================================
# GET MODEL PARAMETERS
# ============================================================

def get_model_parameters(
    model,
):

    return {
        key: value.detach()
        .cpu()
        .clone()
        for key, value
        in model.state_dict().items()
    }


# ============================================================
# SET MODEL PARAMETERS
# ============================================================

def set_model_parameters(
    model,
    parameters,
):

    state_dict = {
        key: value.clone()
        for key, value
        in parameters.items()
    }

    model.load_state_dict(
        state_dict
    )


# ============================================================
# CLIENT CLASS WEIGHTS
# ============================================================

def calculate_client_class_weights(
    labels,
    device,
):

    labels = np.asarray(
        labels,
        dtype=np.int64,
    )

    if np.any(
        (labels < 0)
        | (labels >= NUM_CLASSES)
    ):
        raise RuntimeError(
            "Client contains unknown or invalid training labels."
        )

    counts = np.bincount(
        labels,
        minlength=NUM_CLASSES,
    ).astype(np.float64)

    if np.any(
        counts == 0
    ):

        # A client may legitimately not contain
        # every class under a non-IID partition.
        #
        # Therefore missing classes receive
        # zero weight.

        weights = np.zeros(
            NUM_CLASSES,
            dtype=np.float64,
        )

        present = (
            counts > 0
        )

        total = counts[present].sum()

        weights[present] = (
            total
            / (
                present.sum()
                * counts[present]
            )
        )

    else:

        total = counts.sum()

        weights = (
            total
            / (
                NUM_CLASSES
                * counts
            )
        )

    # Normalize only positive weights.

    positive = (
        weights > 0
    )

    if np.any(
        positive
    ):

        weights[positive] /= (
            weights[positive].mean()
        )

    return (
        torch.tensor(
            weights,
            dtype=torch.float32,
            device=device,
        ),
        counts,
    )


# ============================================================
# LOCAL CLIENT TRAINING
# ============================================================

def train_client(
    global_parameters,
    client_id,
    X,
    y,
    device,
    local_epochs=1,
    batch_size=512,
    learning_rate=0.001,
    weight_decay=0.00001,
    seed=42,
):
    """
    Train one client locally starting from the
    current global model.

    Returns:

        client parameters
        number of samples
        local metrics
    """

    client_sample_count = int(
        len(y)
    )

    generator = torch.Generator().manual_seed(
        int(seed)
    )

    loader = DataLoader(
        TensorDataset(
            torch.from_numpy(X),
            torch.from_numpy(y),
        ),
        batch_size=batch_size,
        shuffle=True,
        generator=generator,
        num_workers=0,
        pin_memory=torch.cuda.is_available(),
    )

    model = create_global_model(
        device
    )

    set_model_parameters(
        model,
        global_parameters,
    )

    class_weights, counts = (
        calculate_client_class_weights(
            y,
            device,
        )
    )

    criterion = (
        nn.CrossEntropyLoss(
            weight=class_weights
        )
    )

    optimizer = torch.optim.Adam(
        model.parameters(),
        lr=learning_rate,
        weight_decay=weight_decay,
    )

    model.train()

    total_loss = 0.0

    total_samples = 0

    correct = 0

    start_time = time.time()

    for local_epoch in range(
        local_epochs
    ):

        epoch_loss = 0.0

        epoch_samples = 0

        epoch_correct = 0

        for X, y in loader:

            X = X.to(
                device
            )

            y = y.to(
                device
            )

            optimizer.zero_grad(
                set_to_none=True
            )

            logits = model(
                X
            )

            loss = criterion(
                logits,
                y,
            )

            loss.backward()

            optimizer.step()

            batch_size_actual = (
                X.size(0)
            )

            epoch_loss += (
                loss.item()
                * batch_size_actual
            )

            epoch_samples += (
                batch_size_actual
            )

            predictions = (
                torch.argmax(
                    logits,
                    dim=1,
                )
            )

            epoch_correct += (
                predictions == y
            ).sum().item()

        total_loss = epoch_loss

        total_samples = (
            epoch_samples
        )

        correct = (
            epoch_correct
        )

    training_time = (
        time.time()
        - start_time
    )

    local_loss = (
        total_loss
        / total_samples
    )

    local_accuracy = (
        correct
        / total_samples
    )

    return (
        get_model_parameters(
            model
        ),
        client_sample_count,
        {
            "client_id":
                client_id,

            "samples":
                client_sample_count,

            "loss":
                float(local_loss),

            "accuracy":
                float(local_accuracy),

            "training_time_seconds":
                float(training_time),

            "class_counts":
                {
                    str(i):
                        int(counts[i])
                    for i in range(
                        NUM_CLASSES
                    )
                },
        },
    )


# ============================================================
# FEDAVG AGGREGATION
# ============================================================

def fedavg_aggregate(
    client_parameters,
    client_sample_counts,
):
    """
    Weighted Federated Averaging.

    W_global =
        sum(
            n_k / N * W_k
        )
    """

    if len(
        client_parameters
    ) == 0:

        raise ValueError(
            "No client parameters "
            "provided."
        )

    total_samples = sum(
        client_sample_counts
    )

    if total_samples <= 0:

        raise ValueError(
            "Total client samples "
            "must be positive."
        )

    global_parameters = {}

    parameter_keys = (
        client_parameters[
            0
        ].keys()
    )

    for key in parameter_keys:

        aggregated = None

        for parameters, sample_count in zip(
            client_parameters,
            client_sample_counts,
        ):

            weight = (
                sample_count
                / total_samples
            )

            value = (
                parameters[key]
                .float()
            )

            if aggregated is None:

                aggregated = (
                    weight * value
                )

            else:

                aggregated += (
                    weight * value
                )

        global_parameters[
            key
        ] = aggregated

    return global_parameters


# ============================================================
# VALIDATION
# ============================================================

def evaluate_model(
    model,
    loader,
    device,
):
    """
    Evaluate global model on validation data.
    """

    model.eval()

    criterion = (
        nn.CrossEntropyLoss()
    )

    total_loss = 0.0

    total_samples = 0

    correct = 0

    all_predictions = []

    all_targets = []

    with torch.no_grad():

        for X, y in loader:

            X = X.to(
                device
            )

            y = y.to(
                device
            )

            logits = model(
                X
            )

            loss = criterion(
                logits,
                y,
            )

            batch_size = (
                X.size(0)
            )

            total_loss += (
                loss.item()
                * batch_size
            )

            total_samples += (
                batch_size
            )

            predictions = (
                torch.argmax(
                    logits,
                    dim=1,
                )
            )

            correct += (
                predictions == y
            ).sum().item()

            all_predictions.append(
                predictions
                .cpu()
                .numpy()
            )

            all_targets.append(
                y.cpu()
                .numpy()
            )

    y_true = np.concatenate(
        all_targets
    )

    y_pred = np.concatenate(
        all_predictions
    )

    from sklearn.metrics import (
        precision_score,
        recall_score,
        f1_score,
    )

    accuracy = (
        correct
        / total_samples
    )

    precision_macro = (
        precision_score(
            y_true,
            y_pred,
            average="macro",
            zero_division=0,
        )
    )

    recall_macro = (
        recall_score(
            y_true,
            y_pred,
            average="macro",
            zero_division=0,
        )
    )

    f1_macro = (
        f1_score(
            y_true,
            y_pred,
            average="macro",
            zero_division=0,
        )
    )

    f1_weighted = (
        f1_score(
            y_true,
            y_pred,
            average="weighted",
            zero_division=0,
        )
    )

    return {

        "loss":
            float(
                total_loss
                / total_samples
            ),

        "accuracy":
            float(
                accuracy
            ),

        "precision_macro":
            float(
                precision_macro
            ),

        "recall_macro":
            float(
                recall_macro
            ),

        "f1_macro":
            float(
                f1_macro
            ),

        "f1_weighted":
            float(
                f1_weighted
            ),
    }


# ============================================================
# SAVE JSON
# ============================================================

def save_json(
    data,
    path,
):

    path.parent.mkdir(
        parents=True,
        exist_ok=True,
    )

    with open(
        path,
        "w",
        encoding="utf-8",
    ) as file:

        json.dump(
            data,
            file,
            indent=4,
        )


# ============================================================
# MAIN FEDAVG EXPERIMENT
# ============================================================

def main():

    print("=" * 70)

    print(
        "AEFL-OSIDS FEDAVG BASELINE"
    )

    print("=" * 70)

    set_seed(
        SEED
    )

    device = get_device()

    print()

    print(
        f"Device          : "
        f"{device}"
    )

    print(
        f"Scenario        : "
        f"{SCENARIO_NAME}"
    )

    print(
        f"Clients         : "
        f"{NUM_CLIENTS}"
    )

    print(
        f"Clients/round   : "
        f"{CLIENTS_PER_ROUND}"
    )

    print(
        f"FL rounds       : "
        f"{FL_ROUNDS}"
    )

    print(
        f"Local epochs    : "
        f"{LOCAL_EPOCHS}"
    )

    print(
        f"Batch size      : "
        f"{BATCH_SIZE}"
    )

    print(
        f"Learning rate   : "
        f"{LEARNING_RATE}"
    )

    # --------------------------------------------------------
    # Federated client and validation arrays
    # --------------------------------------------------------

    print()

    print(
        "Loading federated data efficiently..."
    )

    client_arrays = load_federated_client_arrays(
        scenario=SCENARIO_NAME,
        num_clients=NUM_CLIENTS,
        num_classes=NUM_CLASSES,
        input_features=INPUT_FEATURES,
    )

    validation_X, validation_y = load_known_split_arrays(
        scenario=SCENARIO_NAME,
        split_name="validation",
        num_classes=NUM_CLASSES,
        input_features=INPUT_FEATURES,
    )

    validation_loader = DataLoader(
        TensorDataset(
            torch.from_numpy(validation_X),
            torch.from_numpy(validation_y),
        ),
        batch_size=BATCH_SIZE,
        shuffle=False,
        num_workers=0,
        pin_memory=torch.cuda.is_available(),
    )

    print(
        f"Validation samples: "
        f"{len(validation_y):,}"
    )

    # --------------------------------------------------------
    # Global model
    # --------------------------------------------------------

    global_model = (
        create_global_model(
            device
        )
    )

    global_parameters = (
        get_model_parameters(
            global_model
        )
    )

    # --------------------------------------------------------
    # Output
    # --------------------------------------------------------

    results_dir = (
        PROJECT_ROOT
        / "results"
        / "fedavg"
    )

    model_dir = (
        PROJECT_ROOT
        / "data"
        / "models"
    )

    results_dir.mkdir(
        parents=True,
        exist_ok=True,
    )

    model_dir.mkdir(
        parents=True,
        exist_ok=True,
    )

    history = []

    best_validation_f1 = -1.0
    best_round = 0
    best_parameters = None
    rounds_without_improvement = 0

    experiment_start = (
        time.time()
    )

    # ========================================================
    # FEDERATED ROUNDS
    # ========================================================

    for round_number in range(
        1,
        FL_ROUNDS + 1,
    ):

        print()

        print(
            "=" * 70
        )

        print(
            f"FEDERATED ROUND "
            f"{round_number}/{FL_ROUNDS}"
        )

        print(
            "=" * 70
        )

        round_start = time.time()

        client_parameters = []

        client_sample_counts = []

        client_metrics = []

        # ----------------------------------------------------
        # Select clients
        # ----------------------------------------------------

        selected_clients = list(
            range(
                NUM_CLIENTS
            )
        )

        if (
            CLIENTS_PER_ROUND
            < NUM_CLIENTS
        ):

            rng = np.random.default_rng(
                SEED
                + round_number
            )

            selected_clients = (
                rng.choice(
                    NUM_CLIENTS,
                    size=CLIENTS_PER_ROUND,
                    replace=False,
                )
                .tolist()
            )

        print()

        print(
            "Selected clients:"
        )

        print(
            [
                client_id + 1
                for client_id
                in selected_clients
            ]
        )

        # ----------------------------------------------------
        # Local training
        # ----------------------------------------------------

        for position, client_id in enumerate(
            selected_clients,
            start=1,
        ):

            print()

            print(
                f"[Client "
                f"{position}/"
                f"{len(selected_clients)}] "
                f"Training Client "
                f"{client_id + 1}..."
            )

            client_start = (
                time.time()
            )

            client_X, client_y = client_arrays[
                client_id
            ]

            (
                parameters,
                sample_count,
                metrics,
            ) = train_client(
                global_parameters=
                    global_parameters,

                client_id=
                    client_id,

                X=
                    client_X,

                y=
                    client_y,

                device=
                    device,

                local_epochs=
                    LOCAL_EPOCHS,

                batch_size=
                    BATCH_SIZE,

                learning_rate=
                    LEARNING_RATE,

                weight_decay=
                    WEIGHT_DECAY,

                seed=(
                    SEED
                    + round_number * 100
                    + client_id
                ),
            )

            client_parameters.append(
                parameters
            )

            client_sample_counts.append(
                sample_count
            )

            client_metrics.append(
                metrics
            )

            elapsed = (
                time.time()
                - client_start
            )

            print(
                f"  Samples : "
                f"{sample_count:,}"
            )

            print(
                f"  Loss    : "
                f"{metrics['loss']:.6f}"
            )

            print(
                f"  Accuracy: "
                f"{metrics['accuracy']:.6f}"
            )

            print(
                f"  Time    : "
                f"{elapsed:.2f}s"
            )

        # ----------------------------------------------------
        # FedAvg
        # ----------------------------------------------------

        print()

        print(
            "Aggregating client models..."
        )

        global_parameters = (
            fedavg_aggregate(
                client_parameters,
                client_sample_counts,
            )
        )

        set_model_parameters(
            global_model,
            global_parameters,
        )

        # ----------------------------------------------------
        # Validation
        # ----------------------------------------------------

        print()

        print(
            "Evaluating global model..."
        )

        validation_metrics = (
            evaluate_model(
                global_model,
                validation_loader,
                device,
            )
        )

        round_time = (
            time.time()
            - round_start
        )

        round_record = {

            "round":
                round_number,

            "selected_clients":
                [
                    int(x)
                    for x
                    in selected_clients
                ],

            "client_sample_counts":
                [
                    int(x)
                    for x
                    in client_sample_counts
                ],

            "validation":
                validation_metrics,

            "clients":
                client_metrics,

            "round_time_seconds":
                float(round_time),
        }

        history.append(
            round_record
        )

        current_f1 = float(
            validation_metrics["f1_macro"]
        )
        if current_f1 > best_validation_f1:
            best_validation_f1 = current_f1
            best_round = round_number
            best_parameters = {
                key: value.detach().cpu().clone()
                for key, value in global_parameters.items()
            }
            rounds_without_improvement = 0
        else:
            rounds_without_improvement += 1

        print()

        print(
            "-" * 70
        )

        print(
            f"Round {round_number} result:"
        )

        print(
            f"  Validation Loss     : "
            f"{validation_metrics['loss']:.6f}"
        )

        print(
            f"  Validation Accuracy : "
            f"{validation_metrics['accuracy']:.6f}"
        )

        print(
            f"  Macro Precision     : "
            f"{validation_metrics['precision_macro']:.6f}"
        )

        print(
            f"  Macro Recall        : "
            f"{validation_metrics['recall_macro']:.6f}"
        )

        print(
            f"  Macro F1            : "
            f"{validation_metrics['f1_macro']:.6f}"
        )

        print(
            f"  Weighted F1         : "
            f"{validation_metrics['f1_weighted']:.6f}"
        )

        print(
            f"  Round time          : "
            f"{round_time:.2f}s"
        )

        if rounds_without_improvement >= EARLY_STOPPING_PATIENCE:
            print()
            print(
                "Early stopping: validation Macro-F1 has not "
                f"improved for {EARLY_STOPPING_PATIENCE} rounds."
            )
            break

    # ========================================================
    # FINAL SAVE
    # ========================================================

    total_time = (
        time.time()
        - experiment_start
    )

    if best_parameters is None:
        raise RuntimeError(
            "FedAvg did not produce a valid global model."
        )

    global_parameters = best_parameters
    set_model_parameters(
        global_model,
        global_parameters,
    )

    # --------------------------------------------------------
    # Global model
    # --------------------------------------------------------

    global_model_path = (
        model_dir
        / "fedavg_global.pt"
    )

    torch.save(
        {
            "model_state_dict":
                global_model.state_dict(),

            "input_features":
                INPUT_FEATURES,

            "num_classes":
                NUM_CLASSES,

            "class_names":
                CLASS_NAMES,

            "scenario":
                SCENARIO_NAME,

            "rounds":
                FL_ROUNDS,

            "best_round":
                best_round,

            "best_validation_f1_macro":
                best_validation_f1,

            "local_epochs":
                LOCAL_EPOCHS,

            "batch_size":
                BATCH_SIZE,

            "learning_rate":
                LEARNING_RATE,

            "seed":
                SEED,
        },
        global_model_path,
    )

    # --------------------------------------------------------
    # History
    # --------------------------------------------------------

    history_path = (
        results_dir
        / "round_history.json"
    )

    save_json(
        history,
        history_path,
    )

    # --------------------------------------------------------
    # Final metrics
    # --------------------------------------------------------

    final_metrics = (
        history[best_round - 1][
            "validation"
        ]
    )

    final_metrics_path = (
        results_dir
        / "final_metrics.json"
    )

    save_json(
        final_metrics,
        final_metrics_path,
    )

    # --------------------------------------------------------
    # Metadata
    # --------------------------------------------------------

    metadata = {

        "scenario":
            SCENARIO_NAME,

        "num_clients":
            NUM_CLIENTS,

        "clients_per_round":
            CLIENTS_PER_ROUND,

        "fl_rounds":
            FL_ROUNDS,

        "local_epochs":
            LOCAL_EPOCHS,

        "batch_size":
            BATCH_SIZE,

        "learning_rate":
            LEARNING_RATE,

        "weight_decay":
            WEIGHT_DECAY,

        "dirichlet_alpha":
            0.5,

        "seed":
            SEED,

        "device":
            str(device),

        "total_training_time_seconds":
            total_time,

        "best_round":
            best_round,

        "best_validation_f1_macro":
            best_validation_f1,
    }

    metadata_path = (
        results_dir
        / "metadata.json"
    )

    save_json(
        metadata,
        metadata_path,
    )

    # ========================================================
    # FINAL OUTPUT
    # ========================================================

    print()

    print(
        "=" * 70
    )

    print(
        "FEDAVG TRAINING COMPLETE"
    )

    print(
        "=" * 70
    )

    print()

    print(
        "Final validation metrics:"
    )

    for key, value in (
        final_metrics.items()
    ):

        print(
            f"  {key:<22}: "
            f"{value:.6f}"
        )

    print()

    print(
        f"Best round: {best_round} | "
        f"Validation Macro-F1: {best_validation_f1:.6f}"
    )

    print()

    print(
        f"Total training time: "
        f"{total_time:.2f}s"
    )

    print()

    print(
        "Global model:"
    )

    print(
        global_model_path
    )

    print()

    print(
        "Results:"
    )

    print(
        results_dir
    )

    print()

    print(
        "=" * 70
    )


# ============================================================
# ENTRY POINT
# ============================================================

if __name__ == "__main__":
    main()
