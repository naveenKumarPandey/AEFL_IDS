from pathlib import Path
from typing import Optional

import numpy as np
import pandas as pd

from preprocessing.data_loader import (
    DATASET_DIR,
    EXPECTED_FEATURE_COUNT,
    LABEL_COLUMN,
    find_csv_files,
)


FEATURE_COLUMNS = [
    "Header_Length",
    "Protocol Type",
    "Time_To_Live",
    "Rate",
    "fin_flag_number",
    "syn_flag_number",
    "rst_flag_number",
    "psh_flag_number",
    "ack_flag_number",
    "ece_flag_number",
    "cwr_flag_number",
    "ack_count",
    "syn_count",
    "fin_count",
    "rst_count",
    "HTTP",
    "HTTPS",
    "DNS",
    "Telnet",
    "SMTP",
    "SSH",
    "IRC",
    "TCP",
    "UDP",
    "DHCP",
    "ARP",
    "ICMP",
    "IGMP",
    "IPv",
    "LLC",
    "Tot sum",
    "Min",
    "Max",
    "AVG",
    "Std",
    "Tot size",
    "IAT",
    "Number",
    "Variance",
]


def normalize_attack_label(label: str) -> str:
    """
    Normalize a raw attack label.
    """

    label = str(label).strip()

    if label == "Benign_Final":
        return "BENIGN"

    return label


def get_attack_family(label: str) -> str:
    """
    Convert detailed CICIoT2023 attack labels into
    higher-level attack families.
    """

    label = normalize_attack_label(label)

    if label == "BENIGN":
        return "BENIGN"

    if label.startswith("DDoS-"):
        return "DDoS"

    if label.startswith("DoS-"):
        return "DoS"

    if label.startswith("Recon-"):
        return "Recon"

    if label.startswith("Mirai-"):
        return "Mirai"

    if label in {
        "MITM-ArpSpoofing",
        "DNS_Spoofing",
    }:
        return "Spoofing"

    if label in {
        "BrowserHijacking",
        "CommandInjection",
        "SqlInjection",
        "Uploading_Attack",
        "XSS",
        "Backdoor_Malware",
        "VulnerabilityScan",
    }:
        return "Web-based"

    if label == "DictionaryBruteForce":
        return "BruteForce"

    return "Other"


def clean_dataframe(
    df: pd.DataFrame,
    remove_duplicates: bool = True,
    missing_threshold: float = 0.50,
) -> pd.DataFrame:
    """
    Clean one dataframe chunk.

    This function does not fit any scaler or use
    test-set statistics.
    """

    required_columns = set(FEATURE_COLUMNS)

    missing_columns = required_columns.difference(df.columns)

    if missing_columns:
        raise ValueError(
            "Missing expected feature columns: "
            f"{sorted(missing_columns)}"
        )

    # Keep only expected features + labels/metadata.
    columns = FEATURE_COLUMNS + [
        LABEL_COLUMN,
        "source_file",
    ]

    df = df[columns].copy()

    # Convert features to numeric.
    for column in FEATURE_COLUMNS:
        df[column] = pd.to_numeric(
            df[column],
            errors="coerce",
        )

    # Replace positive/negative infinity.
    df[FEATURE_COLUMNS] = df[FEATURE_COLUMNS].replace(
        [np.inf, -np.inf],
        np.nan,
    )

    # Remove rows with too many missing feature values.
    row_missing_ratio = df[FEATURE_COLUMNS].isna().mean(axis=1)

    df = df[
        row_missing_ratio <= missing_threshold
    ].copy()

    # Do not impute with a median calculated from the current chunk. Doing so
    # would let validation/test statistics influence their own features and
    # makes identical raw rows depend on arbitrary CSV chunk boundaries.
    # CICIoT2023 contains very few residual invalid rows, so dropping them is
    # the reproducible, leakage-safe policy used by this project.
    if df.empty:
        return df

    df = df.dropna(
        subset=FEATURE_COLUMNS
    ).copy()

    if remove_duplicates:
        df = df.drop_duplicates(
            subset=FEATURE_COLUMNS + [LABEL_COLUMN]
        )

    # Normalize label.
    df[LABEL_COLUMN] = df[
        LABEL_COLUMN
    ].map(normalize_attack_label)

    # Add attack family.
    df["attack_family"] = df[
        LABEL_COLUMN
    ].map(get_attack_family)

    return df


def process_sample(
    dataset_dir: Path = DATASET_DIR,
    rows_per_file: int = 1000,
) -> pd.DataFrame:
    """
    Process a small sample from every CSV file.

    This is used for pipeline validation only.
    """

    csv_files = find_csv_files(dataset_dir)

    if not csv_files:
        raise RuntimeError(
            "No CSV files found."
        )

    processed_chunks = []

    for csv_file in csv_files:

        df = pd.read_csv(
            csv_file,
            nrows=rows_per_file,
        )

        if len(df.columns) != EXPECTED_FEATURE_COUNT:
            raise ValueError(
                f"{csv_file.name}: expected "
                f"{EXPECTED_FEATURE_COUNT} columns, "
                f"found {len(df.columns)}."
            )

        df[LABEL_COLUMN] = (
            csv_file.parent.name
        )

        df["source_file"] = csv_file.name

        cleaned = clean_dataframe(df)

        if not cleaned.empty:
            processed_chunks.append(cleaned)

    if not processed_chunks:
        raise RuntimeError(
            "No valid rows remained after preprocessing."
        )

    return pd.concat(
        processed_chunks,
        ignore_index=True,
    )


def print_statistics(df: pd.DataFrame) -> None:
    """
    Print basic preprocessing statistics.
    """

    print("=" * 70)
    print("PREPROCESSING SAMPLE TEST")
    print("=" * 70)

    print(f"\nRows after cleaning: {len(df)}")
    print(f"Feature count: {len(FEATURE_COLUMNS)}")

    print("\nDetailed labels:")
    print(
        df[LABEL_COLUMN]
        .value_counts()
        .sort_index()
        .to_string()
    )

    print("\nAttack families:")
    print(
        df["attack_family"]
        .value_counts()
        .sort_index()
        .to_string()
    )

    print("\nMissing values:")
    print(
        int(df[FEATURE_COLUMNS].isna().sum().sum())
    )

    print("\nInfinite values:")
    print(
        int(
            np.isinf(
                df[FEATURE_COLUMNS].to_numpy()
            ).sum()
        )
    )

    print("\nFinal shape:")
    print(df.shape)

    print("\n" + "=" * 70)
    print("PREPROCESSING SAMPLE TEST COMPLETE")
    print("=" * 70)


if __name__ == "__main__":

    sample_df = process_sample(
        dataset_dir=DATASET_DIR,
        rows_per_file=1000,
    )

    print_statistics(sample_df)
