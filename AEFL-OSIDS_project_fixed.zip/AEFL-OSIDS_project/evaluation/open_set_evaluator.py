from pathlib import Path
import json

import numpy as np
import torch
from torch.utils.data import DataLoader

from models.intrusion_model import create_model
from data_loader.cic_iot_dataset import create_dataset


# ============================================================
# AEFL-OSIDS
# OPEN-SET INTRUSION DETECTION EVALUATOR
# ============================================================

PROJECT_ROOT = Path(__file__).resolve().parents[1]

SCENARIO_NAME = "scenario_C_multiple"

MODEL_PATH = (
    PROJECT_ROOT
    / "data"
    / "models"
    / "adaptive_fedavg_v2_global.pt"
)

RESULTS_DIR = (
    PROJECT_ROOT
    / "results"
    / "open_set"
)

INPUT_FEATURES = 39
NUM_CLASSES = 5

BATCH_SIZE = 512

CLASS_NAMES = [
    "BENIGN",
    "DDoS",
    "DoS",
    "Mirai",
    "Recon",
]

UNKNOWN_LABEL = -1


# ============================================================
# DEVICE
# ============================================================

def get_device():

    if torch.cuda.is_available():

        return torch.device("cuda")

    return torch.device("cpu")


# ============================================================
# LOAD MODEL
# ============================================================

def load_model(device):

    if not MODEL_PATH.exists():

        raise FileNotFoundError(
            f"Model not found:\n{MODEL_PATH}"
        )

    checkpoint = torch.load(
        MODEL_PATH,
        map_location=device,
        weights_only=False,
    )

    model = create_model(
        input_features=INPUT_FEATURES,
        num_classes=NUM_CLASSES,
    )

    if isinstance(checkpoint, dict):

        if "model_state_dict" in checkpoint:

            state_dict = checkpoint[
                "model_state_dict"
            ]

        else:

            state_dict = checkpoint

    else:

        state_dict = checkpoint

    model.load_state_dict(
        state_dict
    )

    model.to(device)

    model.eval()

    return model


# ============================================================
# COLLECT PREDICTIONS
# ============================================================

def collect_predictions(
    model,
    dataset,
    device,
):

    loader = DataLoader(
        dataset,
        batch_size=BATCH_SIZE,
        shuffle=False,
        num_workers=0,
    )

    all_true = []
    all_pred = []
    all_confidence = []

    with torch.no_grad():

        for X, y in loader:

            X = X.to(device)

            logits = model(X)

            probabilities = torch.softmax(
                logits,
                dim=1,
            )

            confidence, predictions = (
                torch.max(
                    probabilities,
                    dim=1,
                )
            )

            all_true.extend(
                y.numpy().tolist()
            )

            all_pred.extend(
                predictions.cpu()
                .numpy()
                .tolist()
            )

            all_confidence.extend(
                confidence.cpu()
                .numpy()
                .tolist()
            )

    return (
        np.asarray(all_true),
        np.asarray(all_pred),
        np.asarray(all_confidence),
    )


# ============================================================
# DETERMINE CONFIDENCE THRESHOLD
# ============================================================

def determine_threshold(
    model,
    validation_dataset,
    device,
):

    (
        y_true,
        predictions,
        confidence,
    ) = collect_predictions(
        model,
        validation_dataset,
        device,
    )

    # Validation contains only known classes.
    known_mask = (
        y_true >= 0
    )

    known_confidence = (
        confidence[known_mask]
    )

    if len(known_confidence) == 0:

        raise ValueError(
            "No known samples found "
            "in validation dataset."
        )

    # --------------------------------------------------------
    # Conservative threshold.
    #
    # 5th percentile means approximately
    # 95% of known validation samples
    # remain accepted.
    # --------------------------------------------------------

    threshold = float(
        np.percentile(
            known_confidence,
            5,
        )
    )

    return (
        threshold,
        {
            "validation_samples":
                int(len(y_true)),

            "known_samples":
                int(len(known_confidence)),

            "confidence_mean":
                float(
                    np.mean(
                        known_confidence
                    )
                ),

            "confidence_median":
                float(
                    np.median(
                        known_confidence
                    )
                ),

            "confidence_std":
                float(
                    np.std(
                        known_confidence
                    )
                ),

            "confidence_min":
                float(
                    np.min(
                        known_confidence
                    )
                ),

            "confidence_max":
                float(
                    np.max(
                        known_confidence
                    )
                ),

            "threshold_percentile":
                5,

            "threshold":
                threshold,
        }
    )


# ============================================================
# OPEN-SET PREDICTIONS
# ============================================================

def apply_open_set_threshold(
    predictions,
    confidence,
    threshold,
):

    open_set_predictions = (
        predictions.copy()
    )

    unknown_mask = (
        confidence < threshold
    )

    open_set_predictions[
        unknown_mask
    ] = UNKNOWN_LABEL

    return (
        open_set_predictions,
        unknown_mask,
    )


# ============================================================
# OPEN-SET METRICS
# ============================================================

def calculate_open_set_metrics(
    y_true,
    y_pred,
    confidence,
    threshold,
):

    from sklearn.metrics import (
        accuracy_score,
        precision_score,
        recall_score,
        f1_score,
        confusion_matrix,
        roc_auc_score,
    )

    # --------------------------------------------------------
    # Ground truth known/unknown
    # --------------------------------------------------------

    true_unknown = (
        y_true == UNKNOWN_LABEL
    )

    true_known = (
        y_true != UNKNOWN_LABEL
    )

    predicted_unknown = (
        y_pred == UNKNOWN_LABEL
    )

    predicted_known = (
        y_pred != UNKNOWN_LABEL
    )

    # --------------------------------------------------------
    # Detection statistics
    # --------------------------------------------------------

    tp_unknown = int(
        np.sum(
            true_unknown
            & predicted_unknown
        )
    )

    fn_unknown = int(
        np.sum(
            true_unknown
            & predicted_known
        )
    )

    fp_unknown = int(
        np.sum(
            true_known
            & predicted_unknown
        )
    )

    tn_unknown = int(
        np.sum(
            true_known
            & predicted_known
        )
    )

    unknown_precision = (
        tp_unknown
        / (tp_unknown + fp_unknown)
        if (
            tp_unknown + fp_unknown
        ) > 0
        else 0.0
    )

    unknown_recall = (
        tp_unknown
        / (tp_unknown + fn_unknown)
        if (
            tp_unknown + fn_unknown
        ) > 0
        else 0.0
    )

    unknown_f1 = (
        2
        * unknown_precision
        * unknown_recall
        / (
            unknown_precision
            + unknown_recall
        )
        if (
            unknown_precision
            + unknown_recall
        ) > 0
        else 0.0
    )

    known_fpr = (
        fp_unknown
        / (fp_unknown + tn_unknown)
        if (
            fp_unknown + tn_unknown
        ) > 0
        else 0.0
    )

    # --------------------------------------------------------
    # Closed-set metrics on known samples
    # --------------------------------------------------------

    known_mask = (
        y_true != UNKNOWN_LABEL
    )

    known_true = y_true[
        known_mask
    ]

    known_pred = y_pred[
        known_mask
    ]

    # Unknown predictions are not valid
    # class predictions for closed-set metrics.

    known_prediction_mask = (
        known_pred != UNKNOWN_LABEL
    )

    if np.any(
        known_prediction_mask
    ):

        known_true_filtered = (
            known_true[
                known_prediction_mask
            ]
        )

        known_pred_filtered = (
            known_pred[
                known_prediction_mask
            ]
        )

    else:

        known_true_filtered = (
            np.asarray([], dtype=int)
        )

        known_pred_filtered = (
            np.asarray([], dtype=int)
        )

    if len(
        known_true_filtered
    ) > 0:

        accuracy = float(
            accuracy_score(
                known_true_filtered,
                known_pred_filtered,
            )
        )

        precision = float(
            precision_score(
                known_true_filtered,
                known_pred_filtered,
                average="macro",
                zero_division=0,
            )
        )

        recall = float(
            recall_score(
                known_true_filtered,
                known_pred_filtered,
                average="macro",
                zero_division=0,
            )
        )

        macro_f1 = float(
            f1_score(
                known_true_filtered,
                known_pred_filtered,
                average="macro",
                zero_division=0,
            )
        )

    else:

        accuracy = 0.0
        precision = 0.0
        recall = 0.0
        macro_f1 = 0.0

    # --------------------------------------------------------
    # Binary unknown detection metrics
    # --------------------------------------------------------

    y_unknown_true = (
        true_unknown.astype(int)
    )

    y_unknown_pred = (
        predicted_unknown.astype(int)
    )

    unknown_detection_accuracy = float(
        accuracy_score(
            y_unknown_true,
            y_unknown_pred,
        )
    )

    unknown_detection_precision = float(
        precision_score(
            y_unknown_true,
            y_unknown_pred,
            zero_division=0,
        )
    )

    unknown_detection_recall = float(
        recall_score(
            y_unknown_true,
            y_unknown_pred,
            zero_division=0,
        )
    )

    unknown_detection_f1 = float(
        f1_score(
            y_unknown_true,
            y_unknown_pred,
            zero_division=0,
        )
    )

    # --------------------------------------------------------
    # Confidence-based AUROC
    #
    # Lower confidence = more likely unknown.
    # --------------------------------------------------------

    unknown_score = (
        1.0 - confidence
    )

    if (
        len(
            np.unique(
                y_unknown_true
            )
        )
        == 2
    ):

        auroc = float(
            roc_auc_score(
                y_unknown_true,
                unknown_score,
            )
        )

    else:

        auroc = None

    # --------------------------------------------------------
    # Confusion matrix
    # --------------------------------------------------------

    cm_labels = [
        0,
        1,
        2,
        3,
        4,
        UNKNOWN_LABEL,
    ]

    cm = confusion_matrix(
        y_true,
        y_pred,
        labels=cm_labels,
    )

    return {

        "threshold":
            float(threshold),

        "total_samples":
            int(len(y_true)),

        "known_samples":
            int(np.sum(true_known)),

        "unknown_samples":
            int(np.sum(true_unknown)),

        "predicted_unknown":
            int(np.sum(predicted_unknown)),

        "true_unknown":
            int(np.sum(true_unknown)),

        "unknown_true_positive":
            tp_unknown,

        "unknown_false_negative":
            fn_unknown,

        "unknown_false_positive":
            fp_unknown,

        "unknown_true_negative":
            tn_unknown,

        "unknown_precision":
            float(unknown_precision),

        "unknown_recall":
            float(unknown_recall),

        "unknown_f1":
            float(unknown_f1),

        "known_false_positive_rate":
            float(known_fpr),

        "known_accuracy":
            accuracy,

        "known_macro_precision":
            precision,

        "known_macro_recall":
            recall,

        "known_macro_f1":
            macro_f1,

        "unknown_detection_accuracy":
            unknown_detection_accuracy,

        "unknown_detection_precision":
            unknown_detection_precision,

        "unknown_detection_recall":
            unknown_detection_recall,

        "unknown_detection_f1":
            unknown_detection_f1,

        "open_set_auroc":
            auroc,

        "confusion_matrix":
            cm.tolist(),
    }


# ============================================================
# UNKNOWN FAMILY ANALYSIS
# ============================================================

def analyze_unknown_families(
    dataset,
    y_pred,
    confidence,
    threshold,
):

    # Try to obtain metadata from dataset.
    result = {}

    if hasattr(
        dataset,
        "data"
    ):

        data = dataset.data

        if hasattr(
            data,
            "attack_family"
        ):

            families = (
                data[
                    "attack_family"
                ]
                .astype(str)
                .to_numpy()
            )

        else:

            families = None

    else:

        families = None

    if families is None:

        return result

    unknown_prediction_mask = (
        y_pred == UNKNOWN_LABEL
    )

    unique_families = np.unique(
        families
    )

    for family in unique_families:

        family_mask = (
            families == family
        )

        sample_count = int(
            np.sum(
                family_mask
            )
        )

        detected_count = int(
            np.sum(
                family_mask
                & unknown_prediction_mask
            )
        )

        mean_confidence = float(
            np.mean(
                confidence[
                    family_mask
                ]
            )
        )

        result[family] = {

            "samples":
                sample_count,

            "detected_as_unknown":
                detected_count,

            "detection_rate":
                float(
                    detected_count
                    / sample_count
                )
                if sample_count > 0
                else 0.0,

            "mean_confidence":
                mean_confidence,
        }

    return result


# ============================================================
# SAVE JSON
# ============================================================

def save_json(
    data,
    path,
):

    path.parent.mkdir(
        parents=True,
        exist_ok=True,
    )

    with open(
        path,
        "w",
        encoding="utf-8",
    ) as file:

        json.dump(
            data,
            file,
            indent=4,
        )


# ============================================================
# MAIN
# ============================================================

def main():

    print(
        "=" * 70
    )

    print(
        "AEFL-OSIDS OPEN-SET "
        "INTRUSION DETECTION EVALUATION"
    )

    print(
        "=" * 70
    )

    device = get_device()

    print()

    print(
        f"Device  : {device}"
    )

    print(
        f"Scenario: {SCENARIO_NAME}"
    )

    print(
        f"Model   : {MODEL_PATH}"
    )

    print()

    # --------------------------------------------------------
    # Load model
    # --------------------------------------------------------

    print(
        "Loading adaptive global model..."
    )

    model = load_model(
        device
    )

    print(
        "Model loaded successfully."
    )

    # --------------------------------------------------------
    # Load validation
    # --------------------------------------------------------

    print()

    print(
        "Loading validation dataset..."
    )

    validation_dataset = create_dataset(
        SCENARIO_NAME,
        "validation",
    )

    print(
        f"Validation samples: "
        f"{len(validation_dataset):,}"
    )

    # --------------------------------------------------------
    # Determine threshold
    # --------------------------------------------------------

    print()

    print(
        "Calibrating open-set threshold..."
    )

    (
        threshold,
        threshold_info,
    ) = determine_threshold(
        model,
        validation_dataset,
        device,
    )

    print()

    print(
        "Threshold calibration:"
    )

    print(
        f"  Mean confidence   : "
        f"{threshold_info['confidence_mean']:.6f}"
    )

    print(
        f"  Median confidence : "
        f"{threshold_info['confidence_median']:.6f}"
    )

    print(
        f"  Minimum confidence: "
        f"{threshold_info['confidence_min']:.6f}"
    )

    print(
        f"  Maximum confidence: "
        f"{threshold_info['confidence_max']:.6f}"
    )

    print(
        f"  Open-set threshold: "
        f"{threshold:.6f}"
    )

    # --------------------------------------------------------
    # Load test
    # --------------------------------------------------------

    print()

    print(
        "Loading test dataset..."
    )

    test_dataset = create_dataset(
        SCENARIO_NAME,
        "test",
    )

    print(
        f"Test samples: "
        f"{len(test_dataset):,}"
    )

    # --------------------------------------------------------
    # Predictions
    # --------------------------------------------------------

    print()

    print(
        "Running test inference..."
    )

    (
        y_true,
        predictions,
        confidence,
    ) = collect_predictions(
        model,
        test_dataset,
        device,
    )

    print(
        "Inference complete."
    )

    # --------------------------------------------------------
    # Open-set decision
    # --------------------------------------------------------

    (
        open_set_predictions,
        unknown_mask,
    ) = apply_open_set_threshold(
        predictions,
        confidence,
        threshold,
    )

    # --------------------------------------------------------
    # Metrics
    # --------------------------------------------------------

    metrics = (
        calculate_open_set_metrics(
            y_true,
            open_set_predictions,
            confidence,
            threshold,
        )
    )

    # --------------------------------------------------------
    # Family analysis
    # --------------------------------------------------------

    family_analysis = (
        analyze_unknown_families(
            test_dataset,
            open_set_predictions,
            confidence,
            threshold,
        )
    )

    # --------------------------------------------------------
    # Results
    # --------------------------------------------------------

    results = {

        "scenario":
            SCENARIO_NAME,

        "model":
            str(MODEL_PATH),

        "known_classes":
            CLASS_NAMES,

        "unknown_label":
            UNKNOWN_LABEL,

        "threshold_calibration":
            threshold_info,

        "metrics":
            metrics,

        "family_analysis":
            family_analysis,
    }

    output_path = (
        RESULTS_DIR
        / "open_set_results.json"
    )

    save_json(
        results,
        output_path,
    )

    # ========================================================
    # PRINT RESULTS
    # ========================================================

    print()

    print(
        "=" * 70
    )

    print(
        "OPEN-SET EVALUATION RESULTS"
    )

    print(
        "=" * 70
    )

    print()

    print(
        "Dataset:"
    )

    print(
        f"  Total samples       : "
        f"{metrics['total_samples']:,}"
    )

    print(
        f"  Known samples       : "
        f"{metrics['known_samples']:,}"
    )

    print(
        f"  Unknown samples     : "
        f"{metrics['unknown_samples']:,}"
    )

    print()

    print(
        "Open-set detection:"
    )

    print(
        f"  Threshold           : "
        f"{metrics['threshold']:.6f}"
    )

    print(
        f"  Unknown precision   : "
        f"{metrics['unknown_precision']:.6f}"
    )

    print(
        f"  Unknown recall      : "
        f"{metrics['unknown_recall']:.6f}"
    )

    print(
        f"  Unknown F1          : "
        f"{metrics['unknown_f1']:.6f}"
    )

    print(
        f"  Known FPR           : "
        f"{metrics['known_false_positive_rate']:.6f}"
    )

    if metrics[
        "open_set_auroc"
    ] is not None:

        print(
            f"  Open-set AUROC      : "
            f"{metrics['open_set_auroc']:.6f}"
        )

    print()

    print(
        "Known-class performance:"
    )

    print(
        f"  Accuracy            : "
        f"{metrics['known_accuracy']:.6f}"
    )

    print(
        f"  Macro Precision     : "
        f"{metrics['known_macro_precision']:.6f}"
    )

    print(
        f"  Macro Recall        : "
        f"{metrics['known_macro_recall']:.6f}"
    )

    print(
        f"  Macro F1            : "
        f"{metrics['known_macro_f1']:.6f}"
    )

    print()

    if family_analysis:

        print(
            "Family-wise analysis:"
        )

        for family, info in (
            family_analysis.items()
        ):

            print()

            print(
                f"  {family}"
            )

            print(
                f"    Samples          : "
                f"{info['samples']:,}"
            )

            print(
                f"    Detected unknown : "
                f"{info['detected_as_unknown']:,}"
            )

            print(
                f"    Detection rate   : "
                f"{info['detection_rate']:.6f}"
            )

            print(
                f"    Mean confidence  : "
                f"{info['mean_confidence']:.6f}"
            )

    print()

    print(
        "Confusion matrix labels:"
    )

    print(
        "  0 = BENIGN"
    )

    print(
        "  1 = DDoS"
    )

    print(
        "  2 = DoS"
    )

    print(
        "  3 = Mirai"
    )

    print(
        "  4 = Recon"
    )

    print(
        " -1 = UNKNOWN"
    )

    print()

    print(
        "Results saved:"
    )

    print(
        output_path
    )

    print()

    print(
        "=" * 70
    )

    print(
        "OPEN-SET EVALUATION COMPLETE"
    )

    print(
        "=" * 70
    )


if __name__ == "__main__":

    main()