"""Efficient array loading for full-scale federated simulations.

The original lazy client dataset repeatedly opened compressed NPZ archives
when client indices were shuffled.  These helpers read each training archive
once, distribute its rows to the owning clients, and keep only numeric X/y
arrays in memory for globally shuffled PyTorch batches.
"""

from pathlib import Path
from typing import List, Tuple

import numpy as np


PROJECT_ROOT = Path(__file__).resolve().parents[1]


def load_federated_client_arrays(
    scenario: str,
    num_clients: int,
    num_classes: int,
    input_features: int,
) -> List[Tuple[np.ndarray, np.ndarray]]:
    """Load every federated client while reading each NPZ file only once."""

    train_dir = (
        PROJECT_ROOT
        / "data"
        / "processed"
        / scenario
        / "train"
    )
    indices_path = (
        PROJECT_ROOT
        / "data"
        / "federated"
        / scenario
        / "client_indices.npz"
    )

    files = sorted(train_dir.rglob("*.npz"))
    if not files:
        raise FileNotFoundError(
            f"No training NPZ files found in:\n{train_dir}"
        )
    if not indices_path.exists():
        raise FileNotFoundError(
            f"Federated indices not found:\n{indices_path}"
        )

    client_indices = []
    with np.load(indices_path, allow_pickle=False) as data:
        for client_id in range(num_clients):
            key = f"client_{client_id}"
            if key not in data.files:
                raise KeyError(f"Missing federated partition: {key}")
            indices = np.asarray(data[key], dtype=np.int64).copy()
            if len(indices) == 0:
                raise RuntimeError(f"Client {client_id} has zero samples")
            client_indices.append(indices)

    client_sizes = [len(indices) for indices in client_indices]
    total_samples = int(sum(client_sizes))

    owners = np.full(
        total_samples,
        -1,
        dtype=np.int16,
    )
    for client_id, indices in enumerate(client_indices):
        if np.any(indices < 0) or np.any(indices >= total_samples):
            raise RuntimeError(
                f"Client {client_id} contains out-of-range indices"
            )
        owners[indices] = client_id

    if np.any(owners < 0):
        raise RuntimeError(
            "Federated client indices do not cover every training row exactly once"
        )

    client_X = [
        np.empty((size, input_features), dtype=np.float32)
        for size in client_sizes
    ]
    client_y = [
        np.empty(size, dtype=np.int64)
        for size in client_sizes
    ]
    client_offsets = np.zeros(num_clients, dtype=np.int64)

    print()
    print(
        "Loading federated client arrays once "
        "(each compressed file is read once)..."
    )

    global_start = 0
    file_count = len(files)

    for file_number, file_path in enumerate(files, start=1):
        with np.load(file_path, allow_pickle=False) as data:
            X = np.asarray(data["X"], dtype=np.float32)
            y = np.asarray(data["y"], dtype=np.int64)

        if X.ndim != 2 or X.shape[1] != input_features:
            raise RuntimeError(
                f"Invalid feature shape {X.shape} in {file_path}"
            )
        if len(X) != len(y):
            raise RuntimeError(f"X/y size mismatch in {file_path}")
        if np.any((y < 0) | (y >= num_classes)):
            raise RuntimeError(
                f"Unknown or invalid training labels found in {file_path}"
            )

        global_end = global_start + len(y)
        if global_end > total_samples:
            raise RuntimeError(
                "Processed training rows exceed the federated partition size"
            )
        file_owners = owners[global_start:global_end]

        for client_id in range(num_clients):
            rows = np.flatnonzero(file_owners == client_id)
            count = len(rows)
            if count == 0:
                continue

            local_start = int(client_offsets[client_id])
            local_end = local_start + count
            client_X[client_id][local_start:local_end] = X[rows]
            client_y[client_id][local_start:local_end] = y[rows]
            client_offsets[client_id] = local_end

        global_start = global_end

        if (
            file_number == 1
            or file_number % 25 == 0
            or file_number == file_count
        ):
            print(
                f"  Files {file_number:,}/{file_count:,} | "
                f"Rows {global_start:,}/{total_samples:,}"
            )

    if global_start != total_samples:
        raise RuntimeError(
            "Processed/federated sample mismatch: "
            f"loaded {global_start:,}, expected {total_samples:,}"
        )

    for client_id, (offset, expected) in enumerate(
        zip(client_offsets, client_sizes)
    ):
        if int(offset) != int(expected):
            raise RuntimeError(
                f"Client {client_id} load mismatch: "
                f"loaded {int(offset):,}, expected {expected:,}"
            )

    del owners
    return list(zip(client_X, client_y))


def load_known_split_arrays(
    scenario: str,
    split_name: str,
    num_classes: int,
    input_features: int,
) -> Tuple[np.ndarray, np.ndarray]:
    """Load known X/y arrays for fast repeated validation."""

    split_dir = (
        PROJECT_ROOT
        / "data"
        / "processed"
        / scenario
        / split_name
    )
    files = sorted(split_dir.rglob("*.npz"))
    if not files:
        raise FileNotFoundError(
            f"No {split_name} NPZ files found in:\n{split_dir}"
        )

    x_parts = []
    y_parts = []
    for file_path in files:
        with np.load(file_path, allow_pickle=False) as data:
            X = np.asarray(data["X"], dtype=np.float32)
            y = np.asarray(data["y"], dtype=np.int64)

        if X.ndim != 2 or X.shape[1] != input_features:
            raise RuntimeError(
                f"Invalid feature shape {X.shape} in {file_path}"
            )
        keep = (y >= 0) & (y < num_classes)
        if np.any(keep):
            if np.all(keep):
                x_parts.append(X)
                y_parts.append(y)
            else:
                x_parts.append(X[keep])
                y_parts.append(y[keep])

    if not x_parts:
        raise RuntimeError(
            f"No known samples found in {scenario}/{split_name}"
        )

    return np.concatenate(x_parts), np.concatenate(y_parts)
