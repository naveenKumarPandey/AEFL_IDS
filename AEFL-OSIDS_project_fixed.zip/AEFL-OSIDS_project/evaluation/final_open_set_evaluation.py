from pathlib import Path
import json

import numpy as np
import torch
from torch.utils.data import DataLoader

from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    roc_auc_score,
    confusion_matrix,
)

from models.intrusion_model import create_model
from data_loader.cic_iot_dataset import create_dataset


# ============================================================
# CONFIGURATION
# ============================================================

PROJECT_ROOT = Path(__file__).resolve().parents[1]

SCENARIO_NAME = "scenario_C_multiple"

MODEL_PATH = (
    PROJECT_ROOT
    / "data"
    / "models"
    / "adaptive_fedavg_v2_global.pt"
)

CALIBRATION_PATH = (
    PROJECT_ROOT
    / "results"
    / "threshold_calibration"
    / "threshold_calibration.json"
)

OUTPUT_DIR = (
    PROJECT_ROOT
    / "results"
    / "final_open_set"
)

INPUT_FEATURES = 39
NUM_CLASSES = 5

BATCH_SIZE = 512

UNKNOWN_LABEL = -1

CLASS_NAMES = [
    "BENIGN",
    "DDoS",
    "DoS",
    "Mirai",
    "Recon",
]

UNKNOWN_FAMILIES = [
    "BruteForce",
    "Spoofing",
    "Web-based",
]


# ============================================================
# DEVICE
# ============================================================

def get_device():

    if torch.cuda.is_available():

        return torch.device("cuda")

    return torch.device("cpu")


# ============================================================
# LOAD MODEL
# ============================================================

def load_model(device):

    if not MODEL_PATH.exists():

        raise FileNotFoundError(
            f"Model not found:\n{MODEL_PATH}"
        )

    checkpoint = torch.load(
        MODEL_PATH,
        map_location=device,
        weights_only=False,
    )

    model = create_model(
        input_features=INPUT_FEATURES,
        num_classes=NUM_CLASSES,
    )

    if (
        isinstance(checkpoint, dict)
        and "model_state_dict" in checkpoint
    ):

        state_dict = checkpoint[
            "model_state_dict"
        ]

    else:

        state_dict = checkpoint

    model.load_state_dict(
        state_dict
    )

    model.to(device)

    model.eval()

    return model


# ============================================================
# LOAD LOCKED THRESHOLD
# ============================================================

def load_threshold():

    if not CALIBRATION_PATH.exists():

        raise FileNotFoundError(
            f"Calibration file not found:\n"
            f"{CALIBRATION_PATH}"
        )

    with open(
        CALIBRATION_PATH,
        "r",
        encoding="utf-8",
    ) as file:

        calibration = json.load(file)

    selected = calibration[
        "selected_operating_point"
    ]

    threshold = float(
        selected["threshold"]
    )

    return threshold


# ============================================================
# TEST INFERENCE
# ============================================================

def run_inference(
    model,
    dataset,
    device,
):

    loader = DataLoader(
        dataset,
        batch_size=BATCH_SIZE,
        shuffle=False,
        num_workers=0,
    )

    true_labels = []
    predicted_labels = []
    confidence_values = []

    with torch.no_grad():

        for X, y in loader:

            X = X.to(device)

            logits = model(X)

            probabilities = torch.softmax(
                logits,
                dim=1,
            )

            confidence, predictions = (
                torch.max(
                    probabilities,
                    dim=1,
                )
            )

            true_labels.extend(
                y.numpy().tolist()
            )

            predicted_labels.extend(
                predictions.cpu()
                .numpy()
                .tolist()
            )

            confidence_values.extend(
                confidence.cpu()
                .numpy()
                .tolist()
            )

    return (
        np.asarray(
            true_labels,
            dtype=np.int64,
        ),
        np.asarray(
            predicted_labels,
            dtype=np.int64,
        ),
        np.asarray(
            confidence_values,
            dtype=np.float64,
        ),
    )


# ============================================================
# APPLY LOCKED THRESHOLD
# ============================================================

def apply_threshold(
    predictions,
    confidence,
    threshold,
):

    final_predictions = (
        predictions.copy()
    )

    unknown_mask = (
        confidence < threshold
    )

    final_predictions[
        unknown_mask
    ] = UNKNOWN_LABEL

    return final_predictions


# ============================================================
# UNKNOWN DETECTION METRICS
# ============================================================

def calculate_unknown_metrics(
    y_true,
    y_pred,
):

    true_unknown = (
        y_true == UNKNOWN_LABEL
    )

    predicted_unknown = (
        y_pred == UNKNOWN_LABEL
    )

    tp = int(
        np.sum(
            true_unknown
            & predicted_unknown
        )
    )

    tn = int(
        np.sum(
            (~true_unknown)
            & (~predicted_unknown)
        )
    )

    fp = int(
        np.sum(
            (~true_unknown)
            & predicted_unknown
        )
    )

    fn = int(
        np.sum(
            true_unknown
            & (~predicted_unknown)
        )
    )

    precision = (
        tp / (tp + fp)
        if (tp + fp) > 0
        else 0.0
    )

    recall = (
        tp / (tp + fn)
        if (tp + fn) > 0
        else 0.0
    )

    f1 = (
        2 * precision * recall
        / (precision + recall)
        if (precision + recall) > 0
        else 0.0
    )

    known_fpr = (
        fp / (fp + tn)
        if (fp + tn) > 0
        else 0.0
    )

    return {

        "true_positive":
            tp,

        "true_negative":
            tn,

        "false_positive":
            fp,

        "false_negative":
            fn,

        "precision":
            float(precision),

        "recall":
            float(recall),

        "f1":
            float(f1),

        "known_fpr":
            float(known_fpr),
    }


# ============================================================
# KNOWN CLASS METRICS
# ============================================================

def calculate_known_metrics(
    y_true,
    y_pred,
):

    known_mask = (
        y_true != UNKNOWN_LABEL
    )

    true_known = y_true[
        known_mask
    ]

    pred_known = y_pred[
        known_mask
    ]

    # Unknown prediction means rejection.
    # It is not treated as a valid known class.

    accepted_mask = (
        pred_known != UNKNOWN_LABEL
    )

    true_accepted = true_known[
        accepted_mask
    ]

    pred_accepted = pred_known[
        accepted_mask
    ]

    if len(
        true_accepted
    ) == 0:

        return {

            "accuracy":
                0.0,

            "macro_precision":
                0.0,

            "macro_recall":
                0.0,

            "macro_f1":
                0.0,

        }

    return {

        "accuracy":
            float(
                accuracy_score(
                    true_accepted,
                    pred_accepted,
                )
            ),

        "macro_precision":
            float(
                precision_score(
                    true_accepted,
                    pred_accepted,
                    average="macro",
                    zero_division=0,
                )
            ),

        "macro_recall":
            float(
                recall_score(
                    true_accepted,
                    pred_accepted,
                    average="macro",
                    zero_division=0,
                )
            ),

        "macro_f1":
            float(
                f1_score(
                    true_accepted,
                    pred_accepted,
                    average="macro",
                    zero_division=0,
                )
            ),
    }


# ============================================================
# UNKNOWN FAMILY ANALYSIS
# ============================================================

def extract_attack_families(
    dataset,
):

    # The processed dataset should contain
    # attack_family metadata.

    if hasattr(
        dataset,
        "data",
    ):

        data = dataset.data

        if hasattr(
            data,
            "attack_family",
        ):

            return (
                data[
                    "attack_family"
                ]
                .astype(str)
                .to_numpy()
            )

    return None


def analyze_unknown_families(
    families,
    y_pred,
    confidence,
):

    results = {}

    if families is None:

        return results

    for family in UNKNOWN_FAMILIES:

        mask = (
            families == family
        )

        total = int(
            np.sum(mask)
        )

        if total == 0:

            results[family] = {

                "samples":
                    0,

                "detected_as_unknown":
                    0,

                "detection_rate":
                    0.0,

                "mean_confidence":
                    None,
            }

            continue

        unknown_detected = (
            y_pred[mask]
            == UNKNOWN_LABEL
        )

        detected = int(
            np.sum(
                unknown_detected
            )
        )

        results[family] = {

            "samples":
                total,

            "detected_as_unknown":
                detected,

            "detection_rate":
                float(
                    detected / total
                ),

            "mean_confidence":
                float(
                    np.mean(
                        confidence[mask]
                    )
                ),
        }

    return results


# ============================================================
# AUROC
# ============================================================

def calculate_auroc(
    y_true,
    confidence,
):

    true_unknown = (
        y_true == UNKNOWN_LABEL
    ).astype(int)

    unknown_score = (
        1.0 - confidence
    )

    if len(
        np.unique(
            true_unknown
        )
    ) < 2:

        return None

    return float(
        roc_auc_score(
            true_unknown,
            unknown_score,
        )
    )


# ============================================================
# CONFUSION MATRIX
# ============================================================

def calculate_confusion_matrix(
    y_true,
    y_pred,
):

    labels = [
        0,
        1,
        2,
        3,
        4,
        UNKNOWN_LABEL,
    ]

    matrix = confusion_matrix(
        y_true,
        y_pred,
        labels=labels,
    )

    return {

        "labels":
            [
                "BENIGN",
                "DDoS",
                "DoS",
                "Mirai",
                "Recon",
                "UNKNOWN",
            ],

        "matrix":
            matrix.tolist(),
    }


# ============================================================
# MAIN
# ============================================================

def main():

    print(
        "=" * 70
    )

    print(
        "AEFL-OSIDS FINAL OPEN-SET EVALUATION"
    )

    print(
        "=" * 70
    )

    device = get_device()

    print()

    print(
        f"Device  : {device}"
    )

    print(
        f"Scenario: {SCENARIO_NAME}"
    )

    # --------------------------------------------------------
    # Load model
    # --------------------------------------------------------

    print()

    print(
        "Loading adaptive global model..."
    )

    model = load_model(
        device
    )

    print(
        "Model loaded successfully."
    )

    # --------------------------------------------------------
    # Load threshold
    # --------------------------------------------------------

    print()

    print(
        "Loading calibrated threshold..."
    )

    threshold = load_threshold()

    print(
        f"LOCKED threshold: "
        f"{threshold:.6f}"
    )

    # --------------------------------------------------------
    # Load test dataset
    # --------------------------------------------------------

    print()

    print(
        "Loading TEST dataset..."
    )

    test_dataset = create_dataset(
        SCENARIO_NAME,
        "test",
    )

    print(
        f"Test samples: "
        f"{len(test_dataset):,}"
    )

    # --------------------------------------------------------
    # Inference
    # --------------------------------------------------------

    print()

    print(
        "Running final test inference..."
    )

    (
        y_true,
        predictions,
        confidence,
    ) = run_inference(
        model,
        test_dataset,
        device,
    )

    print(
        "Inference complete."
    )

    # --------------------------------------------------------
    # Apply threshold
    # --------------------------------------------------------

    final_predictions = (
        apply_threshold(
            predictions,
            confidence,
            threshold,
        )
    )

    # --------------------------------------------------------
    # Metrics
    # --------------------------------------------------------

    unknown_metrics = (
        calculate_unknown_metrics(
            y_true,
            final_predictions,
        )
    )

    known_metrics = (
        calculate_known_metrics(
            y_true,
            final_predictions,
        )
    )

    auroc = calculate_auroc(
        y_true,
        confidence,
    )

    # --------------------------------------------------------
    # Family analysis
    # --------------------------------------------------------

    families = (
        extract_attack_families(
            test_dataset
        )
    )

    family_results = (
        analyze_unknown_families(
            families,
            final_predictions,
            confidence,
        )
    )

    # --------------------------------------------------------
    # Confusion matrix
    # --------------------------------------------------------

    cm = calculate_confusion_matrix(
        y_true,
        final_predictions,
    )

    # --------------------------------------------------------
    # Final result
    # --------------------------------------------------------

    results = {

        "experiment":
            "Final Open-Set Evaluation",

        "scenario":
            SCENARIO_NAME,

        "model":
            str(MODEL_PATH),

        "threshold_source":
            str(CALIBRATION_PATH),

        "locked_threshold":
            float(threshold),

        "test_samples":
            int(len(y_true)),

        "unknown_families":
            UNKNOWN_FAMILIES,

        "unknown_detection":
            unknown_metrics,

        "known_class_performance":
            known_metrics,

        "open_set_auroc":
            auroc,

        "unknown_family_analysis":
            family_results,

        "confusion_matrix":
            cm,
    }

    # --------------------------------------------------------
    # Save
    # --------------------------------------------------------

    OUTPUT_DIR.mkdir(
        parents=True,
        exist_ok=True,
    )

    output_path = (
        OUTPUT_DIR
        / "final_open_set_results.json"
    )

    with open(
        output_path,
        "w",
        encoding="utf-8",
    ) as file:

        json.dump(
            results,
            file,
            indent=4,
        )

    # ========================================================
    # PRINT RESULTS
    # ========================================================

    print()

    print(
        "=" * 70
    )

    print(
        "FINAL OPEN-SET RESULTS"
    )

    print(
        "=" * 70
    )

    print()

    print(
        "Locked threshold:"
    )

    print(
        f"  {threshold:.6f}"
    )

    print()

    print(
        "Unknown attack detection:"
    )

    print(
        f"  Precision : "
        f"{unknown_metrics['precision']:.6f}"
    )

    print(
        f"  Recall    : "
        f"{unknown_metrics['recall']:.6f}"
    )

    print(
        f"  F1        : "
        f"{unknown_metrics['f1']:.6f}"
    )

    print(
        f"  Known FPR : "
        f"{unknown_metrics['known_fpr']:.6f}"
    )

    print()

    print(
        "Known-class performance:"
    )

    print(
        f"  Accuracy        : "
        f"{known_metrics['accuracy']:.6f}"
    )

    print(
        f"  Macro Precision : "
        f"{known_metrics['macro_precision']:.6f}"
    )

    print(
        f"  Macro Recall    : "
        f"{known_metrics['macro_recall']:.6f}"
    )

    print(
        f"  Macro F1        : "
        f"{known_metrics['macro_f1']:.6f}"
    )

    print()

    print(
        "Open-set AUROC:"
    )

    if auroc is not None:

        print(
            f"  {auroc:.6f}"
        )

    else:

        print(
            "  N/A"
        )

    print()

    print(
        "UNKNOWN FAMILY PERFORMANCE"
    )

    print(
        "-" * 70
    )

    for family, info in (
        family_results.items()
    ):

        print()

        print(
            family
        )

        print(
            f"  Samples           : "
            f"{info['samples']:,}"
        )

        print(
            f"  Detected Unknown  : "
            f"{info['detected_as_unknown']:,}"
        )

        print(
            f"  Detection Rate    : "
            f"{info['detection_rate']:.6f}"
        )

        if (
            info["mean_confidence"]
            is not None
        ):

            print(
                f"  Mean Confidence   : "
                f"{info['mean_confidence']:.6f}"
            )

    print()

    print(
        "Confusion matrix:"
    )

    print(
        "Labels:"
    )

    print(
        cm["labels"]
    )

    for row in cm["matrix"]:

        print(
            row
        )

    print()

    print(
        "Results saved:"
    )

    print(
        output_path
    )

    print()

    print(
        "=" * 70
    )

    print(
        "FINAL OPEN-SET EVALUATION COMPLETE"
    )

    print(
        "=" * 70
    )


if __name__ == "__main__":

    main()