from pathlib import Path
import json
import math

import numpy as np


# ============================================================
# AEFL-OSIDS
# CLASS-AWARE ADAPTIVE AGGREGATION TEST
# ============================================================

PROJECT_ROOT = Path(__file__).resolve().parents[1]

SCENARIO_NAME = "scenario_C_multiple"

NUM_CLASSES = 5

CLASS_NAMES = [
    "BENIGN",
    "DDoS",
    "DoS",
    "Mirai",
    "Recon",
]


# ============================================================
# ADAPTIVE COEFFICIENTS
# ============================================================

QUALITY_WEIGHT = 0.30

DIVERSITY_WEIGHT = 0.25

COVERAGE_WEIGHT = 0.25

RELIABILITY_WEIGHT = 0.20


# ============================================================
# LOAD CLIENT STATISTICS
# ============================================================

def load_client_statistics():

    path = (
        PROJECT_ROOT
        / "data"
        / "federated"
        / SCENARIO_NAME
        / "client_statistics.json"
    )

    if not path.exists():

        raise FileNotFoundError(
            f"Client statistics not found:\n{path}"
        )

    with open(
        path,
        "r",
        encoding="utf-8",
    ) as file:

        return json.load(file)


# ============================================================
# EXTRACT CLIENT INFORMATION
# ============================================================

def extract_clients(data):

    clients = []

    # --------------------------------------------------------
    # The generated statistics file may contain either:
    #
    # {
    #   "clients": [...]
    # }
    #
    # or directly:
    #
    # {
    #   "0": {...},
    #   "1": {...}
    # }
    # --------------------------------------------------------

    if isinstance(data, dict):

        if "clients" in data:

            data = data["clients"]

        elif "client_statistics" in data:

            data = data["client_statistics"]

        else:

            data = list(data.values())

    if isinstance(data, dict):

        data = list(data.values())

    for index, item in enumerate(data):

        if not isinstance(item, dict):

            continue

        clients.append(item)

    if not clients:

        raise ValueError(
            "No client statistics found."
        )

    return clients


# ============================================================
# GET CLASS COUNTS
# ============================================================

def get_class_counts(client):

    possible_keys = [
        "class_counts",
        "label_distribution",
        "distribution",
        "classes",
    ]

    counts = None

    for key in possible_keys:

        if key in client:

            counts = client[key]

            break

    if counts is None:

        raise ValueError(
            "Class distribution not found "
            f"for client: {client}"
        )

    result = np.zeros(
        NUM_CLASSES,
        dtype=np.float64,
    )

    if isinstance(counts, dict):

        for i in range(NUM_CLASSES):

            # Try numeric label
            if str(i) in counts:

                result[i] = float(
                    counts[str(i)]
                )

            # Try class name
            elif CLASS_NAMES[i] in counts:

                result[i] = float(
                    counts[CLASS_NAMES[i]]
                )

    elif isinstance(counts, list):

        if len(counts) != NUM_CLASSES:

            raise ValueError(
                "Invalid class-count length."
            )

        result = np.asarray(
            counts,
            dtype=np.float64,
        )

    return result


# ============================================================
# CLASS COVERAGE
# ============================================================

def calculate_class_coverage(
    class_counts,
):
    """
    Measures how many classes are represented
    by the client.

    Example:

        5/5 classes -> 1.0
        4/5 classes -> 0.8
        3/5 classes -> 0.6
        1/5 class   -> 0.2
    """

    represented = np.sum(
        class_counts > 0
    )

    return float(
        represented / NUM_CLASSES
    )


# ============================================================
# CLASS DIVERSITY
# ============================================================

def calculate_diversity(
    class_counts,
):
    """
    Normalized entropy.

    Higher value means more balanced
    class distribution.
    """

    total = class_counts.sum()

    if total <= 0:

        return 0.0

    probabilities = (
        class_counts / total
    )

    probabilities = probabilities[
        probabilities > 0
    ]

    if len(probabilities) <= 1:

        return 0.0

    entropy = -np.sum(
        probabilities
        * np.log(probabilities)
    )

    maximum_entropy = math.log(
        NUM_CLASSES
    )

    return float(
        entropy / maximum_entropy
    )


# ============================================================
# NORMALIZATION
# ============================================================

def normalize(values):

    values = np.asarray(
        values,
        dtype=np.float64,
    )

    minimum = values.min()

    maximum = values.max()

    if (
        maximum - minimum
        < 1e-12
    ):

        return np.ones_like(
            values
        )

    return (
        values - minimum
    ) / (
        maximum - minimum
    )


# ============================================================
# QUALITY PROXY
# ============================================================

def calculate_quality_proxy(
    class_counts,
):
    """
    Development-stage proxy.

    This is NOT the final client quality.

    During actual FL training, this component
    will use local validation/training quality.

    For this isolated aggregation test we use
    diversity + coverage as a stable proxy.
    """

    diversity = calculate_diversity(
        class_counts
    )

    coverage = calculate_class_coverage(
        class_counts
    )

    return (
        0.5 * diversity
        +
        0.5 * coverage
    )


# ============================================================
# RELIABILITY PROXY
# ============================================================

def calculate_reliability_proxy(
    class_counts,
):
    """
    Development-stage reliability proxy.

    Clients with extremely concentrated
    distributions receive lower reliability.
    """

    diversity = calculate_diversity(
        class_counts
    )

    coverage = calculate_class_coverage(
        class_counts
    )

    return (
        0.6 * diversity
        +
        0.4 * coverage
    )


# ============================================================
# ADAPTIVE WEIGHTS
# ============================================================

def calculate_weights(
    clients,
):

    class_distributions = []

    sample_counts = []

    qualities = []

    diversities = []

    coverages = []

    reliabilities = []

    # --------------------------------------------------------
    # Extract values
    # --------------------------------------------------------

    for client in clients:

        counts = get_class_counts(
            client
        )

        samples = int(
            counts.sum()
        )

        diversity = (
            calculate_diversity(
                counts
            )
        )

        coverage = (
            calculate_class_coverage(
                counts
            )
        )

        quality = (
            calculate_quality_proxy(
                counts
            )
        )

        reliability = (
            calculate_reliability_proxy(
                counts
            )
        )

        class_distributions.append(
            counts
        )

        sample_counts.append(
            samples
        )

        qualities.append(
            quality
        )

        diversities.append(
            diversity
        )

        coverages.append(
            coverage
        )

        reliabilities.append(
            reliability
        )

    # --------------------------------------------------------
    # Normalize components
    # --------------------------------------------------------

    q = normalize(
        qualities
    )

    d = normalize(
        diversities
    )

    c = normalize(
        coverages
    )

    r = normalize(
        reliabilities
    )

    # --------------------------------------------------------
    # Adaptive score
    # --------------------------------------------------------

    scores = (
        QUALITY_WEIGHT * q
        +
        DIVERSITY_WEIGHT * d
        +
        COVERAGE_WEIGHT * c
        +
        RELIABILITY_WEIGHT * r
    )

    # --------------------------------------------------------
    # Soft sample influence
    # --------------------------------------------------------

    samples = np.asarray(
        sample_counts,
        dtype=np.float64,
    )

    sample_factor = np.sqrt(
        samples
    )

    raw_weights = (
        sample_factor
        * (scores + 1e-8)
    )

    weights = (
        raw_weights
        / raw_weights.sum()
    )

    return {
        "class_distributions":
            class_distributions,

        "sample_counts":
            sample_counts,

        "quality":
            q.tolist(),

        "diversity":
            d.tolist(),

        "coverage":
            c.tolist(),

        "reliability":
            r.tolist(),

        "adaptive_scores":
            scores.tolist(),

        "sample_factor":
            sample_factor.tolist(),

        "adaptive_weights":
            weights.tolist(),
    }


# ============================================================
# FEDAVG WEIGHTS
# ============================================================

def calculate_fedavg_weights(
    sample_counts,
):

    samples = np.asarray(
        sample_counts,
        dtype=np.float64,
    )

    return (
        samples / samples.sum()
    )


# ============================================================
# PRINT DISTRIBUTION
# ============================================================

def print_client_distribution(
    result,
):

    distributions = (
        result["class_distributions"]
    )

    print()

    print(
        "=" * 70
    )

    print(
        "CLIENT CLASS DISTRIBUTION"
    )

    print(
        "=" * 70
    )

    for client_id, counts in enumerate(
        distributions
    ):

        total = counts.sum()

        print()

        print(
            f"Client {client_id + 1}"
        )

        print(
            f"  Total samples: "
            f"{int(total):,}"
        )

        for class_id, name in enumerate(
            CLASS_NAMES
        ):

            percentage = (
                counts[class_id]
                / total
                * 100
                if total > 0
                else 0
            )

            print(
                f"  {name:<10}: "
                f"{int(counts[class_id]):>8,}"
                f" ({percentage:6.2f}%)"
            )


# ============================================================
# PRINT COMPARISON
# ============================================================

def print_comparison(
    result,
    fedavg,
):

    print()

    print(
        "=" * 70
    )

    print(
        "FEDAVG VS CLASS-AWARE ADAPTIVE"
    )

    print(
        "=" * 70
    )

    print()

    print(
        f"{'Client':<10}"
        f"{'FedAvg':>15}"
        f"{'Adaptive':>15}"
        f"{'Change':>15}"
    )

    print(
        "-" * 55
    )

    adaptive = np.asarray(
        result["adaptive_weights"]
    )

    for i in range(
        len(fedavg)
    ):

        change = (
            adaptive[i]
            - fedavg[i]
        )

        print(
            f"{'Client ' + str(i + 1):<10}"
            f"{fedavg[i] * 100:>14.2f}%"
            f"{adaptive[i] * 100:>14.2f}%"
            f"{change * 100:>+14.2f}%"
        )

    print()

    print(
        "Component scores:"
    )

    print()

    print(
        f"{'Client':<10}"
        f"{'Quality':>12}"
        f"{'Diversity':>12}"
        f"{'Coverage':>12}"
        f"{'Reliability':>14}"
    )

    print(
        "-" * 62
    )

    for i in range(
        len(fedavg)
    ):

        print(
            f"{'Client ' + str(i + 1):<10}"
            f"{result['quality'][i]:>12.4f}"
            f"{result['diversity'][i]:>12.4f}"
            f"{result['coverage'][i]:>12.4f}"
            f"{result['reliability'][i]:>14.4f}"
        )


# ============================================================
# SAVE TEST RESULT
# ============================================================

def save_result(
    result,
    fedavg,
):

    output_dir = (
        PROJECT_ROOT
        / "results"
        / "adaptive_aggregation_test"
    )

    output_dir.mkdir(
        parents=True,
        exist_ok=True,
    )

    # --------------------------------------------------------
    # Convert NumPy objects to normal Python objects
    # --------------------------------------------------------

    class_distributions = [
        counts.tolist()
        for counts
        in result["class_distributions"]
    ]

    output = {

        "scenario":
            SCENARIO_NAME,

        "quality_weight":
            float(QUALITY_WEIGHT),

        "diversity_weight":
            float(DIVERSITY_WEIGHT),

        "coverage_weight":
            float(COVERAGE_WEIGHT),

        "reliability_weight":
            float(RELIABILITY_WEIGHT),

        "sample_weighting":
            "sqrt",

        "fedavg_weights":
            [
                float(x)
                for x in fedavg
            ],

        "adaptive_result": {

            "class_distributions":
                class_distributions,

            "sample_counts":
                [
                    int(x)
                    for x
                    in result["sample_counts"]
                ],

            "quality":
                [
                    float(x)
                    for x
                    in result["quality"]
                ],

            "diversity":
                [
                    float(x)
                    for x
                    in result["diversity"]
                ],

            "coverage":
                [
                    float(x)
                    for x
                    in result["coverage"]
                ],

            "reliability":
                [
                    float(x)
                    for x
                    in result["reliability"]
                ],

            "adaptive_scores":
                [
                    float(x)
                    for x
                    in result["adaptive_scores"]
                ],

            "sample_factor":
                [
                    float(x)
                    for x
                    in result["sample_factor"]
                ],

            "adaptive_weights":
                [
                    float(x)
                    for x
                    in result["adaptive_weights"]
                ],
        },
    }

    path = (
        output_dir
        / "aggregation_test.json"
    )

    with open(
        path,
        "w",
        encoding="utf-8",
    ) as file:

        json.dump(
            output,
            file,
            indent=4,
        )

    return path


# ============================================================
# MAIN
# ============================================================

def main():

    print(
        "=" * 70
    )

    print(
        "AEFL-OSIDS CLASS-AWARE "
        "ADAPTIVE AGGREGATION TEST"
    )

    print(
        "=" * 70
    )

    print()

    print(
        f"Scenario: {SCENARIO_NAME}"
    )

    print(
        f"Clients : 5"
    )

    print()

    print(
        "Aggregation formula:"
    )

    print(
        "  Score = "
        "0.30 Quality + "
        "0.25 Diversity + "
        "0.25 Coverage + "
        "0.20 Reliability"
    )

    print()

    print(
        "Sample influence:"
    )

    print(
        "  sqrt(number_of_samples)"
    )

    # --------------------------------------------------------
    # Load
    # --------------------------------------------------------

    data = load_client_statistics()

    clients = extract_clients(
        data
    )

    print()

    print(
        f"Client records loaded: "
        f"{len(clients)}"
    )

    # --------------------------------------------------------
    # Calculate
    # --------------------------------------------------------

    result = calculate_weights(
        clients
    )

    fedavg = (
        calculate_fedavg_weights(
            result["sample_counts"]
        )
    )

    # --------------------------------------------------------
    # Print
    # --------------------------------------------------------

    print_client_distribution(
        result
    )

    print_comparison(
        result,
        fedavg
    )

    # --------------------------------------------------------
    # Verification
    # --------------------------------------------------------

    adaptive = np.asarray(
        result["adaptive_weights"]
    )

    print()

    print(
        "=" * 70
    )

    print(
        "WEIGHT VALIDATION"
    )

    print(
        "=" * 70
    )

    print()

    print(
        f"FedAvg weight sum     : "
        f"{fedavg.sum():.6f}"
    )

    print(
        f"Adaptive weight sum   : "
        f"{adaptive.sum():.6f}"
    )

    if abs(
        adaptive.sum() - 1.0
    ) < 1e-6:

        print(
            "Weight normalization  : PASS"
        )

    else:

        print(
            "Weight normalization  : FAIL"
        )

        raise ValueError(
            "Adaptive weights do not sum to 1."
        )

    if np.all(
        adaptive >= 0
    ):

        print(
            "Non-negative weights  : PASS"
        )

    else:

        print(
            "Non-negative weights  : FAIL"
        )

        raise ValueError(
            "Negative aggregation weight."
        )

    # --------------------------------------------------------
    # Save
    # --------------------------------------------------------

    path = save_result(
        result,
        fedavg,
    )

    print()

    print(
        "Test result saved:"
    )

    print(
        path
    )

    print()

    print(
        "=" * 70
    )

    print(
        "CLASS-AWARE AGGREGATION TEST "
        "SUCCESSFUL"
    )

    print(
        "=" * 70
    )


if __name__ == "__main__":

    main()