"""
AEFL-OSIDS USER-FRIENDLY RESEARCH DASHBOARD

Purpose
-------
A read-only Streamlit dashboard for the verified AEFL-OSIDS experiment.

IMPORTANT
---------
- Reads existing experiment outputs only.
- Does NOT retrain the model.
- Does NOT modify model weights.
- Does NOT modify dataset files.
- Prioritizes independently recomputed test results for the proposed model.

Run from project root:
    python -m streamlit run ui/app.py
"""

from __future__ import annotations
import sys
import json
import socket
import threading
import textwrap
import time
from collections import deque
from pathlib import Path
from typing import Any, Optional


import pandas as pd
import streamlit as st


# ============================================================
# PATHS
# ============================================================

PROJECT_ROOT = Path(__file__).resolve().parents[1]

# Ensure the project root is on Python's import path.
# Streamlit executes this file from the ui/ directory, while the live
# detection package is a sibling directory:
#     AEFL-OSIDS/
#       ui/app.py
#       live_detection/
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

RESULTS_ROOT = PROJECT_ROOT / "results"
PAPER_RESULTS = RESULTS_ROOT / "paper_results"
PER_CLASS_RESULTS = RESULTS_ROOT / "per_class_results"
OPEN_SET_RESULTS = RESULTS_ROOT / "final_open_set"
HYBRID_OPEN_SET_RESULTS = RESULTS_ROOT / "hybrid_open_set"
UNKNOWN_RESULTS = RESULTS_ROOT / "unknown_family_analysis"
LEGACY_ADAPTIVE_RESULTS = RESULTS_ROOT / "adaptive_fedavg_v2"
PROPOSED_RESULTS = RESULTS_ROOT / "robust_adaptive_fedprox"
PROPOSED_FIGURES = RESULTS_ROOT / "proposed_publication"
ADAPTIVE_RESULTS = (
    PROPOSED_RESULTS
    if (PROPOSED_RESULTS / "final_metrics.json").exists()
    else LEGACY_ADAPTIVE_RESULTS
)
SHAP_RESULTS = (
    RESULTS_ROOT / "shap_proposed" / "scenario_C_multiple"
    if (RESULTS_ROOT / "shap_proposed" / "scenario_C_multiple").exists()
    else RESULTS_ROOT / "shap" / "scenario_C_multiple"
)
VERIFICATION_RESULTS = RESULTS_ROOT / "verification"

SCENARIO = "scenario_C_multiple"
PROPOSED_MODEL_PATH = PROJECT_ROOT / "data" / "models" / "robust_adaptive_fedprox_global.pt"
LEGACY_MODEL_PATH = PROJECT_ROOT / "data" / "models" / "adaptive_fedavg_v2_global.pt"
MODEL_PATH = PROPOSED_MODEL_PATH if PROPOSED_MODEL_PATH.exists() else LEGACY_MODEL_PATH
MODEL_NAME = (
    "Robust Class-Balanced FedProx"
    if MODEL_PATH == PROPOSED_MODEL_PATH
    else "Adaptive FedAvg v2"
)

CLASS_NAMES = ["BENIGN", "DDoS", "DoS", "Mirai", "Recon"]
UNKNOWN_FAMILIES = ["BruteForce", "Spoofing", "Web-based"]

# Faster live-flow completion for the presentation monitor.
# The original PacketCapture default is 15 s; using 2 s here makes
# normal mobile HTTP flows appear within roughly 2-3 seconds while
# preserving the trained model, open-set logic, and rule thresholds.
LIVE_FLOW_TIMEOUT_SECONDS = 2.0

# Browser page loads may create multiple TCP connections for one user action
# (for example the page plus favicon/parallel request).  Collapse matching
# focused flows that arrive within this short window into one visible event.
FOCUSED_EVENT_DEDUP_SECONDS = 3.0


# ============================================================
# PAGE CONFIG
# ============================================================

st.set_page_config(
    page_title="AEFL-OSIDS Research Dashboard",
    page_icon="🛡️",
    layout="wide",
    initial_sidebar_state="expanded",
)


# ============================================================
# STYLE
# ============================================================

st.markdown(
    """
<style>
.live-shell {
    background: linear-gradient(135deg, #10162b 0%, #17133a 55%, #10182d 100%);
    border: 1px solid rgba(140, 120, 255, 0.25);
    border-radius: 18px;
    padding: 1.35rem 1.5rem;
    margin: 0.25rem 0 1rem 0;
    color: #f5f7ff;
    box-shadow: 0 10px 35px rgba(15, 10, 45, 0.20);
}
.live-topbar {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 1rem;
}
.live-kicker {
    color: #9fa9ff;
    font-size: 0.72rem;
    font-weight: 700;
    letter-spacing: 0.14em;
}
.live-title {
    font-size: 2rem;
    font-weight: 800;
    letter-spacing: 0.02em;
    margin-top: 0.2rem;
}
.live-subtitle {
    color: #b8bfd8;
    font-size: 0.84rem;
    margin-top: 0.15rem;
}
.capture-badge {
    border-radius: 999px;
    padding: 0.55rem 0.85rem;
    font-size: 0.75rem;
    font-weight: 800;
    letter-spacing: 0.06em;
    white-space: nowrap;
}
.live-on {
    background: rgba(46, 204, 113, 0.14);
    color: #69f0a1;
    border: 1px solid rgba(46, 204, 113, 0.35);
}
.live-off {
    background: rgba(150, 160, 185, 0.12);
    color: #b8bfd8;
    border: 1px solid rgba(150, 160, 185, 0.25);
}
.pulse-dot {
    display: inline-block;
    width: 8px;
    height: 8px;
    margin-right: 0.45rem;
    border-radius: 50%;
    background: currentColor;
    box-shadow: 0 0 12px currentColor;
}
.attack-banner {
    background: linear-gradient(135deg, rgba(177, 53, 255, 0.18), rgba(255, 70, 100, 0.13));
    border: 1px solid rgba(255, 95, 125, 0.38);
    border-radius: 14px;
    padding: 0.9rem 1rem;
    margin: 0 0 1rem 0;
}
.attack-label {
    color: #ff9cab;
    font-size: 0.72rem;
    font-weight: 800;
    letter-spacing: 0.1em;
}
.attack-main {
    color: #ffffff;
    font-size: 1.25rem;
    font-weight: 800;
    margin-top: 0.15rem;
}
.attack-meta {
    color: #c6ccdf;
    font-size: 0.78rem;
    margin-top: 0.2rem;
}
.live-card-grid {
    display: grid;
    grid-template-columns: repeat(6, minmax(0, 1fr));
    gap: 0.7rem;
    margin-bottom: 1rem;
}
.live-card {
    background: rgba(19, 25, 49, 0.92);
    border: 1px solid rgba(130, 140, 190, 0.18);
    border-radius: 13px;
    padding: 0.85rem 0.8rem;
    min-height: 105px;
}
.live-card-label {
    color: #8e98b7;
    font-size: 0.65rem;
    font-weight: 800;
    letter-spacing: 0.08em;
}
.live-card-value {
    color: #f7f8ff;
    font-size: 1.25rem;
    font-weight: 800;
    margin-top: 0.5rem;
    overflow-wrap: anywhere;
}
.live-card-note {
    color: #747e9e;
    font-size: 0.68rem;
    margin-top: 0.35rem;
}
@media (max-width: 1100px) {
    .live-card-grid {
        grid-template-columns: repeat(3, minmax(0, 1fr));
    }
}
.main-title {
    font-size: 2.25rem;
    font-weight: 700;
    margin-bottom: 0.15rem;
}
.subtitle {
    color: #666;
    font-size: 1rem;
    margin-bottom: 1rem;
}
.section-note {
    padding: 0.8rem 1rem;
    border-radius: 0.5rem;
    background: rgba(128,128,128,0.08);
    margin-bottom: 1rem;
}
.small-muted {
    color: #777;
    font-size: 0.85rem;
}
.metric-note {
    color: #777;
    font-size: 0.78rem;
}
.metric-note {
    color: #777;
    font-size: 0.78rem;
}

/* ============================================================
   CYBER LIVE MONITOR — presentation layer
   ============================================================ */
.cyber-wrap {
    background:
        radial-gradient(circle at 15% 10%, rgba(39, 120, 255, .16), transparent 30%),
        radial-gradient(circle at 85% 5%, rgba(175, 66, 255, .13), transparent 28%),
        linear-gradient(135deg, #050916 0%, #0a1024 48%, #09081b 100%);
    border: 1px solid rgba(74, 151, 255, .42);
    border-radius: 18px;
    padding: 1.25rem 1.35rem;
    color: #eef4ff;
    box-shadow: 0 18px 55px rgba(0,0,0,.30), inset 0 0 35px rgba(30, 95, 255, .04);
}
.cyber-header {
    display:flex;
    align-items:center;
    justify-content:space-between;
    gap:1rem;
}
.cyber-kicker {
    color:#8faaff;
    font-size:.68rem;
    font-weight:800;
    letter-spacing:.18em;
}
.cyber-title {
    font-size:2.05rem;
    line-height:1.05;
    font-weight:900;
    letter-spacing:.025em;
    margin:.25rem 0 .35rem;
    text-shadow:0 0 18px rgba(42,170,255,.20);
}
.cyber-title span {
    color:#16d5ff;
}
.cyber-sub {
    color:#aebbd8;
    font-size:.78rem;
    letter-spacing:.04em;
}
.cyber-live {
    border:1px solid rgba(45,230,154,.42);
    background:rgba(21,207,131,.10);
    color:#55f2ad;
    border-radius:999px;
    padding:.55rem .85rem;
    font-size:.72rem;
    font-weight:900;
    letter-spacing:.08em;
    white-space:nowrap;
    box-shadow:0 0 22px rgba(40,230,150,.10);
}
.cyber-off {
    border-color:rgba(150,165,195,.25);
    background:rgba(150,165,195,.08);
    color:#aab5cf;
}
.cyber-alert {
    margin-top:1rem;
    padding:.85rem 1rem;
    border:1px solid rgba(255,70,104,.72);
    border-radius:13px;
    background:
        linear-gradient(90deg, rgba(120,0,20,.48), rgba(52,9,36,.25)),
        radial-gradient(circle at 0 50%, rgba(255,50,75,.16), transparent 50%);
    box-shadow:0 0 30px rgba(255,35,80,.10);
}
.cyber-alert-title {
    color:#ff687e;
    font-size:.72rem;
    font-weight:900;
    letter-spacing:.11em;
}
.cyber-alert-main {
    color:#fff;
    font-size:1.22rem;
    font-weight:900;
    margin-top:.15rem;
}
.cyber-alert-meta {
    color:#bac5dd;
    font-size:.73rem;
    margin-top:.25rem;
}
.cyber-risk {
    float:right;
    text-align:right;
    margin-left:1rem;
}
.cyber-risk-value {
    color:#ffcf45;
    font-size:1.25rem;
    font-weight:900;
}
.cyber-risk-label {
    color:#8f9bb8;
    font-size:.62rem;
    letter-spacing:.08em;
}
.cyber-grid {
    display:grid;
    grid-template-columns:repeat(6,minmax(0,1fr));
    gap:.65rem;
    margin:1rem 0;
}
.cyber-card {
    min-height:105px;
    padding:.75rem .75rem .7rem;
    border-radius:12px;
    background:linear-gradient(145deg, rgba(17,28,60,.98), rgba(9,14,34,.98));
    border:1px solid rgba(73,138,255,.34);
    box-shadow:inset 0 1px 0 rgba(255,255,255,.025), 0 8px 25px rgba(0,0,0,.16);
    position:relative;
    overflow:hidden;
}
.cyber-card:after {
    content:"";
    position:absolute;
    left:0; right:0; bottom:0;
    height:2px;
    background:linear-gradient(90deg,#18cfff,#8a4dff,#ff3f8e);
    opacity:.8;
}
.cyber-label {
    color:#7e8bab;
    font-size:.60rem;
    font-weight:900;
    letter-spacing:.10em;
}
.cyber-value {
    color:#f5f8ff;
    font-size:1.28rem;
    font-weight:900;
    margin-top:.42rem;
    overflow-wrap:anywhere;
}
.cyber-note {
    color:#687694;
    font-size:.62rem;
    margin-top:.25rem;
}
.cyber-panel {
    background:linear-gradient(145deg, rgba(7,15,36,.98), rgba(7,10,25,.98));
    border:1px solid rgba(57,128,255,.34);
    border-radius:14px;
    padding:.9rem 1rem;
    min-height:255px;
}
.cyber-panel-title {
    color:#b7c7ef;
    font-size:.72rem;
    font-weight:900;
    letter-spacing:.09em;
    margin-bottom:.8rem;
}
.cyber-big {
    color:#9c4dff;
    font-size:2.4rem;
    font-weight:900;
    line-height:1;
}
.cyber-big-unit {
    color:#c6d0e8;
    font-size:.82rem;
    font-weight:800;
}
.cyber-progress {
    height:9px;
    background:#111a35;
    border-radius:99px;
    overflow:hidden;
    margin:.75rem 0 .35rem;
    border:1px solid rgba(96,130,210,.18);
}
.cyber-progress > div {
    height:100%;
    border-radius:99px;
    background:linear-gradient(90deg,#713dff,#ca35ff,#ff3f8e);
    box-shadow:0 0 18px rgba(159,56,255,.55);
}
.cyber-mini {
    color:#7d8baa;
    font-size:.66rem;
}
.cyber-bars { display:flex; flex-direction:column; gap:.52rem; }
.cyber-bar-row {
    display:grid;
    grid-template-columns:70px 1fr 50px;
    gap:.45rem;
    align-items:center;
    font-size:.68rem;
}
.cyber-bar-name { color:#b8c5e4; font-weight:800; }
.cyber-bar-track { height:7px; background:#121a34; border-radius:99px; overflow:hidden; }
.cyber-bar-fill { height:100%; border-radius:99px; background:linear-gradient(90deg,#0ccfff,#754dff); }
.cyber-bar-num { color:#f0f5ff; text-align:right; font-weight:900; }
.cyber-donut {
    width:145px; height:145px; border-radius:50%;
    margin:.25rem auto .6rem;
    display:flex; align-items:center; justify-content:center;
    background:conic-gradient(#ff3f68 0 45%, #ff9b3f 45% 58%, #8d55ff 58% 78%, #12c8ff 78% 100%);
    box-shadow:0 0 25px rgba(81,89,255,.22);
}
.cyber-donut-inner {
    width:92px; height:92px; border-radius:50%;
    background:#091027;
    display:flex; flex-direction:column; align-items:center; justify-content:center;
    border:1px solid rgba(120,145,220,.22);
}
.cyber-donut-main { color:#fff; font-size:1rem; font-weight:900; }
.cyber-donut-sub { color:#8290ae; font-size:.62rem; }
.cyber-legend {
    display:grid; grid-template-columns:1fr 1fr; gap:.3rem .8rem;
    font-size:.65rem; color:#a9b6d2;
}
.cyber-dot { display:inline-block; width:7px; height:7px; border-radius:50%; margin-right:.35rem; }
.cyber-table-wrap {
    background:linear-gradient(145deg, rgba(6,13,31,.98), rgba(7,10,24,.98));
    border:1px solid rgba(57,128,255,.30);
    border-radius:14px;
    padding:.85rem 1rem;
}
.cyber-footer {
    margin-top:.7rem;
    padding:.55rem .75rem;
    border-top:1px solid rgba(75,112,190,.18);
    color:#70809f;
    font-size:.65rem;
    display:flex;
    justify-content:space-between;
    gap:.5rem;
}
@media(max-width:1100px){
    .cyber-grid{grid-template-columns:repeat(3,minmax(0,1fr));}
}
@media(max-width:700px){
    .cyber-grid{grid-template-columns:repeat(2,minmax(0,1fr));}
    .cyber-title{font-size:1.45rem;}
}
</style>
""",
    unsafe_allow_html=True,
)



# ============================================================
# REAL-TIME MONITOR SERVICE
# ============================================================

class LiveMonitorService:
    """Thread-safe bridge between the existing live detector and Streamlit."""

    def __init__(self) -> None:
        self.lock = threading.RLock()
        self.thread: Optional[threading.Thread] = None
        self.capture = None
        self.detector = None
        self.running = False
        self.error: Optional[str] = None
        self.started_at: Optional[float] = None
        self.last_detection_at: Optional[float] = None
        self.total_detection_latency_ms = 0.0
        self.detection_count = 0
        self.recent_alerts = deque(maxlen=100)
        # Keep every completed flow for live dashboard statistics.
        # recent_alerts intentionally contains only SUSPICIOUS/INTRUSION/UNKNOWN.
        self.recent_detections = deque(maxlen=500)
        self.packet_window = deque(maxlen=20000)
        self.last_result = None
        self.last_flow = None

        # Presentation-focused monitoring. Packet capture and detection still
        # run on all traffic, but only flows matching this target are surfaced
        # as visible security alerts while focus mode is armed.
        self.focus_enabled = False
        self.focus_target = ""
        self.focus_local_ip = ""
        self.focus_port: Optional[int] = None
        self.focus_protocol = "ANY"
        self.focus_started_at: Optional[float] = None
        self.focused_alerts = deque(maxlen=50)
        # Presentation status is event-based, not sticky. A focused alert is
        # considered active only for this many seconds after its latest flow.
        self.alert_hold_seconds = 5.0


    @staticmethod
    def _endpoint_host(endpoint: Any) -> str:
        value = str(endpoint or "").strip().lower()
        if not value:
            return ""
        if value.rsplit(":", 1)[-1].isdigit():
            return value.rsplit(":", 1)[0]
        return value

    @staticmethod
    def _endpoint_port(endpoint: Any) -> Optional[int]:
        value = str(endpoint or "").strip()
        if not value:
            return None
        try:
            return int(value.rsplit(":", 1)[1])
        except (ValueError, IndexError):
            return None

    @staticmethod
    def _protocol_matches(actual: Any, wanted: str) -> bool:
        wanted = str(wanted or "ANY").strip().upper()
        if wanted == "ANY":
            return True
        actual_text = str(actual or "").strip().upper()
        aliases = {
            "TCP": {"TCP", "6", "6.0"},
            "UDP": {"UDP", "17", "17.0"},
            "ICMP": {"ICMP", "1", "1.0"},
        }
        return actual_text in aliases.get(wanted, {wanted})

    def _matches_focus(self, record: dict) -> bool:
        """Match only the explicitly armed test conversation.

        Example mobile HTTP test:
          device 172.20.39.176 <-> laptop 172.20.34.174, TCP port 8765

        This deliberately rejects unrelated traffic from the same phone such
        as mDNS (224.0.0.251:5353), DNS, browser traffic, etc.
        """
        if not self.focus_enabled or not self.focus_target:
            return False
        if self.focus_started_at is not None and float(record.get("timestamp", 0.0)) < self.focus_started_at:
            return False

        target = self.focus_target.strip().lower()
        local_ip = self.focus_local_ip.strip().lower()
        src = self._endpoint_host(record.get("source"))
        dst = self._endpoint_host(record.get("destination"))
        sport = self._endpoint_port(record.get("source"))
        dport = self._endpoint_port(record.get("destination"))

        # The remote/mobile IP must participate.
        if target not in {src, dst}:
            return False

        # If a laptop/local IP is supplied, require the exact two-host pair.
        if local_ip and {src, dst} != {target, local_ip}:
            return False

        # If a service port is supplied, require that exact port in either
        # direction so both request and response flows can be observed.
        if self.focus_port is not None and self.focus_port not in {sport, dport}:
            return False

        if not self._protocol_matches(record.get("protocol"), self.focus_protocol):
            return False

        return True

    def arm_focus(
        self,
        target: str,
        local_ip: str = "",
        port: Optional[int] = None,
        protocol: str = "ANY",
    ) -> None:
        target = str(target or "").strip()
        local_ip = str(local_ip or "").strip()
        protocol = str(protocol or "ANY").strip().upper()

        if not target:
            raise ValueError("Enter the remote/mobile IP before arming focused monitoring.")

        if port in ("", None):
            parsed_port = None
        else:
            try:
                parsed_port = int(port)
            except (TypeError, ValueError):
                raise ValueError("Port must be a number, for example 8765.")
            if not 1 <= parsed_port <= 65535:
                raise ValueError("Port must be between 1 and 65535.")

        if protocol not in {"ANY", "TCP", "UDP", "ICMP"}:
            raise ValueError("Protocol must be ANY, TCP, UDP, or ICMP.")

        with self.lock:
            self.focus_enabled = True
            self.focus_target = target
            self.focus_local_ip = local_ip
            self.focus_port = parsed_port
            self.focus_protocol = protocol
            self.focus_started_at = time.monotonic()
            self.focused_alerts.clear()
            self.recent_alerts.clear()

    def clear_focus(self) -> None:
        with self.lock:
            self.focus_enabled = False
            self.focus_target = ""
            self.focus_local_ip = ""
            self.focus_port = None
            self.focus_protocol = "ANY"
            self.focus_started_at = None
            self.focused_alerts.clear()
            self.recent_alerts.clear()

    def _packet_callback(self, flow: Any) -> None:
        if flow is None:
            return

        if hasattr(flow, "to_dict") and callable(flow.to_dict):
            try:
                flow = flow.to_dict()
            except Exception:
                return

        if not isinstance(flow, dict):
            return

        started = time.perf_counter()
        try:
            result = self.detector.process_flow(flow)
        except Exception as exc:
            with self.lock:
                self.error = f"Detection error: {exc}"
            return

        latency_ms = (time.perf_counter() - started) * 1000.0
        now = time.monotonic()

        decision = str(getattr(result, "decision", "UNKNOWN"))
        ml_class = str(getattr(result, "ml_class", "N/A"))
        confidence = float(getattr(result, "ml_confidence", 0.0) or 0.0)
        risk = float(getattr(result, "risk_score", 0.0) or 0.0)
        rule_risk = float(getattr(result, "rule_risk_score", 0.0) or 0.0)
        rule_count = int(getattr(result, "rule_count", 0) or 0)

        src = flow.get("src_ip", flow.get("source_ip", "?"))
        dst = flow.get("dst_ip", flow.get("destination_ip", "?"))
        sport = flow.get("src_port", flow.get("source_port", "?"))
        dport = flow.get("dst_port", flow.get("destination_port", "?"))
        protocol = flow.get("protocol", flow.get("protocol_type", "?"))

        record = {
            "time": time.strftime("%H:%M:%S"),
            "timestamp": now,
            "decision": decision,
            "ml_class": ml_class,
            "confidence": confidence,
            "risk_score": risk,
            "rule_risk": rule_risk,
            "rule_count": rule_count,
            "latency_ms": latency_ms,
            "source": f"{src}:{sport}",
            "destination": f"{dst}:{dport}",
            "protocol": protocol,
            "packets": flow.get("packet_count", flow.get("packets", 0)),
            "bytes": flow.get("byte_count", flow.get("bytes", 0)),
        }

        with self.lock:
            self.last_result = result
            self.last_flow = flow
            self.last_detection_at = now
            self.total_detection_latency_ms += latency_ms
            self.detection_count += 1
            self.recent_detections.appendleft(record)

            # Do not flood the presentation with unrelated background
            # browser/DNS/mDNS traffic.  Visible security alerts are emitted
            # only for a user-armed focused target.  The underlying detector
            # still analyzes every completed flow and updates statistics.
            if self._matches_focus(record):
                # One browser refresh can create two or more TCP connections
                # with different ephemeral source ports.  They are distinct
                # network flows, so the detector analyzes every one of them,
                # but the presentation should show them as ONE security event.
                duplicate_event = False
                previous = self.focused_alerts[0] if self.focused_alerts else None

                if previous is not None:
                    age = now - float(previous.get("timestamp", 0.0))
                    prev_src = self._endpoint_host(previous.get("source"))
                    prev_dst = self._endpoint_host(previous.get("destination"))
                    cur_src = self._endpoint_host(record.get("source"))
                    cur_dst = self._endpoint_host(record.get("destination"))

                    same_hosts = {prev_src, prev_dst} == {cur_src, cur_dst}
                    same_decision = str(previous.get("decision")) == decision
                    same_class = str(previous.get("ml_class")) == ml_class
                    same_protocol = str(previous.get("protocol")) == str(protocol)

                    duplicate_event = (
                        age <= FOCUSED_EVENT_DEDUP_SECONDS
                        and same_hosts
                        and same_decision
                        and same_class
                        and same_protocol
                    )

                if duplicate_event and previous is not None:
                    # Refresh the existing visible event instead of adding a
                    # duplicate row.  Keep the strongest observed values.
                    previous["time"] = record["time"]
                    previous["timestamp"] = now
                    previous["confidence"] = max(
                        float(previous.get("confidence", 0.0)),
                        confidence,
                    )
                    previous["risk_score"] = max(
                        float(previous.get("risk_score", 0.0)),
                        risk,
                    )
                    previous["rule_risk"] = max(
                        float(previous.get("rule_risk", 0.0)),
                        rule_risk,
                    )
                    previous["rule_count"] = max(
                        int(previous.get("rule_count", 0)),
                        rule_count,
                    )
                    previous["latency_ms"] = latency_ms
                    previous["flow_count"] = int(
                        previous.get("flow_count", 1)
                    ) + 1
                    # source/destination are deliberately left as the first
                    # representative flow; ephemeral source-port changes do
                    # not create a second visible alert.
                else:
                    record["flow_count"] = 1
                    self.focused_alerts.appendleft(record)
                    if decision in {"SUSPICIOUS", "INTRUSION", "UNKNOWN"} or rule_count > 0:
                        self.recent_alerts.appendleft(record)

    def _run_capture(self, interface: Optional[str], bpf_filter: str) -> None:
        try:
            from live_detection.live_detector import LiveDetector
            from live_detection.packet_capture import PacketCapture

            service = self

            class DashboardPacketCapture(PacketCapture):
                def _handle_packet(self, packet) -> None:
                    try:
                        packet_len = int(len(packet))
                    except Exception:
                        packet_len = 0

                    with service.lock:
                        service.packet_window.append(
                            (time.monotonic(), packet_len)
                        )

                    super()._handle_packet(packet)

            detector = LiveDetector(debug_features=False)

            capture = DashboardPacketCapture(
                interface=interface,
                bpf_filter=bpf_filter,
                flow_timeout=LIVE_FLOW_TIMEOUT_SECONDS,
                flow_callback=service._packet_callback,
            )

            with self.lock:
                self.detector = detector
                self.capture = capture
                self.error = None
                self.running = True
                self.started_at = time.monotonic()

            # blocking=True is deliberate. The existing PacketCapture
            # expires inactive flows once per second in this worker.
            capture.start(blocking=True)

        except Exception as exc:
            with self.lock:
                self.error = str(exc)
        finally:
            with self.lock:
                self.running = False

    def start(self, interface: Optional[str], bpf_filter: str) -> bool:
        with self.lock:
            if self.running:
                return True
            if self.thread is not None and self.thread.is_alive():
                return False

            self.error = None
            self.recent_alerts.clear()
            self.recent_detections.clear()
            self.packet_window.clear()
            self.last_result = None
            self.last_flow = None
            self.last_detection_at = None
            self.focus_enabled = False
            self.focus_target = ""
            self.focus_started_at = None
            self.focused_alerts.clear()
            self.total_detection_latency_ms = 0.0
            self.detection_count = 0

            self.thread = threading.Thread(
                target=self._run_capture,
                args=(interface, bpf_filter),
                name="aefl-osids-live-capture",
                daemon=True,
            )
            self.thread.start()
            return True

    def stop(self) -> None:
        """Stop the existing Scapy capture immediately.

        The capture itself already runs in a background worker.  Calling the
        existing PacketCapture.stop() directly here is intentional: it stops
        the AsyncSniffer and flushes active flows, allowing the worker to exit
        normally.  We do not join the worker from the Streamlit thread.
        """
        with self.lock:
            capture = self.capture

        if capture is None:
            with self.lock:
                self.running = False
            return

        try:
            capture.stop()
        except Exception as exc:
            with self.lock:
                self.error = f"Capture stop error: {exc}"
        finally:
            with self.lock:
                self.running = False

    def is_active(self) -> bool:
        with self.lock:
            capture = self.capture
            thread = self.thread
            return bool(self.running and capture is not None and thread is not None and thread.is_alive())

    def snapshot(self) -> dict:
        now = time.monotonic()

        with self.lock:
            while self.packet_window and now - self.packet_window[0][0] > 10.0:
                self.packet_window.popleft()

            packets_1s = sum(
                1 for timestamp, _ in self.packet_window
                if now - timestamp <= 1.0
            )
            bytes_1s = sum(
                packet_bytes for timestamp, packet_bytes in self.packet_window
                if now - timestamp <= 1.0
            )

            stats = {}
            if self.capture is not None:
                try:
                    stats = self.capture.statistics()
                except Exception:
                    stats = {}

            flow_stats = stats.get("flows", {}) if isinstance(stats, dict) else {}
            capture_stats = (
                stats.get("capture", {}) if isinstance(stats, dict) else {}
            )

            detector = self.detector
            counts = {
                "BENIGN": int(getattr(detector, "benign_count", 0) or 0),
                "SUSPICIOUS": int(
                    getattr(detector, "suspicious_count", 0) or 0
                ),
                "INTRUSION": int(
                    getattr(detector, "intrusion_count", 0) or 0
                ),
                "UNKNOWN": int(getattr(detector, "unknown_count", 0) or 0),
            }

            last = dict(self.recent_alerts[0]) if self.recent_alerts else None
            last_focused = dict(self.focused_alerts[0]) if self.focused_alerts else None
            focused_counts = {"BENIGN": 0, "SUSPICIOUS": 0, "INTRUSION": 0, "UNKNOWN": 0}
            for item in self.focused_alerts:
                key = str(item.get("decision", "UNKNOWN")).upper()
                if key in focused_counts:
                    focused_counts[key] += 1
            focused_age = (
                max(0.0, now - float(last_focused.get("timestamp", now)))
                if last_focused is not None
                else None
            )
            last_detection = (
                dict(self.recent_detections[0])
                if self.recent_detections
                else None
            )

            return {
                "running": bool(self.running),
                "error": self.error,
                "packets_per_second": packets_1s,
                "bytes_per_second": bytes_1s,
                "captured_packets": int(
                    capture_stats.get("captured_packets", 0)
                ),
                "ignored_packets": int(
                    capture_stats.get("ignored_packets", 0)
                ),
                "completed_flows": int(
                    capture_stats.get("completed_flows", 0)
                ),
                "active_flows": int(
                    flow_stats.get("active_flows", 0)
                ),
                "counts": counts,
                "last": last,
                "last_detection": last_detection,
                "alerts": [dict(x) for x in self.recent_alerts],
                "focused_flows": [dict(x) for x in self.focused_alerts],
                "last_focused": last_focused,
                "focused_counts": focused_counts,
                "focused_age": focused_age,
                "alert_hold_seconds": self.alert_hold_seconds,
                "focus_enabled": self.focus_enabled,
                "focus_target": self.focus_target,
                "focus_local_ip": self.focus_local_ip,
                "focus_port": self.focus_port,
                "focus_protocol": self.focus_protocol,
                "avg_latency_ms": (
                    self.total_detection_latency_ms / self.detection_count
                    if self.detection_count
                    else 0.0
                ),
                "detection_count": self.detection_count,
                "uptime": (
                    max(0.0, now - self.started_at)
                    if self.started_at is not None and self.running
                    else 0.0
                ),
            }


def get_live_monitor() -> LiveMonitorService:
    if "aefl_live_monitor" not in st.session_state:
        st.session_state["aefl_live_monitor"] = LiveMonitorService()
    return st.session_state["aefl_live_monitor"]


def _format_rate(value: int) -> str:
    if value >= 1_000_000:
        return f"{value / 1_000_000:.2f} MB/s"
    if value >= 1_000:
        return f"{value / 1_000:.1f} KB/s"
    return f"{value} B/s"


def _format_duration(seconds: float) -> str:
    seconds = int(max(0, seconds))
    hours, remainder = divmod(seconds, 3600)
    minutes, secs = divmod(remainder, 60)
    return f"{hours:02d}:{minutes:02d}:{secs:02d}"


def _render_live_monitor(service: LiveMonitorService) -> None:
    """Render the presentation-ready real-time cybersecurity monitor."""

    snap = service.snapshot()
    # Security banner/table intentionally follow the focused terminal test,
    # not unrelated background traffic.
    last = snap.get("last_focused") if snap.get("focus_enabled") else None

    # ------------------------------------------------------------
    # CONTROL STRIP
    # ------------------------------------------------------------
    st.markdown(
        """
        <div class="cyber-wrap">
          <div class="cyber-header">
            <div>
              <div class="cyber-kicker">AEFL-OSIDS • REAL-TIME SECURITY MONITOR</div>
              <div class="cyber-title">HYBRID <span>INTRUSION DETECTION</span></div>
              <div class="cyber-sub">
                ADAPTIVE FEDAVG V2 • OPEN-SET DETECTION • RULE-BASED NETWORK ANALYSIS
              </div>
            </div>
            <div class="cyber-live %s">
              <span class="pulse-dot"></span>%s
            </div>
          </div>
        </div>
        """
        % (
            "" if snap["running"] else "cyber-off",
            "CAPTURE ACTIVE" if snap["running"] else "CAPTURE STOPPED",
        ),
        unsafe_allow_html=True,
    )

    # ------------------------------------------------------------
    # FOCUSED TERMINAL TEST
    # ------------------------------------------------------------
    st.markdown("#### 🎯 FOCUSED TERMINAL TEST")
    st.caption(
        "Capture remains real and continuous, but the presentation alert state is "
        "restricted to the armed target. Live flows use a 2-second inactivity timeout "
        "for faster response. A focused alert is shown for about 5 seconds, then the "
        "dashboard returns to TRAFFIC NORMAL if no new matching alert arrives."
    )
    fc1, fc2, fc3, fc4 = st.columns([1.45, 1.45, 0.8, 0.8])
    with fc1:
        focus_target = st.text_input(
            "Remote / Mobile IP",
            value=snap.get("focus_target") or "172.20.39.176",
            key="aefl_focus_target",
            help="IP of the device generating the test traffic.",
        ).strip()
    with fc2:
        focus_local_ip = st.text_input(
            "Laptop IP",
            value=snap.get("focus_local_ip") or "172.20.34.174",
            key="aefl_focus_local_ip",
            help="Laptop Wi-Fi IP receiving the controlled test traffic.",
        ).strip()
    with fc3:
        focus_port = st.number_input(
            "Port",
            min_value=1,
            max_value=65535,
            value=int(snap.get("focus_port") or 8765),
            step=1,
            key="aefl_focus_port",
        )
    with fc4:
        focus_protocol = st.selectbox(
            "Protocol",
            ["TCP", "UDP", "ICMP", "ANY"],
            index=["TCP", "UDP", "ICMP", "ANY"].index(
                str(snap.get("focus_protocol") or "TCP").upper()
                if str(snap.get("focus_protocol") or "TCP").upper() in {"TCP", "UDP", "ICMP", "ANY"}
                else "TCP"
            ),
            key="aefl_focus_protocol",
        )

    fb1, fb2 = st.columns([1, 1])
    with fb1:
        if st.button("🎯 ARM TEST", use_container_width=True, type="primary", key="aefl_arm_focus"):
            try:
                service.arm_focus(
                    focus_target,
                    local_ip=focus_local_ip,
                    port=int(focus_port),
                    protocol=focus_protocol,
                )
                st.rerun()
            except Exception as exc:
                st.error(str(exc))
    with fb2:
        if st.button("CLEAR TEST", use_container_width=True, key="aefl_clear_focus"):
            service.clear_focus()
            st.rerun()

    snap = service.snapshot()
    last = snap.get("last_focused") if snap.get("focus_enabled") else None
    focused_age = snap.get("focused_age")
    hold_seconds = float(snap.get("alert_hold_seconds", 5.0))
    recent_focused = bool(
        last is not None
        and focused_age is not None
        and float(focused_age) <= hold_seconds
    )
    focused_is_alert = bool(
        recent_focused
        and (
            str(last.get("decision", "")).upper() in {"SUSPICIOUS", "INTRUSION", "UNKNOWN"}
            or int(last.get("rule_count", 0) or 0) > 0
        )
    )

    if snap.get("focus_enabled"):
        st.success(
            f"FOCUSED MONITOR ARMED • Target: {snap.get('focus_target')} • "
            "Send the authorized test traffic from the second terminal."
        )
    else:
        st.info("Monitoring traffic statistics. Arm a target to display focused security events.")

    # ------------------------------------------------------------
    # ERROR
    # ------------------------------------------------------------
    if snap["error"]:
        st.error(f"Live capture error: {snap['error']}")

    # ------------------------------------------------------------
    # EVENT-BASED SECURITY BANNER
    # ------------------------------------------------------------
    if focused_is_alert:
        decision = str(last["decision"]).upper()
        ml_class = str(last["ml_class"])
        risk = max(0.0, min(100.0, float(last["risk_score"])))

        if risk >= 70.0:
            severity = "HIGH RISK"
        elif risk >= 40.0:
            severity = "MEDIUM RISK"
        else:
            severity = "CAUTION"

        if decision == "INTRUSION":
            banner_title = "⚠ ATTACK DETECTED"
            attack_type = ml_class if ml_class and ml_class != "N/A" else "INTRUSION"
        elif decision == "SUSPICIOUS":
            banner_title = "⚠ POSSIBLE ATTACK DETECTED"
            attack_type = ml_class if ml_class and ml_class != "N/A" else "SUSPICIOUS"
        else:
            banner_title = "⚠ UNKNOWN / POSSIBLE ZERO-DAY TRAFFIC DETECTED"
            attack_type = "UNKNOWN / POSSIBLE ZERO-DAY"

        st.markdown(
            f"""
            <div class="cyber-alert">
              <div class="cyber-risk">
                <div class="cyber-risk-value">{risk:.1f}</div>
                <div class="cyber-risk-label">RISK SCORE / 100</div>
              </div>
              <div class="cyber-alert-title">{banner_title} • {severity}</div>
              <div class="cyber-alert-main">ATTACK TYPE: {attack_type}</div>
              <div class="cyber-alert-meta">
                ML class: {ml_class}
                &nbsp; • &nbsp; Decision: {decision}
                &nbsp; • &nbsp; Confidence: {last["confidence"]:.1%}
                &nbsp; • &nbsp; Rule risk: {last["rule_risk"]:.2f}
                &nbsp; • &nbsp; Rules: {last["rule_count"]}
              </div>
            </div>
            """,
            unsafe_allow_html=True,
        )
    elif recent_focused:
        # A recent focused flow was observed but the hybrid detector did not
        # classify it as a security alert. Keep the message factual.
        st.markdown(
            f"""
            <div class="cyber-alert" style="border-color:rgba(31,226,151,.38);
                 background:linear-gradient(90deg,rgba(0,70,45,.30),rgba(7,20,35,.25));">
              <div class="cyber-alert-title" style="color:#53edaa;">✓ TEST TRAFFIC DETECTED • NO ACTIVE ATTACK ALERT</div>
              <div class="cyber-alert-main">{last["decision"]} • {last["ml_class"]}</div>
              <div class="cyber-alert-meta">
                Confidence: {last["confidence"]:.1%}
                &nbsp; • &nbsp; {last["source"]} → {last["destination"]}
              </div>
            </div>
            """,
            unsafe_allow_html=True,
        )
    else:
        # Do not keep the previous attack sticky. Once the most recent focused
        # event is older than the hold window, the presentation returns to
        # normal while the historical alert remains in the table below.
        st.markdown(
            """
            <div class="cyber-alert" style="border-color:rgba(31,226,151,.38);
                 background:linear-gradient(90deg,rgba(0,70,45,.30),rgba(7,20,35,.25));">
              <div class="cyber-alert-title" style="color:#53edaa;">✓ TRAFFIC NORMAL • SYSTEM MONITORING</div>
              <div class="cyber-alert-main">NO ACTIVE SECURITY ALERT</div>
              <div class="cyber-alert-meta">
                Packet capture remains active. Historical focused alerts are retained below.
              </div>
            </div>
            """,
            unsafe_allow_html=True,
        )

    # ------------------------------------------------------------
    # KPI CARDS
    # ------------------------------------------------------------
    if focused_is_alert:
        latest_class = str(last["ml_class"])
        latest_status = str(last["decision"])
        active_rules = int(last["rule_count"] or 0)
        attack_type_card = (
            "UNKNOWN / ZERO-DAY"
            if str(last["decision"]).upper() == "UNKNOWN"
            else latest_class
        )
    elif recent_focused:
        latest_class = str(last["ml_class"])
        latest_status = "TEST TRAFFIC"
        active_rules = int(last["rule_count"] or 0)
        attack_type_card = "NONE"
    else:
        latest_class = "—"
        latest_status = "NORMAL" if snap["running"] else "STANDBY"
        active_rules = 0
        attack_type_card = "NONE"

    cards = [
        ("PACKETS / SEC", f"{snap['packets_per_second']:,}", "Live packet rate"),
        ("TOTAL PACKETS", f"{snap['captured_packets']:,}", "Captured by Scapy"),
        ("LATENCY", f"{snap['avg_latency_ms']:.1f} ms", "Average flow analysis"),
        ("ML STATUS", latest_status, f"Class: {latest_class}"),
        ("ATTACK TYPE", attack_type_card, "Current focused event"),
        ("ACTIVE RULES", f"{active_rules}", "Current focused event"),
    ]

    html = '<div class="cyber-grid">'
    for label, value, note in cards:
        html += (
            '<div class="cyber-card">'
            f'<div class="cyber-label">{label}</div>'
            f'<div class="cyber-value">{value}</div>'
            f'<div class="cyber-note">{note}</div>'
            '</div>'
        )
    html += "</div>"
    st.markdown(html, unsafe_allow_html=True)

    # ------------------------------------------------------------
    # TRAFFIC FLOW + LIVE RATE
    # ------------------------------------------------------------
    history = st.session_state.setdefault("aefl_live_history", deque(maxlen=60))
    history.append(
        {
            "time": time.strftime("%H:%M:%S"),
            "Packets/sec": snap["packets_per_second"],
            "Bytes/sec": snap["bytes_per_second"],
        }
    )

    max_pps = max(
        60,
        max((int(x["Packets/sec"]) for x in history), default=0),
    )
    pps = snap["packets_per_second"]
    pct = min(100.0, (pps / max_pps) * 100.0)

    p1, p2 = st.columns([0.9, 1.55])

    with p1:
        st.markdown(
            f"""
            <div class="cyber-panel">
              <div class="cyber-panel-title">TRAFFIC FLOW & RATE</div>
              <div class="cyber-mini">R1 • LIVE TRAFFIC RATE MONITOR</div>
              <div style="margin-top:.7rem;">
                <span class="cyber-big">{pps}</span>
                <span class="cyber-big-unit">PPS</span>
              </div>
              <div class="cyber-progress"><div style="width:{pct:.1f}%"></div></div>
              <div style="display:flex;justify-content:space-between;">
                <span class="cyber-mini">{_format_rate(snap["bytes_per_second"])}</span>
                <span class="cyber-mini">{max_pps} PPS display scale</span>
              </div>
              <div style="margin-top:1rem;">
                <span class="cyber-mini">ACTIVE FLOWS</span>
                <div style="color:#eaf0ff;font-size:1.35rem;font-weight:900;">
                  {snap["active_flows"]:,}
                </div>
              </div>
              <div>
                <span class="cyber-mini">COMPLETED FLOWS</span>
                <div style="color:#aebce0;font-size:.95rem;font-weight:800;">
                  {snap["completed_flows"]:,}
                </div>
              </div>
            </div>
            """,
            unsafe_allow_html=True,
        )

    with p2:
        st.markdown(
            """
            <div class="cyber-panel-title"
                 style="background:linear-gradient(145deg,#070f24,#070a19);
                        border:1px solid rgba(57,128,255,.30);
                        border-radius:14px 14px 0 0;
                        padding:.9rem 1rem .55rem;
                        margin-bottom:0;">
              LIVE TRAFFIC DETECTION
            </div>
            """,
            unsafe_allow_html=True,
        )
        hist_df = pd.DataFrame(list(history))
        if not hist_df.empty:
            vals = hist_df["Packets/sec"].astype(float).tolist()
            if len(vals) == 1:
                vals = [vals[0], vals[0]]
            vmax = max(max(vals), 1.0)
            width, height = 760, 250
            pad_x, pad_y = 18, 20
            plot_w = width - 2 * pad_x
            plot_h = height - 2 * pad_y

            points = []
            for i, val in enumerate(vals[-60:]):
                x = pad_x + (i / max(len(vals[-60:]) - 1, 1)) * plot_w
                y = pad_y + plot_h - (val / vmax) * plot_h
                points.append((x, y))

            line_points = " ".join(f"{x:.1f},{y:.1f}" for x, y in points)
            area_points = (
                f"{pad_x},{pad_y + plot_h} "
                + line_points
                + f" {pad_x + plot_w},{pad_y + plot_h}"
            )

            grid = []
            for frac in (0, .25, .5, .75, 1):
                y = pad_y + plot_h - frac * plot_h
                label = vmax * frac
                grid.append(
                    f'<line x1="{pad_x}" y1="{y:.1f}" x2="{pad_x + plot_w}" '
                    f'y2="{y:.1f}" stroke="rgba(120,150,220,.16)" stroke-width="1"/>'
                    f'<text x="{pad_x + 6}" y="{y - 5:.1f}" fill="#7182ad" '
                    f'font-size="10">{label:.0f}</text>'
                )

            circles = "".join(
                f'<circle cx="{x:.1f}" cy="{y:.1f}" r="2.6" fill="#5b8cff"/>'
                for x, y in points[-12:]
            )

            svg = f"""
            <div style="background:#070a19;border:1px solid rgba(57,128,255,.30);
                        border-top:0;border-radius:0 0 14px 14px;
                        padding:8px 10px 5px;">
              <svg viewBox="0 0 {width} {height}" width="100%" height="245"
                   preserveAspectRatio="none">
                {''.join(grid)}
                <polygon points="{area_points}" fill="rgba(91,140,255,.16)"/>
                <polyline points="{line_points}" fill="none" stroke="#6f8cff"
                          stroke-width="3" stroke-linecap="round"
                          stroke-linejoin="round"/>
                {circles}
                <text x="{width-pad_x}" y="{height-4}" text-anchor="end"
                      fill="#7182ad" font-size="10">LIVE PACKETS / SEC</text>
              </svg>
            </div>
            """
            st.markdown(textwrap.dedent(svg), unsafe_allow_html=True)
        else:
            st.markdown(
                '<div style="height:260px;background:#070a19;'
                'border:1px solid rgba(57,128,255,.30);border-top:0;'
                'border-radius:0 0 14px 14px;"></div>',
                unsafe_allow_html=True,
            )

    # ------------------------------------------------------------
    # CLASSIFICATION + PROTOCOL/DECISION VIEW
    # ------------------------------------------------------------
    c1, c2 = st.columns([1, 1.35])

    counts = snap.get("focused_counts", {"BENIGN": 0, "SUSPICIOUS": 0, "INTRUSION": 0, "UNKNOWN": 0})
    total_decisions = max(1, sum(counts.values()))
    known_count = counts.get("BENIGN", 0)
    attack_count = (
        counts.get("SUSPICIOUS", 0)
        + counts.get("INTRUSION", 0)
    )
    unknown_count = counts.get("UNKNOWN", 0)

    with c1:
        attack_share = (attack_count / total_decisions) * 100.0
        benign_share = (known_count / total_decisions) * 100.0
        unknown_share = (unknown_count / total_decisions) * 100.0

        st.markdown(
            f"""
            <div class="cyber-panel">
              <div class="cyber-panel-title">ML TRAFFIC CLASSIFICATION</div>
              <div class="cyber-donut"
                   style="background:conic-gradient(
                     #22d3ff 0 {benign_share:.2f}%,
                     #ff3f68 {benign_share:.2f}% {benign_share + attack_share:.2f}%,
                     #9b55ff {benign_share + attack_share:.2f}% 100%);">
                <div class="cyber-donut-inner">
                  <div class="cyber-donut-main">{latest_class}</div>
                  <div class="cyber-donut-sub">LATEST CLASS</div>
                </div>
              </div>
              <div class="cyber-legend">
                <div><span class="cyber-dot" style="background:#22d3ff"></span>BENIGN {known_count}</div>
                <div><span class="cyber-dot" style="background:#ff3f68"></span>ALERT {attack_count}</div>
                <div><span class="cyber-dot" style="background:#9b55ff"></span>UNKNOWN {unknown_count}</div>
                <div><span class="cyber-dot" style="background:#ffd24d"></span>DECISIONS {sum(counts.values())}</div>
              </div>
            </div>
            """,
            unsafe_allow_html=True,
        )

    with c2:
        # Render as a single-line HTML string so Markdown cannot interpret
        # indented HTML fragments as a code block.
        max_count = max(1, max(counts.values(), default=1))
        decision_rows = []

        for name in ["BENIGN", "SUSPICIOUS", "INTRUSION", "UNKNOWN"]:
            value = counts.get(name, 0)
            width = (value / max_count) * 100.0
            decision_rows.append(
                f'<div class="cyber-bar-row">'
                f'<div class="cyber-bar-name">{name}</div>'
                f'<div class="cyber-bar-track" '
                f'style="background:#111a35;border:1px solid rgba(110,145,230,.20);">'
                f'<div class="cyber-bar-fill" '
                f'style="width:{width:.1f}%;background:linear-gradient(90deg,#4f7cff,#a84cff);'
                f'height:100%;border-radius:999px;"></div>'
                f'</div>'
                f'<div class="cyber-bar-num">{value}</div>'
                f'</div>'
            )

        decision_panel_html = (
            '<div class="cyber-panel">'
            '<div class="cyber-panel-title">FOCUSED TEST DECISIONS</div>'
            '<div class="cyber-bars">'
            + ''.join(decision_rows)
            + '</div>'
            '<div style="margin-top:1rem;display:grid;grid-template-columns:1fr 1fr;gap:.7rem;">'
            '<div>'
            '<div class="cyber-mini">DETECTION LATENCY</div>'
            f'<div style="font-size:1.15rem;font-weight:900;color:#fff;">'
            f'{snap["avg_latency_ms"]:.1f} ms</div>'
            '</div>'
            '<div>'
            '<div class="cyber-mini">CAPTURE UPTIME</div>'
            f'<div style="font-size:1.15rem;font-weight:900;color:#fff;">'
            f'{_format_duration(snap["uptime"])}</div>'
            '</div>'
            '</div>'
            '</div>'
        )

        st.markdown(
            decision_panel_html,
            unsafe_allow_html=True,
        )

    # ------------------------------------------------------------
    # RECENT ALERTS — compact, secondary
    # ------------------------------------------------------------
    st.markdown(
        '<div class="cyber-table-wrap" style="margin-top:1rem;">'
        '<div class="cyber-panel-title">RECENT SECURITY ALERTS</div>',
        unsafe_allow_html=True,
    )

    if snap["alerts"]:
        rows = [
            {
                "TIME": a["time"],
                "DECISION": a["decision"],
                "ML CLASS": a["ml_class"],
                "CONFIDENCE": f"{a['confidence']:.1%}",
                "RISK": f"{a['risk_score']:.2f}",
                "RULES": a["rule_count"],
                "SOURCE": a["source"],
                "DESTINATION": a["destination"],
            }
            for a in snap["alerts"][:8]
        ]
        st.dataframe(
            pd.DataFrame(rows),
            use_container_width=True,
            hide_index=True,
        )
    else:
        st.success("No focused security alert. Arm a target and send traffic from the second terminal.")

    st.markdown("</div>", unsafe_allow_html=True)

    st.markdown(
        f"""
        <div class="cyber-footer">
          <span>● Robust FedProx Engine &nbsp; • &nbsp; ● Rule Engine &nbsp; • &nbsp; ● Hybrid Open-Set Detection</span>
          <span>Capture: {"LIVE" if snap["running"] else "OFF"} &nbsp; • &nbsp; Ignored packets: {snap["ignored_packets"]:,}</span>
        </div>
        """,
        unsafe_allow_html=True,
    )


# ============================================================
# HELPERS
# ============================================================

def existing(path: Path) -> bool:
    return path.exists()


@st.cache_data(show_spinner=False)
def load_json(path_string: str) -> Optional[Any]:
    path = Path(path_string)
    if not path.exists():
        return None
    try:
        with path.open("r", encoding="utf-8") as handle:
            return json.load(handle)
    except Exception:
        return None


@st.cache_data(show_spinner=False)
def load_csv(path_string: str) -> Optional[pd.DataFrame]:
    path = Path(path_string)
    if not path.exists():
        return None
    try:
        return pd.read_csv(path)
    except Exception:
        return None


def pct(value: Any, digits: int = 2) -> str:
    try:
        return f"{float(value) * 100:.{digits}f}%"
    except (TypeError, ValueError):
        return "N/A"


def pct_value(value: Any) -> Optional[float]:
    try:
        return float(value) * 100.0
    except (TypeError, ValueError):
        return None


def number(value: Any) -> str:
    try:
        return f"{int(value):,}"
    except (TypeError, ValueError):
        return "N/A"


def show_image(path: Path, caption: str) -> None:
    if path.exists():
        st.image(str(path), caption=caption, use_container_width=True)
    else:
        st.info(f"Figure not available: {path.name}")


def download_df(df: Optional[pd.DataFrame], filename: str, label: str) -> None:
    if df is None or df.empty:
        return
    st.download_button(
        label=label,
        data=df.to_csv(index=False, encoding="utf-8-sig"),
        file_name=filename,
        mime="text/csv",
    )


def metric_row(items):
    cols = st.columns(len(items))
    for col, (label, value, help_text) in zip(cols, items):
        col.metric(label, value, help=help_text)


def read_text(path: Path) -> Optional[str]:
    if not path.exists():
        return None
    try:
        return path.read_text(encoding="utf-8")
    except Exception:
        return None


def normalize_open_set_result(data: Any) -> dict:
    """Expose nested evaluator fields through one stable dashboard schema."""
    if not isinstance(data, dict):
        return {}
    normalized = dict(data)
    unknown = data.get("unknown_detection") or {}
    known = data.get("known_class_performance") or {}
    aliases = {
        "unknown_precision": unknown.get("precision"),
        "unknown_recall": unknown.get("recall"),
        "unknown_f1": unknown.get("f1"),
        "known_fpr": unknown.get("known_fpr"),
        "known_accuracy": known.get("accuracy"),
        "known_macro_precision": known.get("macro_precision"),
        "known_macro_recall": known.get("macro_recall"),
        "known_macro_f1": known.get("macro_f1"),
    }
    for key, value in aliases.items():
        if normalized.get(key) is None and value is not None:
            normalized[key] = value
    return normalized


# ============================================================
# LOAD VERIFIED DATA
# ============================================================

final_metrics = load_json(
    str(ADAPTIVE_RESULTS / "final_metrics.json")
) or {}

comparison_json = load_json(
    str(RESULTS_ROOT / "final_comparison" / "final_comparison.json")
) or {}

hybrid_open_set_path = HYBRID_OPEN_SET_RESULTS / "hybrid_open_set_results.json"

open_set_json = normalize_open_set_result(
    load_json(
        str(
            hybrid_open_set_path
            if hybrid_open_set_path.exists()
            else OPEN_SET_RESULTS / "final_open_set_results.json"
        )
    ) or {}
)

if open_set_json.get("unknown_family_analysis"):
    unknown_family_json = {
        "unknown_samples": sum(
            int(item.get("samples", 0))
            for item in open_set_json["unknown_family_analysis"]
        ),
        "unknown_families": open_set_json.get("unknown_families", UNKNOWN_FAMILIES),
        "threshold": open_set_json.get("locked_threshold"),
        "family_performance": open_set_json["unknown_family_analysis"],
    }
else:
    unknown_family_json = load_json(
        str(UNKNOWN_RESULTS / "unknown_family_analysis.json")
    ) or {}

metadata = load_json(
    str(ADAPTIVE_RESULTS / "metadata.json")
) or {}

verification_json = load_json(
    str(VERIFICATION_RESULTS / "final_results_verification.json")
) or {}

comparison_df = load_csv(
    str(RESULTS_ROOT / "verified_comparison" / "publication_test_comparison.csv")
)

if comparison_df is None:
    comparison_df = load_csv(
        str(PAPER_RESULTS / "classification_comparison.csv")
    )

if comparison_df is None:
    comparison_df = load_csv(
        str(RESULTS_ROOT / "final_comparison" / "classification_comparison.csv")
    )

per_class_df = load_csv(
    str(RESULTS_ROOT / "verified_comparison" / "proposed_per_class_test.csv")
)

if per_class_df is None:
    per_class_df = load_csv(
        str(PER_CLASS_RESULTS / "adaptive_fedavg_v2_per_class.csv")
    )

if per_class_df is None:
    per_class_df = load_csv(
        str(PAPER_RESULTS / "adaptive_fedavg_v2_per_class.csv")
    )

open_set_df = load_csv(
    str(HYBRID_OPEN_SET_RESULTS / "hybrid_vs_msp.csv")
)

if open_set_df is None:
    open_set_df = load_csv(
        str(PAPER_RESULTS / "open_set_results.csv")
    )

unknown_family_df = load_csv(
    str(HYBRID_OPEN_SET_RESULTS / "unknown_family_performance.csv")
)

if unknown_family_df is None:
    unknown_family_df = load_csv(
        str(PAPER_RESULTS / "unknown_family_performance.csv")
    )

using_hybrid_open_set = hybrid_open_set_path.exists()
threshold_df = None if using_hybrid_open_set else load_csv(
    str(PAPER_RESULTS / "threshold_analysis.csv")
)

shap_df = load_csv(str(SHAP_RESULTS / "global_feature_importance.csv"))

if shap_df is None:
    shap_df = load_csv(str(PAPER_RESULTS / "shap_global_importance.csv"))

round_history = load_json(str(PROPOSED_RESULTS / "round_history.json"))
convergence_df = None
if isinstance(round_history, list) and round_history:
    convergence_df = pd.DataFrame(
        [
            {
                "Round": item.get("round"),
                "Accuracy": (item.get("validation") or {}).get("accuracy"),
                "Macro F1": (item.get("validation") or {}).get("f1_macro"),
                "Loss": (item.get("validation") or {}).get("loss"),
                "Round Time (s)": item.get("round_time_seconds"),
                "Communication (bytes)": item.get("communication_bytes"),
            }
            for item in round_history
        ]
    )

if convergence_df is None:
    convergence_df = load_csv(
        str(PAPER_RESULTS / "adaptive_fedavg_v2_convergence_data.csv")
    )

if convergence_df is None:
    convergence_df = load_csv(
        str(PAPER_RESULTS / "fl_convergence_data.csv")
    )

integrity_json = load_json(
    str(RESULTS_ROOT / "data_integrity" / f"{SCENARIO}_audit.json")
) or {}

primary_metrics = dict(final_metrics)
primary_split_label = "validation"

if comparison_df is not None and not comparison_df.empty:
    proposed_rows = comparison_df[
        comparison_df["Method"].astype(str).str.contains(
            "proposed", case=False, regex=False
        )
    ]
    if not proposed_rows.empty:
        proposed = proposed_rows.iloc[0]
        primary_metrics = {
            "accuracy": proposed.get("Accuracy"),
            "precision_macro": proposed.get("Macro Precision"),
            "recall_macro": proposed.get("Macro Recall"),
            "f1_macro": proposed.get("Macro F1"),
            "f1_weighted": proposed.get("Weighted F1"),
            "loss": final_metrics.get("loss"),
        }
        primary_split_label = "independent known-class test"


# ============================================================
# SIDEBAR
# ============================================================

st.sidebar.title("🛡️ AEFL-OSIDS")

st.sidebar.caption("Robust Adaptive Explainable Federated Open-Set IDS")

page = st.sidebar.radio(
    "Navigation",
    [
        "🏠 Dashboard",
        "📡 Real-Time Monitor",
        "📊 Classification",
        "🎯 Per-Class Analysis",
        "🔓 Open-Set Detection",
        "🕵️ Unknown Families",
        "🧠 SHAP Explainability",
        "🔄 Federated Learning",
        "📑 Research Results",
        "ℹ️ About Experiment",
    ],
)

st.sidebar.divider()

st.sidebar.markdown("### Experiment")
st.sidebar.write(f"**Scenario:** `{SCENARIO}`")
st.sidebar.write(f"**Model:** `{MODEL_NAME}`")
st.sidebar.write(
    f"**Model file:** {'Available' if MODEL_PATH.exists() else 'Not found'}"
)

verification_status = (
    "PRELIMINARY"
    if integrity_json.get("status") == "FAIL"
    else verification_json.get("status")
    or verification_json.get("overall_status")
    or "NOT RUN"
)

if str(verification_status).upper() == "PASS":
    st.sidebar.success("Verified results: PASS")
else:
    st.sidebar.warning(f"Verification: {verification_status}")

st.sidebar.caption(
    "This dashboard is read-only. It does not retrain or modify the model."
)


# ============================================================
# HEADER
# ============================================================

st.markdown(
    '<div class="main-title">🛡️ AEFL-OSIDS Research Dashboard</div>',
    unsafe_allow_html=True,
)
st.markdown(
    '<div class="subtitle">'
    "Adaptive Explainable Federated Learning with Open-Set Intrusion Detection for IoT Networks"
    "</div>",
    unsafe_allow_html=True,
)


# ============================================================
# REAL-TIME MONITOR
# ============================================================

if page == "📡 Real-Time Monitor":

    service = get_live_monitor()

    st.sidebar.markdown("### Live Capture")
    interface = st.sidebar.text_input(
        "Network interface",
        value="",
        help="Leave blank to use the default capture interface.",
    ).strip() or None

    bpf_filter = st.sidebar.text_input(
        "BPF filter",
        value="ip or ip6",
        help="Packet filter passed to the existing Scapy capture layer.",
    ).strip() or "ip or ip6"

    if hasattr(st, "fragment"):

        @st.fragment(run_every="1s")
        def live_fragment():
            # Keep the control buttons inside the same fragment as the live
            # monitor.  This is important because fragment reruns do not
            # rerender widgets that live outside the fragment.  Previously,
            # STOP could remain visually disabled even while capture was active.
            control1, control2, control3 = st.columns([1, 1, 2])

            with control1:
                if st.button(
                    "▶ START CAPTURE",
                    type="primary",
                    use_container_width=True,
                    disabled=service.is_active(),
                    key="aefl_start_capture",
                ):
                    service.start(interface, bpf_filter)

            with control2:
                if st.button(
                    "■ STOP CAPTURE",
                    use_container_width=True,
                    disabled=not service.is_active(),
                    key="aefl_stop_capture",
                ):
                    service.stop()
                    st.toast("Packet capture stopped.", icon="🛑")

            with control3:
                st.caption(
                    "PacketCapture → FlowManager → 39-feature builder → "
                    f"{MODEL_NAME} + Rule Engine + hybrid open-set detector."
                )

            _render_live_monitor(service)

        live_fragment()

    else:
        control1, control2, control3 = st.columns([1, 1, 2])

        with control1:
            if st.button(
                "▶ START CAPTURE",
                type="primary",
                use_container_width=True,
                disabled=service.is_active(),
                key="aefl_start_capture_fallback",
            ):
                service.start(interface, bpf_filter)
                st.rerun()

        with control2:
            if st.button(
                "■ STOP CAPTURE",
                use_container_width=True,
                disabled=not service.is_active(),
                key="aefl_stop_capture_fallback",
            ):
                service.stop()
                st.toast("Packet capture stopped.", icon="🛑")
                st.rerun()

        with control3:
            st.caption(
                "PacketCapture → FlowManager → 39-feature builder → "
                f"{MODEL_NAME} + Rule Engine + hybrid open-set detector."
            )

        _render_live_monitor(service)


# ============================================================
# DASHBOARD
# ============================================================

elif page == "🏠 Dashboard":

    st.header("Research Overview")

    st.markdown(
        """
<div class="section-note">
This dashboard prioritizes the proposed Robust Class-Balanced FedProx model.
Classification metrics use the independent known-class portion of Scenario-C;
open-set metrics use the complete Scenario-C test split. Validation is used
only for model selection and threshold calibration.
</div>
""",
        unsafe_allow_html=True,
    )

    validation_items = [
        (
            "Test Accuracy",
            pct(primary_metrics.get("accuracy")),
            "Independent known-class test performance",
        ),
        (
            "Test Macro-F1",
            pct(primary_metrics.get("f1_macro")),
            "Class-balanced independent test F1",
        ),
        (
            "Test Weighted-F1",
            pct(primary_metrics.get("f1_weighted")),
            "Support-weighted independent test F1",
        ),
        (
            "Open-set AUROC",
            pct(open_set_json.get("open_set_auroc")),
            "Known vs unknown discrimination",
        ),
        (
            "Known FPR",
            pct(open_set_json.get("known_fpr")),
            "Known traffic incorrectly rejected as unknown",
        ),
    ]

    metric_row(validation_items)

    if integrity_json.get("status") == "FAIL":
        st.warning(
            "Dataset integrity audit failed: exact feature duplicates cross the "
            "current train/validation/test boundaries and source filenames were "
            "truncated by the old preprocessor. Results are preliminary until the "
            "processed dataset is regenerated with the corrected pipeline."
        )

    st.subheader("Key Findings")

    col1, col2 = st.columns(2)

    with col1:
        st.markdown(
            f"""
**Proposed federated classification**

- Evaluation split: **{primary_split_label}**
- Accuracy: **{pct(primary_metrics.get("accuracy"))}**
- Macro-F1: **{pct(primary_metrics.get("f1_macro"))}**
- Weighted-F1: **{pct(primary_metrics.get("f1_weighted"))}**
- Selected-round validation loss: **{final_metrics.get("loss", float("nan")):.4f}**
"""
        )

    with col2:
        st.markdown(
            f"""
**Open-set detection**

- Method: **{open_set_json.get("method", "confidence threshold")}**
- Test samples: **{number(open_set_json.get("test_samples"))}**
- Unknown families: **{", ".join(open_set_json.get("unknown_families", UNKNOWN_FAMILIES))}**
- Unknown F1: **{pct(open_set_json.get("unknown_f1"))}**
- Open-set AUROC: **{pct(open_set_json.get("open_set_auroc"))}**
- Known FPR: **{pct(open_set_json.get("known_fpr"))}**
"""
        )

    st.subheader("Model Comparison")

    if comparison_df is not None and not comparison_df.empty:
        display_cols = [
            c for c in [
                "Method",
                "Accuracy",
                "Macro Precision",
                "Macro Recall",
                "Macro F1",
                "Weighted F1",
            ]
            if c in comparison_df.columns
        ]
        table = comparison_df[display_cols].copy()

        for col in display_cols:
            if col != "Method":
                table[col] = pd.to_numeric(table[col], errors="coerce") * 100

        st.dataframe(
            table.style.format(
                {
                    col: "{:.2f}%"
                    for col in display_cols
                    if col != "Method"
                }
            ),
            use_container_width=True,
            hide_index=True,
        )

    st.subheader("Publication Figures")

    col1, col2 = st.columns(2)
    with col1:
        show_image(
            PROPOSED_FIGURES / "verified_test_comparison.png",
            "Classification accuracy comparison",
        )
    with col2:
        show_image(
            PROPOSED_FIGURES / "verified_test_per_class_f1.png",
            "Classification Macro-F1 comparison",
        )


# ============================================================
# CLASSIFICATION
# ============================================================

elif page == "📊 Classification":

    st.header("📊 Classification Performance")

    st.caption(
        "Comparison of the four evaluated learning strategies using the "
        "stored Scenario-C experimental results."
    )

    if comparison_df is None or comparison_df.empty:
        st.warning("Classification comparison data is not available.")
    else:
        display = comparison_df.copy()

        metric_cols = [
            c for c in [
                "Accuracy",
                "Macro Precision",
                "Macro Recall",
                "Macro F1",
                "Weighted F1",
            ]
            if c in display.columns
        ]

        for col in metric_cols:
            display[col] = pd.to_numeric(display[col], errors="coerce") * 100

        st.dataframe(
            display.style.format(
                {col: "{:.2f}%" for col in metric_cols}
            ),
            use_container_width=True,
            hide_index=True,
        )

        download_df(
            display,
            "AEFL_OSIDS_classification_comparison.csv",
            "⬇️ Download classification table",
        )

    st.subheader("Classification Figures")

    show_image(
        PROPOSED_FIGURES / "verified_test_comparison.png",
        "Independent test comparison",
    )

    show_image(
        PROPOSED_FIGURES / "verified_test_per_class_f1.png",
        "Independent per-class F1 comparison",
    )

    show_image(
        PROPOSED_FIGURES / "proposed_training_convergence.png",
        "Proposed federated training convergence",
    )

    show_image(
        PROPOSED_FIGURES / "hybrid_open_set_comparison.png",
        "Hybrid open-set detector versus MSP confidence",
    )

    st.info(
        "Interpretation: accuracy and Weighted-F1 are influenced strongly by "
        "the dominant classes. Macro-F1 gives equal importance to each class "
        "and therefore exposes minority-class weaknesses."
    )


# ============================================================
# PER-CLASS
# ============================================================

elif page == "🎯 Per-Class Analysis":

    st.header("🎯 Known-Class Performance")

    st.caption(
        "Independent Scenario-C test evaluation restricted to the five known families."
    )

    if per_class_df is None or per_class_df.empty:
        st.warning(
            "Per-class results are not available. Run "
            "evaluation.generate_per_class_results first."
        )
    else:
        display = per_class_df.copy()

        for col in ["Precision", "Recall", "F1"]:
            if col in display.columns:
                values = pd.to_numeric(display[col], errors="coerce")
                display[col] = values * 100 if values.max() <= 1.5 else values

        st.dataframe(
            display.style.format(
                {
                    col: "{:.2f}%"
                    for col in ["Precision", "Recall", "F1"]
                    if col in display.columns
                }
            ),
            use_container_width=True,
            hide_index=True,
        )

        download_df(
            display,
            "AEFL_OSIDS_per_class_results.csv",
            "⬇️ Download per-class results",
        )

        st.subheader("Class-level observations")

        if "Class" in display.columns and "Recall" in display.columns:
            recall_series = display.set_index("Class")["Recall"]
            weakest = recall_series.idxmin()
            strongest = recall_series.idxmax()

            col1, col2 = st.columns(2)

            with col1:
                st.metric(
                    "Highest recall",
                    str(strongest),
                    f"{recall_series[strongest]:.2f}%",
                )

            with col2:
                st.metric(
                    "Lowest recall",
                    str(weakest),
                    f"{recall_series[weakest]:.2f}%",
                )

    show_image(
        PROPOSED_FIGURES / "verified_test_per_class_f1.png",
        "Verified independent-test per-class F1 scores",
    )

    show_image(
        PROPOSED_FIGURES / "proposed_test_confusion_matrix.png",
        "Proposed model independent-test confusion matrix",
    )

    st.warning(
        "The current test results show strong performance for DDoS and Mirai "
        "but substantially weaker recall for BENIGN and DoS. This is important "
        "to discuss rather than relying on accuracy alone."
    )


# ============================================================
# OPEN SET
# ============================================================

elif page == "🔓 Open-Set Detection":

    st.header("🔓 Open-Set / Unknown Intrusion Detection")

    threshold = (
        open_set_json.get("locked_threshold")
        or open_set_json.get("threshold")
        or 0.5699575841426849
    )

    metric_row(
        [
            (
                "Locked Threshold",
                f"{float(threshold):.6f}",
                "Calibrated open-set threshold",
            ),
            (
                "Unknown Precision",
                pct(open_set_json.get("unknown_precision")),
                "Precision of unknown predictions",
            ),
            (
                "Unknown Recall",
                pct(open_set_json.get("unknown_recall")),
                "Fraction of unknown traffic detected",
            ),
            (
                "Unknown F1",
                pct(open_set_json.get("unknown_f1")),
                "Unknown detection F1",
            ),
            (
                "AUROC",
                pct(open_set_json.get("open_set_auroc")),
                "Known/unknown discrimination",
            ),
        ]
    )

    st.subheader("Open-set Test Results")

    if open_set_df is not None and not open_set_df.empty:
        display = open_set_df.copy()
        percentage_columns = [
            name
            for name in [
                "Unknown Precision",
                "Unknown Recall",
                "Unknown F1",
                "Known FPR",
                "AUROC",
            ]
            if name in display.columns
        ]
        for name in percentage_columns:
            values = pd.to_numeric(display[name], errors="coerce")
            display[name] = values * 100 if values.max() <= 1.5 else values
        st.dataframe(
            display.style.format(
                {name: "{:.2f}%" for name in percentage_columns}
            ),
            use_container_width=True,
            hide_index=True,
        )
        download_df(
            display,
            "AEFL_OSIDS_open_set_results.csv",
            "⬇️ Download open-set results",
        )
    else:
        st.json(open_set_json)

    st.subheader("Threshold Analysis")

    if using_hybrid_open_set:
        st.success(
            "The rejection threshold is calibrated on known validation traffic "
            "only. Unknown test families are not used to fit the Isolation Forest, "
            "choose fusion weights, or select the threshold."
        )
        st.json(
            {
                "Target validation known FPR": open_set_json.get(
                    "target_validation_known_fpr"
                ),
                "Locked hybrid threshold": open_set_json.get("locked_threshold"),
                "Confidence weight": (
                    open_set_json.get("fusion_weights") or {}
                ).get("confidence"),
                "Anomaly weight": (
                    open_set_json.get("fusion_weights") or {}
                ).get("anomaly"),
                "Calibration uses unknown samples": open_set_json.get(
                    "calibration_uses_unknown_samples"
                ),
            }
        )
    elif threshold_df is not None and not threshold_df.empty:
        st.dataframe(
            threshold_df,
            use_container_width=True,
            hide_index=True,
        )
        download_df(
            threshold_df,
            "AEFL_OSIDS_threshold_analysis.csv",
            "⬇️ Download threshold analysis",
        )

    if using_hybrid_open_set:
        show_image(
            PROPOSED_FIGURES / "hybrid_open_set_comparison.png",
            "Hybrid detector versus the confidence-only baseline",
        )
    else:
        show_image(
            PAPER_RESULTS / "threshold_vs_f1.png",
            "Open-set threshold vs unknown detection F1",
        )
        show_image(
            PAPER_RESULTS / "threshold_vs_recall.png",
            "Open-set threshold vs unknown recall",
        )
        show_image(
            PAPER_RESULTS / "threshold_vs_known_fpr.png",
            "Open-set threshold vs known false-positive rate",
        )

    st.info(
        "Open-set evaluation uses the complete independent Scenario-C test set; "
        "classification metrics use its known-class subset. Validation is reserved "
        "for model selection and threshold calibration."
    )


# ============================================================
# UNKNOWN FAMILIES
# ============================================================

elif page == "🕵️ Unknown Families":

    st.header("🕵️ Unknown-Family Analysis")

    families = unknown_family_json.get(
        "unknown_families",
        UNKNOWN_FAMILIES,
    )

    metric_row(
        [
            (
                "Unknown Samples",
                number(unknown_family_json.get("unknown_samples")),
                "Total ground-truth unknown samples",
            ),
            (
                "Unknown Families",
                str(len(families)),
                "Held-out attack families",
            ),
            (
                "Threshold",
                f"{float(unknown_family_json.get('threshold', threshold if 'threshold' in locals() else 0.569958)):.6f}",
                "Locked threshold",
            ),
        ]
    )

    st.write(
        "**Unknown families:** "
        + ", ".join(families)
    )

    if unknown_family_df is not None and not unknown_family_df.empty:
        display = unknown_family_df.copy()

        st.dataframe(
            display,
            use_container_width=True,
            hide_index=True,
        )

        download_df(
            display,
            "AEFL_OSIDS_unknown_family_results.csv",
            "⬇️ Download unknown-family table",
        )
    else:
        family_records = unknown_family_json.get("family_performance", [])

        if family_records:
            display = pd.DataFrame(family_records)
            st.dataframe(
                display,
                use_container_width=True,
                hide_index=True,
            )

    show_image(
        PROPOSED_FIGURES / "hybrid_unknown_family_recall.png",
        "Hybrid unknown-family detection recall",
    )

    st.info(
        "Family-level recall should always be reported with aggregate unknown F1; "
        "it shows whether the detector generalizes consistently across held-out attacks."
    )


# ============================================================
# SHAP
# ============================================================

elif page == "🧠 SHAP Explainability":

    st.header("🧠 SHAP Explainability")

    shap_metadata = load_json(
        str(SHAP_RESULTS / "shap_metadata.json")
    ) or comparison_json.get("shap_configuration", {})

    metric_row(
        [
            (
                "Features",
                number(shap_metadata.get("feature_count", 39)),
                "Input feature count",
            ),
            (
                "Samples explained",
                number(
                    shap_metadata.get(
                        "samples_explained",
                        shap_metadata.get("explanation_samples", 100),
                    )
                ),
                "Samples used for SHAP",
            ),
            (
                "Background samples",
                number(
                    shap_metadata.get(
                        "background_samples",
                        50,
                    )
                ),
                "SHAP background set",
            ),
        ]
    )

    if shap_df is not None and not shap_df.empty:
        st.subheader("Global Feature Importance")

        st.dataframe(
            shap_df.head(20),
            use_container_width=True,
            hide_index=True,
        )

        download_df(
            shap_df,
            "AEFL_OSIDS_SHAP_global_importance.csv",
            "⬇️ Download SHAP importance",
        )

    show_image(
        SHAP_RESULTS / "global_shap_feature_importance.png",
        "Top global SHAP features",
    )

    summary_plot = SHAP_RESULTS / "shap_summary.png"
    show_image(
        summary_plot,
        "SHAP summary plot",
    )

    st.info(
        "SHAP explanations indicate feature attribution patterns for the "
        "trained model. They should be interpreted as model explanations, "
        "not as causal relationships."
    )


# ============================================================
# FEDERATED LEARNING
# ============================================================

elif page == "🔄 Federated Learning":

    st.header("🔄 Federated Learning Convergence")

    metric_row(
        [
            (
                "Clients",
                number(metadata.get("clients", 5)),
                "Federated clients",
            ),
            (
                "Rounds",
                number(metadata.get("rounds_completed", metadata.get("rounds", 5))),
                "Completed communication rounds",
            ),
            (
                "Local Epochs",
                number(metadata.get("local_epochs", 1)),
                "Local training epochs per round",
            ),
            (
                "Batch Size",
                number(metadata.get("batch_size", 512)),
                "Local training batch size",
            ),
            (
                "Learning Rate",
                str(metadata.get("learning_rate", 0.001)),
                "Optimizer learning rate",
            ),
        ]
    )

    st.subheader("Robust Non-IID Training Controls")
    st.dataframe(
        pd.DataFrame(
            [
                {"Control": "Class-balanced focal loss", "Value": f"gamma={metadata.get('focal_gamma', 1.5)}"},
                {"Control": "FedProx client-drift penalty", "Value": metadata.get("fedprox_mu", 0.0001)},
                {"Control": "Update norm clipping", "Value": f"median × {metadata.get('update_clip_factor', 2.5)}"},
                {"Control": "Maximum shared client weight", "Value": metadata.get("maximum_client_weight", 0.35)},
                {"Control": "Classifier aggregation", "Value": "per-class support + update reliability"},
                {"Control": "Model selection", "Value": "validation Macro-F1"},
            ]
        ),
        use_container_width=True,
        hide_index=True,
    )

    if convergence_df is not None and not convergence_df.empty:
        st.subheader("Round-wise Validation Results")

        display = convergence_df.copy()

        for col in [
            "Validation Accuracy",
            "Accuracy",
            "Macro F1",
            "Weighted F1",
        ]:
            if col in display.columns:
                display[col] = pd.to_numeric(
                    display[col], errors="coerce"
                ) * 100

        st.dataframe(
            display.style.format(
                {
                    col: "{:.2f}%"
                    for col in [
                        "Validation Accuracy",
                        "Accuracy",
                        "Macro F1",
                        "Weighted F1",
                    ]
                    if col in display.columns
                }
            ),
            use_container_width=True,
            hide_index=True,
        )

    show_image(
        PROPOSED_FIGURES / "proposed_training_convergence.png",
        "Validation convergence for the proposed federated model",
    )

    st.caption(
        f"Best round: {metadata.get('best_round', 'N/A')}; total simulated "
        f"communication: {float(metadata.get('total_communication_bytes', 0)) / 1_000_000:.2f} MB."
    )


# ============================================================
# RESEARCH RESULTS
# ============================================================

elif page == "📑 Research Results":

    st.header("📑 Publication Results")

    st.markdown(
        """
This page collects the files generated for the research paper. These are
derived from the existing experiment outputs and do not retrain the model.
"""
    )

    files = [
        ("Verified test comparison", RESULTS_ROOT / "verified_comparison" / "publication_test_comparison.csv"),
        ("Proposed per-class results", RESULTS_ROOT / "verified_comparison" / "proposed_per_class_test.csv"),
        ("Hybrid open-set comparison", HYBRID_OPEN_SET_RESULTS / "hybrid_vs_msp.csv"),
        ("Hybrid unknown-family results", HYBRID_OPEN_SET_RESULTS / "unknown_family_performance.csv"),
        ("Dataset integrity audit", RESULTS_ROOT / "data_integrity" / f"{SCENARIO}_audit.json"),
        ("Proposed training history", PROPOSED_RESULTS / "round_history.json"),
        ("Proposed-model SHAP importance", SHAP_RESULTS / "global_feature_importance.csv"),
        ("Reproducibility report", RESULTS_ROOT / "PROPOSED_RESULTS.md"),
    ]

    rows = []
    for label, path in files:
        rows.append(
            {
                "Artifact": label,
                "Status": "Available" if path.exists() else "Missing",
                "File": path.name,
            }
        )

    artifact_df = pd.DataFrame(rows)
    st.dataframe(
        artifact_df,
        use_container_width=True,
        hide_index=True,
    )

    summary = read_text(RESULTS_ROOT / "PROPOSED_RESULTS.md")

    if summary:
        st.subheader("Proposed Results Summary")
        st.markdown(summary)

    st.subheader("Verification")

    verification_summary = read_text(
        VERIFICATION_RESULTS / "final_results_verification.txt"
    )

    if verification_summary:
        st.text(verification_summary)
    else:
        st.info(
            "Verification summary text is not available. "
            "Run evaluation.verify_final_results to regenerate it."
        )


# ============================================================
# ABOUT
# ============================================================

elif page == "ℹ️ About Experiment":

    st.header("ℹ️ About AEFL-OSIDS")

    st.markdown(
        f"""
### Project

**AEFL-OSIDS — Adaptive Explainable Federated Learning with Open-Set
Intrusion Detection for IoT Networks**

### Current experiment

- Scenario: `scenario_C_multiple`
- Model: {MODEL_NAME}
- Input features: 39
- Federated clients: {metadata.get("clients", 5)}
- Completed federated rounds: {metadata.get("rounds_completed", 5)}
- Best round selected by validation Macro-F1: {metadata.get("best_round", "N/A")}
- Local epochs: {metadata.get("local_epochs", 1)}
- Training batch size: {metadata.get("batch_size", 512)}
- Learning rate: {metadata.get("learning_rate", 0.001)}
- Random seed: {metadata.get("seed", 42)}

### Proposed federated method

- Class-balanced focal loss for minority classes
- FedProx regularization for non-IID client drift
- Reliability-aware, capped client aggregation
- Median-based update clipping
- Per-class classifier aggregation using client class support

### Evaluation protocol

Validation selects the federated checkpoint and calibrates the open-set threshold.
The independent Scenario-C **test** partition is then used once for known-class
comparison and held-out-family detection.

This distinction is important when reporting the results in a research paper.

### Integrity status

Current status: **{integrity_json.get("status", "NOT RUN")}**. The included legacy
processed split contains exact cross-split feature duplicates and truncated source
metadata. The corrected preprocessing and audit code is included, but current
scores must be treated as **preliminary** until the raw dataset is regenerated and
the audit passes.

Accuracy must be reported together with Macro-F1, per-class recall, open-set
AUROC, unknown F1, and known FPR.
"""
    )

    st.divider()

    st.write("Project root:")
    st.code(str(PROJECT_ROOT))

    st.write("Model:")
    st.code(str(MODEL_PATH))
