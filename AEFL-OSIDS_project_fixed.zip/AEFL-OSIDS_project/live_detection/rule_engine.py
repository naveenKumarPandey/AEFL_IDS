"""
AEFL-OSIDS
Real-Time Rule-Based Network Analysis Engine

This module provides a lightweight rule-based layer that operates
alongside the Adaptive FedAvg v2 ML detector.

Pipeline:

    Live flow
       |
       +--------------------+
       |                    |
       v                    v
   ML Detector          Rule Engine
       |                    |
       +---------+----------+
                 |
                 v
          Hybrid Decision

The rule engine does NOT:
- train the ML model
- modify model weights
- modify the scaler
- modify stored experiment results
- capture packets

It only evaluates flow/network behavior.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any, Dict, List, Mapping, Optional

import numpy as np


# =====================================================================
# LOGGING
# =====================================================================

logger = logging.getLogger(
    __name__
)


# =====================================================================
# RULE CONFIGURATION
# =====================================================================

@dataclass(frozen=True)
class RuleConfig:
    """
    Thresholds used by the live rule engine.

    These are operational detection thresholds, NOT trained ML
    parameters.

    They can later be tuned using a dedicated validation experiment.
    """

    # ---------------------------------------------------------------
    # Traffic-rate rules
    # ---------------------------------------------------------------

    high_packet_rate: float = 1000.0

    very_high_packet_rate: float = 5000.0

    # ---------------------------------------------------------------
    # Flow-size rules
    # ---------------------------------------------------------------

    high_packet_count: int = 10000

    high_byte_count: float = 10_000_000.0

    # ---------------------------------------------------------------
    # SYN behavior
    # ---------------------------------------------------------------

    syn_count_threshold: int = 50

    syn_ratio_threshold: float = 0.80

    # ---------------------------------------------------------------
    # Reset behavior
    # ---------------------------------------------------------------

    rst_count_threshold: int = 50

    rst_ratio_threshold: float = 0.50

    # ---------------------------------------------------------------
    # Connection duration
    # ---------------------------------------------------------------

    short_flow_duration: float = 1.0

    # ---------------------------------------------------------------
    # Port-related rules
    # ---------------------------------------------------------------

    suspicious_destination_ports: tuple = (
        21,      # FTP
        23,      # Telnet
        445,     # SMB
        3389,    # RDP
        4444,    # common lab/test service
        5900,    # VNC
        8080,    # alternate HTTP
    )


# =====================================================================
# RULE RESULT
# =====================================================================

@dataclass
class RuleMatch:
    """
    Represents one triggered rule.
    """

    rule_id: str

    severity: str

    score: float

    message: str

    evidence: Dict[str, Any] = field(
        default_factory=dict
    )


# =====================================================================
# COMPLETE RULE ANALYSIS RESULT
# =====================================================================

@dataclass
class RuleAnalysisResult:
    """
    Result returned by the rule engine.
    """

    risk_score: float

    severity: str

    triggered_rules: List[RuleMatch]

    rule_count: int

    suspicious: bool

    intrusion: bool

    summary: str

    evidence: Dict[str, Any] = field(
        default_factory=dict
    )

    def to_dict(self) -> Dict[str, Any]:

        return {
            "risk_score":
                float(self.risk_score),

            "severity":
                self.severity,

            "rule_count":
                int(self.rule_count),

            "suspicious":
                bool(self.suspicious),

            "intrusion":
                bool(self.intrusion),

            "summary":
                self.summary,

            "triggered_rules": [
                {
                    "rule_id":
                        rule.rule_id,

                    "severity":
                        rule.severity,

                    "score":
                        float(rule.score),

                    "message":
                        rule.message,

                    "evidence":
                        rule.evidence,
                }
                for rule in self.triggered_rules
            ],

            "evidence":
                self.evidence,
        }


# =====================================================================
# RULE ENGINE
# =====================================================================

class RuleEngine:
    """
    Behavioral rule engine for live network flows.

    Each rule produces a bounded risk contribution.

    Final risk score:

        0   -> normal
        1-29 -> low
        30-59 -> medium
        60-79 -> high
        80-100 -> critical
    """

    def __init__(
        self,
        config: Optional[RuleConfig] = None,
    ) -> None:

        self.config = (
            config
            if config is not None
            else RuleConfig()
        )

        logger.info(
            "RuleEngine initialized."
        )

    # =================================================================
    # HELPERS
    # =================================================================

    @staticmethod
    def _number(
        flow: Mapping[str, Any],
        *names: str,
        default: float = 0.0,
    ) -> float:

        for name in names:

            if name not in flow:
                continue

            try:

                value = float(
                    flow[name]
                )

                if np.isfinite(value):
                    return value

            except (
                TypeError,
                ValueError,
            ):

                continue

        return float(default)

    @staticmethod
    def _integer(
        flow: Mapping[str, Any],
        *names: str,
        default: int = 0,
    ) -> int:

        value = RuleEngine._number(
            flow,
            *names,
            default=float(default),
        )

        return int(value)

    @staticmethod
    def _text(
        flow: Mapping[str, Any],
        *names: str,
        default: str = "",
    ) -> str:

        for name in names:

            if name in flow:

                value = flow[name]

                if value is not None:

                    return str(value)

        return default

    # =================================================================
    # FLOW STATISTICS
    # =================================================================

    def _extract_statistics(
        self,
        flow: Mapping[str, Any],
    ) -> Dict[str, Any]:

        packets = max(
            self._integer(
                flow,
                "packets",
                "packet_count",
                "Number",
            ),
            0,
        )

        bytes_count = max(
            self._number(
                flow,
                "bytes",
                "byte_count",
                "total_bytes",
                "Tot size",
            ),
            0.0,
        )

        duration = max(
            self._number(
                flow,
                "duration",
                "flow_duration",
                "Duration",
            ),
            0.0,
        )

        packet_rate = self._number(
            flow,
            "packet_rate",
            "packets_per_second",
            "Rate",
            "rate",
            default=(
                packets / duration
                if duration > 0
                else 0.0
            ),
        )

        syn_count = max(
            self._integer(
                flow,
                "syn_count",
                "SYN_count",
            ),
            0,
        )

        ack_count = max(
            self._integer(
                flow,
                "ack_count",
                "ACK_count",
            ),
            0,
        )

        fin_count = max(
            self._integer(
                flow,
                "fin_count",
                "FIN_count",
            ),
            0,
        )

        rst_count = max(
            self._integer(
                flow,
                "rst_count",
                "RST_count",
            ),
            0,
        )

        dst_port = self._integer(
            flow,
            "dst_port",
            "destination_port",
            "dport",
            default=0,
        )

        src_port = self._integer(
            flow,
            "src_port",
            "source_port",
            "sport",
            default=0,
        )

        protocol = self._integer(
            flow,
            "protocol",
            "protocol_type",
            "Protocol Type",
            default=0,
        )

        return {
            "packets":
                packets,

            "bytes":
                bytes_count,

            "duration":
                duration,

            "packet_rate":
                packet_rate,

            "syn_count":
                syn_count,

            "ack_count":
                ack_count,

            "fin_count":
                fin_count,

            "rst_count":
                rst_count,

            "dst_port":
                dst_port,

            "src_port":
                src_port,

            "protocol":
                protocol,
        }

    # =================================================================
    # RULE: HIGH PACKET RATE
    # =================================================================

    def _rule_high_packet_rate(
        self,
        stats: Mapping[str, Any],
    ) -> Optional[RuleMatch]:

        rate = float(
            stats["packet_rate"]
        )

        if rate < self.config.high_packet_rate:
            return None

        if (
            rate
            >= self.config.very_high_packet_rate
        ):

            return RuleMatch(
                rule_id="RATE_CRITICAL",
                severity="critical",
                score=30.0,
                message=(
                    "Extremely high packet rate "
                    "detected."
                ),
                evidence={
                    "packet_rate":
                        rate,
                    "threshold":
                        self.config
                        .very_high_packet_rate,
                },
            )

        return RuleMatch(
            rule_id="RATE_HIGH",
            severity="high",
            score=20.0,
            message=(
                "High packet rate detected."
            ),
            evidence={
                "packet_rate":
                    rate,
                "threshold":
                    self.config.high_packet_rate,
            },
        )

    # =================================================================
    # RULE: LARGE FLOW
    # =================================================================

    def _rule_large_flow(
        self,
        stats: Mapping[str, Any],
    ) -> Optional[RuleMatch]:

        packets = int(
            stats["packets"]
        )

        bytes_count = float(
            stats["bytes"]
        )

        if (
            packets
            >= self.config.high_packet_count
            and
            bytes_count
            >= self.config.high_byte_count
        ):

            return RuleMatch(
                rule_id="LARGE_FLOW",
                severity="high",
                score=15.0,
                message=(
                    "Unusually large flow "
                    "detected."
                ),
                evidence={
                    "packets":
                        packets,
                    "bytes":
                        bytes_count,
                },
            )

        return None

    # =================================================================
    # RULE: SYN FLOOD / SYN HEAVY
    # =================================================================

    def _rule_syn_behavior(
        self,
        stats: Mapping[str, Any],
    ) -> Optional[RuleMatch]:

        packets = int(
            stats["packets"]
        )

        syn_count = int(
            stats["syn_count"]
        )

        if packets <= 0:
            return None

        syn_ratio = (
            syn_count / packets
        )

        if (
            syn_count
            >= self.config.syn_count_threshold
            and
            syn_ratio
            >= self.config.syn_ratio_threshold
        ):

            return RuleMatch(
                rule_id="SYN_FLOOD_PATTERN",
                severity="critical",
                score=35.0,
                message=(
                    "SYN-dominant traffic pattern "
                    "detected."
                ),
                evidence={
                    "packets":
                        packets,
                    "syn_count":
                        syn_count,
                    "syn_ratio":
                        syn_ratio,
                },
            )

        if (
            syn_count
            >= self.config.syn_count_threshold
        ):

            return RuleMatch(
                rule_id="SYN_HEAVY",
                severity="medium",
                score=15.0,
                message=(
                    "High SYN activity detected."
                ),
                evidence={
                    "packets":
                        packets,
                    "syn_count":
                        syn_count,
                    "syn_ratio":
                        syn_ratio,
                },
            )

        return None

    # =================================================================
    # RULE: RESET HEAVY
    # =================================================================

    def _rule_rst_behavior(
        self,
        stats: Mapping[str, Any],
    ) -> Optional[RuleMatch]:

        packets = int(
            stats["packets"]
        )

        rst_count = int(
            stats["rst_count"]
        )

        if packets <= 0:
            return None

        rst_ratio = (
            rst_count / packets
        )

        if (
            rst_count
            >= self.config.rst_count_threshold
            and
            rst_ratio
            >= self.config.rst_ratio_threshold
        ):

            return RuleMatch(
                rule_id="RST_HEAVY",
                severity="high",
                score=20.0,
                message=(
                    "RST-dominant traffic pattern "
                    "detected."
                ),
                evidence={
                    "packets":
                        packets,
                    "rst_count":
                        rst_count,
                    "rst_ratio":
                        rst_ratio,
                },
            )

        return None

    # =================================================================
    # RULE: SHORT SYN FLOW
    # =================================================================

    def _rule_short_syn_flow(
        self,
        stats: Mapping[str, Any],
    ) -> Optional[RuleMatch]:

        duration = float(
            stats["duration"]
        )

        syn_count = int(
            stats["syn_count"]
        )

        if (
            duration
            <= self.config.short_flow_duration
            and
            syn_count
            > 0
        ):

            return RuleMatch(
                rule_id="SHORT_SYN_FLOW",
                severity="medium",
                score=10.0,
                message=(
                    "Short-lived flow with "
                    "SYN activity detected."
                ),
                evidence={
                    "duration":
                        duration,
                    "syn_count":
                        syn_count,
                },
            )

        return None

    # =================================================================
    # RULE: SUSPICIOUS DESTINATION PORT
    # =================================================================

    def _rule_destination_port(
        self,
        stats: Mapping[str, Any],
    ) -> Optional[RuleMatch]:

        dst_port = int(
            stats["dst_port"]
        )

        if dst_port not in (
            self.config
            .suspicious_destination_ports
        ):

            return None

        return RuleMatch(
            rule_id="SUSPICIOUS_SERVICE_PORT",
            severity="low",
            score=5.0,
            message=(
                "Traffic targets a monitored "
                "service port."
            ),
            evidence={
                "destination_port":
                    dst_port,
            },
        )

    # =================================================================
    # RULE: HIGH RATE + SYN
    # =================================================================

    def _rule_rate_syn_combination(
        self,
        stats: Mapping[str, Any],
    ) -> Optional[RuleMatch]:

        rate = float(
            stats["packet_rate"]
        )

        packets = int(
            stats["packets"]
        )

        syn_count = int(
            stats["syn_count"]
        )

        if packets <= 0:
            return None

        syn_ratio = (
            syn_count / packets
        )

        if (
            rate
            >= self.config.high_packet_rate
            and
            syn_ratio
            >= 0.50
        ):

            return RuleMatch(
                rule_id="HIGH_RATE_SYN_COMBINATION",
                severity="critical",
                score=30.0,
                message=(
                    "High-rate traffic combined "
                    "with strong SYN activity."
                ),
                evidence={
                    "packet_rate":
                        rate,
                    "syn_ratio":
                        syn_ratio,
                },
            )

        return None

    # =================================================================
    # ANALYZE
    # =================================================================

    def analyze(
        self,
        flow: Mapping[str, Any],
    ) -> RuleAnalysisResult:
        """
        Analyze one flow.

        Returns a RuleAnalysisResult.
        """

        stats = self._extract_statistics(
            flow
        )

        matches: List[
            RuleMatch
        ] = []

        rules = [
            self._rule_high_packet_rate,
            self._rule_large_flow,
            self._rule_syn_behavior,
            self._rule_rst_behavior,
            self._rule_short_syn_flow,
            self._rule_destination_port,
            self._rule_rate_syn_combination,
        ]

        for rule in rules:

            try:

                match = rule(
                    stats
                )

                if match is not None:
                    matches.append(match)

            except Exception as exc:

                logger.warning(
                    "Rule evaluation failed: %s",
                    exc,
                )

        # -------------------------------------------------------------
        # Risk score
        # -------------------------------------------------------------

        raw_score = sum(
            match.score
            for match in matches
        )

        risk_score = min(
            100.0,
            float(raw_score),
        )

        # -------------------------------------------------------------
        # Severity
        # -------------------------------------------------------------

        if risk_score >= 80:

            severity = "critical"

        elif risk_score >= 60:

            severity = "high"

        elif risk_score >= 30:

            severity = "medium"

        elif risk_score > 0:

            severity = "low"

        else:

            severity = "normal"

        suspicious = (
            risk_score >= 30
        )

        intrusion = (
            risk_score >= 60
        )

        if not matches:

            summary = (
                "No rule-based anomaly detected."
            )

        else:

            summary = (
                f"{len(matches)} rule(s) triggered; "
                f"risk score {risk_score:.1f}/100."
            )

        evidence = {
            "packets":
                stats["packets"],

            "bytes":
                stats["bytes"],

            "duration":
                stats["duration"],

            "packet_rate":
                stats["packet_rate"],

            "syn_count":
                stats["syn_count"],

            "ack_count":
                stats["ack_count"],

            "fin_count":
                stats["fin_count"],

            "rst_count":
                stats["rst_count"],

            "source_port":
                stats["src_port"],

            "destination_port":
                stats["dst_port"],

            "protocol":
                stats["protocol"],
        }

        return RuleAnalysisResult(
            risk_score=risk_score,

            severity=severity,

            triggered_rules=matches,

            rule_count=len(matches),

            suspicious=suspicious,

            intrusion=intrusion,

            summary=summary,

            evidence=evidence,
        )


# =====================================================================
# CONVENIENCE API
# =====================================================================

_default_engine: Optional[
    RuleEngine
] = None


def get_rule_engine() -> RuleEngine:

    global _default_engine

    if _default_engine is None:

        _default_engine = RuleEngine()

    return _default_engine


def analyze_live_flow(
    flow: Mapping[str, Any],
) -> RuleAnalysisResult:

    return get_rule_engine().analyze(
        flow
    )


# =====================================================================
# SELF TEST
# =====================================================================

def _normal_test_flow() -> Dict[str, Any]:

    return {
        "src_ip":
            "192.168.1.10",

        "dst_ip":
            "192.168.1.20",

        "src_port":
            50000,

        "dst_port":
            80,

        "protocol":
            6,

        "packets":
            3,

        "bytes":
            300,

        "duration":
            0.2,

        "packet_rate":
            15.0,

        "syn_count":
            1,

        "ack_count":
            2,

        "fin_count":
            0,

        "rst_count":
            0,
    }


def _suspicious_test_flow() -> Dict[str, Any]:

    return {
        "src_ip":
            "10.0.0.50",

        "dst_ip":
            "10.0.0.10",

        "src_port":
            45000,

        "dst_port":
            80,

        "protocol":
            6,

        "packets":
            100,

        "bytes":
            10000,

        "duration":
            0.1,

        "packet_rate":
            1000.0,

        "syn_count":
            95,

        "ack_count":
            2,

        "fin_count":
            0,

        "rst_count":
            0,
    }


def main() -> None:

    logging.basicConfig(
        level=logging.INFO,
        format=(
            "%(asctime)s - "
            "%(levelname)s - "
            "%(message)s"
        ),
    )

    print("=" * 70)
    print(
        "AEFL-OSIDS RULE ENGINE TEST"
    )
    print("=" * 70)

    engine = RuleEngine()

    # ---------------------------------------------------------------
    # Normal flow
    # ---------------------------------------------------------------

    print()
    print(
        "Testing normal flow..."
    )

    normal_result = engine.analyze(
        _normal_test_flow()
    )

    print(
        f"Risk score : "
        f"{normal_result.risk_score:.1f}/100"
    )

    print(
        f"Severity   : "
        f"{normal_result.severity}"
    )

    print(
        f"Rules      : "
        f"{normal_result.rule_count}"
    )

    print(
        f"Suspicious : "
        f"{normal_result.suspicious}"
    )

    # ---------------------------------------------------------------
    # Suspicious flow
    # ---------------------------------------------------------------

    print()
    print(
        "Testing suspicious flow..."
    )

    suspicious_result = engine.analyze(
        _suspicious_test_flow()
    )

    print(
        f"Risk score : "
        f"{suspicious_result.risk_score:.1f}/100"
    )

    print(
        f"Severity   : "
        f"{suspicious_result.severity}"
    )

    print(
        f"Rules      : "
        f"{suspicious_result.rule_count}"
    )

    print(
        f"Suspicious : "
        f"{suspicious_result.suspicious}"
    )

    print(
        f"Intrusion  : "
        f"{suspicious_result.intrusion}"
    )

    print()
    print(
        "Triggered rules:"
    )

    for rule in (
        suspicious_result.triggered_rules
    ):

        print(
            f"  [{rule.severity.upper():8}] "
            f"{rule.rule_id:<30} "
            f"+{rule.score:.1f}"
        )

        print(
            f"      {rule.message}"
        )

    # ---------------------------------------------------------------
    # Assertions
    # ---------------------------------------------------------------

    if normal_result.rule_count < 0:

        raise RuntimeError(
            "Invalid normal-flow result."
        )

    if not suspicious_result.suspicious:

        raise RuntimeError(
            "Suspicious test flow was not detected."
        )

    if suspicious_result.risk_score <= 0:

        raise RuntimeError(
            "Suspicious test flow produced "
            "zero risk."
        )

    print()
    print("=" * 70)
    print(
        "RULE ENGINE TEST SUCCESSFUL"
    )
    print("=" * 70)


if __name__ == "__main__":
    main()