"""
AEFL-OSIDS
Real-Time Hybrid ML + Rule-Based Intrusion Detector

Combines:

    Adaptive FedAvg v2 ML detector
              +
    Rule-based network analysis
              |
              v
       Hybrid risk assessment
              |
              v
    BENIGN / SUSPICIOUS / INTRUSION / UNKNOWN

This module does NOT:
- retrain the ML model
- modify model weights
- modify the scaler
- modify stored research results
- capture packets
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Any, Dict, Mapping, Optional

from live_detection.ml_detector import (
    MLDetector,
)

from live_detection.rule_engine import (
    RuleEngine,
    RuleAnalysisResult,
)


# =====================================================================
# LOGGING
# =====================================================================

logger = logging.getLogger(
    __name__
)


# =====================================================================
# HYBRID CONFIGURATION
# =====================================================================

@dataclass(frozen=True)
class HybridConfig:
    """
    Configuration for combining ML and rule-based evidence.

    ML confidence is converted into a suspiciousness contribution
    only when the ML model predicts UNKNOWN.

    Rule risk is independently calculated by RuleEngine.
    """

    # ---------------------------------------------------------------
    # Rule-risk contribution
    # ---------------------------------------------------------------

    rule_weight: float = 0.60

    # ---------------------------------------------------------------
    # ML contribution
    # ---------------------------------------------------------------

    ml_weight: float = 0.40

    # ---------------------------------------------------------------
    # Final decision thresholds
    # ---------------------------------------------------------------

    suspicious_threshold: float = 30.0

    intrusion_threshold: float = 60.0

    # ---------------------------------------------------------------
    # UNKNOWN handling
    # ---------------------------------------------------------------

    unknown_min_risk: float = 30.0

    # ---------------------------------------------------------------
    # Strong ML intrusion confidence
    # ---------------------------------------------------------------

    high_ml_confidence: float = 0.85


# =====================================================================
# RESULT
# =====================================================================

@dataclass
class HybridDetectionResult:
    """
    Final result produced by the hybrid detector.
    """

    decision: str

    risk_score: float

    ml_class: str

    ml_confidence: float

    ml_unknown: bool

    rule_risk_score: float

    rule_severity: str

    rule_count: int

    explanation: str

    ml_result: Dict[str, Any]

    rule_result: Dict[str, Any]

    def to_dict(
        self,
    ) -> Dict[str, Any]:

        return {
            "decision":
                self.decision,

            "risk_score":
                float(self.risk_score),

            "ml_class":
                self.ml_class,

            "ml_confidence":
                float(self.ml_confidence),

            "ml_unknown":
                bool(self.ml_unknown),

            "rule_risk_score":
                float(
                    self.rule_risk_score
                ),

            "rule_severity":
                self.rule_severity,

            "rule_count":
                int(self.rule_count),

            "explanation":
                self.explanation,

            "ml_result":
                self.ml_result,

            "rule_result":
                self.rule_result,
        }


# =====================================================================
# HYBRID DETECTOR
# =====================================================================

class HybridDetector:
    """
    Combines Adaptive FedAvg v2 ML predictions with behavioral rules.
    """

    def __init__(
        self,
        ml_detector: Optional[
            MLDetector
        ] = None,
        rule_engine: Optional[
            RuleEngine
        ] = None,
        config: Optional[
            HybridConfig
        ] = None,
    ) -> None:

        self.config = (
            config
            if config is not None
            else HybridConfig()
        )

        self.ml_detector = (
            ml_detector
            if ml_detector is not None
            else MLDetector()
        )

        self.rule_engine = (
            rule_engine
            if rule_engine is not None
            else RuleEngine()
        )

        self._validate_config()

        logger.info(
            "HybridDetector initialized."
        )

    # =================================================================
    # CONFIG VALIDATION
    # =================================================================

    def _validate_config(
        self,
    ) -> None:

        if self.config.ml_weight < 0:

            raise ValueError(
                "ml_weight cannot be negative."
            )

        if self.config.rule_weight < 0:

            raise ValueError(
                "rule_weight cannot be negative."
            )

        total = (
            self.config.ml_weight
            + self.config.rule_weight
        )

        if total <= 0:

            raise ValueError(
                "ML and rule weights cannot both be zero."
            )

        if (
            self.config.suspicious_threshold
            < 0
        ):

            raise ValueError(
                "Invalid suspicious threshold."
            )

        if (
            self.config.intrusion_threshold
            < self.config.suspicious_threshold
        ):

            raise ValueError(
                "Intrusion threshold must be "
                "greater than suspicious threshold."
            )

    # =================================================================
    # NORMALIZE WEIGHTS
    # =================================================================

    def _normalized_weights(
        self,
    ) -> tuple[float, float]:

        total = (
            self.config.ml_weight
            + self.config.rule_weight
        )

        return (
            self.config.ml_weight / total,
            self.config.rule_weight / total,
        )

    # =================================================================
    # ML RISK
    # =================================================================

    def _calculate_ml_risk(
        self,
        ml_result: Mapping[str, Any],
    ) -> float:
        """
        Convert ML evidence to a 0-100 risk contribution.

        Design:

        Known class:
            BENIGN -> 0
            Attack class -> confidence * 100

        UNKNOWN:
            uncertainty itself does not automatically mean attack.
            It contributes a moderate risk proportional to confidence.
        """

        predicted_class = str(
            ml_result.get(
                "predicted_class",
                "UNKNOWN",
            )
        )

        confidence = float(
            ml_result.get(
                "confidence",
                0.0,
            )
        )

        confidence = max(
            0.0,
            min(
                1.0,
                confidence,
            ),
        )

        is_unknown = bool(
            ml_result.get(
                "is_unknown",
                False,
            )
        )

        # -------------------------------------------------------------
        # BENIGN prediction
        # -------------------------------------------------------------

        if (
            predicted_class
            == "BENIGN"
            and not is_unknown
        ):

            return 0.0

        # -------------------------------------------------------------
        # UNKNOWN prediction
        # -------------------------------------------------------------

        if is_unknown:

            # Unknown traffic is suspicious, but it should not
            # automatically be considered an intrusion.
            return min(
                60.0,
                confidence * 100.0,
            )

        # -------------------------------------------------------------
        # Known attack class
        # -------------------------------------------------------------

        return min(
            100.0,
            confidence * 100.0,
        )

    # =================================================================
    # COMBINE EVIDENCE
    # =================================================================

    def _calculate_hybrid_risk(
        self,
        ml_risk: float,
        rule_risk: float,
    ) -> float:

        ml_weight, rule_weight = (
            self._normalized_weights()
        )

        risk = (
            ml_weight * ml_risk
            +
            rule_weight * rule_risk
        )

        return max(
            0.0,
            min(
                100.0,
                float(risk),
            ),
        )

    # =================================================================
    # DECISION
    # =================================================================

    def _make_decision(
        self,
        risk_score: float,
        ml_result: Mapping[str, Any],
        rule_result: RuleAnalysisResult,
    ) -> str:

        ml_class = str(
            ml_result.get(
                "predicted_class",
                "UNKNOWN",
            )
        )

        ml_confidence = float(
            ml_result.get(
                "confidence",
                0.0,
            )
        )

        ml_unknown = bool(
            ml_result.get(
                "is_unknown",
                False,
            )
        )

        # -------------------------------------------------------------
        # Critical rule evidence always has priority.
        # -------------------------------------------------------------

        if (
            rule_result.intrusion
        ):

            return "INTRUSION"

        # -------------------------------------------------------------
        # Strong ML attack prediction combined with at least some
        # behavioral evidence.
        # -------------------------------------------------------------

        if (
            ml_class != "BENIGN"
            and not ml_unknown
            and
            ml_confidence
            >= self.config.high_ml_confidence
            and
            rule_result.rule_count > 0
        ):

            return "INTRUSION"

        # -------------------------------------------------------------
        # Hybrid risk threshold.
        # -------------------------------------------------------------

        if (
            risk_score
            >= self.config.intrusion_threshold
        ):

            return "INTRUSION"

        # -------------------------------------------------------------
        # UNKNOWN traffic.
        #
        # Unknown by itself is not automatically intrusion.
        # -------------------------------------------------------------

        if ml_unknown:

            if (
                risk_score
                >= self.config.unknown_min_risk
            ):

                return "UNKNOWN"

            return "UNKNOWN"

        # -------------------------------------------------------------
        # Suspicious threshold.
        # -------------------------------------------------------------

        if (
            risk_score
            >= self.config.suspicious_threshold
        ):

            return "SUSPICIOUS"

        # -------------------------------------------------------------
        # Known attack prediction, even with relatively low confidence.
        # -------------------------------------------------------------

        if (
            ml_class != "BENIGN"
            and not ml_unknown
        ):

            return "SUSPICIOUS"

        return "BENIGN"

    # =================================================================
    # EXPLANATION
    # =================================================================

    @staticmethod
    def _build_explanation(
        decision: str,
        ml_result: Mapping[str, Any],
        rule_result: RuleAnalysisResult,
        risk_score: float,
    ) -> str:

        ml_class = str(
            ml_result.get(
                "predicted_class",
                "UNKNOWN",
            )
        )

        confidence = float(
            ml_result.get(
                "confidence",
                0.0,
            )
        )

        rule_count = (
            rule_result.rule_count
        )

        rule_risk = (
            rule_result.risk_score
        )

        if rule_count > 0:

            rule_text = (
                f"{rule_count} rule(s) triggered "
                f"with rule risk {rule_risk:.1f}/100"
            )

        else:

            rule_text = (
                "no behavioral rules triggered"
            )

        return (
            f"Decision={decision}; "
            f"ML={ml_class} "
            f"(confidence={confidence:.3f}); "
            f"{rule_text}; "
            f"hybrid risk={risk_score:.1f}/100."
        )

    # =================================================================
    # ANALYZE FLOW
    # =================================================================

    def analyze_flow(
        self,
        flow: Mapping[str, Any],
    ) -> HybridDetectionResult:
        """
        Run both ML and rule-based detection on one flow.
        """

        # -------------------------------------------------------------
        # Rule analysis
        # -------------------------------------------------------------

        rule_result = (
            self.rule_engine.analyze(
                flow
            )
        )

        # -------------------------------------------------------------
        # ML analysis
        #
        # MLDetector.predict_flow() uses the existing 39-feature
        # live feature builder.
        # -------------------------------------------------------------

        ml_result = (
            self.ml_detector.predict_flow(
                flow
            )
        )

        # -------------------------------------------------------------
        # ML risk
        # -------------------------------------------------------------

        ml_risk = (
            self._calculate_ml_risk(
                ml_result
            )
        )

        # -------------------------------------------------------------
        # Hybrid risk
        # -------------------------------------------------------------

        hybrid_risk = (
            self._calculate_hybrid_risk(
                ml_risk,
                rule_result.risk_score,
            )
        )

        # -------------------------------------------------------------
        # Final decision
        # -------------------------------------------------------------

        decision = (
            self._make_decision(
                hybrid_risk,
                ml_result,
                rule_result,
            )
        )

        explanation = (
            self._build_explanation(
                decision,
                ml_result,
                rule_result,
                hybrid_risk,
            )
        )

        return HybridDetectionResult(
            decision=decision,

            risk_score=hybrid_risk,

            ml_class=str(
                ml_result.get(
                    "predicted_class",
                    "UNKNOWN",
                )
            ),

            ml_confidence=float(
                ml_result.get(
                    "confidence",
                    0.0,
                )
            ),

            ml_unknown=bool(
                ml_result.get(
                    "is_unknown",
                    False,
                )
            ),

            rule_risk_score=float(
                rule_result.risk_score
            ),

            rule_severity=(
                rule_result.severity
            ),

            rule_count=int(
                rule_result.rule_count
            ),

            explanation=explanation,

            ml_result=dict(
                ml_result
            ),

            rule_result=(
                rule_result.to_dict()
            ),
        )

    # =================================================================
    # ANALYZE FLOW FROM FEATURES
    # =================================================================

    def analyze_features(
        self,
        features: Any,
        flow: Optional[
            Mapping[str, Any]
        ] = None,
    ) -> HybridDetectionResult:
        """
        Analyze an already-created 39-feature vector.

        Rule analysis still requires flow statistics. If no flow is
        provided, a minimal flow is constructed from the feature
        vector where possible.
        """

        if flow is None:

            flow = {}

        # -------------------------------------------------------------
        # ML inference directly from 39 features.
        # -------------------------------------------------------------

        ml_result = (
            self.ml_detector.predict(
                features
            )
        )

        # -------------------------------------------------------------
        # Rule analysis.
        # -------------------------------------------------------------

        rule_result = (
            self.rule_engine.analyze(
                flow
            )
        )

        ml_risk = (
            self._calculate_ml_risk(
                ml_result
            )
        )

        hybrid_risk = (
            self._calculate_hybrid_risk(
                ml_risk,
                rule_result.risk_score,
            )
        )

        decision = (
            self._make_decision(
                hybrid_risk,
                ml_result,
                rule_result,
            )
        )

        explanation = (
            self._build_explanation(
                decision,
                ml_result,
                rule_result,
                hybrid_risk,
            )
        )

        return HybridDetectionResult(
            decision=decision,

            risk_score=hybrid_risk,

            ml_class=str(
                ml_result.get(
                    "predicted_class",
                    "UNKNOWN",
                )
            ),

            ml_confidence=float(
                ml_result.get(
                    "confidence",
                    0.0,
                )
            ),

            ml_unknown=bool(
                ml_result.get(
                    "is_unknown",
                    False,
                )
            ),

            rule_risk_score=float(
                rule_result.risk_score
            ),

            rule_severity=(
                rule_result.severity
            ),

            rule_count=int(
                rule_result.rule_count
            ),

            explanation=explanation,

            ml_result=dict(
                ml_result
            ),

            rule_result=(
                rule_result.to_dict()
            ),
        )


# =====================================================================
# CONVENIENCE API
# =====================================================================

_default_hybrid_detector: Optional[
    HybridDetector
] = None


def get_hybrid_detector() -> HybridDetector:

    global _default_hybrid_detector

    if (
        _default_hybrid_detector
        is None
    ):

        _default_hybrid_detector = (
            HybridDetector()
        )

    return _default_hybrid_detector


def detect_live_flow(
    flow: Mapping[str, Any],
) -> HybridDetectionResult:

    return (
        get_hybrid_detector()
        .analyze_flow(
            flow
        )
    )


# =====================================================================
# TEST FLOWS
# =====================================================================

def _normal_flow() -> Dict[str, Any]:

    return {
        "src_ip":
            "192.168.1.10",

        "dst_ip":
            "192.168.1.20",

        "src_port":
            50000,

        "dst_port":
            80,

        "protocol":
            6,

        "packets":
            3,

        "bytes":
            300,

        "duration":
            0.2,

        "packet_rate":
            15.0,

        "syn_count":
            1,

        "ack_count":
            2,

        "fin_count":
            0,

        "rst_count":
            0,
    }


def _attack_like_flow() -> Dict[str, Any]:

    return {
        "src_ip":
            "10.0.0.50",

        "dst_ip":
            "10.0.0.10",

        "src_port":
            45000,

        "dst_port":
            80,

        "protocol":
            6,

        "packets":
            100,

        "bytes":
            10000,

        "duration":
            0.1,

        "packet_rate":
            1000.0,

        "syn_count":
            95,

        "ack_count":
            2,

        "fin_count":
            0,

        "rst_count":
            0,
    }


# =====================================================================
# SELF TEST
# =====================================================================

def main() -> None:

    logging.basicConfig(
        level=logging.INFO,
        format=(
            "%(asctime)s - "
            "%(levelname)s - "
            "%(message)s"
        ),
    )

    print("=" * 70)
    print(
        "AEFL-OSIDS HYBRID DETECTOR TEST"
    )
    print("=" * 70)

    print()
    print(
        "Initializing ML + Rule engines..."
    )

    detector = HybridDetector()

    # ---------------------------------------------------------------
    # Configuration
    # ---------------------------------------------------------------

    ml_weight, rule_weight = (
        detector._normalized_weights()
    )

    print()
    print(
        "Hybrid configuration:"
    )

    print(
        f"  ML weight       : "
        f"{ml_weight:.2f}"
    )

    print(
        f"  Rule weight     : "
        f"{rule_weight:.2f}"
    )

    print(
        f"  Suspicious at   : "
        f"{detector.config.suspicious_threshold:.1f}"
    )

    print(
        f"  Intrusion at   : "
        f"{detector.config.intrusion_threshold:.1f}"
    )

    # ---------------------------------------------------------------
    # Normal flow
    # ---------------------------------------------------------------

    print()
    print(
        "Testing normal flow..."
    )

    normal_result = (
        detector.analyze_flow(
            _normal_flow()
        )
    )

    print()
    print(
        "NORMAL FLOW RESULT"
    )
    print("-" * 70)

    print(
        f"Decision       : "
        f"{normal_result.decision}"
    )

    print(
        f"Hybrid risk    : "
        f"{normal_result.risk_score:.2f}/100"
    )

    print(
        f"ML class       : "
        f"{normal_result.ml_class}"
    )

    print(
        f"ML confidence  : "
        f"{normal_result.ml_confidence:.4f}"
    )

    print(
        f"Rule risk      : "
        f"{normal_result.rule_risk_score:.2f}/100"
    )

    print(
        f"Rule count     : "
        f"{normal_result.rule_count}"
    )

    print(
        f"Explanation    : "
        f"{normal_result.explanation}"
    )

    # ---------------------------------------------------------------
    # Attack-like flow
    # ---------------------------------------------------------------

    print()
    print(
        "Testing attack-like flow..."
    )

    attack_result = (
        detector.analyze_flow(
            _attack_like_flow()
        )
    )

    print()
    print(
        "ATTACK-LIKE FLOW RESULT"
    )
    print("-" * 70)

    print(
        f"Decision       : "
        f"{attack_result.decision}"
    )

    print(
        f"Hybrid risk    : "
        f"{attack_result.risk_score:.2f}/100"
    )

    print(
        f"ML class       : "
        f"{attack_result.ml_class}"
    )

    print(
        f"ML confidence  : "
        f"{attack_result.ml_confidence:.4f}"
    )

    print(
        f"Rule risk      : "
        f"{attack_result.rule_risk_score:.2f}/100"
    )

    print(
        f"Rule count     : "
        f"{attack_result.rule_count}"
    )

    print(
        f"Explanation    : "
        f"{attack_result.explanation}"
    )

    print()
    print(
        "Triggered rules:"
    )

    for rule in (
        attack_result.rule_result[
            "triggered_rules"
        ]
    ):

        print(
            f"  [{rule['severity'].upper():8}] "
            f"{rule['rule_id']:<32} "
            f"+{rule['score']:.1f}"
        )

    # ---------------------------------------------------------------
    # Validation
    # ---------------------------------------------------------------

    if (
        attack_result.rule_count
        <= 0
    ):

        raise RuntimeError(
            "Attack-like flow did not trigger "
            "any behavioral rule."
        )

    if (
        attack_result.risk_score
        <= 0
    ):

        raise RuntimeError(
            "Hybrid risk score is zero for "
            "attack-like flow."
        )

    if (
        attack_result.decision
        not in {
            "INTRUSION",
            "SUSPICIOUS",
            "UNKNOWN",
        }
    ):

        raise RuntimeError(
            "Attack-like flow produced an "
            "unexpected benign decision."
        )

    print()
    print("=" * 70)
    print(
        "HYBRID DETECTOR TEST SUCCESSFUL"
    )
    print("=" * 70)


if __name__ == "__main__":
    main()