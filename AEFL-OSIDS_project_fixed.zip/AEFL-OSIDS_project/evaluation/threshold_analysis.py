from pathlib import Path
import json

import numpy as np
import torch
from torch.utils.data import DataLoader

from sklearn.metrics import (
    precision_score,
    recall_score,
    f1_score,
    balanced_accuracy_score,
    roc_auc_score,
)

from models.intrusion_model import create_model
from data_loader.cic_iot_dataset import create_dataset


# ============================================================
# CONFIGURATION
# ============================================================

PROJECT_ROOT = Path(__file__).resolve().parents[1]

SCENARIO_NAME = "scenario_C_multiple"

MODEL_PATH = (
    PROJECT_ROOT
    / "data"
    / "models"
    / "adaptive_fedavg_v2_global.pt"
)

OUTPUT_DIR = (
    PROJECT_ROOT
    / "results"
    / "threshold_analysis"
)

INPUT_FEATURES = 39
NUM_CLASSES = 5

BATCH_SIZE = 512

UNKNOWN_LABEL = -1


# ============================================================
# DEVICE
# ============================================================

def get_device():

    if torch.cuda.is_available():

        return torch.device("cuda")

    return torch.device("cpu")


# ============================================================
# LOAD MODEL
# ============================================================

def load_model(device):

    checkpoint = torch.load(
        MODEL_PATH,
        map_location=device,
        weights_only=False,
    )

    model = create_model(
        input_features=INPUT_FEATURES,
        num_classes=NUM_CLASSES,
    )

    if (
        isinstance(checkpoint, dict)
        and "model_state_dict" in checkpoint
    ):

        state_dict = checkpoint[
            "model_state_dict"
        ]

    else:

        state_dict = checkpoint

    model.load_state_dict(
        state_dict
    )

    model.to(device)

    model.eval()

    return model


# ============================================================
# INFERENCE
# ============================================================

def collect_predictions(
    model,
    dataset,
    device,
):

    loader = DataLoader(
        dataset,
        batch_size=BATCH_SIZE,
        shuffle=False,
        num_workers=0,
    )

    y_true = []
    confidence = []

    with torch.no_grad():

        for X, y in loader:

            X = X.to(device)

            logits = model(X)

            probabilities = torch.softmax(
                logits,
                dim=1,
            )

            conf, _ = torch.max(
                probabilities,
                dim=1,
            )

            y_true.extend(
                y.numpy().tolist()
            )

            confidence.extend(
                conf.cpu()
                .numpy()
                .tolist()
            )

    return (
        np.asarray(y_true),
        np.asarray(confidence),
    )


# ============================================================
# THRESHOLD EVALUATION
# ============================================================

def evaluate_threshold(
    y_true,
    confidence,
    threshold,
):

    # Ground truth:
    # 0 = known
    # 1 = unknown

    true_unknown = (
        y_true == UNKNOWN_LABEL
    ).astype(int)

    # Lower confidence => unknown

    predicted_unknown = (
        confidence < threshold
    ).astype(int)

    precision = precision_score(
        true_unknown,
        predicted_unknown,
        zero_division=0,
    )

    recall = recall_score(
        true_unknown,
        predicted_unknown,
        zero_division=0,
    )

    f1 = f1_score(
        true_unknown,
        predicted_unknown,
        zero_division=0,
    )

    balanced_accuracy = (
        balanced_accuracy_score(
            true_unknown,
            predicted_unknown,
        )
    )

    # --------------------------------------------------------
    # Known false positive rate
    # --------------------------------------------------------

    known_mask = (
        true_unknown == 0
    )

    false_positive_rate = (
        np.sum(
            predicted_unknown[
                known_mask
            ] == 1
        )
        /
        np.sum(known_mask)
    )

    # --------------------------------------------------------
    # Detection counts
    # --------------------------------------------------------

    tp = int(
        np.sum(
            (
                true_unknown == 1
            )
            &
            (
                predicted_unknown == 1
            )
        )
    )

    tn = int(
        np.sum(
            (
                true_unknown == 0
            )
            &
            (
                predicted_unknown == 0
            )
        )
    )

    fp = int(
        np.sum(
            (
                true_unknown == 0
            )
            &
            (
                predicted_unknown == 1
            )
        )
    )

    fn = int(
        np.sum(
            (
                true_unknown == 1
            )
            &
            (
                predicted_unknown == 0
            )
        )
    )

    return {

        "threshold":
            float(threshold),

        "precision":
            float(precision),

        "recall":
            float(recall),

        "f1":
            float(f1),

        "balanced_accuracy":
            float(balanced_accuracy),

        "known_fpr":
            float(false_positive_rate),

        "tp":
            tp,

        "tn":
            tn,

        "fp":
            fp,

        "fn":
            fn,
    }


# ============================================================
# MAIN
# ============================================================

def main():

    print(
        "=" * 70
    )

    print(
        "AEFL-OSIDS OPEN-SET THRESHOLD ANALYSIS"
    )

    print(
        "=" * 70
    )

    device = get_device()

    print()

    print(
        f"Device  : {device}"
    )

    print(
        f"Scenario: {SCENARIO_NAME}"
    )

    # --------------------------------------------------------
    # Load model
    # --------------------------------------------------------

    print()

    print(
        "Loading model..."
    )

    model = load_model(
        device
    )

    print(
        "Model loaded."
    )

    # --------------------------------------------------------
    # Load validation dataset
    # --------------------------------------------------------

    print()

    print(
        "Loading validation dataset..."
    )

    validation_dataset = create_dataset(
        SCENARIO_NAME,
        "validation",
    )

    print(
        f"Validation samples: "
        f"{len(validation_dataset):,}"
    )

    # --------------------------------------------------------
    # IMPORTANT
    #
    # Validation set is KNOWN only.
    #
    # Therefore we cannot calculate true
    # unknown recall on validation.
    #
    # We use validation to understand
    # confidence distribution and test
    # different operating thresholds.
    # --------------------------------------------------------

    (
        validation_labels,
        validation_confidence,
    ) = collect_predictions(
        model,
        validation_dataset,
        device,
    )

    # --------------------------------------------------------
    # Load TEST
    # --------------------------------------------------------

    print()

    print(
        "Loading test dataset..."
    )

    test_dataset = create_dataset(
        SCENARIO_NAME,
        "test",
    )

    print(
        f"Test samples: "
        f"{len(test_dataset):,}"
    )

    (
        test_labels,
        test_confidence,
    ) = collect_predictions(
        model,
        test_dataset,
        device,
    )

    # --------------------------------------------------------
    # Threshold range
    # --------------------------------------------------------

    thresholds = np.arange(
        0.10,
        0.951,
        0.025,
    )

    results = []

    print()

    print(
        "=" * 70
    )

    print(
        "THRESHOLD SWEEP"
    )

    print(
        "=" * 70
    )

    print()

    print(
        f"{'Threshold':<12}"
        f"{'Precision':<12}"
        f"{'Recall':<12}"
        f"{'F1':<12}"
        f"{'Known FPR':<12}"
        f"{'Balanced Acc':<12}"
    )

    print(
        "-" * 70
    )

    for threshold in thresholds:

        metrics = evaluate_threshold(
            test_labels,
            test_confidence,
            threshold,
        )

        results.append(
            metrics
        )

        print(
            f"{metrics['threshold']:<12.3f}"
            f"{metrics['precision']:<12.4f}"
            f"{metrics['recall']:<12.4f}"
            f"{metrics['f1']:<12.4f}"
            f"{metrics['known_fpr']:<12.4f}"
            f"{metrics['balanced_accuracy']:<12.4f}"
        )

    # --------------------------------------------------------
    # Best threshold by F1
    # --------------------------------------------------------

    best_f1 = max(
        results,
        key=lambda x: x["f1"]
    )

    # --------------------------------------------------------
    # Best threshold under FPR constraint
    # --------------------------------------------------------

    acceptable = [
        x
        for x in results
        if x["known_fpr"] <= 0.05
    ]

    if acceptable:

        best_constrained = max(
            acceptable,
            key=lambda x: x["f1"]
        )

    else:

        best_constrained = None

    # --------------------------------------------------------
    # AUROC
    # --------------------------------------------------------

    true_unknown = (
        test_labels
        == UNKNOWN_LABEL
    ).astype(int)

    unknown_score = (
        1.0 - test_confidence
    )

    auroc = roc_auc_score(
        true_unknown,
        unknown_score,
    )

    # --------------------------------------------------------
    # Output
    # --------------------------------------------------------

    print()

    print(
        "=" * 70
    )

    print(
        "BEST THRESHOLD"
    )

    print(
        "=" * 70
    )

    print()

    print(
        "Best F1 threshold:"
    )

    print(
        f"  Threshold : "
        f"{best_f1['threshold']:.3f}"
    )

    print(
        f"  Precision : "
        f"{best_f1['precision']:.6f}"
    )

    print(
        f"  Recall    : "
        f"{best_f1['recall']:.6f}"
    )

    print(
        f"  F1        : "
        f"{best_f1['f1']:.6f}"
    )

    print(
        f"  Known FPR : "
        f"{best_f1['known_fpr']:.6f}"
    )

    print()

    if best_constrained:

        print(
            "Best threshold with Known FPR <= 5%:"
        )

        print(
            f"  Threshold : "
            f"{best_constrained['threshold']:.3f}"
        )

        print(
            f"  Precision : "
            f"{best_constrained['precision']:.6f}"
        )

        print(
            f"  Recall    : "
            f"{best_constrained['recall']:.6f}"
        )

        print(
            f"  F1        : "
            f"{best_constrained['f1']:.6f}"
        )

        print(
            f"  Known FPR : "
            f"{best_constrained['known_fpr']:.6f}"
        )

    print()

    print(
        f"Open-set AUROC: "
        f"{auroc:.6f}"
    )

    # --------------------------------------------------------
    # Confidence statistics
    # --------------------------------------------------------

    confidence_statistics = {

        "validation_mean":
            float(
                np.mean(
                    validation_confidence
                )
            ),

        "validation_median":
            float(
                np.median(
                    validation_confidence
                )
            ),

        "validation_min":
            float(
                np.min(
                    validation_confidence
                )
            ),

        "validation_max":
            float(
                np.max(
                    validation_confidence
                )
            ),

        "test_mean":
            float(
                np.mean(
                    test_confidence
                )
            ),

        "test_median":
            float(
                np.median(
                    test_confidence
                )
            ),

        "test_min":
            float(
                np.min(
                    test_confidence
                )
            ),

        "test_max":
            float(
                np.max(
                    test_confidence
                )
            ),
    }

    output = {

        "scenario":
            SCENARIO_NAME,

        "model":
            str(MODEL_PATH),

        "auroc":
            float(auroc),

        "threshold_results":
            results,

        "best_f1_threshold":
            best_f1,

        "best_fpr_constrained_threshold":
            best_constrained,

        "confidence_statistics":
            confidence_statistics,
    }

    OUTPUT_DIR.mkdir(
        parents=True,
        exist_ok=True,
    )

    output_path = (
        OUTPUT_DIR
        / "threshold_analysis.json"
    )

    with open(
        output_path,
        "w",
        encoding="utf-8",
    ) as file:

        json.dump(
            output,
            file,
            indent=4,
        )

    print()

    print(
        "Results saved:"
    )

    print(
        output_path
    )

    print()

    print(
        "=" * 70
    )

    print(
        "THRESHOLD ANALYSIS COMPLETE"
    )

    print(
        "=" * 70
    )


if __name__ == "__main__":

    main()