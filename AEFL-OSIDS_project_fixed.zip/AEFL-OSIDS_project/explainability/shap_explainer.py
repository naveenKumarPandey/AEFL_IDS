"""
AEFL-OSIDS
SHAP Explainability Module

Purpose:
    Explain predictions made by the proposed robust federated model.

Model:
    data/models/robust_adaptive_fedprox_global.pt

Scenario:
    scenario_C_multiple

The module performs:
    1. Model loading
    2. Validation/test sample selection
    3. SHAP KernelExplainer-based explanations
    4. Global feature importance
    5. Class-wise feature importance
    6. Individual prediction explanations
    7. CSV/JSON result generation
    8. SHAP summary/bar plots

IMPORTANT:
    SHAP is applied after model training.
    It does not modify the trained model.
"""

from __future__ import annotations

import json
import sys
import time
from pathlib import Path
from typing import Dict, List, Tuple

import numpy as np
import pandas as pd
import torch
import shap
import matplotlib.pyplot as plt

# ---------------------------------------------------------------------
# PROJECT ROOT
# ---------------------------------------------------------------------

PROJECT_ROOT = Path(__file__).resolve().parents[1]

if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))


# ---------------------------------------------------------------------
# PROJECT IMPORTS
# ---------------------------------------------------------------------

from utils.config import load_config
from models.intrusion_model import IntrusionDetectionModel

# ---------------------------------------------------------------------
# CONFIGURATION
# ---------------------------------------------------------------------

CONFIG = load_config()

def _get_scenario_from_config(config: dict) -> str:
    """Resolve the active scenario from the project's current config."""
    # Current/expected locations used by different AEFL-OSIDS config versions.
    candidates = [
        config.get("open_set", {}).get("primary_scenario"),
        config.get("scenario"),
        config.get("dataset", {}).get("scenario"),
        config.get("data", {}).get("scenario"),
        config.get("experiment", {}).get("scenario"),
    ]

    for value in candidates:
        if isinstance(value, str) and value.strip():
            return value.strip()

    # The project currently uses scenario_C_multiple.
    return "scenario_C_multiple"


SCENARIO = _get_scenario_from_config(CONFIG)
PROCESSED_DIR = (
    PROJECT_ROOT
    / "data"
    / "processed"
    / SCENARIO
)

PROPOSED_MODEL_PATH = PROJECT_ROOT / "data" / "models" / "robust_adaptive_fedprox_global.pt"
LEGACY_MODEL_PATH = PROJECT_ROOT / "data" / "models" / "adaptive_fedavg_v2_global.pt"
MODEL_PATH = PROPOSED_MODEL_PATH if PROPOSED_MODEL_PATH.exists() else LEGACY_MODEL_PATH

OUTPUT_DIR = (
    PROJECT_ROOT
    / "results"
    / "shap_proposed"
    / SCENARIO
)

OUTPUT_DIR.mkdir(
    parents=True,
    exist_ok=True,
)

DEVICE = torch.device(
    "cuda"
    if torch.cuda.is_available()
    else "cpu"
)


# ---------------------------------------------------------------------
# EXPLAINABILITY SETTINGS
# ---------------------------------------------------------------------

# Keep these relatively small for CPU execution.
# SHAP sampling configuration
# -------------------------------------------------------------
# Background: 10 samples per known class = 50 total.
# Explanation: 20 samples per known class = 100 total.
# This gives equal representation to all five known classes.
BACKGROUND_SAMPLES = 50
EXPLANATION_SAMPLES = 100
BACKGROUND_SAMPLES_PER_CLASS = 10
EXPLANATION_SAMPLES_PER_CLASS = 20

# Number of individual samples for detailed explanations.
INDIVIDUAL_SAMPLES = 10

RANDOM_SEED = 42

np.random.seed(RANDOM_SEED)
torch.manual_seed(RANDOM_SEED)


# ---------------------------------------------------------------------
# LABELS
# ---------------------------------------------------------------------

CLASS_NAMES = {
    0: "BENIGN",
    1: "DDoS",
    2: "DoS",
    3: "Mirai",
    4: "Recon",
}


# ---------------------------------------------------------------------
# FEATURE NAMES
# ---------------------------------------------------------------------

# CICIoT2023 processed feature names.
#
# The processor keeps 39 numerical features.
# If the processed dataset contains different names, the loader below
# automatically falls back to generic Feature_01 ... Feature_39 names.

DEFAULT_FEATURE_NAMES = [
    "flow_duration",
    "Header_Length",
    "Protocol Type",
    "Duration",
    "Rate",
    "Srate",
    "Drate",
    "fin_flag_number",
    "syn_flag_number",
    "rst_flag_number",
    "psh_flag_number",
    "ack_flag_number",
    "ece_flag_number",
    "cwr_flag_number",
    "ack_count",
    "syn_count",
    "fin_count",
    "urg_count",
    "rst_count",
    "HTTP",
    "HTTPS",
    "DNS",
    "Telnet",
    "SMTP",
    "SSH",
    "IRC",
    "TCP",
    "UDP",
    "DHCP",
    "ARP",
    "ICMP",
    "IPv",
    "LLC",
    "Tot sum",
    "Min",
    "Max",
    "AVG",
    "Std",
    "Tot size",
]


# ---------------------------------------------------------------------
# PRINT HELPERS
# ---------------------------------------------------------------------

def print_header(title: str) -> None:
    print()
    print("=" * 70)
    print(title)
    print("=" * 70)


def print_section(title: str) -> None:
    print()
    print("-" * 70)
    print(title)
    print("-" * 70)


# ---------------------------------------------------------------------
# MODEL LOADING
# ---------------------------------------------------------------------

def load_model() -> torch.nn.Module:
    """
    Load the trained proposed federated global model.
    """

    if not MODEL_PATH.exists():
        raise FileNotFoundError(
            f"Trained model not found:\n{MODEL_PATH}"
        )

    print("Loading federated global model...")
    print(f"Model: {MODEL_PATH}")

    checkpoint = torch.load(
        MODEL_PATH,
        map_location=DEVICE,
        weights_only=False,
    )

    # -------------------------------------------------------------
    # Case 1: complete model object
    # -------------------------------------------------------------

    if isinstance(checkpoint, torch.nn.Module):
        model = checkpoint

    # -------------------------------------------------------------
    # Case 2: checkpoint dictionary
    # -------------------------------------------------------------

    elif isinstance(checkpoint, dict):

        state_dict = None

        possible_keys = [
            "model_state_dict",
            "state_dict",
            "global_model_state_dict",
            "model",
        ]

        for key in possible_keys:
            if key in checkpoint:
                value = checkpoint[key]

                if isinstance(value, dict):
                    state_dict = value
                    break

        if state_dict is None:

            # Sometimes the checkpoint itself is a state_dict.
            if all(
                isinstance(v, torch.Tensor)
                for v in checkpoint.values()
            ):
                state_dict = checkpoint

        if state_dict is None:
            raise RuntimeError(
                "Unable to find model state_dict in checkpoint."
            )

        model = IntrusionDetectionModel(
            input_features=39,
            num_classes=5,
            dropout=0.30,
        )

        model.load_state_dict(
            state_dict,
            strict=True,
        )

    else:
        raise RuntimeError(
            f"Unsupported model checkpoint type: "
            f"{type(checkpoint)}"
        )

    model.to(DEVICE)
    model.eval()

    print("Model loaded successfully.")

    return model


# ---------------------------------------------------------------------
# NPZ DISCOVERY
# ---------------------------------------------------------------------

def find_npz_files(split: str) -> List[Path]:
    """
    Find all processed NPZ files for a split.
    """

    split_dir = PROCESSED_DIR / split

    if not split_dir.exists():
        raise FileNotFoundError(
            f"Processed split directory not found:\n"
            f"{split_dir}"
        )

    files = sorted(
        split_dir.rglob("*.npz")
    )

    if not files:
        raise FileNotFoundError(
            f"No NPZ files found in:\n{split_dir}"
        )

    return files


# ---------------------------------------------------------------------
# DATA LOADING
# ---------------------------------------------------------------------

def load_processed_data(
    split: str,
    max_samples: int | None = None,
    include_unknown: bool = False,
) -> Tuple[np.ndarray, np.ndarray]:
    """
    Load processed NPZ data.

    Parameters
    ----------
    split:
        train / validation / test

    max_samples:
        Maximum number of samples to load.

    include_unknown:
        Whether label -1 samples are allowed.
    """

    files = find_npz_files(split)

    X_parts = []
    y_parts = []

    total = 0

    for path in files:

        data = np.load(
            path,
            allow_pickle=False,
        )

        X = np.asarray(
            data["X"],
            dtype=np.float32,
        )

        y = np.asarray(
            data["y"],
            dtype=np.int64,
        )

        if not include_unknown:
            mask = y >= 0

            X = X[mask]
            y = y[mask]

        if max_samples is not None:

            remaining = (
                max_samples - total
            )

            if remaining <= 0:
                break

            if len(X) > remaining:
                X = X[:remaining]
                y = y[:remaining]

        if len(X) == 0:
            continue

        X_parts.append(X)
        y_parts.append(y)

        total += len(X)

        if (
            max_samples is not None
            and total >= max_samples
        ):
            break

    if not X_parts:
        raise RuntimeError(
            f"No usable samples found for split: {split}"
        )

    X_all = np.concatenate(
        X_parts,
        axis=0,
    )

    y_all = np.concatenate(
        y_parts,
        axis=0,
    )

    return X_all, y_all


# ---------------------------------------------------------------------
# FEATURE NAMES
# ---------------------------------------------------------------------

def get_feature_names(
    n_features: int,
) -> List[str]:
    """
    Return feature names for the processed data.
    """

    if n_features == len(
        DEFAULT_FEATURE_NAMES
    ):
        return DEFAULT_FEATURE_NAMES.copy()

    return [
        f"Feature_{i + 1:02d}"
        for i in range(n_features)
    ]


# ---------------------------------------------------------------------
# PREDICTION FUNCTION
# ---------------------------------------------------------------------

def prediction_function(
    model: torch.nn.Module,
):
    """
    Convert the PyTorch model into a NumPy-compatible
    prediction function for SHAP.

    SHAP expects:
        numpy -> numpy probabilities
    """

    def predict(
        X: np.ndarray,
    ) -> np.ndarray:

        X = np.asarray(
            X,
            dtype=np.float32,
        )

        tensor = torch.from_numpy(
            X
        ).to(DEVICE)

        with torch.no_grad():

            output = model(tensor)

            # -----------------------------------------------------
            # Handle model output
            # -----------------------------------------------------

            if isinstance(output, tuple):
                logits = output[0]

            elif isinstance(output, dict):
                if "logits" in output:
                    logits = output["logits"]
                else:
                    raise RuntimeError(
                        "Model dictionary output does not "
                        "contain 'logits'."
                    )

            else:
                logits = output

            probabilities = torch.softmax(
                logits,
                dim=1,
            )

        return (
            probabilities
            .detach()
            .cpu()
            .numpy()
        )

    return predict


# ---------------------------------------------------------------------
# REPRESENTATIVE SAMPLE SELECTION
# ---------------------------------------------------------------------

def select_balanced_samples(
    X: np.ndarray,
    y: np.ndarray,
    samples_per_class: int,
) -> Tuple[np.ndarray, np.ndarray]:
    """
    Select an equal number of samples from every known class.

    The five known classes are explicitly taken from CLASS_NAMES:
        0 BENIGN
        1 DDoS
        2 DoS
        3 Mirai
        4 Recon

    This avoids accidentally selecting only the classes that happen to
    appear early in the validation subset.
    """

    rng = np.random.default_rng(RANDOM_SEED)

    selected_indices = []

    for label in CLASS_NAMES.keys():
        indices = np.where(y == label)[0]

        if len(indices) < samples_per_class:
            raise RuntimeError(
                f"Not enough samples for class "
                f"{CLASS_NAMES[label]} ({label}). "
                f"Required: {samples_per_class}, available: {len(indices)}."
            )

        chosen = rng.choice(
            indices,
            size=samples_per_class,
            replace=False,
        )

        selected_indices.extend(chosen.tolist())

    selected_indices = np.asarray(
        selected_indices,
        dtype=np.int64,
    )

    rng.shuffle(selected_indices)

    X_selected = X[selected_indices]
    y_selected = y[selected_indices]

    # Strict verification: exactly the requested number per known class.
    for label in CLASS_NAMES.keys():
        actual = int(np.sum(y_selected == label))
        if actual != samples_per_class:
            raise RuntimeError(
                f"Balanced selection failed for "
                f"{CLASS_NAMES[label]}: expected "
                f"{samples_per_class}, got {actual}."
            )

    return X_selected, y_selected


# ---------------------------------------------------------------------
# SHAP EXPLAINER
# ---------------------------------------------------------------------

def create_explainer(
    predict_fn,
    background: np.ndarray,
):
    """
    Create SHAP explainer.

    SHAP 0.52 supports the generic Explainer interface.
    We use the permutation algorithm because the model is a
    PyTorch neural network and the processed input has only
    39 features.
    """

    print("Creating SHAP explainer...")

    try:

        explainer = shap.Explainer(
            predict_fn,
            background,
            algorithm="permutation",
        )

        return explainer

    except Exception as exc:

        print(
            "Generic SHAP explainer creation failed."
        )

        print(
            f"Reason: {exc}"
        )

        print(
            "Falling back to KernelExplainer..."
        )

        return shap.KernelExplainer(
            predict_fn,
            background,
        )


# ---------------------------------------------------------------------
# EXPLANATION EXTRACTION
# ---------------------------------------------------------------------

def normalize_shap_values(
    shap_values,
    n_samples: int,
    n_features: int,
    n_classes: int,
):
    """
    Normalize SHAP output into:

        [samples, features, classes]

    Different SHAP versions / explainers can return
    different layouts.
    """

    # -------------------------------------------------------------
    # New SHAP Explanation object
    # -------------------------------------------------------------

    if hasattr(
        shap_values,
        "values",
    ):
        values = np.asarray(
            shap_values.values
        )

    else:
        values = np.asarray(
            shap_values
        )

    # -------------------------------------------------------------
    # Standard 3-D layout
    # -------------------------------------------------------------

    if values.ndim == 3:

        if values.shape == (
            n_samples,
            n_features,
            n_classes,
        ):
            return values

        if values.shape == (
            n_samples,
            n_classes,
            n_features,
        ):
            return np.transpose(
                values,
                (0, 2, 1),
            )

        # Another common layout:
        # [classes, samples, features]

        if values.shape == (
            n_classes,
            n_samples,
            n_features,
        ):
            return np.transpose(
                values,
                (1, 2, 0),
            )

    # -------------------------------------------------------------
    # List of class arrays
    # -------------------------------------------------------------

    if isinstance(
        shap_values,
        list,
    ):

        arrays = [
            np.asarray(v)
            for v in shap_values
        ]

        if len(arrays) == n_classes:

            stacked = np.stack(
                arrays,
                axis=-1,
            )

            return stacked

    raise RuntimeError(
        "Unsupported SHAP value shape: "
        f"{values.shape}"
    )


# ---------------------------------------------------------------------
# GLOBAL FEATURE IMPORTANCE
# ---------------------------------------------------------------------

def calculate_global_importance(
    shap_array: np.ndarray,
    feature_names: List[str],
) -> pd.DataFrame:
    """
    Calculate mean absolute SHAP importance
    across samples and output classes.
    """

    importance = np.mean(
        np.abs(shap_array),
        axis=(0, 2),
    )

    df = pd.DataFrame(
        {
            "feature": feature_names,
            "mean_abs_shap": importance,
        }
    )

    df = df.sort_values(
        "mean_abs_shap",
        ascending=False,
    )

    df["rank"] = np.arange(
        1,
        len(df) + 1,
    )

    return df[
        [
            "rank",
            "feature",
            "mean_abs_shap",
        ]
    ]


# ---------------------------------------------------------------------
# CLASS-WISE FEATURE IMPORTANCE
# ---------------------------------------------------------------------

def calculate_class_importance(
    shap_array: np.ndarray,
    feature_names: List[str],
) -> Dict[str, pd.DataFrame]:
    """
    Calculate class-specific SHAP importance.
    """

    results = {}

    n_classes = shap_array.shape[2]

    for class_id in range(
        n_classes
    ):

        values = np.mean(
            np.abs(
                shap_array[:, :, class_id]
            ),
            axis=0,
        )

        df = pd.DataFrame(
            {
                "feature": feature_names,
                "mean_abs_shap": values,
            }
        )

        df = df.sort_values(
            "mean_abs_shap",
            ascending=False,
        )

        df["rank"] = np.arange(
            1,
            len(df) + 1,
        )

        results[
            CLASS_NAMES.get(
                class_id,
                f"Class_{class_id}",
            )
        ] = df[
            [
                "rank",
                "feature",
                "mean_abs_shap",
            ]
        ]

    return results


# ---------------------------------------------------------------------
# SAVE GLOBAL IMPORTANCE
# ---------------------------------------------------------------------

def save_global_importance(
    df: pd.DataFrame,
) -> Path:

    path = (
        OUTPUT_DIR
        / "global_feature_importance.csv"
    )

    df.to_csv(
        path,
        index=False,
    )

    return path


# ---------------------------------------------------------------------
# SAVE CLASS IMPORTANCE
# ---------------------------------------------------------------------

def save_class_importance(
    results: Dict[str, pd.DataFrame],
) -> Dict[str, str]:

    saved = {}

    for class_name, df in results.items():

        safe_name = (
            class_name
            .lower()
            .replace(" ", "_")
            .replace("-", "_")
        )

        path = (
            OUTPUT_DIR
            / f"class_{safe_name}_importance.csv"
        )

        df.to_csv(
            path,
            index=False,
        )

        saved[class_name] = str(
            path
        )

    return saved


# ---------------------------------------------------------------------
# GLOBAL BAR PLOT
# ---------------------------------------------------------------------

def save_global_plot(
    importance_df: pd.DataFrame,
    top_k: int = 15,
) -> Path:

    top = importance_df.head(
        top_k
    ).sort_values(
        "mean_abs_shap"
    )

    plt.figure(
        figsize=(10, 7)
    )

    plt.barh(
        top["feature"],
        top["mean_abs_shap"],
    )

    plt.xlabel(
        "Mean Absolute SHAP Value"
    )

    plt.ylabel(
        "Feature"
    )

    plt.title(
        "Global SHAP Feature Importance"
    )

    plt.tight_layout()

    path = (
        OUTPUT_DIR
        / "global_shap_feature_importance.png"
    )

    plt.savefig(
        path,
        dpi=200,
        bbox_inches="tight",
    )

    plt.close()

    return path


# ---------------------------------------------------------------------
# CLASS-WISE PLOTS
# ---------------------------------------------------------------------

def save_class_plots(
    class_results: Dict[str, pd.DataFrame],
    top_k: int = 10,
) -> List[str]:

    saved = []

    for class_name, df in class_results.items():

        top = df.head(
            top_k
        ).sort_values(
            "mean_abs_shap"
        )

        plt.figure(
            figsize=(10, 6)
        )

        plt.barh(
            top["feature"],
            top["mean_abs_shap"],
        )

        plt.xlabel(
            "Mean Absolute SHAP Value"
        )

        plt.ylabel(
            "Feature"
        )

        plt.title(
            f"SHAP Importance - {class_name}"
        )

        plt.tight_layout()

        safe_name = (
            class_name
            .lower()
            .replace(" ", "_")
            .replace("-", "_")
        )

        path = (
            OUTPUT_DIR
            / f"shap_{safe_name}.png"
        )

        plt.savefig(
            path,
            dpi=200,
            bbox_inches="tight",
        )

        plt.close()

        saved.append(
            str(path)
        )

    return saved


# ---------------------------------------------------------------------
# SUMMARY PLOT
# ---------------------------------------------------------------------

def save_summary_plot(
    shap_values,
    X: np.ndarray,
    feature_names: List[str],
) -> Path | None:

    path = (
        OUTPUT_DIR
        / "shap_summary.png"
    )

    try:

        # SHAP Explanation object
        if hasattr(
            shap_values,
            "values",
        ):

            values = shap_values.values

            # Multi-output models sometimes return:
            # samples x features x classes.
            if values.ndim == 3:

                # Aggregate output classes for a global
                # explanation.
                values = np.mean(
                    np.abs(values),
                    axis=2,
                )

                plt.figure(
                    figsize=(10, 8)
                )

                shap.summary_plot(
                    values,
                    X,
                    feature_names=feature_names,
                    show=False,
                )

            else:

                plt.figure(
                    figsize=(10, 8)
                )

                shap.summary_plot(
                    values,
                    X,
                    feature_names=feature_names,
                    show=False,
                )

        else:

            values = np.asarray(
                shap_values
            )

            if values.ndim == 3:
                values = np.mean(
                    np.abs(values),
                    axis=2,
                )

            plt.figure(
                figsize=(10, 8)
            )

            shap.summary_plot(
                values,
                X,
                feature_names=feature_names,
                show=False,
            )

        plt.tight_layout()

        plt.savefig(
            path,
            dpi=200,
            bbox_inches="tight",
        )

        plt.close()

        return path

    except Exception as exc:

        plt.close()

        print(
            f"Summary plot skipped: {exc}"
        )

        return None


# ---------------------------------------------------------------------
# INDIVIDUAL EXPLANATIONS
# ---------------------------------------------------------------------

def create_individual_explanations(
    shap_array: np.ndarray,
    X: np.ndarray,
    y: np.ndarray,
    probabilities: np.ndarray,
    feature_names: List[str],
    count: int,
) -> List[Dict]:

    results = []

    count = min(
        count,
        len(X),
    )

    for i in range(count):

        predicted = int(
            np.argmax(
                probabilities[i]
            )
        )

        confidence = float(
            probabilities[i][predicted]
        )

        contribution = (
            shap_array[i, :, predicted]
        )

        ranking = np.argsort(
            np.abs(contribution)
        )[::-1]

        top_features = []

        for index in ranking[:10]:

            feature = feature_names[
                index
            ]

            value = float(
                X[i, index]
            )

            shap_value = float(
                contribution[index]
            )

            top_features.append(
                {
                    "feature": feature,
                    "input_value": value,
                    "shap_value": shap_value,
                    "absolute_shap": abs(
                        shap_value
                    ),
                }
            )

        results.append(
            {
                "sample_index": i,
                "true_label": int(y[i]),
                "true_class": CLASS_NAMES.get(
                    int(y[i]),
                    "UNKNOWN",
                ),
                "predicted_label": predicted,
                "predicted_class": CLASS_NAMES.get(
                    predicted,
                    f"Class_{predicted}",
                ),
                "confidence": confidence,
                "top_features": top_features,
            }
        )

    return results


# ---------------------------------------------------------------------
# SAVE INDIVIDUAL RESULTS
# ---------------------------------------------------------------------

def save_individual_results(
    results: List[Dict],
) -> Path:

    path = (
        OUTPUT_DIR
        / "individual_explanations.json"
    )

    with open(
        path,
        "w",
        encoding="utf-8",
    ) as f:

        json.dump(
            results,
            f,
            indent=2,
        )

    return path


# ---------------------------------------------------------------------
# MAIN
# ---------------------------------------------------------------------

def main() -> None:

    start_time = time.time()

    print_header(
        "AEFL-OSIDS SHAP EXPLAINABILITY"
    )

    print(
        f"Device  : {DEVICE}"
    )

    print(
        f"Scenario: {SCENARIO}"
    )

    print(
        f"SHAP    : {shap.__version__}"
    )

    print(
        f"Output  : {OUTPUT_DIR}"
    )

    print_section(
        "EXPLAINABILITY CONFIGURATION"
    )

    print(
        f"Background samples  : "
        f"{BACKGROUND_SAMPLES}"
    )

    print(
        f"Explanation samples : "
        f"{EXPLANATION_SAMPLES}"
    )

    print(
        f"Individual samples  : "
        f"{INDIVIDUAL_SAMPLES}"
    )

    print(
        f"Background/class    : "
        f"{BACKGROUND_SAMPLES_PER_CLASS}"
    )

    print(
        f"Explanation/class   : "
        f"{EXPLANATION_SAMPLES_PER_CLASS}"
    )

    # -------------------------------------------------------------
    # MODEL
    # -------------------------------------------------------------

    model = load_model()

    # -------------------------------------------------------------
    # VALIDATION DATA
    # -------------------------------------------------------------

    print_section(
        "LOADING VALIDATION DATA"
    )

    X_val, y_val = load_processed_data(
        "validation",
        max_samples=None,
        include_unknown=False,
    )

    print(
        f"Validation samples loaded: "
        f"{len(X_val):,}"
    )

    print(
        f"Feature count: "
        f"{X_val.shape[1]}"
    )

    # -------------------------------------------------------------
    # BALANCED EXPLANATION SET
    # -------------------------------------------------------------

    print_section(
        "SELECTING REPRESENTATIVE SAMPLES"
    )

    X_explain, y_explain = select_balanced_samples(
        X_val,
        y_val,
        EXPLANATION_SAMPLES_PER_CLASS,
    )

    expected_explanation_count = (
        EXPLANATION_SAMPLES_PER_CLASS * len(CLASS_NAMES)
    )

    if len(X_explain) != expected_explanation_count:
        raise RuntimeError(
            f"Expected {expected_explanation_count} explanation samples, "
            f"got {len(X_explain)}."
        )

    if len(X_explain) != EXPLANATION_SAMPLES:
        raise RuntimeError(
            f"EXPLANATION_SAMPLES={EXPLANATION_SAMPLES} does not match "
            f"per-class configuration: {expected_explanation_count}."
        )

    print(
        f"Explanation samples: "
        f"{len(X_explain):,}"
    )

    unique, counts = np.unique(
        y_explain,
        return_counts=True,
    )

    print(
        "Explanation class distribution:"
    )

    for label, count in zip(
        unique,
        counts,
    ):

        print(
            f"  {CLASS_NAMES.get(int(label), 'UNKNOWN'):10s}"
            f": {count:5d}"
        )

    # -------------------------------------------------------------
    # BACKGROUND DATA
    # -------------------------------------------------------------

    print_section(
        "SELECTING SHAP BACKGROUND"
    )

    X_background, y_background = select_balanced_samples(
        X_val,
        y_val,
        BACKGROUND_SAMPLES_PER_CLASS,
    )

    expected_background_count = (
        BACKGROUND_SAMPLES_PER_CLASS * len(CLASS_NAMES)
    )

    if len(X_background) != expected_background_count:
        raise RuntimeError(
            f"Expected {expected_background_count} background samples, "
            f"got {len(X_background)}."
        )

    if len(X_background) != BACKGROUND_SAMPLES:
        raise RuntimeError(
            f"BACKGROUND_SAMPLES={BACKGROUND_SAMPLES} does not match "
            f"per-class configuration: {expected_background_count}."
        )

    print(
        f"Background samples: "
        f"{len(X_background):,}"
    )

    print("Background class distribution:")
    for label in CLASS_NAMES:
        count = int(np.sum(y_background == label))
        print(
            f"  {CLASS_NAMES[label]:10s}: {count:5d}"
        )

    # -------------------------------------------------------------
    # FEATURE NAMES
    # -------------------------------------------------------------

    feature_names = get_feature_names(
        X_explain.shape[1]
    )

    print(
        f"Feature names: "
        f"{len(feature_names)}"
    )

    # -------------------------------------------------------------
    # PREDICT FUNCTION
    # -------------------------------------------------------------

    predict_fn = prediction_function(
        model
    )

    # -------------------------------------------------------------
    # BASE PREDICTION TEST
    # -------------------------------------------------------------

    print_section(
        "MODEL PREDICTION TEST"
    )

    test_probabilities = predict_fn(
        X_explain[:5]
    )

    print(
        f"Prediction shape: "
        f"{test_probabilities.shape}"
    )

    probability_check = np.allclose(
        test_probabilities.sum(axis=1),
        1.0,
        atol=1e-5,
    )

    print(
        f"Probability sum check: {probability_check}"
    )

    # -------------------------------------------------------------
    # CREATE EXPLAINER
    # -------------------------------------------------------------

    print_section(
        "CREATING SHAP EXPLAINER"
    )

    explainer = create_explainer(
        predict_fn,
        X_background,
    )

    print(
        "SHAP explainer created successfully."
    )

    # -------------------------------------------------------------
    # SHAP EXPLANATION
    # -------------------------------------------------------------

    print_section(
        "GENERATING SHAP EXPLANATIONS"
    )

    print(
        "This may take some time on CPU..."
    )

    shap_start = time.time()

    shap_result = explainer(
        X_explain
    )

    shap_time = (
        time.time()
        - shap_start
    )

    print(
        f"SHAP computation time: "
        f"{shap_time:.2f}s"
    )

    # -------------------------------------------------------------
    # NORMALIZE SHAP VALUES
    # -------------------------------------------------------------

    shap_array = normalize_shap_values(
        shap_result,
        n_samples=len(X_explain),
        n_features=X_explain.shape[1],
        n_classes=len(CLASS_NAMES),
    )

    print(
        f"Normalized SHAP shape: "
        f"{shap_array.shape}"
    )

    expected_shape = (
        len(X_explain),
        X_explain.shape[1],
        len(CLASS_NAMES),
    )

    if shap_array.shape != expected_shape:

        raise RuntimeError(
            "Unexpected normalized SHAP shape. "
            f"Expected {expected_shape}, "
            f"got {shap_array.shape}"
        )

    print(
        "SHAP shape validation: PASS"
    )

    # -------------------------------------------------------------
    # GLOBAL IMPORTANCE
    # -------------------------------------------------------------

    print_section(
        "GLOBAL FEATURE IMPORTANCE"
    )

    global_df = calculate_global_importance(
        shap_array,
        feature_names,
    )

    global_path = (
        save_global_importance(
            global_df
        )
    )

    print(
        f"Saved: {global_path}"
    )

    print()
    print(
        "Top 15 features:"
    )

    for _, row in global_df.head(
        15
    ).iterrows():

        print(
            f"  {int(row['rank']):2d}. "
            f"{row['feature']:<25s} "
            f"{row['mean_abs_shap']:.8f}"
        )

    # -------------------------------------------------------------
    # CLASS-WISE IMPORTANCE
    # -------------------------------------------------------------

    print_section(
        "CLASS-WISE FEATURE IMPORTANCE"
    )

    class_results = (
        calculate_class_importance(
            shap_array,
            feature_names,
        )
    )

    class_paths = (
        save_class_importance(
            class_results
        )
    )

    for class_name, df in (
        class_results.items()
    ):

        print()
        print(
            f"{class_name}:"
        )

        for _, row in df.head(
            5
        ).iterrows():

            print(
                f"  {int(row['rank']):2d}. "
                f"{row['feature']:<25s} "
                f"{row['mean_abs_shap']:.8f}"
            )

    # -------------------------------------------------------------
    # PREDICTIONS
    # -------------------------------------------------------------

    probabilities = predict_fn(
        X_explain
    )

    predictions = np.argmax(
        probabilities,
        axis=1,
    )

    # -------------------------------------------------------------
    # INDIVIDUAL EXPLANATIONS
    # -------------------------------------------------------------

    print_section(
        "INDIVIDUAL SAMPLE EXPLANATIONS"
    )

    individual_results = (
        create_individual_explanations(
            shap_array,
            X_explain,
            y_explain,
            probabilities,
            feature_names,
            INDIVIDUAL_SAMPLES,
        )
    )

    individual_path = (
        save_individual_results(
            individual_results
        )
    )

    print(
        f"Saved: {individual_path}"
    )

    for item in individual_results:

        print()
        print(
            f"Sample {item['sample_index']}: "
            f"true={item['true_class']}, "
            f"predicted={item['predicted_class']}, "
            f"confidence="
            f"{item['confidence']:.4f}"
        )

        for feature in item[
            "top_features"
        ][:5]:

            print(
                f"  {feature['feature']:<25s} "
                f"SHAP="
                f"{feature['shap_value']:+.6f}"
            )

    # -------------------------------------------------------------
    # PLOTS
    # -------------------------------------------------------------

    print_section(
        "GENERATING SHAP PLOTS"
    )

    global_plot = save_global_plot(
        global_df
    )

    print(
        f"Global importance plot: "
        f"{global_plot}"
    )

    class_plots = save_class_plots(
        class_results
    )

    for path in class_plots:

        print(
            f"Class plot: {path}"
        )

    summary_plot = (
        save_summary_plot(
            shap_result,
            X_explain,
            feature_names,
        )
    )

    if summary_plot:

        print(
            f"Summary plot: "
            f"{summary_plot}"
        )

    # -------------------------------------------------------------
    # METADATA
    # -------------------------------------------------------------

    metadata = {
        "scenario": SCENARIO,
        "model": str(MODEL_PATH.relative_to(PROJECT_ROOT)),
        "device": str(DEVICE),
        "shap_version": shap.__version__,
        "background_samples": int(
            len(X_background)
        ),
        "explanation_samples": int(
            len(X_explain)
        ),
        "feature_count": int(
            X_explain.shape[1]
        ),
        "class_count": len(
            CLASS_NAMES
        ),
        "class_names": {
            str(k): v for k, v in CLASS_NAMES.items()
        },
        "random_seed": RANDOM_SEED,
        "background_samples_per_class": int(
            BACKGROUND_SAMPLES_PER_CLASS
        ),
        "explanation_samples_per_class": int(
            EXPLANATION_SAMPLES_PER_CLASS
        ),
        "shap_computation_seconds": (
            shap_time
        ),
        "outputs": {
            "global_importance": str(global_path.relative_to(PROJECT_ROOT)),
            "class_importance": {
                name: str(Path(path).relative_to(PROJECT_ROOT))
                for name, path in class_paths.items()
            },
            "individual_explanations": str(individual_path.relative_to(PROJECT_ROOT)),
            "global_plot": str(global_plot.relative_to(PROJECT_ROOT)),
            "class_plots": [
                str(Path(path).relative_to(PROJECT_ROOT)) for path in class_plots
            ],
            "summary_plot": (
                str(summary_plot.relative_to(PROJECT_ROOT))
                if summary_plot
                else None
            ),
        },
    }

    metadata_path = (
        OUTPUT_DIR
        / "shap_metadata.json"
    )

    with open(
        metadata_path,
        "w",
        encoding="utf-8",
    ) as f:

        json.dump(
            metadata,
            f,
            indent=2,
        )

    # -------------------------------------------------------------
    # FINAL
    # -------------------------------------------------------------

    total_time = (
        time.time()
        - start_time
    )

    print_header(
        "SHAP EXPLAINABILITY COMPLETE"
    )

    print(
        f"Scenario           : {SCENARIO}"
    )

    print(
        f"Features           : "
        f"{X_explain.shape[1]}"
    )

    print(
        f"Samples explained  : "
        f"{len(X_explain)}"
    )

    print(
        f"SHAP time          : "
        f"{shap_time:.2f}s"
    )

    print(
        f"Total execution    : "
        f"{total_time:.2f}s"
    )

    print()
    print(
        "Results directory:"
    )

    print(
        OUTPUT_DIR
    )

    print()
    print(
        "======================================================================"
    )
    print(
        "SHAP MODULE SUCCESSFUL"
    )
    print(
        "======================================================================"
    )


# ---------------------------------------------------------------------
# ENTRY POINT
# ---------------------------------------------------------------------

if __name__ == "__main__":
    main()
