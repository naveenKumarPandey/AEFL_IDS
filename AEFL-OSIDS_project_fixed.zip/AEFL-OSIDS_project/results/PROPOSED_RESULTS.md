# Proposed AEFL-OSIDS results

All classification checkpoints were recomputed with the same evaluator on the
known-class portion of the independent Scenario-C test split.

| Method | Accuracy | Macro-F1 | Weighted-F1 |
|---|---:|---:|---:|
| Centralized baseline | 81.74% | 68.23% | 82.95% |
| FedAvg | 80.85% | 67.04% | 81.98% |
| Adaptive FedAvg v2 (legacy) | 83.72% | 54.87% | 78.23% |
| Robust Class-Balanced FedProx (proposed) | 81.95% | **68.69%** | 82.37% |

The proposed hybrid detector combines maximum-softmax uncertainty with a
balanced Isolation Forest. Its rejection threshold is calibrated only on known
validation traffic.

| Open-set method | Unknown F1 | AUROC | Known FPR |
|---|---:|---:|---:|
| MSP confidence baseline | 31.81% | 79.55% | 7.39% |
| Hybrid MSP + Isolation Forest | **66.16%** | **93.45%** | 6.61% |

Balanced SHAP explanations were generated for 100 validation examples (20 per
known class) with 50 balanced background samples. The leading global features
for the proposed checkpoint were `Std`, `Header_Length`, `ICMP`, `Max`, and
`syn_flag_number`. These are model attributions, not causal claims.

> **Preliminary-results warning:** the uploaded legacy processed split fails the
> new integrity audit because exact feature rows cross split boundaries and the
> old preprocessor truncated source filenames. Use the corrected full-data
> pipeline and require a PASS audit before publication.
