from pathlib import Path
from typing import Iterator, Optional

import pandas as pd


# ============================================================
# PROJECT PATHS
# ============================================================

PROJECT_ROOT = Path(__file__).resolve().parents[1]

DATASET_DIR = (
    PROJECT_ROOT
    / "data"
    / "raw"
    / "CICIoT2023"
    / "CSV"
)


# ============================================================
# DATASET CONSTANTS
# ============================================================

EXPECTED_FEATURE_COUNT = 39

LABEL_COLUMN = "attack_label"

BENIGN_FOLDER = "Benign_Final"


# ============================================================
# DATASET DISCOVERY
# ============================================================

def find_csv_files(
    dataset_dir: Path = DATASET_DIR,
) -> list[Path]:
    """
    Recursively find all CSV files in the dataset.
    """

    if not dataset_dir.exists():
        raise FileNotFoundError(
            f"Dataset directory does not exist:\n{dataset_dir}"
        )

    return sorted(dataset_dir.rglob("*.csv"))


def get_attack_label(csv_path: Path) -> str:
    """
    Derive the attack label from the parent folder name.

    Example:
        Benign_Final -> BENIGN
        DDoS-UDP_Flood -> DDoS-UDP_Flood
    """

    folder_name = csv_path.parent.name

    if folder_name == BENIGN_FOLDER:
        return "BENIGN"

    return folder_name


# ============================================================
# CSV READING
# ============================================================

def read_csv_file(
    csv_path: Path,
    nrows: Optional[int] = None,
) -> pd.DataFrame:
    """
    Read one CICIoT2023 CSV file.

    Parameters
    ----------
    csv_path:
        Path to CSV file.

    nrows:
        Optional number of rows to read.
        Useful for testing without loading a large file.
    """

    if not csv_path.exists():
        raise FileNotFoundError(
            f"CSV file does not exist:\n{csv_path}"
        )

    df = pd.read_csv(
        csv_path,
        nrows=nrows,
    )

    # --------------------------------------------------------
    # Validate feature count
    # --------------------------------------------------------

    if len(df.columns) != EXPECTED_FEATURE_COUNT:
        raise ValueError(
            f"Unexpected number of columns in {csv_path.name}. "
            f"Expected {EXPECTED_FEATURE_COUNT}, "
            f"found {len(df.columns)}."
        )

    # --------------------------------------------------------
    # Add label from folder name
    # --------------------------------------------------------

    df[LABEL_COLUMN] = get_attack_label(csv_path)

    # --------------------------------------------------------
    # Store source file for traceability
    # --------------------------------------------------------

    df["source_file"] = csv_path.name

    return df


# ============================================================
# CHUNK-WISE ITERATOR
# ============================================================

def iter_csv_chunks(
    csv_path: Path,
    chunk_size: int = 50_000,
) -> Iterator[pd.DataFrame]:
    """
    Read a CSV file chunk-by-chunk.

    This prevents the complete file from being loaded
    into memory at once.
    """

    if not csv_path.exists():
        raise FileNotFoundError(
            f"CSV file does not exist:\n{csv_path}"
        )

    for chunk in pd.read_csv(
        csv_path,
        chunksize=chunk_size,
    ):
        if len(chunk.columns) != EXPECTED_FEATURE_COUNT:
            raise ValueError(
                f"Unexpected number of columns in "
                f"{csv_path.name}."
            )

        chunk[LABEL_COLUMN] = get_attack_label(csv_path)

        chunk["source_file"] = csv_path.name

        yield chunk


# ============================================================
# DATASET ITERATOR
# ============================================================

def iter_dataset(
    dataset_dir: Path = DATASET_DIR,
    chunk_size: int = 50_000,
) -> Iterator[pd.DataFrame]:
    """
    Iterate over every CSV in the CICIoT2023 dataset
    using chunks.
    """

    csv_files = find_csv_files(dataset_dir)

    for csv_file in csv_files:
        yield from iter_csv_chunks(
            csv_file,
            chunk_size=chunk_size,
        )


# ============================================================
# QUICK DATASET TEST
# ============================================================

def inspect_sample(
    dataset_dir: Path = DATASET_DIR,
) -> None:
    """
    Read a small sample from the first CSV file
    and display basic information.
    """

    csv_files = find_csv_files(dataset_dir)

    if not csv_files:
        raise RuntimeError(
            "No CSV files were found."
        )

    first_file = csv_files[0]

    print("=" * 70)
    print("CICIoT2023 DATA LOADER TEST")
    print("=" * 70)

    print(f"\nDataset directory:")
    print(dataset_dir)

    print(f"\nCSV files found: {len(csv_files)}")

    print(f"\nFirst CSV:")
    print(first_file.relative_to(dataset_dir))

    df = read_csv_file(
        first_file,
        nrows=5,
    )

    print(f"\nLoaded shape: {df.shape}")

    print("\nAssigned attack label:")
    print(df[LABEL_COLUMN].iloc[0])

    print("\nColumns:")
    for column in df.columns:
        print(f"  - {column}")

    print("\nSample:")
    print(df.head(2).to_string(index=False))

    print("\n" + "=" * 70)
    print("DATA LOADER TEST SUCCESSFUL")
    print("=" * 70)


# ============================================================
# MAIN
# ============================================================

if __name__ == "__main__":
    inspect_sample()