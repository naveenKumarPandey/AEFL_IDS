AEFL-OSIDS Proposed v2 Update
==============================

Purpose
-------
This focused update corrects the proposed trainer after the full-data v1
ablation. It does not change the neural-network architecture or dataset.

What changed
------------
1. Weighted loss is normalized by the sum of observed sample weights.
   With focal_gamma=0, it now matches PyTorch weighted cross-entropy.
2. Full inverse-frequency class weights match the successful centralized
   objective (class_weight_power=1.0).
3. Server aggregation is anchored to linear FedAvg sample weights, with only
   a 10% reliability adjustment.
4. Tests cover loss equivalence and FedAvg-anchored aggregation.

Install from PowerShell at the project root
--------------------------------------------
First preserve the v1 ablation:

Copy-Item ".\data\models\robust_adaptive_fedprox_global.pt" ".\data\models\robust_adaptive_fedprox_v1_ablation.pt"
Copy-Item ".\results\robust_adaptive_fedprox" ".\results\robust_adaptive_fedprox_v1_ablation" -Recurse -Force

Then extract this ZIP over:
C:\Users\Naveen Pandey\Desktop\AEFL-OSIDS

Verify
------
python -m py_compile .\federated\robust_adaptive_fedprox.py .\tests\test_robust_components.py
python -m unittest tests.test_robust_components -v

Run
---
python main.py train-proposed

At startup, confirm this line appears:
Proposed v2: class-power=1, focal-gamma=0, sample-power=1, reliability-mix=0.1

Evaluation rule
---------------
Compare the best validation Macro-F1 with the FedAvg reference (about 0.866).
Do not claim an improvement unless the proposed method exceeds it under the
same split, rounds, local epochs, seed, model, and evaluation protocol.
