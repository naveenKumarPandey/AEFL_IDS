from pathlib import Path
import json
import random
import time

import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import TensorDataset

from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    classification_report,
    confusion_matrix,
)

from data_loader.cic_iot_dataset import (
    create_dataset,
    create_dataloader,
)

from models.intrusion_model import (
    create_model,
)

from utils.config import (
    load_config,
)


# ============================================================
# PROJECT ROOT
# ============================================================

PROJECT_ROOT = (
    Path(__file__).resolve().parents[1]
)


# ============================================================
# CLASS NAMES
# ============================================================

CLASS_NAMES = [
    "BENIGN",
    "DDoS",
    "DoS",
    "Mirai",
    "Recon",
]


NUM_CLASSES = len(
    CLASS_NAMES
)


# ============================================================
# EFFICIENT IN-MEMORY TRAINING DATA
# ============================================================

def load_xy_arrays(
    dataset,
):
    """
    Load only X/y into one preallocated pair of arrays.

    Full random shuffling over a one-file NPZ cache causes repeated archive
    decompression, while grouping complete files produces long single-class
    sequences. A compact in-memory X/y representation permits true global
    shuffling without either problem. Metadata remains on disk.
    """

    sample_count = len(dataset)

    X_all = np.empty(
        (sample_count, 39),
        dtype=np.float32,
    )
    y_all = np.empty(
        sample_count,
        dtype=np.int64,
    )

    offset = 0
    file_count = len(dataset.files)

    print()
    print(
        "Loading training X/y into RAM for globally shuffled batches..."
    )

    for file_number, file_path in enumerate(
        dataset.files,
        start=1,
    ):
        with np.load(
            file_path,
            allow_pickle=False,
        ) as data:
            X = np.asarray(
                data["X"],
                dtype=np.float32,
            )
            y = np.asarray(
                data["y"],
                dtype=np.int64,
            )

        end = offset + len(y)
        X_all[offset:end] = X
        y_all[offset:end] = y
        offset = end

        if (
            file_number == 1
            or file_number % 25 == 0
            or file_number == file_count
        ):
            print(
                f"  Files {file_number:,}/{file_count:,} | "
                f"Rows {offset:,}/{sample_count:,}"
            )

    if offset != sample_count:
        raise RuntimeError(
            "Training array size mismatch: "
            f"loaded {offset:,}, expected {sample_count:,}."
        )

    return X_all, y_all


# ============================================================
# REPRODUCIBILITY
# ============================================================

def set_seed(
    seed: int = 42,
) -> None:

    random.seed(seed)

    np.random.seed(seed)

    torch.manual_seed(seed)

    if torch.cuda.is_available():

        torch.cuda.manual_seed_all(
            seed
        )


# ============================================================
# DEVICE
# ============================================================

def get_device():

    if torch.cuda.is_available():

        return torch.device(
            "cuda"
        )

    return torch.device(
        "cpu"
    )


# ============================================================
# CLASS WEIGHTS
# ============================================================

def calculate_class_weights(
    dataset,
    num_classes: int,
    device,
):
    """
    Calculate inverse-frequency class weights.

    Unknown label (-1) is ignored because
    unknown attacks must not occur in training.
    """

    counts = np.zeros(
        num_classes,
        dtype=np.float64,
    )

    for file_path in dataset.files:

        with np.load(
            file_path,
            allow_pickle=False,
        ) as data:

            labels = data["y"]

            valid_labels = labels[
                (labels >= 0)
                & (labels < num_classes)
            ]

            unique, class_counts = (
                np.unique(
                    valid_labels,
                    return_counts=True,
                )
            )

            for label, count in zip(
                unique,
                class_counts,
            ):

                counts[int(label)] += (
                    int(count)
                )

    if np.any(
        counts == 0
    ):

        raise RuntimeError(
            "One or more training classes "
            "have zero samples.\n"
            f"Counts: {counts}"
        )

    total = counts.sum()

    weights = (
        total
        / (
            num_classes
            * counts
        )
    )

    # Normalize average weight to 1.
    weights = (
        weights
        / weights.mean()
    )

    weights_tensor = torch.tensor(
        weights,
        dtype=torch.float32,
        device=device,
    )

    return (
        weights_tensor,
        counts,
    )


# ============================================================
# TRAIN ONE EPOCH
# ============================================================

def train_one_epoch(
    model,
    loader,
    criterion,
    optimizer,
    device,
    epoch,
    total_epochs,
):
    """
    Train for one epoch.

    Progress is printed periodically.
    """

    model.train()

    running_loss = 0.0

    total_samples = 0

    correct = 0

    total_batches = len(
        loader
    )

    epoch_start = time.time()

    print()

    print(
        f"Epoch "
        f"{epoch}/{total_epochs}"
    )

    print(
        "-" * 70
    )

    for batch_index, (
        X,
        y,
    ) in enumerate(
        loader,
        start=1,
    ):

        X = X.to(
            device,
            non_blocking=True,
        )

        y = y.to(
            device,
            non_blocking=True,
        )

        optimizer.zero_grad(
            set_to_none=True
        )

        logits = model(
            X
        )

        loss = criterion(
            logits,
            y,
        )

        loss.backward()

        optimizer.step()

        batch_size = X.size(0)

        running_loss += (
            loss.item()
            * batch_size
        )

        total_samples += (
            batch_size
        )

        predictions = torch.argmax(
            logits,
            dim=1,
        )

        correct += (
            predictions == y
        ).sum().item()

        # ----------------------------------------------------
        # Progress
        # ----------------------------------------------------

        if (
            batch_index == 1
            or batch_index % 25 == 0
            or batch_index == total_batches
        ):

            current_loss = (
                running_loss
                / total_samples
            )

            current_accuracy = (
                correct
                / total_samples
            )

            progress = (
                batch_index
                / total_batches
                * 100
            )

            elapsed = (
                time.time()
                - epoch_start
            )

            print(
                f"  Batch "
                f"{batch_index:>4}/"
                f"{total_batches:<4} "
                f"({progress:>6.2f}%) | "
                f"Loss: "
                f"{current_loss:.5f} | "
                f"Acc: "
                f"{current_accuracy:.5f} | "
                f"Time: "
                f"{elapsed:.1f}s"
            )

    epoch_loss = (
        running_loss
        / total_samples
    )

    epoch_accuracy = (
        correct
        / total_samples
    )

    epoch_time = (
        time.time()
        - epoch_start
    )

    return (
        epoch_loss,
        epoch_accuracy,
        epoch_time,
    )


# ============================================================
# EVALUATION
# ============================================================

def evaluate(
    model,
    loader,
    device,
):
    """
    Evaluate model on known classes.
    """

    model.eval()

    all_predictions = []

    all_targets = []

    total_loss = 0.0

    total_samples = 0

    criterion = (
        nn.CrossEntropyLoss()
    )

    with torch.no_grad():

        for X, y in loader:

            X = X.to(
                device,
                non_blocking=True,
            )

            y = y.to(
                device,
                non_blocking=True,
            )

            logits = model(
                X
            )

            loss = criterion(
                logits,
                y,
            )

            batch_size = X.size(0)

            total_loss += (
                loss.item()
                * batch_size
            )

            total_samples += (
                batch_size
            )

            predictions = (
                torch.argmax(
                    logits,
                    dim=1,
                )
            )

            all_predictions.extend(
                predictions
                .cpu()
                .numpy()
                .tolist()
            )

            all_targets.extend(
                y.cpu()
                .numpy()
                .tolist()
            )

    y_true = np.asarray(
        all_targets,
        dtype=np.int64,
    )

    y_pred = np.asarray(
        all_predictions,
        dtype=np.int64,
    )

    metrics = {

        "loss":
            float(
                total_loss
                / total_samples
            ),

        "accuracy":
            float(
                accuracy_score(
                    y_true,
                    y_pred,
                )
            ),

        "precision_macro":
            float(
                precision_score(
                    y_true,
                    y_pred,
                    average="macro",
                    zero_division=0,
                )
            ),

        "recall_macro":
            float(
                recall_score(
                    y_true,
                    y_pred,
                    average="macro",
                    zero_division=0,
                )
            ),

        "f1_macro":
            float(
                f1_score(
                    y_true,
                    y_pred,
                    average="macro",
                    zero_division=0,
                )
            ),

        "precision_weighted":
            float(
                precision_score(
                    y_true,
                    y_pred,
                    average="weighted",
                    zero_division=0,
                )
            ),

        "recall_weighted":
            float(
                recall_score(
                    y_true,
                    y_pred,
                    average="weighted",
                    zero_division=0,
                )
            ),

        "f1_weighted":
            float(
                f1_score(
                    y_true,
                    y_pred,
                    average="weighted",
                    zero_division=0,
                )
            ),
    }

    report = classification_report(
        y_true,
        y_pred,
        labels=list(
            range(NUM_CLASSES)
        ),
        target_names=CLASS_NAMES,
        zero_division=0,
    )

    cm = confusion_matrix(
        y_true,
        y_pred,
        labels=list(
            range(NUM_CLASSES)
        ),
    )

    return (
        metrics,
        report,
        cm,
    )


# ============================================================
# SAVE JSON
# ============================================================

def save_json(
    data,
    path: Path,
) -> None:

    path.parent.mkdir(
        parents=True,
        exist_ok=True,
    )

    with open(
        path,
        "w",
        encoding="utf-8",
    ) as file:

        json.dump(
            data,
            file,
            indent=4,
        )


# ============================================================
# MAIN
# ============================================================

def main():

    print("=" * 70)
    print(
        "AEFL-OSIDS CENTRALIZED BASELINE"
    )
    print("=" * 70)

    # --------------------------------------------------------
    # Configuration
    # --------------------------------------------------------

    config = load_config()

    seed = config[
        "reproducibility"
    ]["seed"]

    batch_size = config[
        "training"
    ]["batch_size"]

    # "epochs" (total centralized training epochs) is a distinct knob from
    # "local_epochs" (per-round local epochs for federated clients). Fall
    # back to local_epochs only for old config files that predate this key,
    # so a stale config does not silently cap training at a handful of
    # epochs again.
    epochs = config["training"].get(
        "epochs",
        config["training"]["local_epochs"],
    )

    early_stopping_patience = config["training"].get(
        "early_stopping_patience",
        8,
    )

    learning_rate = config[
        "training"
    ]["learning_rate"]

    weight_decay = config[
        "training"
    ]["weight_decay"]

    set_seed(
        seed
    )

    # --------------------------------------------------------
    # Device
    # --------------------------------------------------------

    device = get_device()

    print()

    print(
        f"Device: {device}"
    )

    # --------------------------------------------------------
    # Scenario
    # --------------------------------------------------------

    scenario_name = config[
        "openset"
    ]["primary_scenario"]

    print(
        f"Scenario: "
        f"{scenario_name}"
    )

    # --------------------------------------------------------
    # Training configuration
    # --------------------------------------------------------

    print()

    print(
        "Training configuration:"
    )

    print(
        f"  Batch size: "
        f"{batch_size}"
    )

    print(
        f"  Epochs: "
        f"{epochs}"
    )

    print(
        f"  Learning rate: "
        f"{learning_rate}"
    )

    print(
        f"  Weight decay: "
        f"{weight_decay}"
    )

    # --------------------------------------------------------
    # Dataset
    # --------------------------------------------------------

    print()

    print(
        "Loading datasets..."
    )

    train_source_dataset = create_dataset(
        scenario_name,
        "train",
    )

    validation_dataset = (
        create_dataset(
            scenario_name,
            "validation",
        )
    )

    print(
        f"Train samples: "
        f"{len(train_source_dataset):,}"
    )

    print(
        f"Validation samples: "
        f"{len(validation_dataset):,}"
    )

    # --------------------------------------------------------
    # In-memory training X/y and DataLoaders
    # --------------------------------------------------------

    train_X, train_y = load_xy_arrays(
        train_source_dataset
    )

    train_dataset = TensorDataset(
        torch.from_numpy(train_X),
        torch.from_numpy(train_y),
    )

    train_loader = (
        create_dataloader(
            train_dataset,
            batch_size=batch_size,
            shuffle=True,
        )
    )

    validation_loader = (
        create_dataloader(
            validation_dataset,
            batch_size=batch_size,
            shuffle=False,
        )
    )

    print()

    print(
        f"Train batches per epoch: "
        f"{len(train_loader):,}"
    )

    print(
        f"Validation batches: "
        f"{len(validation_loader):,}"
    )

    # --------------------------------------------------------
    # Model
    # --------------------------------------------------------

    model = create_model(
        input_features=39,
        num_classes=NUM_CLASSES,
    )

    model.to(
        device
    )

    # --------------------------------------------------------
    # Class weights
    # --------------------------------------------------------

    (
        class_weights,
        class_counts,
    ) = calculate_class_weights(
        train_source_dataset,
        NUM_CLASSES,
        device,
    )

    print()

    print(
        "Training class weights:"
    )

    for name, count, weight in zip(
        CLASS_NAMES,
        class_counts,
        class_weights.cpu().numpy(),
    ):

        print(
            f"  {name:<10} "
            f"{int(count):>10,} "
            f"weight={weight:.4f}"
        )

    # --------------------------------------------------------
    # Loss
    # --------------------------------------------------------

    criterion = (
        nn.CrossEntropyLoss(
            weight=class_weights
        )
    )

    # --------------------------------------------------------
    # Optimizer
    # --------------------------------------------------------

    optimizer = torch.optim.Adam(
        model.parameters(),
        lr=learning_rate,
        weight_decay=weight_decay,
    )

    # --------------------------------------------------------
    # Output directories
    # --------------------------------------------------------

    model_dir = (
        PROJECT_ROOT
        / "data"
        / "models"
    )

    results_dir = (
        PROJECT_ROOT
        / "results"
        / "centralized_baseline"
    )

    model_dir.mkdir(
        parents=True,
        exist_ok=True,
    )

    results_dir.mkdir(
        parents=True,
        exist_ok=True,
    )

    best_model_path = (
        model_dir
        / "centralized_baseline.pt"
    )

    # --------------------------------------------------------
    # Training
    # --------------------------------------------------------

    print()
    print("=" * 70)
    print(
        "TRAINING STARTED"
    )
    print("=" * 70)

    history = []

    best_f1 = -1.0

    epochs_without_improvement = 0

    training_start = time.time()

    for epoch in range(
        1,
        epochs + 1,
    ):

        (
            train_loss,
            train_accuracy,
            epoch_time,
        ) = train_one_epoch(
            model=model,
            loader=train_loader,
            criterion=criterion,
            optimizer=optimizer,
            device=device,
            epoch=epoch,
            total_epochs=epochs,
        )

        # ----------------------------------------------------
        # Validation
        # ----------------------------------------------------

        validation_start = (
            time.time()
        )

        (
            validation_metrics,
            _,
            _,
        ) = evaluate(
            model,
            validation_loader,
            device,
        )

        validation_time = (
            time.time()
            - validation_start
        )

        record = {

            "epoch": epoch,

            "train_loss":
                float(train_loss),

            "train_accuracy":
                float(train_accuracy),

            "validation_loss":
                float(
                    validation_metrics[
                        "loss"
                    ]
                ),

            "validation_accuracy":
                float(
                    validation_metrics[
                        "accuracy"
                    ]
                ),

            "validation_precision_macro":
                float(
                    validation_metrics[
                        "precision_macro"
                    ]
                ),

            "validation_recall_macro":
                float(
                    validation_metrics[
                        "recall_macro"
                    ]
                ),

            "validation_f1_macro":
                float(
                    validation_metrics[
                        "f1_macro"
                    ]
                ),

            "epoch_time_seconds":
                float(epoch_time),

            "validation_time_seconds":
                float(validation_time),
        }

        history.append(
            record
        )

        print()

        print(
            "=" * 70
        )

        print(
            f"EPOCH {epoch} SUMMARY"
        )

        print(
            "=" * 70
        )

        print(
            f"Train Loss       : "
            f"{train_loss:.6f}"
        )

        print(
            f"Train Accuracy   : "
            f"{train_accuracy:.6f}"
        )

        print(
            f"Val Loss         : "
            f"{validation_metrics['loss']:.6f}"
        )

        print(
            f"Val Accuracy     : "
            f"{validation_metrics['accuracy']:.6f}"
        )

        print(
            f"Val Macro-F1     : "
            f"{validation_metrics['f1_macro']:.6f}"
        )

        print(
            f"Epoch Time       : "
            f"{epoch_time:.2f}s"
        )

        # ----------------------------------------------------
        # Best model
        # ----------------------------------------------------

        current_f1 = (
            validation_metrics[
                "f1_macro"
            ]
        )

        if current_f1 > best_f1:

            best_f1 = current_f1

            epochs_without_improvement = 0

            torch.save(
                {
                    "model_state_dict":
                        model.state_dict(),

                    "input_features":
                        39,

                    "num_classes":
                        NUM_CLASSES,

                    "class_names":
                        CLASS_NAMES,

                    "scenario":
                        scenario_name,

                    "epoch":
                        epoch,

                    "validation_f1_macro":
                        current_f1,
                },
                best_model_path,
            )

            print()

            print(
                "✓ New best model saved."
            )

        else:

            epochs_without_improvement += 1

            print()

            print(
                f"No improvement for "
                f"{epochs_without_improvement} epoch(s) "
                f"(best Macro-F1={best_f1:.6f})."
            )

            if epochs_without_improvement >= early_stopping_patience:

                print()

                print(
                    "Early stopping: validation Macro-F1 has not "
                    f"improved for {early_stopping_patience} epochs."
                )

                break

    total_training_time = (
        time.time()
        - training_start
    )

    # --------------------------------------------------------
    # Save history
    # --------------------------------------------------------

    history_path = (
        results_dir
        / "training_history.json"
    )

    save_json(
        history,
        history_path,
    )

    # --------------------------------------------------------
    # Load best checkpoint
    # --------------------------------------------------------

    checkpoint = torch.load(
        best_model_path,
        map_location=device,
    )

    model.load_state_dict(
        checkpoint[
            "model_state_dict"
        ]
    )

    # --------------------------------------------------------
    # Final validation
    # --------------------------------------------------------

    (
        final_metrics,
        final_report,
        final_cm,
    ) = evaluate(
        model,
        validation_loader,
        device,
    )

    # --------------------------------------------------------
    # Save final metrics
    # --------------------------------------------------------

    metrics_path = (
        results_dir
        / "validation_metrics.json"
    )

    save_json(
        final_metrics,
        metrics_path,
    )

    # --------------------------------------------------------
    # Save classification report
    # --------------------------------------------------------

    report_path = (
        results_dir
        / "classification_report.txt"
    )

    with open(
        report_path,
        "w",
        encoding="utf-8",
    ) as file:

        file.write(
            final_report
        )

    # --------------------------------------------------------
    # Save confusion matrix
    # --------------------------------------------------------

    cm_path = (
        results_dir
        / "confusion_matrix.npy"
    )

    np.save(
        cm_path,
        final_cm,
    )

    # --------------------------------------------------------
    # Training metadata
    # --------------------------------------------------------

    metadata = {

        "scenario":
            scenario_name,

        "device":
            str(device),

        "seed":
            seed,

        "batch_size":
            batch_size,

        "epochs":
            epochs,

        "learning_rate":
            learning_rate,

        "weight_decay":
            weight_decay,

        "train_samples":
            len(train_dataset),

        "validation_samples":
            len(validation_dataset),

        "total_training_time_seconds":
            total_training_time,

        "best_validation_f1_macro":
            best_f1,
    }

    metadata_path = (
        results_dir
        / "training_metadata.json"
    )

    save_json(
        metadata,
        metadata_path,
    )

    # --------------------------------------------------------
    # Final result
    # --------------------------------------------------------

    print()

    print("=" * 70)

    print(
        "CENTRALIZED BASELINE RESULT"
    )

    print("=" * 70)

    print()

    for key, value in (
        final_metrics.items()
    ):

        print(
            f"{key:<25}: "
            f"{value:.6f}"
        )

    print()

    print(
        "Classification Report:"
    )

    print(
        final_report
    )

    print(
        "Confusion Matrix:"
    )

    print(
        final_cm
    )

    print()

    print(
        f"Total training time: "
        f"{total_training_time:.2f}s"
    )

    print()

    print(
        "Best model:"
    )

    print(
        best_model_path
    )

    print()

    print(
        "Results:"
    )

    print(
        results_dir
    )

    print()

    print("=" * 70)

    print(
        "CENTRALIZED BASELINE "
        "TRAINING COMPLETE"
    )

    print("=" * 70)


# ============================================================
# ENTRY POINT
# ============================================================

if __name__ == "__main__":
    main()
