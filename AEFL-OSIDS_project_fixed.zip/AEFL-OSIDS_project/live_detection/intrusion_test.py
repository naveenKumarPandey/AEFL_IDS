"""
AEFL-OSIDS bounded SYN-burst intrusion test.

PURPOSE
-------
Generate a short, controlled TCP SYN-heavy flow on a private/local network so
the existing AEFL-OSIDS live packet capture + rule engine can be tested.

SAFETY
------
- Refuses public Internet targets.
- Maximum 200 packets.
- No IP spoofing.
- No continuous mode.
- Intended only for devices you own or are authorized to test.

Example:
    python live_detection/intrusion_test.py --target 172.20.39.176 --port 8765
"""

from __future__ import annotations

import argparse
import ipaddress
import sys
import time

from scapy.all import IP, TCP, conf, send


MAX_PACKETS = 200
DEFAULT_PACKETS = 120
DEFAULT_SOURCE_PORT = 40000


def private_or_loopback(value: str) -> bool:
    try:
        ip = ipaddress.ip_address(value)
    except ValueError:
        return False

    return bool(
        ip.is_private
        or ip.is_loopback
        or ip.is_link_local
    )


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Send one short bounded TCP SYN burst to an authorized "
            "private/local target for AEFL-OSIDS testing."
        )
    )
    parser.add_argument(
        "--target",
        required=True,
        help="Private/local IPv4 target, e.g. 172.20.39.176",
    )
    parser.add_argument(
        "--port",
        type=int,
        default=8765,
        help="Destination TCP port (default: 8765)",
    )
    parser.add_argument(
        "--count",
        type=int,
        default=DEFAULT_PACKETS,
        help=f"SYN packet count, 50-{MAX_PACKETS} (default: {DEFAULT_PACKETS})",
    )
    parser.add_argument(
        "--sport",
        type=int,
        default=DEFAULT_SOURCE_PORT,
        help=f"Fixed source port (default: {DEFAULT_SOURCE_PORT})",
    )
    return parser.parse_args()


def validate(args: argparse.Namespace) -> None:
    if not private_or_loopback(args.target):
        raise ValueError(
            "Refusing target: this test only permits private, loopback, "
            "or link-local IP addresses."
        )

    if not 1 <= args.port <= 65535:
        raise ValueError("Destination port must be between 1 and 65535.")

    if not 1 <= args.sport <= 65535:
        raise ValueError("Source port must be between 1 and 65535.")

    if not 50 <= args.count <= MAX_PACKETS:
        raise ValueError(
            f"Packet count must be between 50 and {MAX_PACKETS}."
        )


def main() -> int:
    args = parse_args()

    try:
        validate(args)
    except ValueError as exc:
        print(f"ERROR: {exc}")
        return 2

    packets = [
        IP(dst=args.target)
        / TCP(
            sport=args.sport,
            dport=args.port,
            flags="S",
            seq=100000 + i,
        )
        for i in range(args.count)
    ]

    print("=" * 68)
    print("AEFL-OSIDS CONTROLLED SYN-BURST TEST")
    print("=" * 68)
    print(f"Target        : {args.target}:{args.port}")
    print(f"Source port   : {args.sport}")
    print(f"Packets       : {args.count}")
    print(f"Scapy iface   : {conf.iface}")
    print("Public targets: BLOCKED")
    print()
    print("Sending one bounded burst...")

    started = time.perf_counter()

    # One finite burst only. No loop, no spoofing, no background process.
    send(
        packets,
        inter=0,
        verbose=False,
    )

    elapsed = max(time.perf_counter() - started, 1e-9)
    approx_rate = args.count / elapsed

    print("Burst complete.")
    print(f"Elapsed       : {elapsed:.4f} s")
    print(f"Approx rate   : {approx_rate:.1f} packets/s")
    print()
    print("Now check AEFL-OSIDS for:")
    print("  - triggered rule(s)")
    print("  - rule risk")
    print("  - ML class")
    print("  - final hybrid decision")
    print("=" * 68)

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
