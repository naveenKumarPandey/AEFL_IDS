"""
AEFL-OSIDS Real-Time Packet Capture

Converts live Scapy packets into PacketInfo objects and sends them
to FlowManager.

Pipeline:

    Network Interface
          |
          v
       Scapy
          |
          v
    PacketInfo
          |
          v
     FlowManager
          |
          v
    Completed Flow

This module does NOT:
- train the model
- modify model weights
- perform ML classification
- generate attack traffic
- execute countermeasures

It only captures and normalizes packets.

Requirements:
    pip install scapy

Windows:
    Npcap is normally required for live capture.
"""

from __future__ import annotations

import argparse
import sys
import time
from typing import Callable, List, Optional

from .flow_manager import (
    FlowManager,
    FlowRecord,
    PacketInfo,
    create_packet_info,
)


# ============================================================
# OPTIONAL SCAPY IMPORT
# ============================================================

try:
    from scapy.all import (
        AsyncSniffer,
        Ether,
        ICMP,
        IP,
        IPv6,
        TCP,
        UDP,
        LLC,
    )

    SCAPY_AVAILABLE = True

except ImportError:
    AsyncSniffer = None
    Ether = None
    ICMP = None
    IP = None
    IPv6 = None
    TCP = None
    UDP = None
    LLC = None

    SCAPY_AVAILABLE = False


# ============================================================
# CONFIGURATION
# ============================================================

DEFAULT_INTERFACE = None

DEFAULT_FLOW_TIMEOUT = 15.0
DEFAULT_MAX_FLOW_DURATION = 120.0

DEFAULT_BPF_FILTER = (
    "ip or ip6"
)


# ============================================================
# TYPES
# ============================================================

FlowCallback = Callable[
    [FlowRecord],
    None,
]


# ============================================================
# PACKET CAPTURE CLASS
# ============================================================

class PacketCapture:
    """
    Real-time Scapy packet capture connected to FlowManager.

    Example:

        manager = FlowManager()

        capture = PacketCapture(
            flow_manager=manager
        )

        capture.start()

    The capture runs until stop() is called or Ctrl+C is used.
    """

    def __init__(
        self,
        flow_manager: Optional[FlowManager] = None,
        interface: Optional[str] = DEFAULT_INTERFACE,
        bpf_filter: str = DEFAULT_BPF_FILTER,
        flow_timeout: float = DEFAULT_FLOW_TIMEOUT,
        max_flow_duration: float = DEFAULT_MAX_FLOW_DURATION,
        flow_callback: Optional[FlowCallback] = None,
    ) -> None:

        if not SCAPY_AVAILABLE:
            raise RuntimeError(
                "Scapy is not installed.\n"
                "Install it with:\n"
                "  pip install scapy"
            )

        self.flow_manager = (
            flow_manager
            if flow_manager is not None
            else FlowManager(
                flow_timeout=flow_timeout,
                max_flow_duration=max_flow_duration,
            )
        )

        self.interface = interface

        self.bpf_filter = (
            bpf_filter
        )

        self.flow_callback = (
            flow_callback
        )

        self._sniffer = None

        self._running = False

        self.captured_packets = 0
        self.ignored_packets = 0

        self.completed_flows = 0

    # ========================================================
    # PACKET NORMALIZATION
    # ========================================================

    @staticmethod
    def packet_to_info(
        packet,
    ) -> Optional[PacketInfo]:
        """
        Convert a Scapy packet into PacketInfo.

        Returns None for packets that do not contain IP/IPv6
        network-layer information.
        """

        if not SCAPY_AVAILABLE:
            raise RuntimeError(
                "Scapy is not available."
            )

        # ----------------------------------------------------
        # Timestamp
        # ----------------------------------------------------

        try:
            timestamp = float(
                packet.time
            )
        except Exception:
            timestamp = time.time()

        # ----------------------------------------------------
        # IPv4
        # ----------------------------------------------------

        if packet.haslayer(IP):

            ip_layer = packet.getlayer(IP)

            src_ip = str(
                ip_layer.src
            )

            dst_ip = str(
                ip_layer.dst
            )

            protocol = int(
                ip_layer.proto
            )

            ttl = int(
                getattr(
                    ip_layer,
                    "ttl",
                    0,
                )
            )

        # ----------------------------------------------------
        # IPv6
        # ----------------------------------------------------

        elif packet.haslayer(IPv6):

            ip_layer = packet.getlayer(
                IPv6
            )

            src_ip = str(
                ip_layer.src
            )

            dst_ip = str(
                ip_layer.dst
            )

            protocol = int(
                getattr(
                    ip_layer,
                    "nh",
                    0,
                )
            )

            ttl = int(
                getattr(
                    ip_layer,
                    "hlim",
                    0,
                )
            )

        else:

            return None

        # ----------------------------------------------------
        # Ports
        # ----------------------------------------------------

        src_port = 0
        dst_port = 0

        if packet.haslayer(TCP):

            transport = packet.getlayer(
                TCP
            )

            src_port = int(
                transport.sport
            )

            dst_port = int(
                transport.dport
            )

            protocol = 6

        elif packet.haslayer(UDP):

            transport = packet.getlayer(
                UDP
            )

            src_port = int(
                transport.sport
            )

            dst_port = int(
                transport.dport
            )

            protocol = 17

        elif packet.haslayer(ICMP):

            protocol = 1

        # ----------------------------------------------------
        # Packet length
        # ----------------------------------------------------

        try:
            packet_length = int(
                len(packet)
            )
        except Exception:
            packet_length = 0

        # ----------------------------------------------------
        # Payload length
        # ----------------------------------------------------

        payload_length = 0

        try:

            if packet.haslayer(TCP):

                tcp = packet.getlayer(
                    TCP
                )

                if tcp.payload is not None:
                    payload_length = int(
                        len(tcp.payload)
                    )

            elif packet.haslayer(UDP):

                udp = packet.getlayer(
                    UDP
                )

                if udp.payload is not None:
                    payload_length = int(
                        len(udp.payload)
                    )

        except Exception:

            payload_length = 0

        # ----------------------------------------------------
        # IP version and IP header length
        # ----------------------------------------------------

        ip_version = 0
        ip_header_length = 0

        if packet.haslayer(IP):
            ip_version = 4
            try:
                ip_header_length = int(ip_layer.ihl) * 4
                if ip_header_length <= 0:
                    ip_header_length = 20
            except Exception:
                ip_header_length = 20

        elif packet.haslayer(IPv6):
            ip_version = 6
            ip_header_length = 40

        # ----------------------------------------------------
        # Transport header length
        # ----------------------------------------------------

        transport_header_length = 0

        if packet.haslayer(TCP):
            tcp = packet.getlayer(TCP)
            try:
                transport_header_length = int(tcp.dataofs) * 4
                if transport_header_length <= 0:
                    transport_header_length = 20
            except Exception:
                transport_header_length = 20

        elif packet.haslayer(UDP):
            transport_header_length = 8

        elif packet.haslayer(ICMP):
            transport_header_length = 8

        # ----------------------------------------------------
        # TCP flags
        # ----------------------------------------------------

        tcp_flags = 0
        ece_flag = 0
        cwr_flag = 0

        if packet.haslayer(TCP):
            tcp = packet.getlayer(TCP)

            try:
                tcp_flags = int(tcp.flags)
            except Exception:
                tcp_flags = 0

            ece_flag = 1 if (tcp_flags & 0x40) else 0
            cwr_flag = 1 if (tcp_flags & 0x80) else 0

        # ----------------------------------------------------
        # LLC presence
        # ----------------------------------------------------

        llc_present = 0

        try:
            if (
                Ether is not None
                and LLC is not None
                and packet.haslayer(Ether)
            ):
                ether = packet.getlayer(Ether)
                ether_type = getattr(ether, "type", None)

                if (
                    ether_type is not None
                    and int(ether_type) <= 1500
                    and packet.haslayer(LLC)
                ):
                    llc_present = 1
        except Exception:
            llc_present = 0

        # ----------------------------------------------------
        # Create normalized packet
        # ----------------------------------------------------

        return create_packet_info(
            timestamp=timestamp,

            src_ip=src_ip,
            dst_ip=dst_ip,

            src_port=src_port,
            dst_port=dst_port,

            protocol=protocol,

            packet_length=packet_length,
            payload_length=payload_length,

            tcp_flags=tcp_flags,

            ttl=ttl,

            ip_version=ip_version,
            ip_header_length=ip_header_length,
            transport_header_length=transport_header_length,
            llc_present=llc_present,
        )

    # ========================================================
    # PACKET HANDLER
    # ========================================================

    def _handle_packet(
        self,
        packet,
    ) -> None:
        """
        Process one captured Scapy packet.
        """

        self.captured_packets += 1

        try:

            packet_info = (
                self.packet_to_info(
                    packet
                )
            )

        except Exception as exc:

            self.ignored_packets += 1

            print(
                "[WARN] Packet normalization failed:",
                exc,
            )

            return

        if packet_info is None:

            self.ignored_packets += 1

            return

        try:

            completed = (
                self.flow_manager.add_packet(
                    packet_info
                )
            )

        except Exception as exc:

            self.ignored_packets += 1

            print(
                "[WARN] Flow processing failed:",
                exc,
            )

            return

        # ----------------------------------------------------
        # Completed flows
        # ----------------------------------------------------

        for flow in completed:

            self.completed_flows += 1

            self._emit_completed_flow(
                flow
            )

    # ========================================================
    # COMPLETED FLOW CALLBACK
    # ========================================================

    def _emit_completed_flow(
        self,
        flow: FlowRecord,
    ) -> None:
        """
        Send a completed flow to the next processing stage.

        Currently this uses an optional callback.

        Later this callback will connect to:

            Feature Extraction
                    |
                    +----> ML Detector
                    |
                    +----> Rule Engine
                    |
                    +----> Decision Fusion
        """

        if self.flow_callback is not None:

            try:

                self.flow_callback(
                    flow
                )

            except Exception as exc:

                print(
                    "[WARN] Flow callback failed:",
                    exc,
                )

        else:

            self._print_flow_summary(
                flow
            )

    # ========================================================
    # FLOW SUMMARY
    # ========================================================

    @staticmethod
    def _print_flow_summary(
        flow: FlowRecord,
    ) -> None:

        protocol_names = {
            1: "ICMP",
            6: "TCP",
            17: "UDP",
        }

        protocol = protocol_names.get(
            flow.protocol,
            str(flow.protocol),
        )

        print()
        print(
            "-" * 70
        )

        print(
            "COMPLETED FLOW"
        )

        print(
            f"  Source      : "
            f"{flow.forward_src_ip}:"
            f"{flow.forward_src_port}"
        )

        print(
            f"  Destination : "
            f"{flow.forward_dst_ip}:"
            f"{flow.forward_dst_port}"
        )

        print(
            f"  Protocol    : "
            f"{protocol}"
        )

        print(
            f"  Duration    : "
            f"{flow.duration:.3f}s"
        )

        print(
            f"  Packets     : "
            f"{flow.packet_count}"
        )

        print(
            f"  Bytes       : "
            f"{flow.byte_count}"
        )

        print(
            f"  Forward     : "
            f"{flow.forward_packet_count} packets / "
            f"{flow.forward_byte_count} bytes"
        )

        print(
            f"  Backward    : "
            f"{flow.backward_packet_count} packets / "
            f"{flow.backward_byte_count} bytes"
        )

        print(
            f"  Packet rate : "
            f"{flow.packets_per_second:.2f} pkt/s"
        )

        print(
            "-" * 70
        )

    # ========================================================
    # START
    # ========================================================

    def start(
        self,
        blocking: bool = True,
    ) -> None:
        """
        Start live packet capture.

        blocking=True:
            Capture until stop() or Ctrl+C.

        blocking=False:
            Start background capture and return immediately.
        """

        if self._running:
            print(
                "[INFO] Packet capture is already running."
            )

            return

        print()
        print(
            "=" * 70
        )

        print(
            "AEFL-OSIDS REAL-TIME PACKET CAPTURE"
        )

        print(
            "=" * 70
        )

        print(
            f"Interface : "
            f"{self.interface or 'default'}"
        )

        print(
            f"Filter    : "
            f"{self.bpf_filter}"
        )

        print(
            f"Flow timeout : "
            f"{self.flow_manager.flow_timeout}s"
        )

        print(
            f"Max duration: "
            f"{self.flow_manager.max_flow_duration}s"
        )

        print()

        print(
            "Starting live capture..."
        )

        print(
            "Press Ctrl+C to stop."
        )

        print()

        try:

            self._sniffer = AsyncSniffer(
                iface=self.interface,
                filter=self.bpf_filter,
                prn=self._handle_packet,
                store=False,
            )

            self._sniffer.start()

            self._running = True

        except Exception as exc:

            self._running = False

            raise RuntimeError(
                "Unable to start live packet capture.\n"
                f"Interface: {self.interface}\n"
                f"Filter: {self.bpf_filter}\n"
                f"Error: {exc}"
            ) from exc

        if blocking:

            try:

                while self._running:

                    time.sleep(
                        1.0
                    )

                    self._expire_inactive_flows()

            except KeyboardInterrupt:

                print()
                print(
                    "Stopping capture..."
                )

                self.stop()

    # ========================================================
    # EXPIRE INACTIVE FLOWS
    # ========================================================

    def _expire_inactive_flows(
        self,
    ) -> None:

        try:

            completed = (
                self.flow_manager.expire_flows()
            )

        except Exception as exc:

            print(
                "[WARN] Flow expiration failed:",
                exc,
            )

            return

        for flow in completed:

            self.completed_flows += 1

            self._emit_completed_flow(
                flow
            )

    # ========================================================
    # STOP
    # ========================================================

    def stop(self) -> List[FlowRecord]:
        """
        Stop capture and flush active flows.

        Returns:
            List of flows completed during shutdown.
        """

        if self._sniffer is not None:

            try:

                self._sniffer.stop()

            except Exception as exc:

                print(
                    "[WARN] Sniffer stop failed:",
                    exc,
                )

        self._sniffer = None

        self._running = False

        completed = (
            self.flow_manager.flush()
        )

        for flow in completed:

            self.completed_flows += 1

            self._emit_completed_flow(
                flow
            )

        print()
        print(
            "=" * 70
        )

        print(
            "CAPTURE STOPPED"
        )

        print(
            f"Captured packets : "
            f"{self.captured_packets:,}"
        )

        print(
            f"Ignored packets  : "
            f"{self.ignored_packets:,}"
        )

        print(
            f"Completed flows  : "
            f"{self.completed_flows:,}"
        )

        print(
            f"Active flows     : "
            f"{self.flow_manager.active_flow_count():,}"
        )

        print(
            "=" * 70
        )

        return completed

    # ========================================================
    # STATUS
    # ========================================================

    @property
    def running(self) -> bool:
        """Return whether capture is currently running."""

        return self._running

    # ========================================================
    # STATISTICS
    # ========================================================

    def statistics(self):
        """
        Return capture and flow statistics.
        """

        result = {
            "capture": {
                "running": self._running,

                "captured_packets": int(
                    self.captured_packets
                ),

                "ignored_packets": int(
                    self.ignored_packets
                ),

                "completed_flows": int(
                    self.completed_flows
                ),
            },

            "flows": self.flow_manager.statistics(),
        }

        return result


# ============================================================
# OFFLINE PACKET TEST
# ============================================================

def build_test_packets():
    """
    Create synthetic Scapy packets for local testing.

    This does NOT send packets onto the network.

    It only constructs packet objects in memory.
    """

    if not SCAPY_AVAILABLE:
        raise RuntimeError(
            "Scapy is required for packet tests."
        )

    packets = []

    packets.append(
        Ether()
        / IP(
            src="192.168.1.10",
            dst="192.168.1.20",
            ttl=64,
        )
        / TCP(
            sport=50000,
            dport=80,
            flags="S",
        )
    )

    packets.append(
        Ether()
        / IP(
            src="192.168.1.20",
            dst="192.168.1.10",
            ttl=64,
        )
        / TCP(
            sport=80,
            dport=50000,
            flags="SA",
        )
    )

    packets.append(
        Ether()
        / IP(
            src="192.168.1.10",
            dst="192.168.1.20",
            ttl=64,
        )
        / TCP(
            sport=50000,
            dport=80,
            flags="A",
        )
        / b"GET / HTTP/1.1"
    )

    return packets


def run_packet_conversion_test() -> None:
    """
    Test Scapy -> PacketInfo conversion without live capture.
    """

    print("=" * 70)
    print("AEFL-OSIDS PACKET CONVERSION TEST")
    print("=" * 70)

    if not SCAPY_AVAILABLE:

        print()
        print(
            "[FAIL] Scapy is not installed."
        )

        print(
            "Install it with:"
        )

        print(
            "  pip install scapy"
        )

        return

    packets = build_test_packets()

    manager = FlowManager(
        flow_timeout=5.0,
        max_flow_duration=60.0,
    )

    capture = PacketCapture(
        flow_manager=manager
    )

    print()
    print(
        f"Test packets: {len(packets)}"
    )

    converted = 0

    for packet in packets:

        info = (
            capture.packet_to_info(
                packet
            )
        )

        if info is None:
            continue

        converted += 1

        print()
        print(
            f"Packet {converted}:"
        )

        print(
            f"  Source      : "
            f"{info.src_ip}:"
            f"{info.src_port}"
        )

        print(
            f"  Destination : "
            f"{info.dst_ip}:"
            f"{info.dst_port}"
        )

        print(
            f"  Protocol    : "
            f"{info.protocol}"
        )

        print(
            f"  Length      : "
            f"{info.packet_length}"
        )

        print(
            f"  Payload     : "
            f"{info.payload_length}"
        )

        print(
            f"  TCP flags   : "
            f"{info.tcp_flags}"
        )

        manager.add_packet(
            info
        )

    completed = manager.flush()

    print()
    print(
        "=" * 70
    )

    print(
        "TEST RESULTS"
    )

    print(
        f"Packets converted : "
        f"{converted}"
    )

    print(
        f"Active flows      : "
        f"{manager.active_flow_count()}"
    )

    print(
        f"Completed flows   : "
        f"{len(completed)}"
    )

    if converted != len(packets):
        raise RuntimeError(
            "Packet conversion test failed."
        )

    if len(completed) != 1:
        raise RuntimeError(
            "Flow aggregation test failed: "
            "expected one bidirectional flow."
        )

    flow = completed[0]

    if flow.packet_count != 3:
        raise RuntimeError(
            "Expected three packets in the flow."
        )

    print()
    print(
        "PACKET CAPTURE MODULE TEST SUCCESSFUL"
    )

    print(
        "=" * 70
    )


# ============================================================
# LIVE CAPTURE
# ============================================================

def run_live_capture(
    interface: Optional[str],
    packet_filter: str,
) -> None:
    """
    Start live packet capture.

    At this stage completed flows are only displayed.
    The ML/rule pipeline will be attached in later modules.
    """

    manager = FlowManager(
        flow_timeout=DEFAULT_FLOW_TIMEOUT,
        max_flow_duration=DEFAULT_MAX_FLOW_DURATION,
    )

    capture = PacketCapture(
        flow_manager=manager,
        interface=interface,
        bpf_filter=packet_filter,
    )

    capture.start(
        blocking=True
    )


# ============================================================
# COMMAND LINE
# ============================================================

def parse_arguments():
    parser = argparse.ArgumentParser(
        description=(
            "AEFL-OSIDS real-time packet capture"
        )
    )

    parser.add_argument(
        "--test",
        action="store_true",
        help=(
            "Run offline packet conversion test. "
            "No network traffic is captured."
        ),
    )

    parser.add_argument(
        "--live",
        action="store_true",
        help=(
            "Start live packet capture."
        ),
    )

    parser.add_argument(
        "--interface",
        default=None,
        help=(
            "Network interface to capture from. "
            "If omitted, Scapy uses the default interface."
        ),
    )

    parser.add_argument(
        "--filter",
        default=DEFAULT_BPF_FILTER,
        help=(
            "BPF capture filter."
        ),
    )

    return parser.parse_args()


# ============================================================
# MAIN
# ============================================================

def main() -> None:

    args = parse_arguments()

    # --------------------------------------------------------
    # Default behavior
    # --------------------------------------------------------

    if not args.test and not args.live:

        print(
            "No mode selected."
        )

        print()

        print(
            "Run the safe conversion test:"
        )

        print(
            "  python -m live_detection.packet_capture --test"
        )

        print()

        print(
            "Run live capture:"
        )

        print(
            "  python -m live_detection.packet_capture --live"
        )

        return

    # --------------------------------------------------------
    # Offline test
    # --------------------------------------------------------

    if args.test:

        run_packet_conversion_test()

        return

    # --------------------------------------------------------
    # Live capture
    # --------------------------------------------------------

    if args.live:

        if not SCAPY_AVAILABLE:

            print(
                "[ERROR] Scapy is not installed."
            )

            print(
                "Install it with:"
            )

            print(
                "  pip install scapy"
            )

            sys.exit(1)

        try:

            run_live_capture(
                interface=args.interface,
                packet_filter=args.filter,
            )

        except KeyboardInterrupt:

            print()
            print(
                "Capture interrupted."
            )

        except Exception as exc:

            print()
            print(
                "[ERROR]"
            )

            print(
                str(exc)
            )

            sys.exit(1)


# ============================================================
# ENTRY POINT
# ============================================================

if __name__ == "__main__":
    main()