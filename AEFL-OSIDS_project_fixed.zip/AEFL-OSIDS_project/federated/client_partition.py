from pathlib import Path
import json
import random

import numpy as np


# ============================================================
# PROJECT ROOT
# ============================================================

PROJECT_ROOT = (
    Path(__file__).resolve().parents[1]
)


# ============================================================
# CONFIGURATION
# ============================================================

SCENARIO_NAME = "scenario_C_multiple"

NUM_CLIENTS = 5

NUM_CLASSES = 5

CLASS_NAMES = [
    "BENIGN",
    "DDoS",
    "DoS",
    "Mirai",
    "Recon",
]

# Dirichlet concentration parameter.
#
# Lower alpha  -> more heterogeneous / non-IID
# Higher alpha -> closer to IID
#
# 0.5 is a reasonable starting point.
DIRICHLET_ALPHA = 0.5

SEED = 42


# ============================================================
# REPRODUCIBILITY
# ============================================================

def set_seed(
    seed: int,
):

    random.seed(
        seed
    )

    np.random.seed(
        seed
    )


# ============================================================
# LOAD LABELS
# ============================================================

def load_training_labels():

    train_dir = (
        PROJECT_ROOT
        / "data"
        / "processed"
        / SCENARIO_NAME
        / "train"
    )

    if not train_dir.exists():

        raise FileNotFoundError(
            f"Training directory not found:\n"
            f"{train_dir}"
        )

    files = sorted(
        train_dir.rglob(
            "*.npz"
        )
    )

    if not files:

        raise FileNotFoundError(
            f"No NPZ files found:\n"
            f"{train_dir}"
        )

    all_labels = []

    print()
    print(
        f"Training files found: "
        f"{len(files)}"
    )

    for file_path in files:

        with np.load(
            file_path,
            allow_pickle=False,
        ) as data:

            labels = data["y"]

            if labels.ndim != 1:

                raise ValueError(
                    f"Invalid label array:\n"
                    f"{file_path}"
                )

            all_labels.append(
                labels.astype(
                    np.int64
                )
            )

    labels = np.concatenate(
        all_labels
    )

    # --------------------------------------------------------
    # Unknown labels must not appear in training.
    # --------------------------------------------------------

    unknown_count = int(
        np.sum(
            labels == -1
        )
    )

    if unknown_count > 0:

        raise ValueError(
            "Unknown (-1) labels found "
            "in training data: "
            f"{unknown_count}"
        )

    # --------------------------------------------------------
    # Validate label range.
    # --------------------------------------------------------

    invalid = labels[
        (labels < 0)
        | (labels >= NUM_CLASSES)
    ]

    if len(invalid) > 0:

        raise ValueError(
            "Invalid training labels found."
        )

    return labels


# ============================================================
# DIRICHLET PARTITION
# ============================================================

def dirichlet_partition(
    labels: np.ndarray,
    num_clients: int,
    num_classes: int,
    alpha: float,
    seed: int,
):
    """
    Partition samples using class-wise Dirichlet
    allocation.

    Each class is distributed independently across
    clients.

    This creates non-IID client distributions.
    """

    rng = np.random.default_rng(
        seed
    )

    client_indices = [
        []
        for _ in range(
            num_clients
        )
    ]

    for class_id in range(
        num_classes
    ):

        class_indices = np.where(
            labels == class_id
        )[0]

        rng.shuffle(
            class_indices
        )

        # ----------------------------------------------------
        # Draw client proportions
        # ----------------------------------------------------

        proportions = rng.dirichlet(
            np.repeat(
                alpha,
                num_clients,
            )
        )

        # ----------------------------------------------------
        # Convert proportions to counts.
        # ----------------------------------------------------

        raw_counts = (
            proportions
            * len(class_indices)
        )

        counts = np.floor(
            raw_counts
        ).astype(
            np.int64
        )

        remainder = (
            len(class_indices)
            - int(
                counts.sum()
            )
        )

        # Distribute remaining samples
        # according to largest fractional parts.
        if remainder > 0:

            fractions = (
                raw_counts
                - counts
            )

            order = np.argsort(
                -fractions
            )

            for i in range(
                remainder
            ):

                counts[
                    order[i]
                ] += 1

        # ----------------------------------------------------
        # Assign indices
        # ----------------------------------------------------

        start = 0

        for client_id in range(
            num_clients
        ):

            count = int(
                counts[
                    client_id
                ]
            )

            if count > 0:

                selected = (
                    class_indices[
                        start:
                        start + count
                    ]
                )

                client_indices[
                    client_id
                ].extend(
                    selected.tolist()
                )

            start += count

    # --------------------------------------------------------
    # Shuffle each client
    # --------------------------------------------------------

    for client_id in range(
        num_clients
    ):

        rng.shuffle(
            client_indices[
                client_id
            ]
        )

    return client_indices


# ============================================================
# CLIENT STATISTICS
# ============================================================

def calculate_client_statistics(
    labels,
    client_indices,
):

    statistics = {}

    for client_id, indices in enumerate(
        client_indices
    ):

        client_labels = labels[
            indices
        ]

        class_counts = {}

        for class_id in range(
            NUM_CLASSES
        ):

            count = int(
                np.sum(
                    client_labels
                    == class_id
                )
            )

            class_counts[
                str(class_id)
            ] = count

        statistics[
            str(client_id)
        ] = {

            "client_id":
                client_id,

            "total_samples":
                int(
                    len(indices)
                ),

            "class_counts":
                class_counts,
        }

    return statistics


# ============================================================
# SAVE PARTITION
# ============================================================

def save_partition(
    client_indices,
    statistics,
):

    output_dir = (
        PROJECT_ROOT
        / "data"
        / "federated"
        / SCENARIO_NAME
    )

    output_dir.mkdir(
        parents=True,
        exist_ok=True,
    )

    # --------------------------------------------------------
    # Save indices
    # --------------------------------------------------------

    indices_path = (
        output_dir
        / "client_indices.npz"
    )

    arrays = {}

    for client_id, indices in enumerate(
        client_indices
    ):

        arrays[
            f"client_{client_id}"
        ] = np.asarray(
            indices,
            dtype=np.int64,
        )

    np.savez_compressed(
        indices_path,
        **arrays,
    )

    # --------------------------------------------------------
    # Save statistics
    # --------------------------------------------------------

    statistics_path = (
        output_dir
        / "client_statistics.json"
    )

    metadata = {

        "scenario":
            SCENARIO_NAME,

        "num_clients":
            NUM_CLIENTS,

        "num_classes":
            NUM_CLASSES,

        "class_names":
            CLASS_NAMES,

        "dirichlet_alpha":
            DIRICHLET_ALPHA,

        "seed":
            SEED,

        "clients":
            statistics,
    }

    with open(
        statistics_path,
        "w",
        encoding="utf-8",
    ) as file:

        json.dump(
            metadata,
            file,
            indent=4,
        )

    return (
        indices_path,
        statistics_path,
    )


# ============================================================
# VERIFY PARTITION
# ============================================================

def verify_partition(
    labels,
    client_indices,
):

    print()
    print(
        "=" * 70
    )

    print(
        "PARTITION VERIFICATION"
    )

    print(
        "=" * 70
    )

    total_samples = len(
        labels
    )

    all_indices = np.concatenate(
        [
            np.asarray(
                indices,
                dtype=np.int64,
            )
            for indices in client_indices
        ]
    )

    # --------------------------------------------------------
    # Total sample count
    # --------------------------------------------------------

    total_correct = (
        len(all_indices)
        == total_samples
    )

    print()

    print(
        f"Original samples : "
        f"{total_samples:,}"
    )

    print(
        f"Partition samples: "
        f"{len(all_indices):,}"
    )

    print(
        "Sample count check: "
        f"{'PASS' if total_correct else 'FAIL'}"
    )

    # --------------------------------------------------------
    # Duplicate check
    # --------------------------------------------------------

    unique_indices = np.unique(
        all_indices
    )

    no_duplicates = (
        len(unique_indices)
        == len(all_indices)
    )

    print(
        "Duplicate check: "
        f"{'PASS' if no_duplicates else 'FAIL'}"
    )

    # --------------------------------------------------------
    # Range check
    # --------------------------------------------------------

    range_valid = bool(
        np.all(
            all_indices >= 0
        )
        and np.all(
            all_indices
            < total_samples
        )
    )

    print(
        "Index range check: "
        f"{'PASS' if range_valid else 'FAIL'}"
    )

    # --------------------------------------------------------
    # Client statistics
    # --------------------------------------------------------

    print()

    print(
        "Client distribution:"
    )

    for client_id, indices in enumerate(
        client_indices
    ):

        client_labels = labels[
            indices
        ]

        print()

        print(
            f"Client {client_id + 1}"
        )

        print(
            f"  Total samples: "
            f"{len(indices):,}"
        )

        for class_id, class_name in enumerate(
            CLASS_NAMES
        ):

            count = int(
                np.sum(
                    client_labels
                    == class_id
                )
            )

            percentage = (
                count
                / len(indices)
                * 100
                if len(indices) > 0
                else 0
            )

            print(
                f"  {class_name:<10}: "
                f"{count:>8,} "
                f"({percentage:>6.2f}%)"
            )

    # --------------------------------------------------------
    # Overall result
    # --------------------------------------------------------

    success = (
        total_correct
        and no_duplicates
        and range_valid
    )

    print()

    print(
        "=" * 70
    )

    if success:

        print(
            "FEDERATED PARTITION "
            "VERIFICATION SUCCESSFUL"
        )

    else:

        print(
            "FEDERATED PARTITION "
            "VERIFICATION FAILED"
        )

    print(
        "=" * 70
    )

    return success


# ============================================================
# MAIN
# ============================================================

def main():

    print("=" * 70)

    print(
        "AEFL-OSIDS FEDERATED CLIENT "
        "PARTITION GENERATOR"
    )

    print("=" * 70)

    print()

    print(
        f"Scenario        : "
        f"{SCENARIO_NAME}"
    )

    print(
        f"Clients         : "
        f"{NUM_CLIENTS}"
    )

    print(
        f"Dirichlet alpha : "
        f"{DIRICHLET_ALPHA}"
    )

    print(
        f"Seed            : "
        f"{SEED}"
    )

    # --------------------------------------------------------
    # Seed
    # --------------------------------------------------------

    set_seed(
        SEED
    )

    # --------------------------------------------------------
    # Load labels
    # --------------------------------------------------------

    print()

    print(
        "Loading training labels..."
    )

    labels = load_training_labels()

    print()

    print(
        f"Total training samples: "
        f"{len(labels):,}"
    )

    # --------------------------------------------------------
    # Overall distribution
    # --------------------------------------------------------

    print()

    print(
        "Overall class distribution:"
    )

    for class_id, class_name in enumerate(
        CLASS_NAMES
    ):

        count = int(
            np.sum(
                labels
                == class_id
            )
        )

        percentage = (
            count
            / len(labels)
            * 100
        )

        print(
            f"  {class_name:<10}: "
            f"{count:>9,} "
            f"({percentage:>6.2f}%)"
        )

    # --------------------------------------------------------
    # Partition
    # --------------------------------------------------------

    print()

    print(
        "Generating non-IID partition..."
    )

    client_indices = (
        dirichlet_partition(
            labels=labels,
            num_clients=NUM_CLIENTS,
            num_classes=NUM_CLASSES,
            alpha=DIRICHLET_ALPHA,
            seed=SEED,
        )
    )

    # --------------------------------------------------------
    # Statistics
    # --------------------------------------------------------

    statistics = (
        calculate_client_statistics(
            labels,
            client_indices,
        )
    )

    # --------------------------------------------------------
    # Verify
    # --------------------------------------------------------

    success = verify_partition(
        labels,
        client_indices,
    )

    if not success:

        raise RuntimeError(
            "Partition verification failed."
        )

    # --------------------------------------------------------
    # Save
    # --------------------------------------------------------

    (
        indices_path,
        statistics_path,
    ) = save_partition(
        client_indices,
        statistics,
    )

    print()

    print(
        "Partition saved:"
    )

    print(
        indices_path
    )

    print()

    print(
        "Client statistics saved:"
    )

    print(
        statistics_path
    )

    # --------------------------------------------------------
    # Final
    # --------------------------------------------------------

    print()

    print("=" * 70)

    print(
        "FEDERATED PARTITION GENERATION "
        "COMPLETE"
    )

    print("=" * 70)


# ============================================================
# ENTRY POINT
# ============================================================

if __name__ == "__main__":
    main()