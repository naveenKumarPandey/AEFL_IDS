"""Single command-line entry point for the AEFL-OSIDS workflow."""

from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parent


def run_module(module: str, *arguments: str) -> None:
    command = [sys.executable, "-m", module, *arguments]
    print(f"\n>>> {' '.join(command)}", flush=True)
    subprocess.run(command, cwd=PROJECT_ROOT, check=True)


def prepare_data() -> None:
    """Build leakage-safe processed data and non-IID client partitions."""

    run_module("preprocessing.split_manifest")
    run_module("preprocessing.dataset_processor")
    run_module("evaluation.dataset_integrity_audit", "--fail-on-error")
    run_module("federated.client_partition")


def evaluate() -> None:
    run_module("evaluation.verified_model_comparison")
    run_module("evaluation.hybrid_open_set_evaluation")
    run_module("evaluation.generate_proposed_plots")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="AEFL-OSIDS reproducible experiment runner"
    )
    commands = parser.add_subparsers(dest="command", required=True)
    commands.add_parser("prepare-data", help="split, preprocess, audit, and partition raw data")
    commands.add_parser("audit", help="audit current processed split for leakage")
    train = commands.add_parser("train-proposed", help="train robust class-balanced FedProx")
    train.add_argument("--rounds", type=int)
    train.add_argument("--local-epochs", type=int)
    commands.add_parser("evaluate", help="recompute test/open-set metrics and figures")
    commands.add_parser("explain", help="generate balanced SHAP explanations")
    commands.add_parser("experiment", help="train the proposed model and evaluate it")
    commands.add_parser("dashboard", help="launch the Streamlit research dashboard")
    return parser


def main() -> None:
    args = build_parser().parse_args()
    if args.command == "prepare-data":
        prepare_data()
    elif args.command == "audit":
        run_module("evaluation.dataset_integrity_audit")
    elif args.command == "train-proposed":
        extra = []
        if args.rounds is not None:
            extra.extend(["--rounds", str(args.rounds)])
        if args.local_epochs is not None:
            extra.extend(["--local-epochs", str(args.local_epochs)])
        run_module("federated.robust_adaptive_fedprox", *extra)
    elif args.command == "evaluate":
        evaluate()
    elif args.command == "explain":
        run_module("explainability.shap_explainer")
    elif args.command == "experiment":
        run_module("federated.robust_adaptive_fedprox")
        evaluate()
        run_module("explainability.shap_explainer")
    elif args.command == "dashboard":
        subprocess.run(
            [sys.executable, str(PROJECT_ROOT / "run_dashboard.py")],
            cwd=PROJECT_ROOT,
            check=True,
        )


if __name__ == "__main__":
    main()
