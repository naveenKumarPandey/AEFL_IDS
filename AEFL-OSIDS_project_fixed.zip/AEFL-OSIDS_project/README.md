# AEFL-OSIDS: Robust Federated Open-Set IoT Intrusion Detection

This upgraded project keeps the existing CICIoT2023 Scenario-C experiment and
dashboard, but strengthens the part that previously made the centralized model
look more convincing than the federated contribution.

The proposed method is **Robust Class-Balanced FedProx**. It combines:

- class-balanced focal loss for rare known classes;
- FedProx regularization for highly non-IID clients;
- reliability-aware client weighting without using local accuracy as a proxy;
- median update-norm clipping and a maximum client-weight cap;
- per-class aggregation of classifier rows using each client's class support;
- checkpoint selection by validation Macro-F1 rather than accuracy;
- a hybrid unknown detector using neural uncertainty plus Isolation Forest;
- dataset-integrity, independent-test, and reproducibility checks.

## Quick start with the included processed data

From the project directory on Windows PowerShell:

```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
python main.py audit
python main.py evaluate
python main.py dashboard
```

On Linux or macOS, activate with `source .venv/bin/activate`.

The included checkpoint and result files let the dashboard run without the raw
dataset. The audit intentionally reports **FAIL** for the uploaded legacy
processed split; its existing scores are preliminary, not publication-ready.

## Where the dataset goes

Do not upload the complete dataset through the Streamlit dashboard. Extract the
CICIoT2023 CSV hierarchy into:

```text
data/raw/CICIoT2023/CSV/
```

Each attack directory must retain its original CSV files. The code ZIP can stay
small because raw data is supplied separately on the machine running training.

For a quick pipeline test, leave `experiment.mode: development` in
`configs/config.yaml`; it processes at most 2,000 cleaned rows per source file.
For a final experiment, change it to:

```yaml
experiment:
  mode: full
  development:
    enabled: false
    max_rows_per_file: 2000
  full:
    enabled: true
```

Then run:

```powershell
python main.py prepare-data
python main.py experiment
python main.py dashboard
```

`prepare-data` uses an atomic staging directory, preserves complete source-file
metadata, drops invalid rows without fitting statistics on validation/test data,
removes exact duplicate feature rows globally in train-to-validation-to-test
order, audits the finished splits, and rebuilds the five non-IID client
partitions. It stops before training if the integrity audit does not pass.

## Reproducible commands

| Goal | Command |
|---|---|
| Audit processed data | `python main.py audit` |
| Build processed data from raw CSVs | `python main.py prepare-data` |
| Train proposed model | `python main.py train-proposed` |
| Short custom run | `python main.py train-proposed --rounds 2 --local-epochs 1` |
| Recompute every comparison | `python main.py evaluate` |
| Generate proposed-model SHAP explanations | `python main.py explain` |
| Train, evaluate, and explain | `python main.py experiment` |
| Open dashboard | `python main.py dashboard` |

## Current preliminary result

On the supplied development-sized processed split, the proposed model achieves
68.69% independent-test Macro-F1 versus 68.23% for centralized, 67.04% for
FedAvg, and 54.87% for legacy Adaptive FedAvg v2. The hybrid open-set detector
achieves 66.16% unknown F1 and 93.45% AUROC, compared with 31.81% and 79.55% for
the confidence-only baseline.

These numbers must not be presented as final paper results until:

1. `experiment.mode` is `full`;
2. raw preprocessing and client partitioning are regenerated;
3. `python -m evaluation.dataset_integrity_audit --fail-on-error` exits cleanly;
4. all baselines and the proposed model are retrained on that same clean split;
5. the independent test comparison and hybrid open-set evaluation are rerun.

## Evaluation discipline

- Validation data selects the federated round and calibrates the rejection
  threshold.
- Unknown test families never fit the anomaly model and never select its
  threshold or fusion weights.
- The independent known-class test subset compares centralized and federated
  models using the same evaluator.
- Report Macro-F1 and per-class recall with accuracy; report unknown F1, AUROC,
  and known FPR for open-set behavior.

## Live detection

The live detector now prefers `robust_adaptive_fedprox_global.pt` and loads the
calibrated hybrid artifact automatically. Packet capture may require elevated
permissions; Windows packet capture also requires an installed Npcap-compatible
driver.

## Important files

| File | Purpose |
|---|---|
| `federated/robust_adaptive_fedprox.py` | Proposed federated trainer |
| `evaluation/hybrid_open_set_evaluation.py` | Leakage-safe hybrid calibration/test |
| `evaluation/verified_model_comparison.py` | Same-split checkpoint comparison |
| `evaluation/dataset_integrity_audit.py` | Duplicate, metadata, and finite-value checks |
| `evaluation/generate_proposed_plots.py` | Updated publication figures |
| `explainability/shap_explainer.py` | Balanced proposed-model SHAP explanations |
| `live_detection/ml_detector.py` | Proposed model and hybrid live inference |
| `ui/app.py` | Corrected Streamlit research dashboard |
