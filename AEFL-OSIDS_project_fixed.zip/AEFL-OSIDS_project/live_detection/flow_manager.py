"""
AEFL-OSIDS Real-Time Flow Manager

Maintains bidirectional network flows from captured packets.

This module:
- does NOT perform ML inference
- does NOT modify the trained model
- does NOT assign attack labels
- aggregates packet-level information into flow-level records
- supports TCP, UDP, and other IP traffic
- handles flow inactivity timeouts
- can be tested without Scapy

The output of this module will later be consumed by:
    feature_extractor.py
    ml_detector.py
    rule_engine.py
    decision_fusion.py
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

# ============================================================
# CONFIGURATION
# ============================================================

DEFAULT_FLOW_TIMEOUT = 15.0
DEFAULT_MAX_FLOW_DURATION = 120.0

# ============================================================
# TYPES
# ============================================================

FlowKey = Tuple[str, str, int, int, int]


# ============================================================
# PACKET INFORMATION
# ============================================================

@dataclass
class PacketInfo:
    """
    Normalized representation of a captured packet.

    timestamp:
        Unix timestamp.

    src_ip / dst_ip:
        IPv4 or IPv6 addresses.

    src_port / dst_port:
        Transport-layer ports. Use 0 when unavailable.

    protocol:
        IP protocol number.

        6  = TCP
        17 = UDP
        1  = ICMP

    packet_length:
        Total captured packet length in bytes.

    payload_length:
        Transport/application payload length.

    tcp_flags:
        TCP flags as an integer when available.

    ttl:
        IP TTL / Hop Limit when available.
    """

    timestamp: float
    src_ip: str
    dst_ip: str

    src_port: int = 0
    dst_port: int = 0

    protocol: int = 0

    packet_length: int = 0
    payload_length: int = 0

    tcp_flags: int = 0
    ttl: int = 0
    ip_version: int = 0
    ip_header_length: int = 0
    transport_header_length: int = 0
    llc_present: int = 0


# ============================================================
# FLOW RECORD
# ============================================================

@dataclass
class FlowRecord:
    """
    Aggregated bidirectional network flow.

    This is intentionally a generic intermediate representation.

    The 39 CICIoT2023 features will be calculated later by the
    feature extraction module.
    """

    key: FlowKey

    first_timestamp: float
    last_timestamp: float

    forward_src_ip: str
    forward_dst_ip: str

    forward_src_port: int
    forward_dst_port: int

    protocol: int

    packet_count: int = 0
    byte_count: int = 0

    forward_packet_count: int = 0
    backward_packet_count: int = 0

    forward_byte_count: int = 0
    backward_byte_count: int = 0

    forward_packet_lengths: List[int] = field(default_factory=list)
    backward_packet_lengths: List[int] = field(default_factory=list)

    packet_timestamps: List[float] = field(default_factory=list)

    tcp_syn_count: int = 0
    tcp_ack_count: int = 0
    tcp_fin_count: int = 0
    tcp_rst_count: int = 0
    tcp_psh_count: int = 0
    tcp_urg_count: int = 0

    forward_ttl_values: List[int] = field(default_factory=list)
    backward_ttl_values: List[int] = field(default_factory=list)
    ip_version_values: List[int] = field(default_factory=list)
    ip_header_lengths: List[int] = field(default_factory=list)
    transport_header_lengths: List[int] = field(default_factory=list)
    llc_present_values: List[int] = field(default_factory=list)

    completed: bool = False

    # --------------------------------------------------------
    # DERIVED BASIC PROPERTIES
    # --------------------------------------------------------

    @property
    def duration(self) -> float:
        """Return flow duration in seconds."""
        return max(
            0.0,
            self.last_timestamp - self.first_timestamp,
        )

    @property
    def packets_per_second(self) -> float:
        """Return packets per second."""
        duration = self.duration

        if duration <= 0.0:
            return float(self.packet_count)

        return self.packet_count / duration

    @property
    def bytes_per_second(self) -> float:
        """Return bytes per second."""
        duration = self.duration

        if duration <= 0.0:
            return float(self.byte_count)

        return self.byte_count / duration

    # --------------------------------------------------------
    # FLOW DICTIONARY
    # --------------------------------------------------------

    def to_dict(self) -> Dict[str, Any]:
        """
        Convert the flow into a serializable dictionary.

        This dictionary is the interface used by subsequent
        real-time analysis modules.
        """

        return {
            "flow_key": self.key,

            "src_ip": self.forward_src_ip,
            "dst_ip": self.forward_dst_ip,

            "src_port": self.forward_src_port,
            "dst_port": self.forward_dst_port,

            "protocol": self.protocol,

            "first_timestamp": self.first_timestamp,
            "last_timestamp": self.last_timestamp,

            "duration": self.duration,

            "packet_count": self.packet_count,
            "byte_count": self.byte_count,

            "forward_packet_count": self.forward_packet_count,
            "backward_packet_count": self.backward_packet_count,

            "forward_byte_count": self.forward_byte_count,
            "backward_byte_count": self.backward_byte_count,

            "packets_per_second": self.packets_per_second,
            "bytes_per_second": self.bytes_per_second,

            "forward_packet_lengths": list(
                self.forward_packet_lengths
            ),

            "backward_packet_lengths": list(
                self.backward_packet_lengths
            ),

            "packet_timestamps": list(
                self.packet_timestamps
            ),

            "tcp_syn_count": self.tcp_syn_count,
            "tcp_ack_count": self.tcp_ack_count,
            "tcp_fin_count": self.tcp_fin_count,
            "tcp_rst_count": self.tcp_rst_count,
            "tcp_psh_count": self.tcp_psh_count,
            "tcp_urg_count": self.tcp_urg_count,

            "forward_ttl_values": list(
                self.forward_ttl_values
            ),

            "backward_ttl_values": list(
                self.backward_ttl_values
            ),

            "ip_version_values": list(self.ip_version_values),
            "ip_header_lengths": list(self.ip_header_lengths),
            "transport_header_lengths": list(self.transport_header_lengths),
            "llc_present_values": list(self.llc_present_values),

            "completed": self.completed,
        }


# ============================================================
# FLOW MANAGER
# ============================================================

class FlowManager:
    """
    Maintains active bidirectional flows.

    A flow is identified using a canonicalized five-tuple:

        IP1
        IP2
        Port1
        Port2
        Protocol

    Direction is retained separately so packets can be classified
    as forward or backward traffic.
    """

    def __init__(
            self,
            flow_timeout: float = DEFAULT_FLOW_TIMEOUT,
            max_flow_duration: float = DEFAULT_MAX_FLOW_DURATION,
    ) -> None:

        if flow_timeout <= 0:
            raise ValueError(
                "flow_timeout must be greater than zero."
            )

        if max_flow_duration <= 0:
            raise ValueError(
                "max_flow_duration must be greater than zero."
            )

        self.flow_timeout = float(flow_timeout)
        self.max_flow_duration = float(max_flow_duration)

        self._flows: Dict[FlowKey, FlowRecord] = {}

        self.total_packets = 0
        self.total_bytes = 0
        self.total_flows_completed = 0

    # ========================================================
    # FLOW KEY
    # ========================================================

    @staticmethod
    def _canonical_key(
            packet: PacketInfo,
    ) -> Tuple[FlowKey, bool]:
        """
        Return canonical flow key and direction.

        True:
            packet follows the canonical forward direction.

        False:
            packet belongs to the reverse direction.
        """

        forward = (
            packet.src_ip,
            packet.dst_ip,
            int(packet.src_port),
            int(packet.dst_port),
            int(packet.protocol),
        )

        backward = (
            packet.dst_ip,
            packet.src_ip,
            int(packet.dst_port),
            int(packet.src_port),
            int(packet.protocol),
        )

        # Lexicographic canonicalization.
        if forward <= backward:
            return forward, True

        return backward, False

    # ========================================================
    # CREATE FLOW
    # ========================================================

    @staticmethod
    def _create_flow(
            packet: PacketInfo,
            key: FlowKey,
    ) -> FlowRecord:

        return FlowRecord(
            key=key,

            first_timestamp=packet.timestamp,
            last_timestamp=packet.timestamp,

            forward_src_ip=packet.src_ip,
            forward_dst_ip=packet.dst_ip,

            forward_src_port=packet.src_port,
            forward_dst_port=packet.dst_port,

            protocol=packet.protocol,
        )

    # ========================================================
    # UPDATE TCP FLAGS
    # ========================================================

    @staticmethod
    def _update_tcp_flags(
            flow: FlowRecord,
            packet: PacketInfo,
    ) -> None:

        if packet.protocol != 6:
            return

        flags = int(packet.tcp_flags)

        # TCP flag masks.
        FIN = 0x01
        SYN = 0x02
        RST = 0x04
        PSH = 0x08
        ACK = 0x10
        URG = 0x20

        if flags & SYN:
            flow.tcp_syn_count += 1

        if flags & ACK:
            flow.tcp_ack_count += 1

        if flags & FIN:
            flow.tcp_fin_count += 1

        if flags & RST:
            flow.tcp_rst_count += 1

        if flags & PSH:
            flow.tcp_psh_count += 1

        if flags & URG:
            flow.tcp_urg_count += 1

    # ========================================================
    # ADD PACKET
    # ========================================================

    def add_packet(
            self,
            packet: PacketInfo,
    ) -> List[FlowRecord]:
        """
        Add a packet to the appropriate flow.

        Returns:
            A list of flows that became complete because of this
            packet or because inactive flows were expired.

        Normally this list is empty or contains a small number
        of completed flows.
        """

        if not isinstance(packet, PacketInfo):
            raise TypeError(
                "packet must be a PacketInfo instance."
            )

        if packet.timestamp < 0:
            raise ValueError(
                "packet.timestamp cannot be negative."
            )

        completed = self.expire_flows(
            current_timestamp=packet.timestamp
        )

        key, is_forward = self._canonical_key(
            packet
        )

        flow = self._flows.get(key)

        if flow is None:
            flow = self._create_flow(
                packet,
                key,
            )

            self._flows[key] = flow

        # ----------------------------------------------------
        # Update timestamps
        # ----------------------------------------------------

        flow.last_timestamp = max(
            flow.last_timestamp,
            packet.timestamp,
        )

        # ----------------------------------------------------
        # General counters
        # ----------------------------------------------------

        packet_length = max(
            0,
            int(packet.packet_length),
        )

        flow.packet_count += 1
        flow.byte_count += packet_length

        self.total_packets += 1
        self.total_bytes += packet_length

        flow.packet_timestamps.append(
            float(packet.timestamp)
        )

        if int(packet.ip_version) > 0:
            flow.ip_version_values.append(int(packet.ip_version))
        if int(packet.ip_header_length) > 0:
            flow.ip_header_lengths.append(int(packet.ip_header_length))
        if int(packet.transport_header_length) > 0:
            flow.transport_header_lengths.append(int(packet.transport_header_length))
        flow.llc_present_values.append(1 if int(packet.llc_present) else 0)

        # ----------------------------------------------------
        # Directional counters
        # ----------------------------------------------------

        if is_forward:

            flow.forward_packet_count += 1

            flow.forward_byte_count += (
                packet_length
            )

            flow.forward_packet_lengths.append(
                packet_length
            )

            if packet.ttl > 0:
                flow.forward_ttl_values.append(
                    int(packet.ttl)
                )

        else:

            flow.backward_packet_count += 1

            flow.backward_byte_count += (
                packet_length
            )

            flow.backward_packet_lengths.append(
                packet_length
            )

            if packet.ttl > 0:
                flow.backward_ttl_values.append(
                    int(packet.ttl)
                )

        # ----------------------------------------------------
        # TCP information
        # ----------------------------------------------------

        self._update_tcp_flags(
            flow,
            packet,
        )

        # ----------------------------------------------------
        # Maximum-duration protection
        # ----------------------------------------------------

        if flow.duration >= self.max_flow_duration:

            completed_flow = self._complete_flow(
                key
            )

            if completed_flow is not None:
                completed.append(
                    completed_flow
                )

        return completed

    # ========================================================
    # EXPIRE FLOWS
    # ========================================================

    def expire_flows(
            self,
            current_timestamp: Optional[float] = None,
    ) -> List[FlowRecord]:
        """
        Complete flows that have been inactive longer than
        flow_timeout.

        If current_timestamp is omitted, time.time() is used.
        """

        if current_timestamp is None:
            current_timestamp = time.time()

        current_timestamp = float(
            current_timestamp
        )

        completed: List[FlowRecord] = []

        for key, flow in list(
                self._flows.items()
        ):

            inactive_for = (
                    current_timestamp
                    - flow.last_timestamp
            )

            if inactive_for >= self.flow_timeout:

                completed_flow = (
                    self._complete_flow(key)
                )

                if completed_flow is not None:
                    completed.append(
                        completed_flow
                    )

        return completed

    # ========================================================
    # COMPLETE FLOW
    # ========================================================

    def _complete_flow(
            self,
            key: FlowKey,
    ) -> Optional[FlowRecord]:

        flow = self._flows.pop(
            key,
            None,
        )

        if flow is None:
            return None

        flow.completed = True

        self.total_flows_completed += 1

        return flow

    # ========================================================
    # FLUSH ALL
    # ========================================================

    def flush(self) -> List[FlowRecord]:
        """
        Complete all currently active flows.

        Useful when stopping live capture.
        """

        completed: List[FlowRecord] = []

        for key in list(
                self._flows.keys()
        ):

            flow = self._complete_flow(
                key
            )

            if flow is not None:
                completed.append(
                    flow
                )

        return completed

    # ========================================================
    # ACTIVE FLOWS
    # ========================================================

    def active_flow_count(self) -> int:
        """Return number of currently active flows."""

        return len(
            self._flows
        )

    # ========================================================
    # STATISTICS
    # ========================================================

    def statistics(self) -> Dict[str, Any]:
        """Return current flow-manager statistics."""

        return {
            "active_flows": self.active_flow_count(),
            "total_packets": int(
                self.total_packets
            ),
            "total_bytes": int(
                self.total_bytes
            ),
            "total_flows_completed": int(
                self.total_flows_completed
            ),
        }

    # ========================================================
    # RESET
    # ========================================================

    def reset(self) -> None:
        """Reset all active flows and counters."""

        self._flows.clear()

        self.total_packets = 0
        self.total_bytes = 0
        self.total_flows_completed = 0


# ============================================================
# SIMPLE PACKET FACTORY
# ============================================================

def create_packet_info(
        *,
        timestamp: float,
        src_ip: str,
        dst_ip: str,
        src_port: int = 0,
        dst_port: int = 0,
        protocol: int = 0,
        packet_length: int = 0,
        payload_length: int = 0,
        tcp_flags: int = 0,
        ttl: int = 0,
        ip_version: int = 0,
        ip_header_length: int = 0,
        transport_header_length: int = 0,
        llc_present: int = 0,
) -> PacketInfo:
    """
    Convenience function for creating PacketInfo objects.

    This also provides a clean interface for the future Scapy
    packet-capture module.
    """

    return PacketInfo(
        timestamp=float(timestamp),

        src_ip=str(src_ip),
        dst_ip=str(dst_ip),

        src_port=int(src_port),
        dst_port=int(dst_port),

        protocol=int(protocol),

        packet_length=max(
            0,
            int(packet_length),
        ),

        payload_length=max(
            0,
            int(payload_length),
        ),

        tcp_flags=int(tcp_flags),
        ttl=int(ttl),
        ip_version=int(ip_version),
        ip_header_length=max(0, int(ip_header_length)),
        transport_header_length=max(0, int(transport_header_length)),
        llc_present=1 if int(llc_present) else 0,
    )


# ============================================================
# SELF TEST
# ============================================================

def self_test() -> None:
    """
    Run a small deterministic flow-manager test.

    No network traffic is captured.
    """

    print("=" * 70)
    print("AEFL-OSIDS FLOW MANAGER TEST")
    print("=" * 70)

    manager = FlowManager(
        flow_timeout=5.0,
        max_flow_duration=60.0,
    )

    packets = [
        create_packet_info(
            timestamp=1.0,
            src_ip="192.168.1.10",
            dst_ip="192.168.1.20",
            src_port=50000,
            dst_port=80,
            protocol=6,
            packet_length=100,
            tcp_flags=0x02,
            ttl=64,
        ),
        create_packet_info(
            timestamp=1.1,
            src_ip="192.168.1.20",
            dst_ip="192.168.1.10",
            src_port=80,
            dst_port=50000,
            protocol=6,
            packet_length=80,
            tcp_flags=0x12,
            ttl=64,
        ),
        create_packet_info(
            timestamp=1.2,
            src_ip="192.168.1.10",
            dst_ip="192.168.1.20",
            src_port=50000,
            dst_port=80,
            protocol=6,
            packet_length=120,
            tcp_flags=0x10,
            ttl=64,
        ),
    ]

    completed = []

    for packet in packets:
        completed.extend(
            manager.add_packet(
                packet
            )
        )

    print()
    print(
        "Active flows:",
        manager.active_flow_count(),
    )

    print(
        "Packets:",
        manager.total_packets,
    )

    print(
        "Bytes:",
        manager.total_bytes,
    )

    # Force inactivity timeout.
    completed.extend(
        manager.expire_flows(
            current_timestamp=10.0
        )
    )

    print(
        "Completed flows:",
        len(completed),
    )

    if len(completed) != 1:
        raise RuntimeError(
            "Flow manager self-test failed: "
            "expected exactly one completed flow."
        )

    flow = completed[0]

    assert flow.packet_count == 3
    assert flow.byte_count == 300
    assert flow.forward_packet_count == 2
    assert flow.backward_packet_count == 1
    assert flow.forward_byte_count == 220
    assert flow.backward_byte_count == 80
    assert flow.tcp_syn_count == 2
    assert flow.tcp_ack_count == 2

    print()
    print("Flow:")
    print(
        f"  Source       : "
        f"{flow.forward_src_ip}:"
        f"{flow.forward_src_port}"
    )
    print(
        f"  Destination  : "
        f"{flow.forward_dst_ip}:"
        f"{flow.forward_dst_port}"
    )
    print(
        f"  Protocol     : {flow.protocol}"
    )
    print(
        f"  Packets      : {flow.packet_count}"
    )
    print(
        f"  Bytes        : {flow.byte_count}"
    )
    print(
        f"  Duration     : {flow.duration:.3f}s"
    )
    print(
        f"  Packet rate  : "
        f"{flow.packets_per_second:.3f} pkt/s"
    )

    print()
    print("=" * 70)
    print("FLOW MANAGER TEST SUCCESSFUL")
    print("=" * 70)


# ============================================================
# MAIN
# ============================================================

if __name__ == "__main__":
    self_test()
