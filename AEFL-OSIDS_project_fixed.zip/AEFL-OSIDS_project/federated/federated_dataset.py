from pathlib import Path
from typing import List

import numpy as np
import torch
from torch.utils.data import Dataset, DataLoader


# ============================================================
# PROJECT ROOT
# ============================================================

PROJECT_ROOT = (
    Path(__file__).resolve().parents[1]
)


# ============================================================
# CONFIGURATION
# ============================================================

SCENARIO_NAME = (
    "scenario_C_multiple"
)

NUM_CLIENTS = 5

NUM_CLASSES = 5

CLASS_NAMES = [
    "BENIGN",
    "DDoS",
    "DoS",
    "Mirai",
    "Recon",
]


# ============================================================
# CLIENT DATASET
# ============================================================

class FederatedClientDataset(
    Dataset
):
    """
    PyTorch Dataset representing one federated client.

    The global training dataset is stored in multiple
    NPZ files. client_indices.npz contains global sample
    indices assigned to each client.

    This class maps:

        client sample index
              ↓
        global dataset index
              ↓
        NPZ file + row
              ↓
        X, y
    """

    def __init__(
        self,
        client_id: int,
    ):
        super().__init__()

        if not (
            0
            <= client_id
            < NUM_CLIENTS
        ):

            raise ValueError(
                f"Invalid client_id: "
                f"{client_id}. "
                f"Expected 0-{NUM_CLIENTS - 1}."
            )

        self.client_id = (
            client_id
        )

        # ----------------------------------------------------
        # Training directory
        # ----------------------------------------------------

        self.train_dir = (
            PROJECT_ROOT
            / "data"
            / "processed"
            / SCENARIO_NAME
            / "train"
        )

        if not self.train_dir.exists():

            raise FileNotFoundError(
                f"Training directory not found:\n"
                f"{self.train_dir}"
            )

        # ----------------------------------------------------
        # Global NPZ files
        # ----------------------------------------------------

        self.files = sorted(
            self.train_dir.rglob(
                "*.npz"
            )
        )

        if not self.files:

            raise FileNotFoundError(
                f"No NPZ files found:\n"
                f"{self.train_dir}"
            )

        # ----------------------------------------------------
        # Build cumulative file sizes
        # ----------------------------------------------------

        self.file_sizes = []

        self.cumulative_sizes = []

        total = 0

        for file_path in self.files:

            with np.load(
                file_path,
                allow_pickle=False,
            ) as data:

                X = data["X"]

                y = data["y"]

                if X.ndim != 2:

                    raise ValueError(
                        f"Invalid X dimensions:\n"
                        f"{file_path}"
                    )

                if X.shape[1] != 39:

                    raise ValueError(
                        f"Expected 39 features "
                        f"but found "
                        f"{X.shape[1]}:\n"
                        f"{file_path}"
                    )

                if len(X) != len(y):

                    raise ValueError(
                        f"X/y length mismatch:\n"
                        f"{file_path}"
                    )

                size = len(X)

            self.file_sizes.append(
                size
            )

            total += size

            self.cumulative_sizes.append(
                total
            )

        self.total_global_samples = (
            total
        )

        # ----------------------------------------------------
        # Load client indices
        # ----------------------------------------------------

        indices_path = (
            PROJECT_ROOT
            / "data"
            / "federated"
            / SCENARIO_NAME
            / "client_indices.npz"
        )

        if not indices_path.exists():

            raise FileNotFoundError(
                f"Client partition not found:\n"
                f"{indices_path}"
            )

        with np.load(
            indices_path,
            allow_pickle=False,
        ) as data:

            key = (
                f"client_{client_id}"
            )

            if key not in data.files:

                raise KeyError(
                    f"Client indices not found "
                    f"for {key}"
                )

            self.global_indices = (
                data[key]
                .astype(np.int64)
                .copy()
            )

        # ----------------------------------------------------
        # Validate indices
        # ----------------------------------------------------

        if len(
            self.global_indices
        ) == 0:

            raise ValueError(
                f"Client {client_id} "
                f"has zero samples."
            )

        if np.any(
            self.global_indices < 0
        ):

            raise ValueError(
                f"Negative index found "
                f"for client {client_id}."
            )

        if np.any(
            self.global_indices
            >= self.total_global_samples
        ):

            raise ValueError(
                f"Out-of-range index found "
                f"for client {client_id}."
            )

        # ----------------------------------------------------
        # Cache
        # ----------------------------------------------------

        self._cached_file_index = None

        self._cached_X = None

        self._cached_y = None

    # ========================================================
    # LENGTH
    # ========================================================

    def __len__(
        self,
    ) -> int:

        return len(
            self.global_indices
        )

    # ========================================================
    # GLOBAL INDEX → FILE + ROW
    # ========================================================

    def _global_to_file_row(
        self,
        global_index: int,
    ):

        file_index = np.searchsorted(
            self.cumulative_sizes,
            global_index,
            side="right",
        )

        previous_end = 0

        if file_index > 0:

            previous_end = (
                self.cumulative_sizes[
                    file_index - 1
                ]
            )

        row_index = (
            global_index
            - previous_end
        )

        return (
            int(file_index),
            int(row_index),
        )

    # ========================================================
    # LOAD NPZ FILE
    # ========================================================

    def _load_file(
        self,
        file_index: int,
    ):

        if (
            self._cached_file_index
            == file_index
        ):

            return

        file_path = (
            self.files[
                file_index
            ]
        )

        with np.load(
            file_path,
            allow_pickle=False,
        ) as data:

            X = data["X"].copy()

            y = data["y"].copy()

        self._cached_file_index = (
            file_index
        )

        self._cached_X = X

        self._cached_y = y

    # ========================================================
    # GET ITEM
    # ========================================================

    def __getitem__(
        self,
        index: int,
    ):

        if index < 0:

            index += len(
                self
            )

        if (
            index < 0
            or index >= len(self)
        ):

            raise IndexError(
                "Client dataset index "
                "out of range."
            )

        # ----------------------------------------------------
        # Local index → global index
        # ----------------------------------------------------

        global_index = int(
            self.global_indices[
                index
            ]
        )

        # ----------------------------------------------------
        # Global index → NPZ file + row
        # ----------------------------------------------------

        file_index, row_index = (
            self._global_to_file_row(
                global_index
            )
        )

        # ----------------------------------------------------
        # Load NPZ
        # ----------------------------------------------------

        self._load_file(
            file_index
        )

        X = self._cached_X[
            row_index
        ]

        y = self._cached_y[
            row_index
        ]

        # ----------------------------------------------------
        # Convert to tensors
        # ----------------------------------------------------

        X_tensor = torch.from_numpy(
            X
        ).float()

        y_tensor = torch.tensor(
            int(y),
            dtype=torch.long,
        )

        return (
            X_tensor,
            y_tensor,
        )


# ============================================================
# CLIENT DATALOADER
# ============================================================

def create_client_dataloader(
    client_id: int,
    batch_size: int = 256,
    shuffle: bool = True,
):

    dataset = (
        FederatedClientDataset(
            client_id
        )
    )

    loader = DataLoader(
        dataset,
        batch_size=batch_size,
        shuffle=shuffle,
        num_workers=0,
        pin_memory=False,
        persistent_workers=False,
    )

    return (
        dataset,
        loader,
    )


# ============================================================
# CLIENT LABEL DISTRIBUTION
# ============================================================

def get_client_label_distribution(
    dataset:
        FederatedClientDataset,
):

    distribution = {
        class_id: 0
        for class_id in range(
            NUM_CLASSES
        )
    }

    for file_path in dataset.files:

        with np.load(
            file_path,
            allow_pickle=False,
        ) as data:

            labels = data["y"]

            # ------------------------------------------------
            # Find global indices belonging to this file.
            # ------------------------------------------------

            file_index = (
                dataset.files.index(
                    file_path
                )
            )

            start = 0

            if file_index > 0:

                start = (
                    dataset.cumulative_sizes[
                        file_index - 1
                    ]
                )

            end = (
                dataset.cumulative_sizes[
                    file_index
                ]
            )

            mask = (
                (
                    dataset.global_indices
                    >= start
                )
                & (
                    dataset.global_indices
                    < end
                )
            )

            local_global_indices = (
                dataset.global_indices[
                    mask
                ]
            )

            if len(
                local_global_indices
            ) == 0:

                continue

            rows = (
                local_global_indices
                - start
            )

            selected_labels = (
                labels[rows]
            )

            unique, counts = (
                np.unique(
                    selected_labels,
                    return_counts=True,
                )
            )

            for label, count in zip(
                unique,
                counts,
            ):

                label = int(
                    label
                )

                if (
                    0
                    <= label
                    < NUM_CLASSES
                ):

                    distribution[
                        label
                    ] += int(count)

    return distribution


# ============================================================
# CLIENT TEST
# ============================================================

def test_client(
    client_id: int,
):

    print()

    print(
        "=" * 70
    )

    print(
        f"TESTING CLIENT {client_id + 1}"
    )

    print(
        "=" * 70
    )

    # --------------------------------------------------------
    # Dataset
    # --------------------------------------------------------

    dataset = (
        FederatedClientDataset(
            client_id
        )
    )

    print()

    print(
        f"Client ID: "
        f"{client_id}"
    )

    print(
        f"Samples: "
        f"{len(dataset):,}"
    )

    # --------------------------------------------------------
    # First sample
    # --------------------------------------------------------

    X, y = dataset[0]

    print()

    print(
        "First sample:"
    )

    print(
        f"  X shape: "
        f"{tuple(X.shape)}"
    )

    print(
        f"  X dtype: "
        f"{X.dtype}"
    )

    print(
        f"  y: "
        f"{y.item()}"
    )

    print(
        f"  y dtype: "
        f"{y.dtype}"
    )

    # --------------------------------------------------------
    # DataLoader
    # --------------------------------------------------------

    loader = DataLoader(
        dataset,
        batch_size=256,
        shuffle=True,
        num_workers=0,
    )

    X_batch, y_batch = next(
        iter(loader)
    )

    print()

    print(
        "First batch:"
    )

    print(
        f"  X shape: "
        f"{tuple(X_batch.shape)}"
    )

    print(
        f"  y shape: "
        f"{tuple(y_batch.shape)}"
    )

    # --------------------------------------------------------
    # Distribution
    # --------------------------------------------------------

    distribution = (
        get_client_label_distribution(
            dataset
        )
    )

    print()

    print(
        "Client label distribution:"
    )

    for class_id, class_name in enumerate(
        CLASS_NAMES
    ):

        count = distribution[
            class_id
        ]

        percentage = (
            count
            / len(dataset)
            * 100
        )

        print(
            f"  {class_name:<10}: "
            f"{count:>8,} "
            f"({percentage:>6.2f}%)"
        )

    return True


# ============================================================
# MAIN
# ============================================================

def main():

    print("=" * 70)

    print(
        "AEFL-OSIDS FEDERATED CLIENT "
        "DATASET TEST"
    )

    print("=" * 70)

    print()

    print(
        f"Scenario: "
        f"{SCENARIO_NAME}"
    )

    print(
        f"Clients: "
        f"{NUM_CLIENTS}"
    )

    # --------------------------------------------------------
    # Test all clients
    # --------------------------------------------------------

    all_success = True

    client_sizes = []

    for client_id in range(
        NUM_CLIENTS
    ):

        try:

            dataset = (
                FederatedClientDataset(
                    client_id
                )
            )

            client_sizes.append(
                len(dataset)
            )

            test_client(
                client_id
            )

        except Exception as exc:

            all_success = False

            print()

            print(
                f"CLIENT {client_id + 1} "
                f"FAILED:"
            )

            print(
                exc
            )

    # --------------------------------------------------------
    # Total
    # --------------------------------------------------------

    print()

    print(
        "=" * 70
    )

    print(
        "CLIENT SIZE VERIFICATION"
    )

    print(
        "=" * 70
    )

    total_client_samples = sum(
        client_sizes
    )

    print()

    for client_id, size in enumerate(
        client_sizes
    ):

        print(
            f"Client {client_id + 1}: "
            f"{size:,}"
        )

    print()

    print(
        f"Total client samples: "
        f"{total_client_samples:,}"
    )

    print(
        f"Expected samples: "
        f"411,602"
    )

    if (
        total_client_samples
        != 411602
    ):

        all_success = False

        print()

        print(
            "Total sample verification: "
            "FAIL"
        )

    else:

        print()

        print(
            "Total sample verification: "
            "PASS"
        )

    # --------------------------------------------------------
    # Final
    # --------------------------------------------------------

    print()

    print(
        "=" * 70
    )

    if all_success:

        print(
            "FEDERATED CLIENT DATASET "
            "TEST SUCCESSFUL"
        )

    else:

        print(
            "FEDERATED CLIENT DATASET "
            "TEST FAILED"
        )

    print(
        "=" * 70
    )


# ============================================================
# ENTRY POINT
# ============================================================

if __name__ == "__main__":
    main()