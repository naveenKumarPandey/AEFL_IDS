from pathlib import Path
from collections import defaultdict

import pandas as pd


# Project root:
# C:\project\AEFL-OSIDS
PROJECT_ROOT = Path(__file__).resolve().parents[1]

DATASET_DIR = PROJECT_ROOT / "data" / "raw" / "CICIoT2023" / "CSV"


def find_csv_files(dataset_dir: Path):
    """
    Recursively find all CSV files inside the CICIoT2023 CSV directory.
    """
    return sorted(dataset_dir.rglob("*.csv"))


def inspect_dataset(dataset_dir: Path):
    """
    Inspect the dataset structure without loading the complete dataset
    into memory.
    """

    if not dataset_dir.exists():
        print(f"ERROR: Dataset directory not found:")
        print(dataset_dir)
        return

    csv_files = find_csv_files(dataset_dir)

    print("=" * 70)
    print("CICIoT2023 DATASET INSPECTION")
    print("=" * 70)

    print(f"\nDataset directory:")
    print(dataset_dir)

    print(f"\nTotal CSV files found: {len(csv_files)}")

    if not csv_files:
        print("\nNo CSV files found.")
        print("Please check the dataset extraction path.")
        return

    # Count files by parent directory.
    folder_counts = defaultdict(int)

    for csv_file in csv_files:
        folder_counts[csv_file.parent.name] += 1

    print("\nAttack folders:")
    print("-" * 70)

    for folder, count in sorted(folder_counts.items()):
        print(f"{folder:<40} {count:>6} CSV file(s)")

    # Inspect a few files only.
    print("\n")
    print("=" * 70)
    print("SAMPLE CSV INSPECTION")
    print("=" * 70)

    sample_files = csv_files[:5]

    for csv_file in sample_files:
        print("\n" + "-" * 70)
        print(f"File: {csv_file.relative_to(dataset_dir)}")

        try:
            df = pd.read_csv(csv_file, nrows=5)

            print(f"Columns: {len(df.columns)}")
            print("Column names:")

            for column in df.columns:
                print(f"  - {column}")

            print(f"\nSample shape: {df.shape}")

            print("\nSample data:")
            print(df.head(2).to_string(index=False))

        except Exception as exc:
            print(f"ERROR reading file: {exc}")

    print("\n")
    print("=" * 70)
    print("INSPECTION COMPLETE")
    print("=" * 70)


if __name__ == "__main__":
    inspect_dataset(DATASET_DIR)