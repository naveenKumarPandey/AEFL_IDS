"""
AEFL-OSIDS
Live Flow Feature Builder

Builds the 39-feature input required by the existing
Adaptive FedAvg v2 model from an aggregated live flow.

Confirmed feature order:

01 Header_Length
02 Protocol Type
03 Time_To_Live
04 Rate
05 fin_flag_number
06 syn_flag_number
07 rst_flag_number
08 psh_flag_number
09 ack_flag_number
10 ece_flag_number
11 cwr_flag_number
12 ack_count
13 syn_count
14 fin_count
15 rst_count
16 HTTP
17 HTTPS
18 DNS
19 Telnet
20 SMTP
21 SSH
22 IRC
23 TCP
24 UDP
25 DHCP
26 ARP
27 ICMP
28 IGMP
29 IPv
30 LLC
31 Tot sum
32 Min
33 Max
34 AVG
35 Std
36 Tot size
37 IAT
38 Number
39 Variance

This module does NOT:
- train the model
- modify model weights
- modify the existing scaler
- perform packet capture

It only converts flow statistics into a 39-feature vector.
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Any, Mapping, Optional

import numpy as np


# =====================================================================
# CONFIGURATION
# =====================================================================

EXPECTED_FEATURE_COUNT = 39


FEATURE_NAMES = [
    "Header_Length",
    "Protocol Type",
    "Time_To_Live",
    "Rate",
    "fin_flag_number",
    "syn_flag_number",
    "rst_flag_number",
    "psh_flag_number",
    "ack_flag_number",
    "ece_flag_number",
    "cwr_flag_number",
    "ack_count",
    "syn_count",
    "fin_count",
    "rst_count",
    "HTTP",
    "HTTPS",
    "DNS",
    "Telnet",
    "SMTP",
    "SSH",
    "IRC",
    "TCP",
    "UDP",
    "DHCP",
    "ARP",
    "ICMP",
    "IGMP",
    "IPv",
    "LLC",
    "Tot sum",
    "Min",
    "Max",
    "AVG",
    "Std",
    "Tot size",
    "IAT",
    "Number",
    "Variance",
]


# =====================================================================
# VALIDATION
# =====================================================================

if len(FEATURE_NAMES) != EXPECTED_FEATURE_COUNT:
    raise RuntimeError(
        "Internal feature schema error: "
        f"expected {EXPECTED_FEATURE_COUNT}, "
        f"found {len(FEATURE_NAMES)}."
    )


# =====================================================================
# HELPERS
# =====================================================================

def _number(
    value: Any,
    default: float = 0.0,
) -> float:
    """
    Convert a value safely to float.
    """

    if value is None:
        return float(default)

    try:
        result = float(value)
    except (TypeError, ValueError):
        return float(default)

    if not math.isfinite(result):
        return float(default)

    return result


def _integer(
    value: Any,
    default: int = 0,
) -> int:
    """
    Convert a value safely to integer.
    """

    try:
        return int(value)
    except (TypeError, ValueError):
        return int(default)


def _first(
    flow: Mapping[str, Any],
    *names: str,
    default: float = 0.0,
) -> float:
    """
    Return the first available field from several possible names.

    This allows the builder to work with slightly different naming
    conventions in flow_manager.py without changing the ML schema.
    """

    for name in names:
        if name in flow:
            return _number(
                flow[name],
                default,
            )

    return float(default)


def _flag(
    flow: Mapping[str, Any],
    *names: str,
) -> float:
    """
    Read a binary packet/flow flag.
    """

    value = _first(
        flow,
        *names,
        default=0.0,
    )

    return 1.0 if value > 0 else 0.0


# =====================================================================
# FLOW FEATURE BUILDER
# =====================================================================

@dataclass
class FlowFeatureBuilder:
    """
    Convert a completed flow into the 39-feature representation.

    The builder expects the flow manager to provide aggregate
    statistics. Missing optional protocol/flag statistics default
    to zero.

    NOTE:
    The purpose of this class is to establish a stable interface
    between flow_manager.py and the ML inference layer.
    """

    packets_per_second_scale: float = 1.0

    # -----------------------------------------------------------------
    # BASIC FLOW STATISTICS
    # -----------------------------------------------------------------

    def _packet_count(
        self,
        flow: Mapping[str, Any],
    ) -> float:

        return _first(
            flow,
            "packets",
            "packet_count",
            "Number",
            default=0.0,
        )

    def _byte_count(
        self,
        flow: Mapping[str, Any],
    ) -> float:

        return _first(
            flow,
            "bytes",
            "byte_count",
            "tot_bytes",
            "Tot size",
            default=0.0,
        )

    def _duration(
        self,
        flow: Mapping[str, Any],
    ) -> float:

        return max(
            _first(
                flow,
                "duration",
                "flow_duration",
                "Duration",
                default=0.0,
            ),
            0.0,
        )

    # -----------------------------------------------------------------
    # RATE
    # -----------------------------------------------------------------

    def _rate(
        self,
        flow: Mapping[str, Any],
    ) -> float:

        explicit_rate = _first(
            flow,
            "Rate",
            "rate",
            "packet_rate",
            "packets_per_second",
            default=-1.0,
        )

        if explicit_rate >= 0:
            return explicit_rate * self.packets_per_second_scale

        packets = self._packet_count(flow)
        duration = self._duration(flow)

        if duration <= 0:
            return 0.0

        return (
            packets / duration
        ) * self.packets_per_second_scale

    # -----------------------------------------------------------------
    # HEADER STATISTICS
    # -----------------------------------------------------------------

    def _header_length(
        self,
        flow: Mapping[str, Any],
    ) -> float:
        """
        Build Header_Length from actual packet header metadata retained
        by the live packet/flow pipeline.

        Preference:
          1. Explicit per-packet combined header lengths
          2. IP + transport header arrays
          3. Existing explicit aggregate field
        """
        combined = flow.get("header_lengths")

        if combined:
            arr = np.asarray(combined, dtype=np.float64)
            arr = arr[np.isfinite(arr)]
            if arr.size:
                return float(np.mean(arr))

        ip_values = flow.get("ip_header_lengths", []) or []
        transport_values = flow.get(
            "transport_header_lengths",
            [],
        ) or []

        if ip_values or transport_values:
            ip_arr = np.asarray(ip_values, dtype=np.float64)
            tr_arr = np.asarray(
                transport_values,
                dtype=np.float64,
            )

            n = max(ip_arr.size, tr_arr.size)

            if n:
                if ip_arr.size == 0:
                    ip_arr = np.zeros(n, dtype=np.float64)
                elif ip_arr.size != n:
                    ip_arr = np.resize(ip_arr, n)

                if tr_arr.size == 0:
                    tr_arr = np.zeros(n, dtype=np.float64)
                elif tr_arr.size != n:
                    tr_arr = np.resize(tr_arr, n)

                arr = ip_arr + tr_arr
                arr = arr[np.isfinite(arr)]

                if arr.size:
                    return float(np.mean(arr))

        explicit = _first(
            flow,
            "Header_Length",
            "header_length",
            default=float("nan"),
        )

        if math.isfinite(explicit):
            return explicit

        return 0.0

    # -----------------------------------------------------------------
    # SIZE STATISTICS
    # -----------------------------------------------------------------

    def _packet_size_statistics(
        self,
        flow: Mapping[str, Any],
    ) -> tuple[float, float, float, float, float, float]:
        """
        Calculate packet-size statistics from retained packet lengths.

        When packet lengths are available:
          Tot sum = sum(lengths)
          Min     = minimum(lengths)
          Max     = maximum(lengths)
          AVG     = mean(lengths)
          Std     = population standard deviation
          Tot size = mean(lengths)

        Explicit aggregate fields remain a compatibility fallback.
        """
        lengths = []

        packet_lengths = flow.get("packet_lengths")

        if packet_lengths:
            lengths.extend(packet_lengths)

        # Some older flow dictionaries may only contain directional
        # arrays. Avoid duplicating them when packet_lengths exists.
        if not packet_lengths:
            lengths.extend(
                flow.get("forward_packet_lengths", []) or []
            )
            lengths.extend(
                flow.get("backward_packet_lengths", []) or []
            )

        if lengths:
            arr = np.asarray(lengths, dtype=np.float64)
            arr = arr[np.isfinite(arr)]

            if arr.size:
                total_sum = float(np.sum(arr))
                minimum = float(np.min(arr))
                maximum = float(np.max(arr))
                average = float(np.mean(arr))
                std = float(np.std(arr, ddof=0))

                return (
                    total_sum,
                    minimum,
                    maximum,
                    average,
                    std,
                    average,
                )

        total_sum = _first(
            flow,
            "Tot sum",
            "tot_sum",
            "total_sum",
            "bytes",
            default=0.0,
        )

        minimum = _first(
            flow,
            "Min",
            "min_size",
            "min_packet_size",
            default=0.0,
        )

        maximum = _first(
            flow,
            "Max",
            "max_size",
            "max_packet_size",
            default=0.0,
        )

        average = _first(
            flow,
            "AVG",
            "avg_size",
            "average_packet_size",
            "Tot size",
            "total_size",
            default=0.0,
        )

        std = _first(
            flow,
            "Std",
            "std_size",
            "std_packet_size",
            default=0.0,
        )

        total_size = _first(
            flow,
            "Tot size",
            "total_size",
            "total_bytes",
            default=average,
        )

        return (
            total_sum,
            minimum,
            maximum,
            average,
            std,
            total_size,
        )

    # -----------------------------------------------------------------
    # IAT
    # -----------------------------------------------------------------

    def _iat(
        self,
        flow: Mapping[str, Any],
    ) -> float:
        timestamps = flow.get("packet_timestamps")

        if timestamps:
            arr = np.asarray(
                timestamps,
                dtype=np.float64,
            )
            arr = arr[np.isfinite(arr)]

            if arr.size >= 2:
                arr = np.sort(arr)
                deltas = np.diff(arr)
                deltas = deltas[
                    np.isfinite(deltas)
                    & (deltas >= 0)
                ]

                if deltas.size:
                    return float(np.mean(deltas))

            return 0.0

        return _first(
            flow,
            "IAT",
            "iat",
            "inter_arrival_time",
            "inter_arrival",
            default=self._duration(flow),
        )

    # -----------------------------------------------------------------
    # FLAG FRACTIONS
    # -----------------------------------------------------------------

    @staticmethod
    def _flag_fraction(
        count: float,
        packets: float,
        flow: Mapping[str, Any],
        *fallback_names: str,
    ) -> float:
        if packets > 0:
            return float(count) / float(packets)

        return _flag(flow, *fallback_names)

    # -----------------------------------------------------------------
    # BUILD DICTIONARY
    # -----------------------------------------------------------------

    def build_feature_dict(
        self,
        flow: Mapping[str, Any],
    ) -> dict[str, float]:
        """
        Build the 39-feature live vector.

        The builder consumes packet-level metadata retained by the live
        flow pipeline whenever available. It does not alter the trained
        model, scaler, or stored results.
        """

        packets = self._packet_count(flow)
        duration = self._duration(flow)

        (
            total_sum,
            minimum,
            maximum,
            average,
            std,
            total_size,
        ) = self._packet_size_statistics(flow)

        protocol = _first(
            flow,
            "Protocol Type",
            "protocol",
            "protocol_type",
            default=0.0,
        )

        # -------------------------------------------------------------
        # TTL
        # -------------------------------------------------------------

        ttl_values = []

        ttl_values.extend(
            flow.get("forward_ttl_values", []) or []
        )
        ttl_values.extend(
            flow.get("backward_ttl_values", []) or []
        )

        if ttl_values:
            arr = np.asarray(
                ttl_values,
                dtype=np.float64,
            )
            arr = arr[np.isfinite(arr)]
            ttl = (
                float(np.mean(arr))
                if arr.size
                else 0.0
            )
        else:
            ttl = _first(
                flow,
                "Time_To_Live",
                "ttl",
                "TTL",
                default=0.0,
            )

        # -------------------------------------------------------------
        # TCP FLAG COUNTS
        # -------------------------------------------------------------

        ack_count = _first(
            flow,
            "ack_count",
            "ACK_count",
            "tcp_ack_count",
            default=0.0,
        )
        syn_count = _first(
            flow,
            "syn_count",
            "SYN_count",
            "tcp_syn_count",
            default=0.0,
        )
        fin_count = _first(
            flow,
            "fin_count",
            "FIN_count",
            "tcp_fin_count",
            default=0.0,
        )
        rst_count = _first(
            flow,
            "rst_count",
            "RST_count",
            "tcp_rst_count",
            default=0.0,
        )

        psh_count = _first(
            flow,
            "psh_count",
            "PSH_count",
            "tcp_psh_count",
            default=0.0,
        )
        ece_count = _first(
            flow,
            "ece_count",
            "tcp_ece_count",
            default=0.0,
        )
        cwr_count = _first(
            flow,
            "cwr_count",
            "tcp_cwr_count",
            default=0.0,
        )

        # Use packet fractions for the *_flag_number fields when
        # packet-level counts are available.
        fin_flag = self._flag_fraction(
            fin_count,
            packets,
            flow,
            "fin_flag_number",
            "fin_flag",
            "fin",
        )
        syn_flag = self._flag_fraction(
            syn_count,
            packets,
            flow,
            "syn_flag_number",
            "syn_flag",
            "syn",
        )
        rst_flag = self._flag_fraction(
            rst_count,
            packets,
            flow,
            "rst_flag_number",
            "rst_flag",
            "rst",
        )
        psh_flag = self._flag_fraction(
            psh_count,
            packets,
            flow,
            "psh_flag_number",
            "psh_flag",
            "psh",
        )
        ack_flag = self._flag_fraction(
            ack_count,
            packets,
            flow,
            "ack_flag_number",
            "ack_flag",
            "ack",
        )
        ece_flag = self._flag_fraction(
            ece_count,
            packets,
            flow,
            "ece_flag_number",
            "ece_flag",
            "ece",
        )
        cwr_flag = self._flag_fraction(
            cwr_count,
            packets,
            flow,
            "cwr_flag_number",
            "cwr_flag",
            "cwr",
        )

        # -------------------------------------------------------------
        # APPLICATION PROTOCOL INDICATORS
        # -------------------------------------------------------------

        src_port = _integer(flow.get("src_port", 0))
        dst_port = _integer(flow.get("dst_port", 0))
        ports = {src_port, dst_port}

        http = _flag(flow, "HTTP", "http")
        https = _flag(flow, "HTTPS", "https")
        dns = _flag(flow, "DNS", "dns")
        telnet = _flag(flow, "Telnet", "telnet")
        smtp = _flag(flow, "SMTP", "smtp")
        ssh = _flag(flow, "SSH", "ssh")
        irc = _flag(flow, "IRC", "irc")

        if not http and 80 in ports:
            http = 1.0
        if not https and 443 in ports:
            https = 1.0
        if not dns and 53 in ports:
            dns = 1.0
        if not telnet and 23 in ports:
            telnet = 1.0
        if not smtp and ports.intersection({25, 465, 587}):
            smtp = 1.0
        if not ssh and 22 in ports:
            ssh = 1.0
        if not irc and 6667 in ports:
            irc = 1.0

        # -------------------------------------------------------------
        # NETWORK PROTOCOL INDICATORS
        # -------------------------------------------------------------

        tcp = 1.0 if int(protocol) == 6 else 0.0
        udp = 1.0 if int(protocol) == 17 else 0.0
        icmp = 1.0 if int(protocol) == 1 else 0.0
        igmp = 1.0 if int(protocol) == 2 else 0.0

        tcp = max(tcp, _flag(flow, "TCP", "tcp"))
        udp = max(udp, _flag(flow, "UDP", "udp"))
        icmp = max(icmp, _flag(flow, "ICMP", "icmp"))
        igmp = max(igmp, _flag(flow, "IGMP", "igmp"))

        dhcp = _flag(flow, "DHCP", "dhcp")
        arp = _flag(flow, "ARP", "arp")

        # IPv is represented as the fraction of captured packets that
        # have an IP version. This avoids the previous hard-coded
        # binary assumption when packet arrays are available.
        ip_versions = flow.get("ip_version_values", []) or []

        if ip_versions:
            arr = np.asarray(
                ip_versions,
                dtype=np.float64,
            )
            arr = arr[np.isfinite(arr)]
            ipv = (
                float(np.mean(arr > 0))
                if arr.size
                else 0.0
            )
        else:
            ipv = _flag(
                flow,
                "IPv",
                "ipv",
                "ip",
            )

        # CICIoT2023 LLC is observed to have the same distribution as
        # IPv in the source data. For ordinary IP traffic, therefore,
        # use the retained IP-packet fraction rather than interpreting
        # Scapy's optional 802.2 LLC layer as the dataset feature.
        #
        # An explicit CICIoT-style LLC value still takes precedence.
        explicit_llc = _first(
            flow,
            "LLC",
            "llc",
            default=float("nan"),
        )

        if math.isfinite(explicit_llc):
            llc = explicit_llc
        elif ip_versions:
            arr = np.asarray(
                ip_versions,
                dtype=np.float64,
            )
            arr = arr[np.isfinite(arr)]
            llc = (
                float(np.mean(arr > 0))
                if arr.size
                else 0.0
            )
        else:
            llc_values = flow.get(
                "llc_present_values",
                [],
            ) or []

            if llc_values:
                arr = np.asarray(
                    llc_values,
                    dtype=np.float64,
                )
                arr = arr[np.isfinite(arr)]
                llc = (
                    float(np.mean(arr > 0))
                    if arr.size
                    else 0.0
                )
            else:
                llc = 0.0

        # -------------------------------------------------------------
        # RATE
        # -------------------------------------------------------------

        rate = self._rate(flow)

        # -------------------------------------------------------------
        # IAT / VARIANCE
        # -------------------------------------------------------------

        iat = self._iat(flow)

        explicit_variance = _first(
            flow,
            "Variance",
            "variance",
            default=float("nan"),
        )

        if math.isfinite(explicit_variance):
            variance = max(
                0.0,
                explicit_variance,
            )
        else:
            variance = max(
                0.0,
                std * std,
            )

        # -------------------------------------------------------------
        # FINAL 39 FEATURES
        # -------------------------------------------------------------

        features = {
            "Header_Length": self._header_length(flow),
            "Protocol Type": protocol,
            "Time_To_Live": ttl,
            "Rate": rate,

            "fin_flag_number": fin_flag,
            "syn_flag_number": syn_flag,
            "rst_flag_number": rst_flag,
            "psh_flag_number": psh_flag,
            "ack_flag_number": ack_flag,
            "ece_flag_number": ece_flag,
            "cwr_flag_number": cwr_flag,

            "ack_count": ack_count,
            "syn_count": syn_count,
            "fin_count": fin_count,
            "rst_count": rst_count,

            "HTTP": http,
            "HTTPS": https,
            "DNS": dns,
            "Telnet": telnet,
            "SMTP": smtp,
            "SSH": ssh,
            "IRC": irc,

            "TCP": tcp,
            "UDP": udp,
            "DHCP": dhcp,
            "ARP": arp,
            "ICMP": icmp,
            "IGMP": igmp,
            "IPv": ipv,
            "LLC": llc,

            "Tot sum": total_sum,
            "Min": minimum,
            "Max": maximum,
            "AVG": average,
            "Std": std,
            "Tot size": total_size,
            "IAT": iat,
            "Number": packets,
            "Variance": variance,
        }

        return {
            name: _number(features.get(name, 0.0))
            for name in FEATURE_NAMES
        }

    # -----------------------------------------------------------------
    # VECTOR
    # -----------------------------------------------------------------

    def build_vector(
        self,
        flow: Mapping[str, Any],
    ) -> np.ndarray:
        """
        Return the feature vector in the exact 39-column order.
        """

        feature_dict = self.build_feature_dict(
            flow
        )

        vector = np.asarray(
            [
                feature_dict[name]
                for name in FEATURE_NAMES
            ],
            dtype=np.float32,
        )

        if vector.shape != (
            EXPECTED_FEATURE_COUNT,
        ):
            raise RuntimeError(
                "Feature vector shape error: "
                f"expected ({EXPECTED_FEATURE_COUNT},), "
                f"got {vector.shape}."
            )

        return vector

    # -----------------------------------------------------------------
    # BATCH
    # -----------------------------------------------------------------

    def build_batch(
        self,
        flows: list[Mapping[str, Any]],
    ) -> np.ndarray:
        """
        Build a batch of flow features.

        Returns shape:

            (N, 39)
        """

        if not flows:
            return np.empty(
                (
                    0,
                    EXPECTED_FEATURE_COUNT,
                ),
                dtype=np.float32,
            )

        batch = np.vstack(
            [
                self.build_vector(flow)
                for flow in flows
            ]
        )

        return batch.astype(
            np.float32,
            copy=False,
        )

    # -----------------------------------------------------------------
    # NAMES
    # -----------------------------------------------------------------

    @staticmethod
    def feature_names() -> list[str]:
        return list(FEATURE_NAMES)

    @staticmethod
    def feature_count() -> int:
        return EXPECTED_FEATURE_COUNT


# =====================================================================
# CONVENIENCE API
# =====================================================================

_default_builder: Optional[
    FlowFeatureBuilder
] = None


def get_feature_builder() -> FlowFeatureBuilder:
    global _default_builder

    if _default_builder is None:
        _default_builder = FlowFeatureBuilder()

    return _default_builder


def build_live_features(
    flow: Mapping[str, Any],
) -> np.ndarray:
    """
    Convenience function.

    Returns an unscaled 39-feature vector.
    """

    return get_feature_builder().build_vector(
        flow
    )


# =====================================================================
# SELF TEST
# =====================================================================

def _create_test_flow() -> dict[str, Any]:
    """
    Synthetic flow for interface testing only.

    These values are NOT intended to represent a real attack.
    """

    return {
        "src_ip": "192.168.1.10",
        "dst_ip": "192.168.1.20",
        "src_port": 50000,
        "dst_port": 80,
        "protocol": 6,

        "packets": 3,
        "bytes": 300,
        "duration": 0.2,

        "packet_rate": 15.0,

        "ip_version_values": [4, 4, 4],
        "ip_header_lengths": [20, 20, 20],
        "transport_header_lengths": [20, 20, 20],
        "llc_present_values": [0, 0, 0],
        "packet_lengths": [54, 54, 68],
        "packet_timestamps": [1.0, 1.1, 1.2],

        "header_length": 40,
        "ttl": 64,

        "syn_count": 1,
        "ack_count": 2,
        "fin_count": 0,
        "rst_count": 0,

        "syn_flag": 1,
        "ack_flag": 1,
        "fin_flag": 0,
        "rst_flag": 0,
        "psh_flag": 0,
        "ece_flag": 0,
        "cwr_flag": 0,

        "http": 1,
        "https": 0,
        "dns": 0,
        "telnet": 0,
        "smtp": 0,
        "ssh": 0,
        "irc": 0,

        "tcp": 1,
        "udp": 0,
        "dhcp": 0,
        "arp": 0,
        "icmp": 0,
        "igmp": 0,
        "ipv": 1,
        "llc": 0,

        "total_size": 300,
        "min_size": 54,
        "max_size": 68,
        "avg_size": 60,
        "std_size": 6,

        "iat": 0.1,
        "variance": 36,
    }


def main() -> None:

    print("=" * 70)
    print("AEFL-OSIDS LIVE FLOW FEATURE BUILDER TEST")
    print("=" * 70)

    builder = FlowFeatureBuilder()

    print()
    print(
        f"Feature count: {builder.feature_count()}"
    )

    print()
    print("Building synthetic flow...")

    flow = _create_test_flow()

    features = builder.build_feature_dict(
        flow
    )

    vector = builder.build_vector(
        flow
    )

    print()
    print("Feature vector:")

    for index, name in enumerate(
        FEATURE_NAMES
    ):
        print(
            f"{index + 1:02d}. "
            f"{name:<22} "
            f"{features[name]:>12.6f}"
        )

    print()
    print(
        f"Vector shape : {vector.shape}"
    )

    print(
        f"Vector dtype : {vector.dtype}"
    )

    if vector.shape != (
        EXPECTED_FEATURE_COUNT,
    ):
        raise RuntimeError(
            "SELF TEST FAILED: invalid vector shape."
        )

    print()
    print("=" * 70)
    print("FLOW FEATURE BUILDER TEST SUCCESSFUL")
    print("=" * 70)


if __name__ == "__main__":
    main()