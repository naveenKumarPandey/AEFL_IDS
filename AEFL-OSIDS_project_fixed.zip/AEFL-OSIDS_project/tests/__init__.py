"""AEFL-OSIDS regression tests."""
