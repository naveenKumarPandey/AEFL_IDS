AEFL-OSIDS FULL-DATA PERFORMANCE UPDATE v2.2

Purpose
-------
This update removes repeated compressed-NPZ loading and prevents long
same-class file sequences during centralized and federated training.

Installation
------------
Extract this archive directly into the AEFL-OSIDS project root and allow
Windows to replace the matching Python files. The archive contains code only;
it does not modify or remove raw data, processed data, models, or results.

Verification (run from the project root with .venv active)
-----------------------------------------------------------
python -m py_compile data_loader\cic_iot_dataset.py training\centralized_trainer.py federated\efficient_data.py federated\fedavg.py federated\adaptive_fedavg.py federated\robust_adaptive_fedprox.py

No output from py_compile means verification passed. Dataset preprocessing
does not need to be repeated.
