"""AEFL-OSIDS Windows launcher with reliable Ctrl+C shutdown.

Run from the project root:
    python run_dashboard.py

Ctrl+C stops the Streamlit child process tree immediately on Windows.
"""

from __future__ import annotations

import os
import signal
import subprocess
import sys
import time
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent
APP_PATH = PROJECT_ROOT / "ui" / "app.py"

_child: subprocess.Popen | None = None
_stopping = False


def stop_dashboard() -> None:
    """Stop only the Streamlit process tree started by this launcher."""
    global _child, _stopping

    if _stopping:
        return
    _stopping = True

    proc = _child
    if proc is None or proc.poll() is not None:
        return

    print("\nStopping AEFL-OSIDS dashboard and packet capture...", flush=True)

    if os.name == "nt":
        # Most reliable Windows shutdown: terminate the Streamlit PID and all
        # descendants (including capture/sniffer workers) started beneath it.
        subprocess.run(
            ["taskkill", "/PID", str(proc.pid), "/T", "/F"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            check=False,
        )

        # Wait briefly for Windows to release the process/port.
        deadline = time.time() + 3.0
        while proc.poll() is None and time.time() < deadline:
            time.sleep(0.05)
    else:
        try:
            os.killpg(os.getpgid(proc.pid), signal.SIGTERM)
        except Exception:
            try:
                proc.terminate()
            except Exception:
                pass

    print("Dashboard stopped.", flush=True)


def handle_interrupt(signum, frame) -> None:
    stop_dashboard()
    raise SystemExit(0)


def main() -> int:
    global _child

    if not APP_PATH.exists():
        print(f"ERROR: Streamlit app not found: {APP_PATH}")
        return 1

    # Register Ctrl+C before starting Streamlit.
    signal.signal(signal.SIGINT, handle_interrupt)
    if hasattr(signal, "SIGTERM"):
        signal.signal(signal.SIGTERM, handle_interrupt)

    cmd = [
        sys.executable,
        "-m",
        "streamlit",
        "run",
        str(APP_PATH),
        "--server.port",
        "8501",
    ]

    kwargs = {
        "cwd": str(PROJECT_ROOT),
    }

    if os.name == "nt":
        # Put Streamlit in its own process group so the launcher owns and can
        # reliably terminate that complete child tree.
        kwargs["creationflags"] = subprocess.CREATE_NEW_PROCESS_GROUP
    else:
        kwargs["start_new_session"] = True

    print("=" * 64)
    print("AEFL-OSIDS DASHBOARD")
    print("=" * 64)
    print("Starting Streamlit dashboard...")
    print("Press Ctrl+C in THIS terminal to stop it completely.")
    print()

    _child = subprocess.Popen(cmd, **kwargs)

    try:
        # Poll instead of blocking forever in wait(); this keeps the launcher
        # responsive to Ctrl+C on Windows PowerShell.
        while _child.poll() is None:
            time.sleep(0.20)
        return int(_child.returncode or 0)
    except KeyboardInterrupt:
        stop_dashboard()
        return 0
    finally:
        if _child is not None and _child.poll() is None:
            stop_dashboard()


if __name__ == "__main__":
    raise SystemExit(main())
