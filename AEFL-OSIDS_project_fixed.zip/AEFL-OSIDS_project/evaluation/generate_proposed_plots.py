"""Generate figures from independently recomputed proposed-model results."""

from __future__ import annotations

import json
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


PROJECT_ROOT = Path(__file__).resolve().parents[1]
RESULTS_ROOT = PROJECT_ROOT / "results"
VERIFIED_DIR = RESULTS_ROOT / "verified_comparison"
HYBRID_DIR = RESULTS_ROOT / "hybrid_open_set"
TRAINING_DIR = RESULTS_ROOT / "robust_adaptive_fedprox"
OUTPUT_DIR = RESULTS_ROOT / "proposed_publication"
CLASS_NAMES = ["BENIGN", "DDoS", "DoS", "Mirai", "Recon"]

COLORS = ["#64748b", "#f59e0b", "#ef4444", "#2563eb"]


def _finish(path: Path) -> None:
    plt.tight_layout()
    plt.savefig(path, dpi=220, bbox_inches="tight")
    plt.close()


def _comparison_plot(frame: pd.DataFrame) -> None:
    metrics = ["Accuracy", "Macro F1", "Weighted F1"]
    positions = np.arange(len(frame))
    width = 0.23
    plt.figure(figsize=(11, 5.5))
    for index, metric in enumerate(metrics):
        values = frame[metric].astype(float).to_numpy() * 100
        plt.bar(
            positions + (index - 1) * width,
            values,
            width,
            label=metric,
            color=["#2563eb", "#16a34a", "#7c3aed"][index],
        )
    plt.xticks(positions, frame["Method"], rotation=12, ha="right")
    plt.ylabel("Score (%)")
    plt.ylim(0, 100)
    plt.title("Independent Known-Class Test Comparison")
    plt.legend(ncols=3, loc="lower left")
    plt.grid(axis="y", alpha=0.2)
    _finish(OUTPUT_DIR / "verified_test_comparison.png")


def _per_class_plot(frame: pd.DataFrame) -> None:
    positions = np.arange(len(CLASS_NAMES))
    width = 0.19
    plt.figure(figsize=(11, 5.5))
    for index, (_, row) in enumerate(frame.iterrows()):
        values = [float(row[f"{name} F1"]) * 100 for name in CLASS_NAMES]
        plt.bar(
            positions + (index - (len(frame) - 1) / 2) * width,
            values,
            width,
            label=row["Method"],
            color=COLORS[index % len(COLORS)],
        )
    plt.xticks(positions, CLASS_NAMES)
    plt.ylabel("F1 score (%)")
    plt.ylim(0, 105)
    plt.title("Per-Class F1 on the Independent Known-Class Test Set")
    plt.legend(fontsize=8, ncols=2, loc="lower center")
    plt.grid(axis="y", alpha=0.2)
    _finish(OUTPUT_DIR / "verified_test_per_class_f1.png")


def _convergence_plot(history: list[dict]) -> None:
    rounds = [item["round"] for item in history]
    accuracy = [item["validation"]["accuracy"] * 100 for item in history]
    macro_f1 = [item["validation"]["f1_macro"] * 100 for item in history]
    loss = [item["validation"]["loss"] for item in history]
    figure, left = plt.subplots(figsize=(9, 5.2))
    left.plot(rounds, accuracy, marker="o", linewidth=2.2, label="Accuracy", color="#2563eb")
    left.plot(rounds, macro_f1, marker="o", linewidth=2.2, label="Macro F1", color="#16a34a")
    left.set_xlabel("Federated round")
    left.set_ylabel("Validation score (%)")
    left.set_xticks(rounds)
    left.grid(alpha=0.2)
    right = left.twinx()
    right.plot(rounds, loss, marker="s", linestyle="--", label="Loss", color="#dc2626")
    right.set_ylabel("Cross-entropy loss")
    lines = left.get_lines() + right.get_lines()
    left.legend(lines, [line.get_label() for line in lines], loc="lower right")
    plt.title("Proposed Federated Training Convergence")
    figure.tight_layout()
    figure.savefig(OUTPUT_DIR / "proposed_training_convergence.png", dpi=220, bbox_inches="tight")
    plt.close(figure)


def _hybrid_plot(frame: pd.DataFrame) -> None:
    metrics = ["Unknown Precision", "Unknown Recall", "Unknown F1", "AUROC"]
    positions = np.arange(len(metrics))
    width = 0.34
    plt.figure(figsize=(9, 5.2))
    for index, (_, row) in enumerate(frame.iterrows()):
        values = [float(row[metric]) * 100 for metric in metrics]
        plt.bar(
            positions + (index - 0.5) * width,
            values,
            width,
            label=f"{row['Method']} (known FPR {float(row['Known FPR']) * 100:.1f}%)",
            color=["#64748b", "#2563eb"][index % 2],
        )
    plt.xticks(positions, ["Precision", "Recall", "Unknown F1", "AUROC"])
    plt.ylabel("Score (%)")
    plt.ylim(0, 105)
    plt.title("Open-Set Test Performance")
    plt.legend(loc="lower right", fontsize=8)
    plt.grid(axis="y", alpha=0.2)
    _finish(OUTPUT_DIR / "hybrid_open_set_comparison.png")


def _family_plot(frame: pd.DataFrame) -> None:
    values = frame["unknown_detection_recall"].astype(float).to_numpy() * 100
    plt.figure(figsize=(8, 4.8))
    bars = plt.bar(frame["family"], values, color="#2563eb")
    plt.bar_label(bars, labels=[f"{value:.1f}%" for value in values], padding=3)
    plt.ylabel("Unknown detection recall (%)")
    plt.ylim(0, 100)
    plt.title("Detection Recall by Held-Out Attack Family")
    plt.grid(axis="y", alpha=0.2)
    _finish(OUTPUT_DIR / "hybrid_unknown_family_recall.png")


def _confusion_plot(payload: dict) -> None:
    selected = next(
        item
        for item in payload["results"]
        if "proposed" in item["method"].lower()
        and item["evaluation_split"] == "independent_test_known"
    )
    matrix = np.asarray(selected["metrics"]["confusion_matrix"], dtype=int)
    plt.figure(figsize=(7, 6))
    image = plt.imshow(matrix, cmap="Blues")
    plt.colorbar(image, fraction=0.046, pad=0.04)
    plt.xticks(range(len(CLASS_NAMES)), CLASS_NAMES, rotation=25, ha="right")
    plt.yticks(range(len(CLASS_NAMES)), CLASS_NAMES)
    plt.xlabel("Predicted class")
    plt.ylabel("True class")
    plt.title("Proposed Model: Independent-Test Confusion Matrix")
    cutoff = matrix.max() * 0.55
    for row in range(matrix.shape[0]):
        for column in range(matrix.shape[1]):
            plt.text(
                column,
                row,
                f"{matrix[row, column]:,}",
                ha="center",
                va="center",
                fontsize=8,
                color="white" if matrix[row, column] > cutoff else "black",
            )
    _finish(OUTPUT_DIR / "proposed_test_confusion_matrix.png")


def main() -> None:
    required = [
        VERIFIED_DIR / "publication_test_comparison.csv",
        VERIFIED_DIR / "verified_model_comparison.json",
        HYBRID_DIR / "hybrid_vs_msp.csv",
        HYBRID_DIR / "unknown_family_performance.csv",
        TRAINING_DIR / "round_history.json",
    ]
    missing = [str(path) for path in required if not path.exists()]
    if missing:
        raise FileNotFoundError("Generate evaluation outputs first:\n" + "\n".join(missing))

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    comparison = pd.read_csv(required[0])
    verified = json.loads(required[1].read_text(encoding="utf-8"))
    hybrid = pd.read_csv(required[2])
    families = pd.read_csv(required[3])
    history = json.loads(required[4].read_text(encoding="utf-8"))

    _comparison_plot(comparison)
    _per_class_plot(comparison)
    _convergence_plot(history)
    _hybrid_plot(hybrid)
    _family_plot(families)
    _confusion_plot(verified)
    print(f"Figures: {OUTPUT_DIR}")


if __name__ == "__main__":
    main()
