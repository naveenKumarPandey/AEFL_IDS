"""
AEFL-OSIDS Publication-Ready Results Generator

Reads EXISTING experiment outputs only.
Does NOT retrain models or reprocess the dataset.

Run from project root:

    python -m evaluation.generate_paper_results
"""

from __future__ import annotations

import json
import math
import re
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


# =====================================================================
# PATHS
# =====================================================================

PROJECT_ROOT = Path(__file__).resolve().parents[1]

RESULTS_ROOT = (
    PROJECT_ROOT
    / "results"
)

OUT_DIR = (
    RESULTS_ROOT
    / "paper_results"
)

SCENARIO = "scenario_C_multiple"


# ---------------------------------------------------------------------
# FINAL COMPARISON
# ---------------------------------------------------------------------

COMPARISON_JSON = (
    RESULTS_ROOT
    / "final_comparison"
    / "final_comparison.json"
)

COMPARISON_CSV = (
    RESULTS_ROOT
    / "final_comparison"
    / "classification_comparison.csv"
)

COMPARISON_SUMMARY = (
    RESULTS_ROOT
    / "final_comparison"
    / "summary.txt"
)


# ---------------------------------------------------------------------
# OPEN-SET
# ---------------------------------------------------------------------

OPEN_SET_JSON = (
    RESULTS_ROOT
    / "final_open_set"
    / "final_open_set_results.json"
)


# ---------------------------------------------------------------------
# THRESHOLD
# ---------------------------------------------------------------------

THRESHOLD_JSON = (
    RESULTS_ROOT
    / "threshold_analysis"
    / "threshold_analysis.json"
)

CALIBRATION_JSON = (
    RESULTS_ROOT
    / "threshold_calibration"
    / "threshold_calibration.json"
)


# ---------------------------------------------------------------------
# SHAP
# ---------------------------------------------------------------------

SHAP_METADATA_JSON = (
    RESULTS_ROOT
    / "shap"
    / SCENARIO
    / "shap_metadata.json"
)

SHAP_IMPORTANCE_CSV = (
    RESULTS_ROOT
    / "shap"
    / SCENARIO
    / "global_feature_importance.csv"
)


# ---------------------------------------------------------------------
# FEDERATED LEARNING HISTORY
# ---------------------------------------------------------------------

V2_HISTORY = (
    RESULTS_ROOT
    / "adaptive_fedavg_v2"
    / "round_history.json"
)

V1_HISTORY = (
    RESULTS_ROOT
    / "adaptive_fedavg"
    / "round_history.json"
)


# ---------------------------------------------------------------------
# UNKNOWN FAMILY ANALYSIS
# ---------------------------------------------------------------------

UNKNOWN_FAMILY_JSON = (
    RESULTS_ROOT
    / "unknown_family_analysis"
    / "unknown_family_analysis.json"
)


# =====================================================================
# HELPERS
# =====================================================================

def load_json(
    path: Path,
):
    """
    Load JSON file.
    """

    if not path.exists():
        raise FileNotFoundError(
            f"Required file not found:\n{path}"
        )

    with path.open(
        "r",
        encoding="utf-8",
    ) as f:

        return json.load(f)


# ---------------------------------------------------------------------

def save_csv(
    df: pd.DataFrame,
    path: Path,
):
    """
    Save DataFrame as UTF-8 CSV.
    """

    df.to_csv(
        path,
        index=False,
        encoding="utf-8-sig",
    )


# ---------------------------------------------------------------------

def pct(
    value,
):
    """
    Convert a fraction to percentage.

    Example:
        0.845 -> 84.5
    """

    if value is None:
        return np.nan

    try:

        value = float(value)

    except (
        TypeError,
        ValueError,
    ):

        return np.nan

    if math.isnan(value):
        return np.nan

    return value * 100.0


# ---------------------------------------------------------------------

def normalize_key(
    value,
):
    """
    Normalize dictionary keys for flexible matching.
    """

    return (
        str(value)
        .lower()
        .replace(
            "-",
            "_",
        )
        .replace(
            " ",
            "_",
        )
    )


# ---------------------------------------------------------------------

def find_metric(
    data,
    names,
):
    """
    Find a metric from a dictionary using direct
    and normalized key matching.
    """

    if not isinstance(
        data,
        dict,
    ):
        return None

    # Direct lookup
    for name in names:

        if name in data:
            return data[name]

    # Normalized lookup
    normalized = {
        normalize_key(k): v
        for k, v in data.items()
    }

    for name in names:

        key = normalize_key(
            name
        )

        if key in normalized:
            return normalized[key]

    return None


# ---------------------------------------------------------------------

def normalize_history(
    raw,
):
    """
    Convert common round-history JSON layouts
    into a list of dictionaries.
    """

    if isinstance(
        raw,
        list,
    ):
        return raw

    if isinstance(
        raw,
        dict,
    ):

        for key in (
            "round_history",
            "history",
            "rounds",
            "metrics",
            "results",
        ):

            value = raw.get(
                key
            )

            if isinstance(
                value,
                list,
            ):

                return value

    return []


# =====================================================================
# 1. CLASSIFICATION COMPARISON
# =====================================================================

def generate_classification_table():

    print(
        "      Loading classification results..."
    )

    # ---------------------------------------------------------------
    # Prefer the already-generated CSV.
    # ---------------------------------------------------------------

    if COMPARISON_CSV.exists():

        try:

            df = pd.read_csv(
                COMPARISON_CSV
            )

            if not df.empty:

                save_csv(
                    df,
                    OUT_DIR
                    / "classification_comparison.csv",
                )

                return df

        except Exception as exc:

            print(
                f"      [WARN] Could not read classification CSV: "
                f"{exc}"
            )

    # ---------------------------------------------------------------
    # Fall back to JSON.
    # ---------------------------------------------------------------

    data = load_json(
        COMPARISON_JSON
    )

    methods = (
        data.get("methods")
        or data.get("comparison")
        or data.get("results")
    )

    rows = []

    if isinstance(
        methods,
        dict,
    ):

        iterable = methods.items()

    elif isinstance(
        methods,
        list,
    ):

        iterable = []

        for item in methods:

            if not isinstance(
                item,
                dict,
            ):
                continue

            name = (
                item.get("method")
                or item.get("model")
                or item.get("name")
                or "Unknown"
            )

            iterable.append(
                (
                    name,
                    item,
                )
            )

    else:

        iterable = []

    for name, metrics in iterable:

        if not isinstance(
            metrics,
            dict,
        ):
            continue

        rows.append(
            {
                "Method": name,

                "Accuracy": pct(
                    find_metric(
                        metrics,
                        [
                            "accuracy",
                            "acc",
                        ],
                    )
                ),

                "Macro Precision": pct(
                    find_metric(
                        metrics,
                        [
                            "macro_precision",
                            "precision_macro",
                        ],
                    )
                ),

                "Macro Recall": pct(
                    find_metric(
                        metrics,
                        [
                            "macro_recall",
                            "recall_macro",
                        ],
                    )
                ),

                "Macro F1": pct(
                    find_metric(
                        metrics,
                        [
                            "macro_f1",
                            "f1_macro",
                        ],
                    )
                ),

                "Weighted F1": pct(
                    find_metric(
                        metrics,
                        [
                            "weighted_f1",
                            "f1_weighted",
                        ],
                    )
                ),
            }
        )

    # ---------------------------------------------------------------
    # Summary.txt fallback.
    # ---------------------------------------------------------------

    if (
        not rows
        and COMPARISON_SUMMARY.exists()
    ):

        pattern = re.compile(
            r"^(Centralized Baseline|FedAvg|Adaptive FedAvg \(v1\)|Adaptive FedAvg \(v2\))\s+"
            r"([\d.]+)%\s+"
            r"([\d.]+)%\s+"
            r"([\d.]+)%\s+"
            r"([\d.]+)%\s+"
            r"([\d.]+)%"
        )

        for line in (
            COMPARISON_SUMMARY
            .read_text(
                encoding="utf-8"
            )
            .splitlines()
        ):

            match = pattern.match(
                line.strip()
            )

            if match:

                rows.append(
                    {
                        "Method": match.group(1),
                        "Accuracy": float(
                            match.group(2)
                        ),
                        "Macro Precision": float(
                            match.group(3)
                        ),
                        "Macro Recall": float(
                            match.group(4)
                        ),
                        "Macro F1": float(
                            match.group(5)
                        ),
                        "Weighted F1": float(
                            match.group(6)
                        ),
                    }
                )

    df = pd.DataFrame(
        rows
    )

    if df.empty:

        raise RuntimeError(
            "Could not extract classification comparison data."
        )

    save_csv(
        df,
        OUT_DIR
        / "classification_comparison.csv",
    )

    return df


# =====================================================================
# 2. OPEN-SET TABLE
# =====================================================================

def generate_open_set_table():

    data = load_json(
        OPEN_SET_JSON
    )

    unknown = data.get(
        "unknown_detection",
        {},
    )

    known = data.get(
        "known_class_performance",
        {},
    )

    row = {
        "Scenario": data.get(
            "scenario",
            SCENARIO,
        ),

        "Test Samples": data.get(
            "test_samples"
        ),

        "Locked Threshold": data.get(
            "locked_threshold"
        ),

        "Unknown Precision": pct(
            unknown.get(
                "precision"
            )
        ),

        "Unknown Recall": pct(
            unknown.get(
                "recall"
            )
        ),

        "Unknown F1": pct(
            unknown.get(
                "f1"
            )
        ),

        "Known FPR": pct(
            unknown.get(
                "known_fpr"
            )
        ),

        "Open-set AUROC": pct(
            data.get(
                "open_set_auroc"
            )
        ),

        "Known Accuracy": pct(
            known.get(
                "accuracy"
            )
        ),

        "Known Macro Precision": pct(
            known.get(
                "macro_precision"
            )
        ),

        "Known Macro Recall": pct(
            known.get(
                "macro_recall"
            )
        ),

        "Known Macro F1": pct(
            known.get(
                "macro_f1"
            )
        ),

        "Unknown Families": ", ".join(
            data.get(
                "unknown_families",
                [],
            )
        ),
    }

    df = pd.DataFrame(
        [row]
    )

    save_csv(
        df,
        OUT_DIR
        / "open_set_results.csv",
    )

    return df


# =====================================================================
# 3. THRESHOLD TABLE
# =====================================================================

def generate_threshold_table():

    data = load_json(
        THRESHOLD_JSON
    )

    candidates = (
        data.get("threshold_results")
        or data.get("thresholds")
        or data.get("results")
        or data.get("sweep")
    )

    rows = []

    if isinstance(
        candidates,
        list,
    ):

        for item in candidates:

            if not isinstance(
                item,
                dict,
            ):
                continue

            threshold = find_metric(
                item,
                [
                    "threshold"
                ],
            )

            if threshold is None:
                continue

            rows.append(
                {
                    "Threshold": float(
                        threshold
                    ),

                    "Precision": pct(
                        find_metric(
                            item,
                            [
                                "precision"
                            ],
                        )
                    ),

                    "Recall": pct(
                        find_metric(
                            item,
                            [
                                "recall"
                            ],
                        )
                    ),

                    "F1": pct(
                        find_metric(
                            item,
                            [
                                "f1"
                            ],
                        )
                    ),

                    "Known FPR": pct(
                        find_metric(
                            item,
                            [
                                "known_fpr",
                                "fpr",
                            ],
                        )
                    ),

                    "Balanced Accuracy": pct(
                        find_metric(
                            item,
                            [
                                "balanced_accuracy",
                                "balanced_acc",
                            ],
                        )
                    ),
                }
            )

    if not rows:

        raise RuntimeError(
            "Could not find threshold sweep records in:\n"
            f"{THRESHOLD_JSON}"
        )

    df = pd.DataFrame(
        rows
    )

    df = df.sort_values(
        "Threshold"
    ).reset_index(
        drop=True
    )

    save_csv(
        df,
        OUT_DIR
        / "threshold_analysis.csv",
    )

    return df


# =====================================================================
# 4. FEDERATED LEARNING CONVERGENCE
# =====================================================================

def generate_convergence_plot():

    histories = []

    # ---------------------------------------------------------------
    # Load both histories.
    # ---------------------------------------------------------------

    for label, path in [
        (
            "Adaptive FedAvg v1",
            V1_HISTORY,
        ),
        (
            "Adaptive FedAvg v2",
            V2_HISTORY,
        ),
    ]:

        if not path.exists():

            print(
                f"      [WARN] History not found: {path}"
            )

            continue

        try:

            raw = load_json(
                path
            )

            records = normalize_history(
                raw
            )

        except Exception as exc:

            print(
                f"      [WARN] Could not load {path}: {exc}"
            )

            continue

        for record in records:

            if not isinstance(
                record,
                dict,
            ):
                continue

            rnd = find_metric(
                record,
                [
                    "round",
                    "round_number",
                    "epoch",
                ],
            )

            acc = find_metric(
                record,
                [
                    "validation_accuracy",
                    "val_accuracy",
                    "accuracy",
                ],
            )

            loss = find_metric(
                record,
                [
                    "validation_loss",
                    "val_loss",
                    "loss",
                ],
            )

            macro_f1 = find_metric(
                record,
                [
                    "macro_f1",
                    "f1_macro",
                    "validation_macro_f1",
                ],
            )

            if rnd is None:
                continue

            histories.append(
                {
                    "Method": label,
                    "Round": int(rnd),
                    "Validation Accuracy": acc,
                    "Validation Loss": loss,
                    "Macro F1": macro_f1,
                }
            )

    if not histories:

        print(
            "      [WARN] No round-history records found."
        )

        return None

    df = pd.DataFrame(
        histories
    )

    df = df.sort_values(
        [
            "Method",
            "Round",
        ]
    )

    df.to_csv(
        OUT_DIR
        / "fl_convergence_data.csv",
        index=False,
        encoding="utf-8-sig",
    )

    # ---------------------------------------------------------------
    # Generate one chart for each metric.
    # ---------------------------------------------------------------

    metrics = [
        (
            "Validation Accuracy",
            "fl_convergence_accuracy.png",
            "Validation Accuracy",
        ),

        (
            "Macro F1",
            "fl_convergence_macro_f1.png",
            "Validation Macro F1",
        ),

        (
            "Validation Loss",
            "fl_convergence_loss.png",
            "Validation Loss",
        ),
    ]

    for metric, filename, ylabel in metrics:

        plt.figure(
            figsize=(8, 5)
        )

        plotted = False

        for method, group in df.groupby(
            "Method"
        ):

            values = pd.to_numeric(
                group[metric],
                errors="coerce",
            )

            valid = values.notna()

            if not valid.any():
                continue

            x = group.loc[
                valid,
                "Round",
            ]

            y = values.loc[
                valid
            ]

            plt.plot(
                x,
                y,
                marker="o",
                label=method,
            )

            plotted = True

        plt.xlabel(
            "Federated Learning Round"
        )

        plt.ylabel(
            ylabel
        )

        plt.title(
            f"FL Convergence: {ylabel}"
        )

        plt.grid(
            True,
            alpha=0.25,
        )

        if plotted:

            plt.legend()

        else:

            plt.text(
                0.5,
                0.5,
                "No valid data available",
                ha="center",
                va="center",
                transform=plt.gca().transAxes,
            )

        plt.tight_layout()

        plt.savefig(
            OUT_DIR / filename,
            dpi=300,
            bbox_inches="tight",
        )

        plt.close()

    return df


# =====================================================================
# 5. THRESHOLD TRADE-OFF PLOTS
# =====================================================================

def generate_threshold_plot(
    threshold_df,
):

    if (
        threshold_df is None
        or threshold_df.empty
    ):

        return

    # ---------------------------------------------------------------
    # Get actual locked threshold.
    # ---------------------------------------------------------------

    locked_threshold = None

    if CALIBRATION_JSON.exists():

        try:

            calibration = load_json(
                CALIBRATION_JSON
            )

            selected = calibration.get(
                "selected_operating_point",
                {},
            )

            if isinstance(
                selected,
                dict,
            ):

                locked_threshold = find_metric(
                    selected,
                    [
                        "threshold",
                        "selected_threshold",
                    ],
                )

            if locked_threshold is None:

                locked_threshold = find_metric(
                    calibration,
                    [
                        "locked_threshold",
                        "selected_threshold",
                        "threshold",
                    ],
                )

        except Exception:

            locked_threshold = None

    # Fall back to final open-set result.
    if locked_threshold is None:

        try:

            final_open = load_json(
                OPEN_SET_JSON
            )

            locked_threshold = final_open.get(
                "locked_threshold"
            )

        except Exception:

            locked_threshold = None

    if locked_threshold is None:

        locked_threshold = 0.5699575841426849

    locked_threshold = float(
        locked_threshold
    )

    # ---------------------------------------------------------------
    # F1
    # ---------------------------------------------------------------

    plt.figure(
        figsize=(8, 5)
    )

    plt.plot(
        threshold_df["Threshold"],
        threshold_df["F1"],
        marker="o",
    )

    plt.axvline(
        locked_threshold,
        linestyle="--",
        label=(
            f"Locked threshold = "
            f"{locked_threshold:.6f}"
        ),
    )

    plt.xlabel(
        "Open-set Threshold"
    )

    plt.ylabel(
        "Unknown Detection F1 (%)"
    )

    plt.title(
        "Open-set Threshold vs Unknown Detection F1"
    )

    plt.grid(
        True,
        alpha=0.25,
    )

    plt.legend()

    plt.tight_layout()

    plt.savefig(
        OUT_DIR
        / "threshold_vs_f1.png",
        dpi=300,
        bbox_inches="tight",
    )

    plt.close()

    # ---------------------------------------------------------------
    # Recall
    # ---------------------------------------------------------------

    plt.figure(
        figsize=(8, 5)
    )

    plt.plot(
        threshold_df["Threshold"],
        threshold_df["Recall"],
        marker="o",
    )

    plt.axvline(
        locked_threshold,
        linestyle="--",
        label=(
            f"Locked threshold = "
            f"{locked_threshold:.6f}"
        ),
    )

    plt.xlabel(
        "Open-set Threshold"
    )

    plt.ylabel(
        "Unknown Recall (%)"
    )

    plt.title(
        "Open-set Threshold vs Unknown Recall"
    )

    plt.grid(
        True,
        alpha=0.25,
    )

    plt.legend()

    plt.tight_layout()

    plt.savefig(
        OUT_DIR
        / "threshold_vs_recall.png",
        dpi=300,
        bbox_inches="tight",
    )

    plt.close()

    # ---------------------------------------------------------------
    # Known FPR
    # ---------------------------------------------------------------

    plt.figure(
        figsize=(8, 5)
    )

    plt.plot(
        threshold_df["Threshold"],
        threshold_df["Known FPR"],
        marker="o",
    )

    plt.axhline(
        5.0,
        linestyle="--",
        label="5% FPR target",
    )

    plt.axvline(
        locked_threshold,
        linestyle="--",
        label=(
            f"Locked threshold = "
            f"{locked_threshold:.6f}"
        ),
    )

    plt.xlabel(
        "Open-set Threshold"
    )

    plt.ylabel(
        "Known False Positive Rate (%)"
    )

    plt.title(
        "Open-set Threshold vs Known FPR"
    )

    plt.grid(
        True,
        alpha=0.25,
    )

    plt.legend()

    plt.tight_layout()

    plt.savefig(
        OUT_DIR
        / "threshold_vs_known_fpr.png",
        dpi=300,
        bbox_inches="tight",
    )

    plt.close()


# =====================================================================
# 6. SHAP GLOBAL IMPORTANCE
# =====================================================================

def generate_shap_table_and_plot():

    if not SHAP_IMPORTANCE_CSV.exists():

        print(
            "      [WARN] SHAP importance CSV not found."
        )

        return None

    df = pd.read_csv(
        SHAP_IMPORTANCE_CSV
    )

    if df.empty:

        print(
            "      [WARN] SHAP importance CSV is empty."
        )

        return None

    # ---------------------------------------------------------------
    # Detect feature column.
    # ---------------------------------------------------------------

    feature_col = next(
        (
            c
            for c in df.columns
            if c.lower()
            in {
                "feature",
                "feature_name",
                "features",
            }
        ),
        df.columns[0],
    )

    # ---------------------------------------------------------------
    # Detect importance column.
    # ---------------------------------------------------------------

    importance_col = next(
        (
            c
            for c in df.columns
            if (
                "importance"
                in c.lower()
                or "mean"
                in c.lower()
            )
        ),
        None,
    )

    if importance_col is None:

        if len(df.columns) < 2:

            print(
                "      [WARN] SHAP importance column not found."
            )

            return None

        importance_col = df.columns[1]

    df = df[
        [
            feature_col,
            importance_col,
        ]
    ].copy()

    df.columns = [
        "Feature",
        "Mean Absolute SHAP",
    ]

    df[
        "Mean Absolute SHAP"
    ] = pd.to_numeric(
        df[
            "Mean Absolute SHAP"
        ],
        errors="coerce",
    )

    df = (
        df
        .dropna()
        .sort_values(
            "Mean Absolute SHAP",
            ascending=False,
        )
        .reset_index(
            drop=True
        )
    )

    save_csv(
        df,
        OUT_DIR
        / "shap_global_importance.csv",
    )

    # ---------------------------------------------------------------
    # Plot top 15.
    # ---------------------------------------------------------------

    top = (
        df
        .head(15)
        .sort_values(
            "Mean Absolute SHAP"
        )
    )

    if not top.empty:

        plt.figure(
            figsize=(9, 7)
        )

        plt.barh(
            top["Feature"],
            top["Mean Absolute SHAP"],
        )

        plt.xlabel(
            "Mean Absolute SHAP Value"
        )

        plt.ylabel(
            "Feature"
        )

        plt.title(
            "Top 15 Global SHAP Features"
        )

        plt.grid(
            True,
            axis="x",
            alpha=0.25,
        )

        plt.tight_layout()

        plt.savefig(
            OUT_DIR
            / "shap_global_importance.png",
            dpi=300,
            bbox_inches="tight",
        )

        plt.close()

    return df


# =====================================================================
# 7. UNKNOWN-FAMILY ANALYSIS
# =====================================================================

def generate_unknown_family_table():

    print(
        "      Loading unknown-family analysis..."
    )

    if not UNKNOWN_FAMILY_JSON.exists():

        print(
            "      [WARN] Unknown-family analysis JSON not found:"
        )

        print(
            f"             {UNKNOWN_FAMILY_JSON}"
        )

        return None

    data = load_json(
        UNKNOWN_FAMILY_JSON
    )

    # ---------------------------------------------------------------
    # IMPORTANT:
    #
    # The actual JSON structure is:
    #
    # "family_performance": [
    #     {
    #         "family": "...",
    #         "samples": ...,
    #         "detected_unknown": ...,
    #         "not_detected_unknown": ...,
    #         "unknown_detection_recall": ...,
    #         "mean_confidence": ...
    #     }
    # ]
    # ---------------------------------------------------------------

    family_records = data.get(
        "family_performance",
        [],
    )

    if not isinstance(
        family_records,
        list,
    ):

        print(
            "      [WARN] family_performance is not a list."
        )

        return None

    if not family_records:

        print(
            "      [WARN] No family-level records found."
        )

        return None

    rows = []

    for record in family_records:

        if not isinstance(
            record,
            dict,
        ):
            continue

        family = record.get(
            "family"
        )

        samples = record.get(
            "samples"
        )

        detected_unknown = record.get(
            "detected_unknown"
        )

        not_detected_unknown = record.get(
            "not_detected_unknown"
        )

        detection_recall = record.get(
            "unknown_detection_recall"
        )

        mean_confidence = record.get(
            "mean_confidence"
        )

        if family is None:

            continue

        rows.append(
            {
                "Unknown Family": str(
                    family
                ),

                "Samples": (
                    int(samples)
                    if samples is not None
                    else np.nan
                ),

                "Detected as UNKNOWN": (
                    int(
                        detected_unknown
                    )
                    if detected_unknown is not None
                    else np.nan
                ),

                "Not Detected as UNKNOWN": (
                    int(
                        not_detected_unknown
                    )
                    if not_detected_unknown is not None
                    else np.nan
                ),

                "Unknown Detection Recall (%)": (
                    pct(
                        detection_recall
                    )
                    if detection_recall is not None
                    else np.nan
                ),

                "Mean Confidence": (
                    float(
                        mean_confidence
                    )
                    if mean_confidence is not None
                    else np.nan
                ),
            }
        )

    if not rows:

        print(
            "      [WARN] No valid family-level records found."
        )

        return None

    df = pd.DataFrame(
        rows
    )

    # ---------------------------------------------------------------
    # Save CSV.
    # ---------------------------------------------------------------

    output_csv = (
        OUT_DIR
        / "unknown_family_performance.csv"
    )

    save_csv(
        df,
        output_csv,
    )

    print(
        f"      Saved {output_csv.name} "
        f"({len(df)} families)"
    )

    # ---------------------------------------------------------------
    # Detection recall plot.
    # ---------------------------------------------------------------

    plot_df = (
        df
        .dropna(
            subset=[
                "Unknown Detection Recall (%)"
            ]
        )
        .copy()
    )

    if not plot_df.empty:

        plt.figure(
            figsize=(9, 6)
        )

        plt.bar(
            plot_df[
                "Unknown Family"
            ],
            plot_df[
                "Unknown Detection Recall (%)"
            ],
        )

        plt.xlabel(
            "Unknown Attack Family"
        )

        plt.ylabel(
            "Unknown Detection Recall (%)"
        )

        plt.title(
            "Unknown-Family Detection Recall"
        )

        max_value = float(
            plot_df[
                "Unknown Detection Recall (%)"
            ].max()
        )

        upper_limit = max(
            100.0,
            max_value * 1.15,
        )

        plt.ylim(
            0,
            upper_limit,
        )

        plt.grid(
            True,
            axis="y",
            alpha=0.25,
        )

        plt.tight_layout()

        output_plot = (
            OUT_DIR
            / "unknown_family_detection_recall.png"
        )

        plt.savefig(
            output_plot,
            dpi=300,
            bbox_inches="tight",
        )

        plt.close()

        print(
            f"      Saved {output_plot.name}"
        )

    # ---------------------------------------------------------------
    # Mean confidence plot.
    # ---------------------------------------------------------------

    confidence_df = (
        df
        .dropna(
            subset=[
                "Mean Confidence"
            ]
        )
        .copy()
    )

    if not confidence_df.empty:

        plt.figure(
            figsize=(9, 6)
        )

        plt.bar(
            confidence_df[
                "Unknown Family"
            ],
            confidence_df[
                "Mean Confidence"
            ],
        )

        plt.xlabel(
            "Unknown Attack Family"
        )

        plt.ylabel(
            "Mean Maximum Known-Class Confidence"
        )

        plt.title(
            "Unknown-Family Mean Confidence"
        )

        plt.ylim(
            0,
            1,
        )

        plt.grid(
            True,
            axis="y",
            alpha=0.25,
        )

        plt.tight_layout()

        confidence_plot = (
            OUT_DIR
            / "unknown_family_mean_confidence.png"
        )

        plt.savefig(
            confidence_plot,
            dpi=300,
            bbox_inches="tight",
        )

        plt.close()

        print(
            f"      Saved {confidence_plot.name}"
        )

    # ---------------------------------------------------------------
    # Text summary.
    # ---------------------------------------------------------------

    threshold = data.get(
        "threshold"
    )

    test_samples = data.get(
        "test_samples"
    )

    unknown_samples = data.get(
        "unknown_samples"
    )

    summary_lines = [
        "AEFL-OSIDS UNKNOWN-FAMILY PERFORMANCE",
        "=" * 72,
        f"Scenario        : {data.get('scenario', SCENARIO)}",
        (
            f"Threshold       : "
            f"{float(threshold):.6f}"
            if threshold is not None
            else "Threshold       : N/A"
        ),
        (
            f"Test samples    : "
            f"{int(test_samples):,}"
            if test_samples is not None
            else "Test samples    : N/A"
        ),
        (
            f"Unknown samples : "
            f"{int(unknown_samples):,}"
            if unknown_samples is not None
            else "Unknown samples : N/A"
        ),
        "",
        "FAMILY-LEVEL RESULTS",
        "-" * 72,
    ]

    for _, row in df.iterrows():

        samples_value = row[
            "Samples"
        ]

        detected_value = row[
            "Detected as UNKNOWN"
        ]

        not_detected_value = row[
            "Not Detected as UNKNOWN"
        ]

        recall_value = row[
            "Unknown Detection Recall (%)"
        ]

        confidence_value = row[
            "Mean Confidence"
        ]

        summary_lines.extend(
            [
                "",
                str(
                    row[
                        "Unknown Family"
                    ]
                ),
                (
                    f"  Samples                 : "
                    f"{int(samples_value):,}"
                    if pd.notna(
                        samples_value
                    )
                    else "  Samples                 : N/A"
                ),
                (
                    f"  Detected as UNKNOWN     : "
                    f"{int(detected_value):,}"
                    if pd.notna(
                        detected_value
                    )
                    else "  Detected as UNKNOWN     : N/A"
                ),
                (
                    f"  Not detected            : "
                    f"{int(not_detected_value):,}"
                    if pd.notna(
                        not_detected_value
                    )
                    else "  Not detected            : N/A"
                ),
                (
                    f"  Detection recall        : "
                    f"{recall_value:.2f}%"
                    if pd.notna(
                        recall_value
                    )
                    else "  Detection recall        : N/A"
                ),
                (
                    f"  Mean confidence         : "
                    f"{confidence_value:.6f}"
                    if pd.notna(
                        confidence_value
                    )
                    else "  Mean confidence         : N/A"
                ),
            ]
        )

    summary_lines.extend(
        [
            "",
            "NOTE",
            "-" * 72,
            (
                "All family-level values were read directly "
                "from the completed unknown-family analysis."
            ),
            (
                "No family-level values were fabricated."
            ),
        ]
    )

    summary_path = (
        OUT_DIR
        / "unknown_family_analysis_summary.txt"
    )

    summary_path.write_text(
        "\n".join(
            summary_lines
        ),
        encoding="utf-8",
    )

    print(
        f"      Saved {summary_path.name}"
    )

    return df


# =====================================================================
# 8. SUMMARY REPORT
# =====================================================================

def generate_summary(
    class_df,
    open_df,
    threshold_df,
    shap_df,
    unknown_df,
):

    lines = [
        "AEFL-OSIDS PUBLICATION-READY RESULTS SUMMARY",
        "=" * 72,
        f"Scenario: {SCENARIO}",
        "",
        "KNOWN-CLASS CLASSIFICATION",
        "-" * 72,
    ]

    # ---------------------------------------------------------------
    # Classification
    # ---------------------------------------------------------------

    if (
        class_df is not None
        and not class_df.empty
    ):

        for _, row in class_df.iterrows():

            accuracy = row.get(
                "Accuracy",
                np.nan,
            )

            macro_f1 = row.get(
                "Macro F1",
                np.nan,
            )

            weighted_f1 = row.get(
                "Weighted F1",
                np.nan,
            )

            lines.append(
                f"{row.get('Method', 'Unknown')}: "
                f"Accuracy={accuracy:.2f}%, "
                f"Macro-F1={macro_f1:.2f}%, "
                f"Weighted-F1={weighted_f1:.2f}%"
            )

    # ---------------------------------------------------------------
    # Open-set
    # ---------------------------------------------------------------

    if (
        open_df is not None
        and not open_df.empty
    ):

        row = open_df.iloc[0]

        lines.extend(
            [
                "",
                "FINAL OPEN-SET EVALUATION",
                "-" * 72,

                f"Locked threshold     : "
                f"{row['Locked Threshold']:.6f}",

                f"Unknown precision    : "
                f"{row['Unknown Precision']:.2f}%",

                f"Unknown recall       : "
                f"{row['Unknown Recall']:.2f}%",

                f"Unknown F1           : "
                f"{row['Unknown F1']:.2f}%",

                f"Known FPR            : "
                f"{row['Known FPR']:.2f}%",

                f"Open-set AUROC       : "
                f"{row['Open-set AUROC']:.2f}%",

                f"Known accuracy       : "
                f"{row['Known Accuracy']:.2f}%",

                f"Known macro precision: "
                f"{row['Known Macro Precision']:.2f}%",

                f"Known macro recall   : "
                f"{row['Known Macro Recall']:.2f}%",

                f"Known macro F1       : "
                f"{row['Known Macro F1']:.2f}%",

                f"Test samples         : "
                f"{int(row['Test Samples']):,}",

                f"Unknown families     : "
                f"{row['Unknown Families']}",
            ]
        )

    # ---------------------------------------------------------------
    # Threshold
    # ---------------------------------------------------------------

    if (
        threshold_df is not None
        and not threshold_df.empty
    ):

        best = threshold_df.loc[
            threshold_df["F1"].idxmax()
        ]

        fpr5 = threshold_df[
            threshold_df["Known FPR"] <= 5.0
        ]

        lines.extend(
            [
                "",
                "THRESHOLD ANALYSIS",
                "-" * 72,

                f"Best sweep F1 threshold : "
                f"{best['Threshold']:.6f}",

                f"Best sweep F1           : "
                f"{best['F1']:.2f}%",

                f"Best sweep recall       : "
                f"{best['Recall']:.2f}%",

                f"Best sweep known FPR    : "
                f"{best['Known FPR']:.2f}%",
            ]
        )

        if not fpr5.empty:

            candidate = fpr5.loc[
                fpr5["F1"].idxmax()
            ]

            lines.append(
                f"Best F1 with FPR <= 5%  : "
                f"threshold={candidate['Threshold']:.6f}, "
                f"F1={candidate['F1']:.2f}%, "
                f"recall={candidate['Recall']:.2f}%, "
                f"FPR={candidate['Known FPR']:.2f}%"
            )

    # ---------------------------------------------------------------
    # SHAP
    # ---------------------------------------------------------------

    if (
        shap_df is not None
        and not shap_df.empty
    ):

        lines.extend(
            [
                "",
                "SHAP GLOBAL FEATURE IMPORTANCE",
                "-" * 72,
                f"Features available      : {len(shap_df)}",
                "Top 15 features:",
            ]
        )

        for i, (_, row) in enumerate(
            shap_df.head(15).iterrows(),
            1,
        ):

            lines.append(
                f"{i:2d}. "
                f"{row['Feature']}: "
                f"{row['Mean Absolute SHAP']:.8f}"
            )

    # ---------------------------------------------------------------
    # Unknown families
    # ---------------------------------------------------------------

    if (
        unknown_df is not None
        and not unknown_df.empty
    ):

        lines.extend(
            [
                "",
                "UNKNOWN-FAMILY ANALYSIS",
                "-" * 72,
            ]
        )

        for _, row in unknown_df.iterrows():

            family = row[
                "Unknown Family"
            ]

            recall = row[
                "Unknown Detection Recall (%)"
            ]

            samples = row[
                "Samples"
            ]

            detected = row[
                "Detected as UNKNOWN"
            ]

            lines.append(
                f"{family}: "
                f"Samples={int(samples):,}, "
                f"Detected UNKNOWN={int(detected):,}, "
                f"Recall={recall:.2f}%"
            )

    # ---------------------------------------------------------------
    # Final note
    # ---------------------------------------------------------------

    lines.extend(
        [
            "",
            "NOTE",
            "-" * 72,
            (
                "All values above are derived from existing "
                "experiment outputs."
            ),
            (
                "No model retraining or dataset reprocessing "
                "was performed by this script."
            ),
        ]
    )

    output_path = (
        OUT_DIR
        / "paper_results_summary.txt"
    )

    output_path.write_text(
        "\n".join(
            lines
        ),
        encoding="utf-8",
    )


# =====================================================================
# MAIN
# =====================================================================

def main():

    OUT_DIR.mkdir(
        parents=True,
        exist_ok=True,
    )

    print(
        "=" * 70
    )

    print(
        "AEFL-OSIDS PUBLICATION-READY RESULTS GENERATOR"
    )

    print(
        "=" * 70
    )

    print(
        f"Scenario : {SCENARIO}"
    )

    print(
        f"Output   : {OUT_DIR}"
    )

    print()

    # ---------------------------------------------------------------
    # 1. Classification
    # ---------------------------------------------------------------

    print(
        "[1/7] Classification comparison..."
    )

    class_df = (
        generate_classification_table()
    )

    print(
        "      Saved classification_comparison.csv "
        f"({len(class_df)} methods)"
    )

    # ---------------------------------------------------------------
    # 2. Open-set
    # ---------------------------------------------------------------

    print(
        "[2/7] Open-set results..."
    )

    open_df = (
        generate_open_set_table()
    )

    print(
        "      Saved open_set_results.csv"
    )

    # ---------------------------------------------------------------
    # 3. Threshold
    # ---------------------------------------------------------------

    print(
        "[3/7] Threshold analysis..."
    )

    threshold_df = (
        generate_threshold_table()
    )

    print(
        "      Saved threshold_analysis.csv "
        f"({len(threshold_df)} thresholds)"
    )

    # ---------------------------------------------------------------
    # 4. FL convergence
    # ---------------------------------------------------------------

    print(
        "[4/7] FL convergence..."
    )

    generate_convergence_plot()

    # ---------------------------------------------------------------
    # 5. SHAP
    # ---------------------------------------------------------------

    print(
        "[5/7] SHAP..."
    )

    shap_df = (
        generate_shap_table_and_plot()
    )

    # ---------------------------------------------------------------
    # 6. Unknown family
    # ---------------------------------------------------------------

    print(
        "[6/7] Unknown-family analysis..."
    )

    unknown_df = (
        generate_unknown_family_table()
    )

    if (
        unknown_df is None
        or unknown_df.empty
    ):

        print(
            "      No family-level results available."
        )

    # ---------------------------------------------------------------
    # Threshold plots
    # ---------------------------------------------------------------

    generate_threshold_plot(
        threshold_df
    )

    # ---------------------------------------------------------------
    # 7. Summary
    # ---------------------------------------------------------------

    print(
        "[7/7] Summary report..."
    )

    generate_summary(
        class_df,
        open_df,
        threshold_df,
        shap_df,
        unknown_df,
    )

    # ---------------------------------------------------------------
    # Final output
    # ---------------------------------------------------------------

    print()

    print(
        "=" * 70
    )

    print(
        "PUBLICATION RESULTS GENERATION COMPLETE"
    )

    print(
        "=" * 70
    )

    print(
        f"Results directory: {OUT_DIR}"
    )

    print()

    for path in sorted(
        OUT_DIR.iterdir()
    ):

        if path.is_file():

            print(
                f"  {path.name}"
            )

    print(
        "=" * 70
    )


# =====================================================================
# ENTRY POINT
# =====================================================================

if __name__ == "__main__":
    main()