import sys
from pathlib import Path
from typing import Dict, Optional

import torch
import torch.nn as nn
import torch.nn.functional as F


# ============================================================
# PROJECT ROOT
# ============================================================

PROJECT_ROOT = (
    Path(__file__).resolve().parents[1]
)

if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(
        0,
        str(PROJECT_ROOT),
    )


# ============================================================
# MODEL CONFIGURATION
# ============================================================

INPUT_FEATURES = 39

DEFAULT_NUM_CLASSES = 5


# ============================================================
# INTRUSION DETECTION MODEL
# ============================================================

class IntrusionDetectionModel(
    nn.Module
):
    """
    Neural network for CICIoT2023
    attack-family classification.

    Input:
        39 network-flow features

    Output:
        Probability/logit for each known
        attack family.

    Scenario C known classes:

        0 -> BENIGN
        1 -> DDoS
        2 -> DoS
        3 -> Mirai
        4 -> Recon

    Unknown families are NOT included in
    the supervised output layer.

    Unknown detection will be implemented
    separately as an open-set layer.
    """

    def __init__(
        self,
        input_features: int = INPUT_FEATURES,
        num_classes: int = DEFAULT_NUM_CLASSES,
        dropout: float = 0.30,
    ):
        super().__init__()

        self.input_features = (
            input_features
        )

        self.num_classes = (
            num_classes
        )

        # ----------------------------------------------------
        # Feature representation
        # ----------------------------------------------------

        # NOTE: this used to be BatchNorm1d. BatchNorm keeps running
        # mean/variance statistics that get averaged across clients during
        # federated aggregation (see federated/robust_adaptive_fedprox.py).
        # Under the Dirichlet(alpha=0.5) non-IID client partition used here,
        # each client's local batch statistics reflect a very different
        # class mix, so averaging those running stats across clients is a
        # well-documented source of degraded/unstable federated accuracy
        # (the "FedBN" line of work). GroupNorm has no running statistics
        # to average -- its only aggregated parameters are the same
        # learnable affine weight/bias as every other layer -- so it is not
        # sensitive to this failure mode. It also removes an unrelated
        # footgun for live single-flow inference, where BatchNorm1d in
        # train() mode requires batch size > 1.
        self.feature_extractor = nn.Sequential(

            nn.Linear(
                input_features,
                128,
            ),

            nn.GroupNorm(
                8,
                128,
            ),

            nn.ReLU(),

            nn.Dropout(
                dropout
            ),

            nn.Linear(
                128,
                64,
            ),

            nn.GroupNorm(
                8,
                64,
            ),

            nn.ReLU(),

            nn.Dropout(
                dropout
            ),

            nn.Linear(
                64,
                32,
            ),

            nn.ReLU(),
        )

        # ----------------------------------------------------
        # Classification head
        # ----------------------------------------------------

        self.classifier = nn.Linear(
            32,
            num_classes,
        )

    # ========================================================
    # FEATURE REPRESENTATION
    # ========================================================

    def extract_representation(
        self,
        x: torch.Tensor,
    ) -> torch.Tensor:
        """
        Extract learned feature representation.

        This representation will later be useful
        for adaptive federated learning and
        open-set detection.
        """

        return self.feature_extractor(
            x
        )

    # ========================================================
    # FORWARD
    # ========================================================

    def forward(
        self,
        x: torch.Tensor,
    ) -> torch.Tensor:
        """
        Forward pass.

        Returns raw logits.

        CrossEntropyLoss should be applied
        directly to these logits.
        """

        representation = (
            self.extract_representation(
                x
            )
        )

        logits = self.classifier(
            representation
        )

        return logits

    # ========================================================
    # PROBABILITIES
    # ========================================================

    def predict_proba(
        self,
        x: torch.Tensor,
    ) -> torch.Tensor:
        """
        Return class probabilities.
        """

        logits = self.forward(
            x
        )

        return F.softmax(
            logits,
            dim=1,
        )

    # ========================================================
    # PREDICTION
    # ========================================================

    def predict(
        self,
        x: torch.Tensor,
    ) -> torch.Tensor:
        """
        Return predicted known-class index.
        """

        probabilities = (
            self.predict_proba(
                x
            )
        )

        predictions = torch.argmax(
            probabilities,
            dim=1,
        )

        return predictions

    # ========================================================
    # CONFIDENCE
    # ========================================================

    def confidence(
        self,
        x: torch.Tensor,
    ) -> torch.Tensor:
        """
        Return maximum class probability.

        This will later be used by the
        open-set detector.
        """

        probabilities = (
            self.predict_proba(
                x
            )
        )

        confidence, _ = torch.max(
            probabilities,
            dim=1,
        )

        return confidence


# ============================================================
# MODEL FACTORY
# ============================================================

def create_model(
    num_classes: int = DEFAULT_NUM_CLASSES,
    input_features: int = INPUT_FEATURES,
    dropout: float = 0.30,
) -> IntrusionDetectionModel:
    """
    Create a fresh model instance.
    """

    model = IntrusionDetectionModel(
        input_features=input_features,
        num_classes=num_classes,
        dropout=dropout,
    )

    return model


# ============================================================
# MODEL INFORMATION
# ============================================================

def count_parameters(
    model: nn.Module,
) -> int:
    """
    Count trainable parameters.
    """

    return sum(
        parameter.numel()
        for parameter in model.parameters()
        if parameter.requires_grad
    )


# ============================================================
# MODEL SUMMARY
# ============================================================

def model_summary(
    model: nn.Module,
) -> Dict[str, int]:

    return {
        "input_features":
            model.input_features,

        "num_classes":
            model.num_classes,

        "trainable_parameters":
            count_parameters(model),
    }


# ============================================================
# SAVE MODEL
# ============================================================

def save_model(
    model: nn.Module,
    path: Path,
) -> None:
    """
    Save model state dictionary.
    """

    path.parent.mkdir(
        parents=True,
        exist_ok=True,
    )

    torch.save(
        model.state_dict(),
        path,
    )


# ============================================================
# LOAD MODEL
# ============================================================

def load_model(
    path: Path,
    num_classes: int = DEFAULT_NUM_CLASSES,
    input_features: int = INPUT_FEATURES,
    dropout: float = 0.30,
    device: Optional[
        torch.device
    ] = None,
) -> IntrusionDetectionModel:
    """
    Load model weights from disk.
    """

    model = create_model(
        num_classes=num_classes,
        input_features=input_features,
        dropout=dropout,
    )

    if device is None:
        device = torch.device(
            "cpu"
        )

    state_dict = torch.load(
        path,
        map_location=device,
    )

    model.load_state_dict(
        state_dict
    )

    model.to(
        device
    )

    return model


# ============================================================
# STANDALONE TEST
# ============================================================

def main():

    print("=" * 70)
    print(
        "AEFL-OSIDS PYTORCH MODEL TEST"
    )
    print("=" * 70)

    # --------------------------------------------------------
    # Reproducibility
    # --------------------------------------------------------

    torch.manual_seed(
        42
    )

    # --------------------------------------------------------
    # Device
    # --------------------------------------------------------

    device = torch.device(
        "cuda"
        if torch.cuda.is_available()
        else "cpu"
    )

    print()
    print(
        f"Device: {device}"
    )

    # --------------------------------------------------------
    # Create model
    # --------------------------------------------------------

    model = create_model(
        num_classes=5,
        input_features=39,
    )

    model.to(
        device
    )

    # --------------------------------------------------------
    # Model summary
    # --------------------------------------------------------

    summary = model_summary(
        model
    )

    print()
    print(
        "Model configuration:"
    )

    for key, value in (
        summary.items()
    ):
        print(
            f"  {key}: {value}"
        )

    # --------------------------------------------------------
    # Dummy input
    # --------------------------------------------------------

    batch_size = 16

    x = torch.randn(
        batch_size,
        INPUT_FEATURES,
        device=device,
    )

    print()
    print(
        f"Input shape: "
        f"{tuple(x.shape)}"
    )

    # --------------------------------------------------------
    # Forward
    # --------------------------------------------------------

    model.eval()

    with torch.no_grad():

        logits = model(
            x
        )

        probabilities = (
            model.predict_proba(
                x
            )
        )

        predictions = (
            model.predict(
                x
            )
        )

        confidence = (
            model.confidence(
                x
            )
        )

    # --------------------------------------------------------
    # Output validation
    # --------------------------------------------------------

    print()
    print(
        f"Logits shape: "
        f"{tuple(logits.shape)}"
    )

    print(
        f"Probability shape: "
        f"{tuple(probabilities.shape)}"
    )

    print(
        f"Prediction shape: "
        f"{tuple(predictions.shape)}"
    )

    print(
        f"Confidence shape: "
        f"{tuple(confidence.shape)}"
    )

    # --------------------------------------------------------
    # Probability validation
    # --------------------------------------------------------

    probability_sums = (
        probabilities.sum(
            dim=1
        )
    )

    probabilities_valid = (
        torch.allclose(
            probability_sums,
            torch.ones_like(
                probability_sums
            ),
            atol=1e-5,
        )
    )

    print()
    print(
        "Probability validation: "
        f"{'PASS' if probabilities_valid else 'FAIL'}"
    )

    # --------------------------------------------------------
    # Prediction range
    # --------------------------------------------------------

    predictions_valid = bool(
        torch.all(
            predictions >= 0
        )
        and torch.all(
            predictions < 5
        )
    )

    print(
        "Prediction range validation: "
        f"{'PASS' if predictions_valid else 'FAIL'}"
    )

    # --------------------------------------------------------
    # Confidence range
    # --------------------------------------------------------

    confidence_valid = bool(
        torch.all(
            confidence >= 0
        )
        and torch.all(
            confidence <= 1
        )
    )

    print(
        "Confidence validation: "
        f"{'PASS' if confidence_valid else 'FAIL'}"
    )

    # --------------------------------------------------------
    # Representation
    # --------------------------------------------------------

    with torch.no_grad():

        representation = (
            model.extract_representation(
                x
            )
        )

    print(
        f"Representation shape: "
        f"{tuple(representation.shape)}"
    )

    representation_valid = (
        representation.shape
        == (
            batch_size,
            32,
        )
    )

    print(
        "Representation validation: "
        f"{'PASS' if representation_valid else 'FAIL'}"
    )

    # --------------------------------------------------------
    # Save/load test
    # --------------------------------------------------------

    test_model_path = (
        PROJECT_ROOT
        / "data"
        / "models"
        / "model_test.pt"
    )

    save_model(
        model,
        test_model_path,
    )

    print()
    print(
        "Test model saved:"
    )

    print(
        test_model_path
    )

    loaded_model = load_model(
        test_model_path,
        num_classes=5,
        input_features=39,
        device=device,
    )

    loaded_model.eval()

    with torch.no_grad():

        loaded_logits = (
            loaded_model(x)
        )

    model_load_valid = (
        torch.allclose(
            logits,
            loaded_logits,
            atol=1e-6,
        )
    )

    print(
        "Save/load validation: "
        f"{'PASS' if model_load_valid else 'FAIL'}"
    )

    # --------------------------------------------------------
    # Final result
    # --------------------------------------------------------

    all_tests_passed = all(
        [
            probabilities_valid,
            predictions_valid,
            confidence_valid,
            representation_valid,
            model_load_valid,
        ]
    )

    print()
    print("=" * 70)

    if all_tests_passed:

        print(
            "MODEL TEST SUCCESSFUL"
        )

    else:

        print(
            "MODEL TEST FAILED"
        )

    print("=" * 70)


# ============================================================
# ENTRY POINT
# ============================================================

if __name__ == "__main__":
    main()