"""
AEFL-OSIDS PROCESSED DATASET VERIFICATION

Verifies the regenerated scenario_C_multiple processed dataset:
- Train / validation / test files
- Number of samples
- Feature count
- Data types
- Missing values
- Infinite values
- Label distributions
- Unknown-label placement
- Scaler
- Label mapping
"""

from pathlib import Path
import json

import joblib
import numpy as np
import pandas as pd


# ============================================================
# PROJECT PATHS
# ============================================================

PROJECT_ROOT = Path(__file__).resolve().parents[1]

SCENARIO = "scenario_C_multiple"

PROCESSED_DIR = (
    PROJECT_ROOT
    / "data"
    / "processed"
    / SCENARIO
)

SPLITS = ["train", "validation", "test"]

EXPECTED_FEATURES = 39

KNOWN_LABELS = {
    0: "BENIGN",
    1: "DDoS",
    2: "DoS",
    3: "Mirai",
    4: "Recon",
}

UNKNOWN_LABEL = -1


# ============================================================
# HELPERS
# ============================================================

def print_separator():
    print("=" * 78)


def find_npz_files(split_dir):
    """
    Find all processed NPZ files recursively.
    """
    if not split_dir.exists():
        return []

    return sorted(split_dir.rglob("*.npz"))


def inspect_npz_file(path):
    """
    Load and inspect one NPZ file.
    """
    data = np.load(path, allow_pickle=False)

    if "X" not in data:
        raise ValueError(f"Missing X array: {path}")

    if "y" not in data:
        raise ValueError(f"Missing y array: {path}")

    X = data["X"]
    y = data["y"]

    return X, y


# ============================================================
# MAIN VERIFICATION
# ============================================================

def main():

    print_separator()
    print("AEFL-OSIDS PROCESSED DATASET VERIFICATION")
    print_separator()

    print()
    print(f"Scenario       : {SCENARIO}")
    print(f"Processed dir  : {PROCESSED_DIR}")
    print(f"Expected feats : {EXPECTED_FEATURES}")

    if not PROCESSED_DIR.exists():
        raise FileNotFoundError(
            f"Processed scenario directory not found:\n"
            f"{PROCESSED_DIR}"
        )

    # --------------------------------------------------------
    # Check required metadata files
    # --------------------------------------------------------

    print()
    print_separator()
    print("CHECKING METADATA FILES")
    print_separator()

    required_files = [
        "scaler.joblib",
        "label_mapping.csv",
        "train_summary.csv",
        "validation_summary.csv",
        "test_summary.csv",
    ]

    metadata_ok = True

    for filename in required_files:

        path = PROCESSED_DIR / filename

        if path.exists():
            print(f"[PASS] {filename}")
        else:
            print(f"[FAIL] {filename} NOT FOUND")
            metadata_ok = False

    # --------------------------------------------------------
    # Load scaler
    # --------------------------------------------------------

    scaler_path = PROCESSED_DIR / "scaler.joblib"

    if scaler_path.exists():

        print()
        print_separator()
        print("SCALER")
        print_separator()

        scaler = joblib.load(scaler_path)

        print(f"Scaler type      : {type(scaler).__name__}")

        if hasattr(scaler, "n_features_in_"):
            print(
                f"Scaler features  : "
                f"{scaler.n_features_in_}"
            )

            if scaler.n_features_in_ == EXPECTED_FEATURES:
                print("Feature count    : PASS")
            else:
                print("Feature count    : FAIL")

        if hasattr(scaler, "mean_"):
            print(
                f"Scaler mean size : "
                f"{len(scaler.mean_)}"
            )

    # --------------------------------------------------------
    # Load label mapping
    # --------------------------------------------------------

    mapping_path = PROCESSED_DIR / "label_mapping.csv"

    print()
    print_separator()
    print("LABEL MAPPING")
    print_separator()

    if mapping_path.exists():

        mapping_df = pd.read_csv(mapping_path)

        print(mapping_df.to_string(index=False))

        if "label" in mapping_df.columns:
            labels = set(mapping_df["label"].astype(int))

            expected_labels = {
                -1,
                0,
                1,
                2,
                3,
                4,
            }

            if expected_labels.issubset(labels):
                print()
                print("Label mapping validation: PASS")
            else:
                print()
                print("Label mapping validation: CHECK")

    # --------------------------------------------------------
    # Split verification
    # --------------------------------------------------------

    global_results = {}

    total_samples = 0

    print()
    print_separator()
    print("SPLIT VERIFICATION")
    print_separator()

    for split in SPLITS:

        split_dir = PROCESSED_DIR / split

        print()
        print(f"[{split.upper()}]")

        if not split_dir.exists():

            print(f"  [FAIL] Directory missing: {split_dir}")

            global_results[split] = {
                "status": "FAIL",
                "samples": 0,
            }

            continue

        files = find_npz_files(split_dir)

        print(f"  NPZ files : {len(files)}")

        if not files:

            print("  [FAIL] No NPZ files found")

            global_results[split] = {
                "status": "FAIL",
                "samples": 0,
            }

            continue

        split_samples = 0

        label_counts = {}

        feature_errors = 0
        dtype_errors = 0
        nan_errors = 0
        inf_errors = 0
        shape_errors = 0

        unknown_count = 0

        for file_index, path in enumerate(files, start=1):

            try:

                X, y = inspect_npz_file(path)

                # --------------------------------------------
                # Shape checks
                # --------------------------------------------

                if X.ndim != 2:
                    shape_errors += 1

                elif X.shape[1] != EXPECTED_FEATURES:
                    shape_errors += 1

                if y.ndim != 1:
                    shape_errors += 1

                if X.shape[0] != y.shape[0]:
                    shape_errors += 1

                # --------------------------------------------
                # dtype checks
                # --------------------------------------------

                if X.dtype != np.float32:
                    dtype_errors += 1

                if y.dtype != np.int64:
                    dtype_errors += 1

                # --------------------------------------------
                # NaN / Inf checks
                # --------------------------------------------

                if np.isnan(X).any():
                    nan_errors += 1

                if np.isinf(X).any():
                    inf_errors += 1

                # --------------------------------------------
                # Sample counts
                # --------------------------------------------

                split_samples += X.shape[0]

                # --------------------------------------------
                # Labels
                # --------------------------------------------

                unique, counts = np.unique(
                    y,
                    return_counts=True
                )

                for label, count in zip(unique, counts):

                    label = int(label)
                    count = int(count)

                    label_counts[label] = (
                        label_counts.get(label, 0)
                        + count
                    )

                    if label == UNKNOWN_LABEL:
                        unknown_count += count

            except Exception as exc:

                print()
                print(f"  [ERROR] {path}")
                print(f"          {exc}")

        # ----------------------------------------------------
        # Print split results
        # ----------------------------------------------------

        print(f"  Samples  : {split_samples}")

        print()
        print("  Label distribution:")

        for label in sorted(label_counts.keys()):

            count = label_counts[label]

            if label in KNOWN_LABELS:
                name = KNOWN_LABELS[label]
            elif label == UNKNOWN_LABEL:
                name = "UNKNOWN"
            else:
                name = "UNEXPECTED"

            percentage = (
                100.0 * count / split_samples
                if split_samples > 0
                else 0.0
            )

            print(
                f"    {label:>3} -> "
                f"{name:<10} "
                f"{count:>10,} "
                f"({percentage:>6.2f}%)"
            )

        print()
        print(f"  Unknown samples : {unknown_count:,}")
        print(f"  Shape errors    : {shape_errors}")
        print(f"  Dtype errors    : {dtype_errors}")
        print(f"  NaN errors      : {nan_errors}")
        print(f"  Inf errors      : {inf_errors}")

        # ----------------------------------------------------
        # Unknown-label rule
        # ----------------------------------------------------

        if split in ("train", "validation"):

            if unknown_count == 0:

                unknown_status = "PASS"

            else:

                unknown_status = "FAIL"

                print(
                    "  [FAIL] Unknown labels found "
                    f"in {split}!"
                )

        else:

            # Test is expected to contain unknown samples.
            if unknown_count > 0:
                unknown_status = "PASS"
            else:
                unknown_status = "CHECK"

        # ----------------------------------------------------
        # Split status
        # ----------------------------------------------------

        if (
            shape_errors == 0
            and dtype_errors == 0
            and nan_errors == 0
            and inf_errors == 0
            and unknown_status != "FAIL"
        ):

            status = "PASS"

        else:

            status = "FAIL"

        print(f"  Unknown-label rule: {unknown_status}")
        print(f"  Split status      : {status}")

        global_results[split] = {
            "status": status,
            "files": len(files),
            "samples": split_samples,
            "unknown_samples": unknown_count,
            "labels": label_counts,
            "shape_errors": shape_errors,
            "dtype_errors": dtype_errors,
            "nan_errors": nan_errors,
            "inf_errors": inf_errors,
        }

        total_samples += split_samples

    # --------------------------------------------------------
    # Expected sample counts
    # --------------------------------------------------------

    print()
    print_separator()
    print("EXPECTED SAMPLE COUNTS")
    print_separator()

    expected_counts = {
        "train": 411602,
        "validation": 87995,
        "test": 117190,
    }

    expected_total = sum(expected_counts.values())

    for split in SPLITS:

        actual = global_results.get(
            split,
            {}
        ).get("samples", 0)

        expected = expected_counts[split]

        if actual == expected:

            print(
                f"{split:<12}: "
                f"{actual:>10,} / "
                f"{expected:>10,}  PASS"
            )

        else:

            print(
                f"{split:<12}: "
                f"{actual:>10,} / "
                f"{expected:>10,}  CHECK"
            )

    print()
    print(
        f"Total samples : "
        f"{total_samples:,}"
    )

    print(
        f"Expected total: "
        f"{expected_total:,}"
    )

    if total_samples == expected_total:
        print("Total count validation: PASS")
    else:
        print("Total count validation: CHECK")

    # --------------------------------------------------------
    # Important unknown-label summary
    # --------------------------------------------------------

    print()
    print_separator()
    print("OPEN-SET LABEL VERIFICATION")
    print_separator()

    train_unknown = global_results["train"]["unknown_samples"]
    val_unknown = global_results["validation"]["unknown_samples"]
    test_unknown = global_results["test"]["unknown_samples"]

    print(f"Train UNKNOWN      : {train_unknown:,}")
    print(f"Validation UNKNOWN : {val_unknown:,}")
    print(f"Test UNKNOWN       : {test_unknown:,}")

    if train_unknown == 0 and val_unknown == 0:
        print()
        print(
            "Training/validation unknown-label check: PASS"
        )
    else:
        print()
        print(
            "Training/validation unknown-label check: FAIL"
        )

    if test_unknown > 0:
        print(
            "Test unknown-label presence: PASS"
        )
    else:
        print(
            "Test unknown-label presence: CHECK"
        )

    # --------------------------------------------------------
    # Save verification report
    # --------------------------------------------------------

    report_dir = (
        PROJECT_ROOT
        / "results"
        / "dataset_verification"
    )

    report_dir.mkdir(
        parents=True,
        exist_ok=True
    )

    report_path = (
        report_dir
        / f"{SCENARIO}_verification.json"
    )

    def convert_for_json(obj):

        if isinstance(obj, np.integer):
            return int(obj)

        if isinstance(obj, np.floating):
            return float(obj)

        if isinstance(obj, np.ndarray):
            return obj.tolist()

        raise TypeError(
            f"Object of type {type(obj).__name__} "
            f"is not JSON serializable"
        )

    report = {
        "scenario": SCENARIO,
        "processed_directory": str(PROCESSED_DIR),
        "expected_features": EXPECTED_FEATURES,
        "expected_counts": expected_counts,
        "actual_total_samples": total_samples,
        "expected_total_samples": expected_total,
        "splits": global_results,
    }

    with open(
        report_path,
        "w",
        encoding="utf-8"
    ) as f:

        json.dump(
            report,
            f,
            indent=2,
            default=convert_for_json
        )

    # --------------------------------------------------------
    # Final status
    # --------------------------------------------------------

    all_split_pass = all(
        result["status"] == "PASS"
        for result in global_results.values()
    )

    count_pass = (
        total_samples == expected_total
    )

    metadata_pass = metadata_ok

    print()
    print_separator()

    if all_split_pass and count_pass and metadata_pass:

        print("PROCESSED DATASET VERIFICATION SUCCESSFUL")

    else:

        print("PROCESSED DATASET VERIFICATION REQUIRES ATTENTION")

    print_separator()

    print()
    print(f"Verification report:")
    print(report_path)

    print()


if __name__ == "__main__":
    main()