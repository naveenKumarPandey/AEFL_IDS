"""Leakage-safe hybrid open-set calibration and independent test evaluation.

The detector combines two complementary signals:

1. neural uncertainty: ``1 - max softmax probability``;
2. feature anomaly: a balanced Isolation Forest fitted on known training data.

Fusion weights are fixed in ``configs/config.yaml``.  The rejection threshold
is calibrated only on known validation traffic for a requested false-positive
rate.  Unknown test families are never used for fitting or threshold choice.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Dict, List, Tuple

import joblib
import numpy as np
import pandas as pd
import torch
from sklearn.ensemble import IsolationForest
from sklearn.metrics import (
    accuracy_score,
    confusion_matrix,
    f1_score,
    precision_score,
    recall_score,
    roc_auc_score,
)

from data_loader.cic_iot_dataset import create_dataset
from models.intrusion_model import create_model
from utils.config import load_config


PROJECT_ROOT = Path(__file__).resolve().parents[1]
CLASS_NAMES = ["BENIGN", "DDoS", "DoS", "Mirai", "Recon"]
UNKNOWN_FAMILIES = {"BruteForce", "Spoofing", "Web-based"}
UNKNOWN_LABEL = -1
OUTPUT_DIR = PROJECT_ROOT / "results" / "hybrid_open_set"
ARTIFACT_PATH = PROJECT_ROOT / "data" / "models" / "hybrid_open_set_detector.joblib"


def _resolve_model(value: str | None) -> Path:
    if value:
        aliases = {
            "proposed": PROJECT_ROOT / "data" / "models" / "robust_adaptive_fedprox_global.pt",
            "adaptive_v2": PROJECT_ROOT / "data" / "models" / "adaptive_fedavg_v2_global.pt",
            "fedavg": PROJECT_ROOT / "data" / "models" / "fedavg_global.pt",
            "centralized": PROJECT_ROOT / "data" / "models" / "centralized_baseline.pt",
        }
        return aliases.get(value.lower(), Path(value).expanduser().resolve())
    proposed = PROJECT_ROOT / "data" / "models" / "robust_adaptive_fedprox_global.pt"
    return proposed if proposed.exists() else PROJECT_ROOT / "data" / "models" / "adaptive_fedavg_v2_global.pt"


def _load_model(path: Path) -> torch.nn.Module:
    if not path.exists():
        raise FileNotFoundError(f"Model checkpoint not found: {path}")
    checkpoint = torch.load(path, map_location="cpu")
    state = checkpoint.get("model_state_dict", checkpoint)
    model = create_model(input_features=39, num_classes=len(CLASS_NAMES))
    model.load_state_dict(state, strict=True)
    model.eval()
    return model


def _balanced_training_sample(
    scenario: str,
    per_class: int,
    seed: int,
) -> Tuple[np.ndarray, Dict[str, int]]:
    """Uniform reservoir sample using random keys, balanced by known class."""

    dataset = create_dataset(scenario, "train")
    rng = np.random.default_rng(seed)
    rows = {class_id: np.empty((0, 39), dtype=np.float32) for class_id in range(len(CLASS_NAMES))}
    keys = {class_id: np.empty(0, dtype=np.float64) for class_id in range(len(CLASS_NAMES))}
    seen = {class_id: 0 for class_id in range(len(CLASS_NAMES))}

    for path in dataset.files:
        with np.load(path, allow_pickle=False) as data:
            X = np.asarray(data["X"], dtype=np.float32)
            y = np.asarray(data["y"], dtype=np.int64)
        for class_id in range(len(CLASS_NAMES)):
            selected = X[y == class_id]
            if len(selected) == 0:
                continue
            seen[class_id] += int(len(selected))
            new_keys = rng.random(len(selected))
            candidate_rows = np.concatenate([rows[class_id], selected])
            candidate_keys = np.concatenate([keys[class_id], new_keys])
            if len(candidate_keys) > per_class:
                keep = np.argpartition(candidate_keys, -per_class)[-per_class:]
                candidate_rows = candidate_rows[keep]
                candidate_keys = candidate_keys[keep]
            rows[class_id] = candidate_rows
            keys[class_id] = candidate_keys

    missing = [CLASS_NAMES[class_id] for class_id, values in rows.items() if len(values) == 0]
    if missing:
        raise RuntimeError(f"Cannot fit anomaly detector; classes have no samples: {missing}")
    return np.concatenate([rows[class_id] for class_id in range(len(CLASS_NAMES))]), {
        CLASS_NAMES[class_id]: seen[class_id] for class_id in range(len(CLASS_NAMES))
    }


def _neural_predictions(model: torch.nn.Module, X: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
    predictions: List[np.ndarray] = []
    confidences: List[np.ndarray] = []
    with torch.no_grad():
        for start in range(0, len(X), 4096):
            logits = model(torch.from_numpy(X[start : start + 4096]))
            probabilities = logits.softmax(dim=1)
            confidence, prediction = probabilities.max(dim=1)
            predictions.append(prediction.numpy())
            confidences.append(confidence.numpy())
    return np.concatenate(predictions), np.concatenate(confidences)


def _load_scored_split(
    scenario: str,
    split: str,
    model: torch.nn.Module,
    detector: IsolationForest,
) -> Dict[str, np.ndarray]:
    dataset = create_dataset(scenario, split)
    labels = []
    families = []
    predicted = []
    confidence = []
    anomaly = []
    for path in dataset.files:
        with np.load(path, allow_pickle=True) as data:
            X = np.asarray(data["X"], dtype=np.float32)
            y = np.asarray(data["y"], dtype=np.int64)
            family = data["attack_family"].astype(str)
        batch_prediction, batch_confidence = _neural_predictions(model, X)
        labels.append(y)
        families.append(family)
        predicted.append(batch_prediction)
        confidence.append(batch_confidence)
        anomaly.append(-detector.score_samples(X))
    return {
        "label": np.concatenate(labels),
        "family": np.concatenate(families),
        "prediction": np.concatenate(predicted),
        "confidence": np.concatenate(confidence),
        "anomaly": np.concatenate(anomaly),
    }


def _robust_parameters(values: np.ndarray) -> Dict[str, float]:
    median = float(np.median(values))
    iqr = float(np.percentile(values, 75) - np.percentile(values, 25))
    return {"median": median, "iqr": max(iqr, 1e-8)}


def _scale(values: np.ndarray, parameters: Dict[str, float]) -> np.ndarray:
    return (values - parameters["median"]) / parameters["iqr"]


def _unknown_metrics(truth: np.ndarray, prediction: np.ndarray) -> Dict[str, float | int]:
    tp = int(np.sum(truth & prediction))
    tn = int(np.sum(~truth & ~prediction))
    fp = int(np.sum(~truth & prediction))
    fn = int(np.sum(truth & ~prediction))
    precision = tp / max(tp + fp, 1)
    recall = tp / max(tp + fn, 1)
    f1 = 2 * precision * recall / max(precision + recall, 1e-12)
    return {
        "true_positive": tp,
        "true_negative": tn,
        "false_positive": fp,
        "false_negative": fn,
        "precision": precision,
        "recall": recall,
        "f1": f1,
        "known_fpr": fp / max(fp + tn, 1),
    }


def _known_metrics(y: np.ndarray, predicted: np.ndarray, rejected: np.ndarray) -> Dict[str, float]:
    known = y >= 0
    y_true = y[known]
    y_pred = predicted[known].copy()
    # Rejection of known traffic is an error represented by a new class.
    y_pred[rejected[known]] = len(CLASS_NAMES)
    labels = list(range(len(CLASS_NAMES)))
    return {
        "accuracy": float(accuracy_score(y_true, y_pred)),
        "macro_precision": float(
            precision_score(y_true, y_pred, labels=labels, average="macro", zero_division=0)
        ),
        "macro_recall": float(
            recall_score(y_true, y_pred, labels=labels, average="macro", zero_division=0)
        ),
        "macro_f1": float(
            f1_score(y_true, y_pred, labels=labels, average="macro", zero_division=0)
        ),
    }


def main() -> None:
    config = load_config()
    scenario = config["openset"]["primary_scenario"]
    hybrid = config["hybrid_open_set_detector"]
    parser = argparse.ArgumentParser(description="Evaluate hybrid open-set detector")
    parser.add_argument("--model", default=None, help="proposed, adaptive_v2, fedavg, centralized, or a path")
    args = parser.parse_args()

    model_path = _resolve_model(args.model)
    model = _load_model(model_path)
    seed = int(config["reproducibility"]["seed"])
    max_per_class = int(hybrid["max_training_samples_per_class"])
    confidence_weight = float(hybrid["confidence_weight"])
    anomaly_weight = float(hybrid["anomaly_weight"])
    target_fpr = float(hybrid["target_known_fpr"])
    if not np.isclose(confidence_weight + anomaly_weight, 1.0):
        raise ValueError("Hybrid open-set weights must sum to 1")

    print("=" * 78)
    print("AEFL-OSIDS HYBRID OPEN-SET EVALUATION")
    print("=" * 78)
    print(f"Model: {model_path}")
    training_sample, training_counts = _balanced_training_sample(scenario, max_per_class, seed)
    detector = IsolationForest(
        n_estimators=int(hybrid["isolation_forest_estimators"]),
        max_samples=min(int(hybrid["isolation_forest_max_samples"]), len(training_sample)),
        contamination="auto",
        random_state=seed,
        n_jobs=-1,
    )
    detector.fit(training_sample)
    print(f"Anomaly detector fitted on {len(training_sample):,} balanced known samples")

    validation = _load_scored_split(scenario, "validation", model, detector)
    if np.any(validation["label"] < 0):
        raise RuntimeError("Unknown labels found in validation; threshold calibration would leak")
    test = _load_scored_split(scenario, "test", model, detector)

    confidence_validation = 1.0 - validation["confidence"]
    confidence_test = 1.0 - test["confidence"]
    confidence_scale = _robust_parameters(confidence_validation)
    anomaly_scale = _robust_parameters(validation["anomaly"])
    validation_score = (
        confidence_weight * _scale(confidence_validation, confidence_scale)
        + anomaly_weight * _scale(validation["anomaly"], anomaly_scale)
    )
    test_score = (
        confidence_weight * _scale(confidence_test, confidence_scale)
        + anomaly_weight * _scale(test["anomaly"], anomaly_scale)
    )
    threshold = float(np.quantile(validation_score, 1.0 - target_fpr, method="higher"))
    rejected = test_score > threshold
    unknown_truth = test["label"] == UNKNOWN_LABEL
    metrics = _unknown_metrics(unknown_truth, rejected)
    known_metrics = _known_metrics(test["label"], test["prediction"], rejected)
    auroc = float(roc_auc_score(unknown_truth, test_score))

    baseline_threshold = float(
        np.quantile(confidence_validation, 1.0 - target_fpr, method="higher")
    )
    baseline_rejected = confidence_test > baseline_threshold
    baseline_metrics = _unknown_metrics(unknown_truth, baseline_rejected)
    baseline_auroc = float(roc_auc_score(unknown_truth, confidence_test))

    family_performance = []
    for family in sorted(UNKNOWN_FAMILIES):
        selected = test["family"] == family
        if not np.any(selected):
            continue
        family_performance.append(
            {
                "family": family,
                "samples": int(selected.sum()),
                "detected_unknown": int(rejected[selected].sum()),
                "unknown_detection_recall": float(rejected[selected].mean()),
                "mean_hybrid_score": float(test_score[selected].mean()),
            }
        )

    actual_open = test["label"].copy()
    actual_open[actual_open < 0] = len(CLASS_NAMES)
    predicted_open = test["prediction"].copy()
    predicted_open[rejected] = len(CLASS_NAMES)
    cm = confusion_matrix(
        actual_open, predicted_open, labels=list(range(len(CLASS_NAMES) + 1))
    )
    result = {
        "experiment": "Hybrid Open-Set Evaluation",
        "scenario": scenario,
        "model": str(model_path.relative_to(PROJECT_ROOT)),
        "method": "MSP uncertainty + balanced Isolation Forest",
        "calibration_uses_unknown_samples": False,
        "test_data_used_for_selection": False,
        "fusion_weights": {
            "confidence": confidence_weight,
            "anomaly": anomaly_weight,
        },
        "target_validation_known_fpr": target_fpr,
        "locked_threshold": threshold,
        "test_samples": int(len(test["label"])),
        "unknown_families": sorted(UNKNOWN_FAMILIES),
        "unknown_detection": metrics,
        "known_class_performance": known_metrics,
        "open_set_auroc": auroc,
        # Flat aliases keep the Streamlit UI and external notebooks simple.
        "unknown_precision": metrics["precision"],
        "unknown_recall": metrics["recall"],
        "unknown_f1": metrics["f1"],
        "known_fpr": metrics["known_fpr"],
        "baseline_msp": {
            "locked_threshold": baseline_threshold,
            "unknown_detection": baseline_metrics,
            "open_set_auroc": baseline_auroc,
        },
        "improvement_over_msp": {
            "unknown_f1_absolute": metrics["f1"] - baseline_metrics["f1"],
            "auroc_absolute": auroc - baseline_auroc,
        },
        "training_known_counts": training_counts,
        "anomaly_training_samples": int(len(training_sample)),
        "score_scaling": {
            "confidence": confidence_scale,
            "anomaly": anomaly_scale,
        },
        "unknown_family_analysis": family_performance,
        "confusion_matrix": {
            "labels": CLASS_NAMES + ["UNKNOWN"],
            "matrix": cm.tolist(),
        },
    }

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    ARTIFACT_PATH.parent.mkdir(parents=True, exist_ok=True)
    (OUTPUT_DIR / "hybrid_open_set_results.json").write_text(
        json.dumps(result, indent=2), encoding="utf-8"
    )
    pd.DataFrame(
        [
            {
                "Method": "MSP confidence baseline",
                "Unknown Precision": baseline_metrics["precision"],
                "Unknown Recall": baseline_metrics["recall"],
                "Unknown F1": baseline_metrics["f1"],
                "Known FPR": baseline_metrics["known_fpr"],
                "AUROC": baseline_auroc,
            },
            {
                "Method": "Hybrid MSP + Isolation Forest",
                "Unknown Precision": metrics["precision"],
                "Unknown Recall": metrics["recall"],
                "Unknown F1": metrics["f1"],
                "Known FPR": metrics["known_fpr"],
                "AUROC": auroc,
            },
        ]
    ).to_csv(OUTPUT_DIR / "hybrid_vs_msp.csv", index=False)
    pd.DataFrame(family_performance).to_csv(
        OUTPUT_DIR / "unknown_family_performance.csv", index=False
    )
    joblib.dump(
        {
            "isolation_forest": detector,
            "confidence_weight": confidence_weight,
            "anomaly_weight": anomaly_weight,
            "threshold": threshold,
            "confidence_scale": confidence_scale,
            "anomaly_scale": anomaly_scale,
            "model_path": str(model_path.relative_to(PROJECT_ROOT)),
            "class_names": CLASS_NAMES,
            "scenario": scenario,
        },
        ARTIFACT_PATH,
    )

    print(f"Unknown F1: {metrics['f1']:.4f} (MSP baseline {baseline_metrics['f1']:.4f})")
    print(f"Open-set AUROC: {auroc:.4f} (MSP baseline {baseline_auroc:.4f})")
    print(f"Known FPR: {metrics['known_fpr']:.4f}")
    print(f"Results: {OUTPUT_DIR}")
    print(f"Detector artifact: {ARTIFACT_PATH}")


if __name__ == "__main__":
    main()
