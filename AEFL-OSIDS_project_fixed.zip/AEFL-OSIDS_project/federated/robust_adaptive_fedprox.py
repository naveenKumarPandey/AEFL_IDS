"""Client-balanced, robust FedProx training for AEFL-OSIDS.

This is the proposed federated method.  It fixes the main weaknesses of the
legacy ``adaptive_fedavg.py`` experiment:

* every client uses its own class-balanced objective, matching the strong
  FedAvg baseline under the non-IID partition;
* FedProx limits client drift under the non-IID Dirichlet partition;
* anomalously large client updates are clipped before aggregation;
* shared layers use reliability-aware capped weights;
* classifier rows use a bounded blend of FedAvg and class-specific support;
* the best round is selected by validation Macro-F1, not accuracy.

Raw samples never leave a client dataset.  The implementation is a local
simulation, but its training loop follows the client/server boundary and logs
communication cost explicitly.
"""

from __future__ import annotations

import argparse
import json
import math
import random
import re
import time
from pathlib import Path
from typing import Dict, Iterable, List, Mapping, Sequence, Tuple

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from sklearn.metrics import accuracy_score, f1_score, precision_score, recall_score
from torch.utils.data import DataLoader, TensorDataset

from data_loader.cic_iot_dataset import create_dataset
from federated.efficient_data import (
    load_federated_client_arrays,
    load_known_split_arrays,
)
from federated.federated_dataset import FederatedClientDataset
from models.intrusion_model import create_model
from utils.config import load_config


PROJECT_ROOT = Path(__file__).resolve().parents[1]
CLASS_NAMES = ["BENIGN", "DDoS", "DoS", "Mirai", "Recon"]
NUM_CLASSES = len(CLASS_NAMES)
INPUT_FEATURES = 39


def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def get_device() -> torch.device:
    return torch.device("cuda" if torch.cuda.is_available() else "cpu")


def class_balanced_weights(
    counts: Sequence[int],
    power: float = 1.0,
    maximum: float = 4.0,
) -> np.ndarray:
    """Return stable inverse-frequency weights.

    ``power=1.0`` reproduces the weighted cross-entropy class weights used by
    the successful centralized baseline. The optional cap prevents a very
    small class from receiving an unbounded multiplier.
    """

    values = np.asarray(counts, dtype=np.float64)
    if values.ndim != 1 or len(values) == 0 or np.any(values <= 0):
        raise ValueError(f"All class counts must be positive: {values.tolist()}")
    if not 0.0 <= power <= 1.0:
        raise ValueError("class-weight power must be in [0, 1]")

    weights = np.power(values.max() / values, power)
    weights /= weights.mean()
    # Cap only excessive rare-class amplification. A symmetric lower floor
    # would undo inverse-frequency correction for dominant classes.
    weights = np.minimum(weights, maximum)
    weights /= weights.mean()
    return weights.astype(np.float32)


def client_class_balanced_weights(
    counts: Sequence[int],
    power: float = 1.0,
) -> np.ndarray:
    """Return inverse-frequency weights for one non-IID client.

    Positive classes are normalized to mean one. Missing classes receive zero
    weight, matching the objective used by the FedAvg baseline.
    """

    values = np.asarray(counts, dtype=np.float64)
    if values.ndim != 1 or len(values) == 0 or np.any(values < 0):
        raise ValueError(f"Class counts must be non-negative: {values.tolist()}")
    if not 0.0 <= power <= 1.0:
        raise ValueError("class-weight power must be in [0, 1]")
    present = values > 0
    if not np.any(present):
        raise ValueError("At least one class must be present")

    weights = np.zeros_like(values)
    weights[present] = np.power(1.0 / values[present], power)
    weights[present] /= weights[present].mean()
    return weights.astype(np.float32)


class ClassBalancedFocalLoss(nn.Module):
    """Multi-class focal loss with fixed class weights."""

    def __init__(self, weights: torch.Tensor, gamma: float = 0.0) -> None:
        super().__init__()
        if gamma < 0:
            raise ValueError("focal gamma must be non-negative")
        self.register_buffer("weights", weights.detach().clone().float())
        self.gamma = float(gamma)

    def forward(self, logits: torch.Tensor, targets: torch.Tensor) -> torch.Tensor:
        log_probabilities = F.log_softmax(logits, dim=1)
        probabilities = log_probabilities.exp()
        row = torch.arange(targets.shape[0], device=targets.device)
        target_log_probability = log_probabilities[row, targets]
        target_probability = probabilities[row, targets]
        sample_weights = self.weights[targets]
        losses = -sample_weights * (1.0 - target_probability).pow(self.gamma)
        losses = losses * target_log_probability
        # Match weighted CrossEntropyLoss scaling when gamma=0. Without this
        # normalization, inverse-frequency weights shrink the effective
        # learning rate according to the current client's class mixture.
        return losses.sum() / sample_weights.sum().clamp_min(1e-12)


def _load_client_arrays(client_id: int) -> Tuple[np.ndarray, np.ndarray]:
    """Materialize one client efficiently by reading every NPZ at most once."""

    dataset = FederatedClientDataset(client_id)
    global_indices = np.asarray(dataset.global_indices, dtype=np.int64)
    x_parts: List[np.ndarray] = []
    y_parts: List[np.ndarray] = []

    previous_end = 0
    for file_path, current_end in zip(dataset.files, dataset.cumulative_sizes):
        mask = (global_indices >= previous_end) & (global_indices < current_end)
        if not np.any(mask):
            previous_end = current_end
            continue

        rows = global_indices[mask] - previous_end
        with np.load(file_path, allow_pickle=False) as data:
            x_parts.append(np.asarray(data["X"][rows], dtype=np.float32))
            y_parts.append(np.asarray(data["y"][rows], dtype=np.int64))
        previous_end = current_end

    if not x_parts:
        raise RuntimeError(f"Client {client_id} contains no samples")

    X = np.concatenate(x_parts)
    y = np.concatenate(y_parts)
    if np.any((y < 0) | (y >= NUM_CLASSES)):
        raise RuntimeError(f"Client {client_id} contains invalid/unknown labels")
    return X, y


def _load_known_split(split_name: str, scenario: str) -> Tuple[np.ndarray, np.ndarray]:
    dataset = create_dataset(scenario, split_name)
    x_parts: List[np.ndarray] = []
    y_parts: List[np.ndarray] = []
    for path in dataset.files:
        with np.load(path, allow_pickle=False) as data:
            X = np.asarray(data["X"], dtype=np.float32)
            y = np.asarray(data["y"], dtype=np.int64)
            keep = (y >= 0) & (y < NUM_CLASSES)
            if np.any(keep):
                x_parts.append(X[keep])
                y_parts.append(y[keep])
    return np.concatenate(x_parts), np.concatenate(y_parts)


def _state_dict_cpu(model: nn.Module) -> Dict[str, torch.Tensor]:
    return {name: value.detach().cpu().clone() for name, value in model.state_dict().items()}


def _load_state(model: nn.Module, state: Mapping[str, torch.Tensor]) -> None:
    model.load_state_dict({name: value.detach().clone() for name, value in state.items()})


def _floating_update_norm(
    local: Mapping[str, torch.Tensor],
    global_state: Mapping[str, torch.Tensor],
) -> float:
    squared = 0.0
    for name, global_value in global_state.items():
        local_value = local[name]
        if global_value.is_floating_point():
            delta = local_value.float() - global_value.float()
            squared += float(torch.sum(delta * delta).item())
    return math.sqrt(max(squared, 0.0))


def _flatten_update(
    local: Mapping[str, torch.Tensor],
    global_state: Mapping[str, torch.Tensor],
) -> torch.Tensor:
    pieces = []
    for name, global_value in global_state.items():
        if global_value.is_floating_point():
            pieces.append((local[name].float() - global_value.float()).reshape(-1))
    return torch.cat(pieces)


def _update_reliability(
    local_states: Sequence[Mapping[str, torch.Tensor]],
    global_state: Mapping[str, torch.Tensor],
) -> np.ndarray:
    updates = torch.stack([_flatten_update(state, global_state) for state in local_states])
    reference = torch.median(updates, dim=0).values
    reference_norm = torch.linalg.vector_norm(reference).item()
    if reference_norm <= 1e-12:
        return np.ones(len(local_states), dtype=np.float64)

    values = []
    for update in updates:
        denominator = torch.linalg.vector_norm(update).item() * reference_norm
        cosine = float(torch.dot(update, reference).item() / max(denominator, 1e-12))
        # A floor prevents a single noisy round from permanently excluding a client.
        values.append(float(np.clip((cosine + 1.0) / 2.0, 0.25, 1.0)))
    return np.asarray(values, dtype=np.float64)


def _cap_normalized_weights(weights: Sequence[float], maximum: float) -> np.ndarray:
    """Normalize weights while enforcing a maximum client contribution."""

    result = np.asarray(weights, dtype=np.float64)
    if np.any(result < 0) or result.sum() <= 0:
        raise ValueError("Aggregation weights must be non-negative and non-zero")
    result /= result.sum()
    if maximum <= 0 or maximum >= 1:
        return result
    if maximum * len(result) < 1.0 - 1e-12:
        raise ValueError(
            "maximum client weight is infeasible for the number of clients"
        )

    for _ in range(len(result) + 2):
        high = result > maximum
        if not np.any(high):
            break
        excess = float((result[high] - maximum).sum())
        result[high] = maximum
        low = ~high
        if not np.any(low):
            break
        low_total = float(result[low].sum())
        if low_total <= 0:
            result[low] = excess / int(low.sum())
        else:
            result[low] += excess * result[low] / low_total
    return result / result.sum()


def calculate_server_weights(
    sample_counts: Sequence[int],
    class_counts: np.ndarray,
    reliability: Sequence[float],
    maximum_weight: float = 0.50,
    sample_weight_power: float = 1.0,
    reliability_mix: float = 0.10,
) -> Tuple[np.ndarray, Dict[str, List[float]]]:
    """Calculate FedAvg-anchored reliability-adaptive client weights."""

    samples = np.asarray(sample_counts, dtype=np.float64)
    counts = np.asarray(class_counts, dtype=np.float64)
    reliability_array = np.asarray(reliability, dtype=np.float64)
    if counts.shape != (len(samples), NUM_CLASSES):
        raise ValueError(f"Expected class-count shape {(len(samples), NUM_CLASSES)}, got {counts.shape}")
    if not 0.0 <= sample_weight_power <= 1.0:
        raise ValueError("sample_weight_power must be in [0, 1]")
    if not 0.0 <= reliability_mix <= 1.0:
        raise ValueError("reliability_mix must be in [0, 1]")

    diversity = []
    for row in counts:
        probabilities = row[row > 0] / max(row.sum(), 1.0)
        entropy = -float(np.sum(probabilities * np.log(probabilities))) if len(probabilities) else 0.0
        diversity.append(entropy / math.log(NUM_CLASSES))
    diversity_array = np.asarray(diversity, dtype=np.float64)

    # Linear sample support anchors the method to statistically representative
    # FedAvg. Reliability makes a bounded adjustment without allowing biased
    # local accuracy or client diversity to override sample evidence.
    sample_factor = np.power(samples, sample_weight_power)
    quality_factor = (1.0 - reliability_mix) + reliability_mix * reliability_array
    weights = _cap_normalized_weights(sample_factor * quality_factor, maximum_weight)
    return weights, {
        "sample_factor": sample_factor.tolist(),
        "diversity": diversity_array.tolist(),
        "update_reliability": reliability_array.tolist(),
        "quality_factor": quality_factor.tolist(),
        "final_weights": weights.tolist(),
    }


def aggregate_client_updates(
    global_state: Mapping[str, torch.Tensor],
    local_states: Sequence[Mapping[str, torch.Tensor]],
    shared_weights: Sequence[float],
    class_counts: np.ndarray,
    reliability: Sequence[float],
    clip_factor: float = 2.5,
    reliability_mix: float = 0.10,
    class_support_power: float = 1.0,
    class_aware_mix: float = 0.10,
) -> Tuple[Dict[str, torch.Tensor], Dict[str, object]]:
    """Clip updates and apply a bounded class-aware classifier correction."""

    if not 0.0 <= reliability_mix <= 1.0:
        raise ValueError("reliability_mix must be in [0, 1]")
    if not 0.0 <= class_support_power <= 1.0:
        raise ValueError("class_support_power must be in [0, 1]")
    if not 0.0 <= class_aware_mix <= 1.0:
        raise ValueError("class_aware_mix must be in [0, 1]")

    norms = np.asarray(
        [_floating_update_norm(state, global_state) for state in local_states],
        dtype=np.float64,
    )
    positive = norms[norms > 0]
    reference_norm = float(np.median(positive)) if len(positive) else 0.0
    limit = reference_norm * float(clip_factor)
    scales = np.ones(len(local_states), dtype=np.float64)
    if limit > 0:
        scales = np.minimum(1.0, limit / np.maximum(norms, 1e-12))

    shared = np.asarray(shared_weights, dtype=np.float64)
    reliability_array = np.asarray(reliability, dtype=np.float64)
    adjusted_reliability = (
        (1.0 - reliability_mix)
        + reliability_mix * reliability_array
    )
    result: Dict[str, torch.Tensor] = {}
    class_weight_rows: List[List[float]] = []

    for name, global_value in global_state.items():
        if not global_value.is_floating_point():
            # BatchNorm counters are bookkeeping values, not trainable updates.
            result[name] = max((state[name] for state in local_states), key=lambda value: int(value.item())).clone()
            continue

        if name in {"classifier.weight", "classifier.bias"}:
            rows = []
            for class_id in range(NUM_CLASSES):
                row_raw = (
                    np.power(
                        np.maximum(class_counts[:, class_id], 0.0),
                        class_support_power,
                    )
                    * adjusted_reliability
                )
                if row_raw.sum() > 0:
                    support_weights = row_raw / row_raw.sum()
                else:
                    support_weights = shared / shared.sum()
                # Class support is a correction, not a replacement for the
                # statistically representative FedAvg client weights.
                row_weights = (
                    (1.0 - class_aware_mix) * shared
                    + class_aware_mix * support_weights
                )
                row_weights = row_weights / row_weights.sum()
                if name == "classifier.weight":
                    delta = sum(
                        float(weight * scale)
                        * (local[name][class_id].float() - global_value[class_id].float())
                        for local, weight, scale in zip(local_states, row_weights, scales)
                    )
                    rows.append(global_value[class_id].float() + delta)
                else:
                    delta = sum(
                        float(weight * scale)
                        * (local[name][class_id].float() - global_value[class_id].float())
                        for local, weight, scale in zip(local_states, row_weights, scales)
                    )
                    rows.append(global_value[class_id].float() + delta)
                if name == "classifier.weight":
                    class_weight_rows.append(row_weights.tolist())
            result[name] = torch.stack(rows).to(dtype=global_value.dtype)
            continue

        aggregate_delta = torch.zeros_like(global_value, dtype=torch.float32)
        for local, weight, scale in zip(local_states, shared, scales):
            aggregate_delta += float(weight * scale) * (
                local[name].float() - global_value.float()
            )
        result[name] = (global_value.float() + aggregate_delta).to(dtype=global_value.dtype)

    return result, {
        "update_norms": norms.tolist(),
        "median_update_norm": reference_norm,
        "clip_limit": limit,
        "clip_scales": scales.tolist(),
        "classifier_class_weights": class_weight_rows,
    }


def train_client(
    global_state: Mapping[str, torch.Tensor],
    client_id: int,
    X: np.ndarray,
    y: np.ndarray,
    class_weights: torch.Tensor,
    device: torch.device,
    local_epochs: int,
    batch_size: int,
    learning_rate: float,
    weight_decay: float,
    focal_gamma: float,
    fedprox_mu: float,
    max_grad_norm: float,
    seed: int,
) -> Tuple[Dict[str, torch.Tensor], Dict[str, object]]:
    model = create_model(input_features=INPUT_FEATURES, num_classes=NUM_CLASSES).to(device)
    _load_state(model, global_state)
    global_parameters = {
        name: parameter.detach().clone()
        for name, parameter in model.named_parameters()
    }

    generator = torch.Generator().manual_seed(seed)
    loader = DataLoader(
        TensorDataset(torch.from_numpy(X), torch.from_numpy(y)),
        batch_size=batch_size,
        shuffle=True,
        generator=generator,
        num_workers=0,
    )
    criterion = ClassBalancedFocalLoss(class_weights, gamma=focal_gamma)
    # Keep the same base optimizer as FedAvg so the proposed comparison
    # isolates FedProx and adaptive aggregation rather than optimizer choice.
    optimizer = torch.optim.Adam(model.parameters(), lr=learning_rate, weight_decay=weight_decay)

    model.train()
    total_loss = 0.0
    total_correct = 0
    total_samples = 0
    started = time.time()

    for _ in range(local_epochs):
        for features, targets in loader:
            if len(targets) < 2:
                continue
            features = features.to(device)
            targets = targets.to(device)
            optimizer.zero_grad(set_to_none=True)
            logits = model(features)
            classification_loss = criterion(logits, targets)

            proximal_penalty = torch.zeros((), device=device)
            if fedprox_mu > 0:
                for name, parameter in model.named_parameters():
                    proximal_penalty = proximal_penalty + torch.sum(
                        (parameter - global_parameters[name]) ** 2
                    )
            loss = classification_loss + 0.5 * fedprox_mu * proximal_penalty
            loss.backward()
            if max_grad_norm > 0:
                torch.nn.utils.clip_grad_norm_(model.parameters(), max_grad_norm)
            optimizer.step()

            count = int(targets.shape[0])
            total_loss += float(classification_loss.item()) * count
            total_correct += int((logits.argmax(dim=1) == targets).sum().item())
            total_samples += count

    state = _state_dict_cpu(model)
    return state, {
        "client_id": client_id,
        "samples": int(len(y)),
        "loss": total_loss / max(total_samples, 1),
        "accuracy": total_correct / max(total_samples, 1),
        "class_counts": np.bincount(y, minlength=NUM_CLASSES).astype(int).tolist(),
        "training_time_seconds": time.time() - started,
    }


def evaluate_arrays(
    model: nn.Module,
    X: np.ndarray,
    y: np.ndarray,
    device: torch.device,
    batch_size: int,
) -> Dict[str, float]:
    model.eval()
    predictions: List[int] = []
    total_loss = 0.0
    with torch.no_grad():
        for start in range(0, len(y), batch_size):
            features = torch.from_numpy(X[start : start + batch_size]).to(device)
            targets = torch.from_numpy(y[start : start + batch_size]).to(device)
            logits = model(features)
            total_loss += float(F.cross_entropy(logits, targets, reduction="sum").item())
            predictions.extend(logits.argmax(dim=1).cpu().numpy().tolist())

    predicted = np.asarray(predictions, dtype=np.int64)
    labels = list(range(NUM_CLASSES))
    return {
        "loss": total_loss / len(y),
        "accuracy": float(accuracy_score(y, predicted)),
        "precision_macro": float(precision_score(y, predicted, labels=labels, average="macro", zero_division=0)),
        "recall_macro": float(recall_score(y, predicted, labels=labels, average="macro", zero_division=0)),
        "f1_macro": float(f1_score(y, predicted, labels=labels, average="macro", zero_division=0)),
        "f1_weighted": float(f1_score(y, predicted, labels=labels, average="weighted", zero_division=0)),
    }


def _model_size_bytes(state: Mapping[str, torch.Tensor]) -> int:
    return int(sum(value.numel() * value.element_size() for value in state.values()))


def _save_json(value: object, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2), encoding="utf-8")


def _resolve_warm_start(value: str | None) -> Path | None:
    if not value or value.lower() in {"none", "scratch"}:
        return None
    aliases = {
        "fedavg": PROJECT_ROOT / "data" / "models" / "fedavg_global.pt",
        "adaptive_v2": PROJECT_ROOT / "data" / "models" / "adaptive_fedavg_v2_global.pt",
        "centralized": PROJECT_ROOT / "data" / "models" / "centralized_baseline.pt",
    }
    return aliases.get(value.lower(), Path(value).expanduser().resolve())


def build_parser() -> argparse.ArgumentParser:
    config = load_config()
    proposed = config.get("proposed_training", {})
    training = config.get("training", {})
    return argparse.ArgumentParser(description="Train the robust class-balanced FedProx model")


def parse_args() -> argparse.Namespace:
    config = load_config()
    proposed = config.get("proposed_training", {})
    training = config.get("training", {})
    parser = argparse.ArgumentParser(description="Train FedAvg-anchored client-balanced FedProx")
    parser.add_argument("--rounds", type=int, default=int(proposed.get("rounds", 5)))
    parser.add_argument("--local-epochs", type=int, default=int(proposed.get("local_epochs", 1)))
    parser.add_argument("--batch-size", type=int, default=int(training.get("batch_size", 512)))
    parser.add_argument("--learning-rate", type=float, default=float(training.get("learning_rate", 0.001)))
    parser.add_argument("--warm-start", default=str(proposed.get("warm_start", "scratch")))
    parser.add_argument("--output-name", default=str(proposed.get("output_name", "robust_adaptive_fedprox")))
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    config = load_config()
    proposed = config.get("proposed_training", {})
    scenario = config["openset"]["primary_scenario"]
    num_clients = int(config["federated"]["num_clients"])
    seed = int(config["reproducibility"]["seed"])
    weight_decay = float(config["training"].get("weight_decay", 1e-5))
    focal_gamma = float(proposed.get("focal_gamma", 0.0))
    class_weight_power = float(proposed.get("class_weight_power", 1.0))
    loss_weight_scope = str(proposed.get("loss_weight_scope", "client")).strip().lower()
    fedprox_mu = float(proposed.get("fedprox_mu", 1e-4))
    max_grad_norm = float(proposed.get("max_grad_norm", 5.0))
    clip_factor = float(proposed.get("update_clip_factor", 2.5))
    maximum_client_weight = float(proposed.get("maximum_client_weight", 0.50))
    sample_weight_power = float(proposed.get("sample_weight_power", 1.0))
    reliability_mix = float(proposed.get("reliability_mix", 0.10))
    class_support_power = float(proposed.get("class_support_power", 1.0))
    class_aware_mix = float(proposed.get("class_aware_mix", 0.10))
    patience = int(proposed.get("early_stopping_patience", 3))

    output_name = re.sub(r"[^A-Za-z0-9_.-]+", "_", args.output_name).strip("._")
    if not output_name:
        raise ValueError("output name cannot be empty")
    if args.rounds < 1 or args.local_epochs < 1:
        raise ValueError("rounds and local epochs must be positive")
    if loss_weight_scope not in {"client", "global"}:
        raise ValueError("loss_weight_scope must be 'client' or 'global'")

    set_seed(seed)
    device = get_device()
    print("=" * 78)
    print("AEFL-OSIDS FEDAVG-ANCHORED CLIENT-BALANCED FEDPROX")
    print("=" * 78)
    print(f"Scenario: {scenario} | Device: {device} | Clients: {num_clients}")
    print(f"Rounds: {args.rounds} | Local epochs: {args.local_epochs}")
    print(
        "Proposed v3: "
        f"loss-scope={loss_weight_scope}, class-power={class_weight_power:g}, "
        f"focal-gamma={focal_gamma:g}, sample-power={sample_weight_power:g}, "
        f"reliability-mix={reliability_mix:g}, class-aware-mix={class_aware_mix:g}"
    )

    print("Loading federated client arrays once for efficient local training...")
    clients = load_federated_client_arrays(
        scenario=scenario,
        num_clients=num_clients,
        num_classes=NUM_CLASSES,
        input_features=INPUT_FEATURES,
    )
    sample_counts = np.asarray([len(y) for _, y in clients], dtype=np.int64)
    counts = np.stack([np.bincount(y, minlength=NUM_CLASSES) for _, y in clients])
    global_counts = counts.sum(axis=0)
    weights_np = class_balanced_weights(global_counts, power=class_weight_power)
    if loss_weight_scope == "client":
        client_weights_np = np.stack(
            [client_class_balanced_weights(row, power=class_weight_power) for row in counts]
        )
    else:
        client_weights_np = np.repeat(weights_np[None, :], num_clients, axis=0)
    client_class_weights = [
        torch.tensor(row, dtype=torch.float32, device=device)
        for row in client_weights_np
    ]
    print("Global class counts:", dict(zip(CLASS_NAMES, global_counts.astype(int).tolist())))
    print("Global reference weights:", dict(zip(CLASS_NAMES, np.round(weights_np, 4).tolist())))
    print(f"Loss weighting scope: {loss_weight_scope}")
    if loss_weight_scope == "client":
        for client_id, row in enumerate(client_weights_np):
            print(f"  Client {client_id} loss weights: {np.round(row, 4).tolist()}")

    validation_X, validation_y = load_known_split_arrays(
        scenario=scenario,
        split_name="validation",
        num_classes=NUM_CLASSES,
        input_features=INPUT_FEATURES,
    )
    model = create_model(input_features=INPUT_FEATURES, num_classes=NUM_CLASSES).to(device)
    warm_start = _resolve_warm_start(args.warm_start)
    if warm_start is not None:
        if not warm_start.exists():
            raise FileNotFoundError(f"Warm-start checkpoint not found: {warm_start}")
        checkpoint = torch.load(warm_start, map_location="cpu")
        state = checkpoint.get("model_state_dict", checkpoint)
        model.load_state_dict(state, strict=True)
        print(f"Warm start: {warm_start}")
    else:
        print("Warm start: scratch (publication-safe default)")

    global_state = _state_dict_cpu(model)
    history: List[Dict[str, object]] = []
    best_f1 = -1.0
    best_round = 0
    best_state = {name: value.clone() for name, value in global_state.items()}
    stale_rounds = 0
    experiment_started = time.time()
    model_bytes = _model_size_bytes(global_state)

    for round_number in range(1, args.rounds + 1):
        round_started = time.time()
        print(f"\nRound {round_number}/{args.rounds}")
        local_states = []
        client_metrics = []
        for client_id, (X, y) in enumerate(clients):
            local_state, metrics = train_client(
                global_state=global_state,
                client_id=client_id,
                X=X,
                y=y,
                class_weights=client_class_weights[client_id],
                device=device,
                local_epochs=args.local_epochs,
                batch_size=args.batch_size,
                learning_rate=args.learning_rate,
                weight_decay=weight_decay,
                focal_gamma=focal_gamma,
                fedprox_mu=fedprox_mu,
                max_grad_norm=max_grad_norm,
                seed=seed + round_number * 100 + client_id,
            )
            local_states.append(local_state)
            client_metrics.append(metrics)
            print(
                f"  Client {client_id}: n={len(y):,}, "
                f"loss={metrics['loss']:.4f}, acc={metrics['accuracy']:.4f}, "
                f"time={metrics['training_time_seconds']:.1f}s"
            )

        reliability = _update_reliability(local_states, global_state)
        server_weights, weight_details = calculate_server_weights(
            sample_counts,
            counts,
            reliability,
            maximum_weight=maximum_client_weight,
            sample_weight_power=sample_weight_power,
            reliability_mix=reliability_mix,
        )
        global_state, robust_details = aggregate_client_updates(
            global_state=global_state,
            local_states=local_states,
            shared_weights=server_weights,
            class_counts=counts,
            reliability=reliability,
            clip_factor=clip_factor,
            reliability_mix=reliability_mix,
            class_support_power=class_support_power,
            class_aware_mix=class_aware_mix,
        )
        _load_state(model, global_state)
        validation = evaluate_arrays(
            model, validation_X, validation_y, device=device, batch_size=max(args.batch_size, 2048)
        )
        elapsed = time.time() - round_started
        communication = model_bytes * num_clients * 2
        record = {
            "round": round_number,
            "validation": validation,
            "client_metrics": client_metrics,
            "aggregation_weights": server_weights.tolist(),
            "weight_details": weight_details,
            "robust_aggregation": robust_details,
            "communication_bytes": communication,
            "round_time_seconds": elapsed,
        }
        history.append(record)
        print(
            f"  Validation: accuracy={validation['accuracy']:.4f}, "
            f"Macro-F1={validation['f1_macro']:.4f}, loss={validation['loss']:.4f}"
        )
        print("  Aggregation weights:", np.round(server_weights, 4).tolist())

        if validation["f1_macro"] > best_f1 + 1e-6:
            best_f1 = validation["f1_macro"]
            best_round = round_number
            best_state = {name: value.clone() for name, value in global_state.items()}
            stale_rounds = 0
        else:
            stale_rounds += 1
            if patience > 0 and stale_rounds >= patience:
                print(f"Early stopping after {stale_rounds} rounds without Macro-F1 improvement.")
                break

    _load_state(model, best_state)
    best_metrics = evaluate_arrays(
        model, validation_X, validation_y, device=device, batch_size=max(args.batch_size, 2048)
    )
    total_seconds = time.time() - experiment_started

    model_path = PROJECT_ROOT / "data" / "models" / f"{output_name}_global.pt"
    result_dir = PROJECT_ROOT / "results" / output_name
    model_path.parent.mkdir(parents=True, exist_ok=True)
    result_dir.mkdir(parents=True, exist_ok=True)
    checkpoint = {
        "model_state_dict": best_state,
        "input_features": INPUT_FEATURES,
        "num_classes": NUM_CLASSES,
        "class_names": CLASS_NAMES,
        "scenario": scenario,
        "algorithm": "FedAvg-Anchored Client-Balanced FedProx v3",
        "best_round": best_round,
        "validation_f1_macro": best_f1,
        "warm_start": str(warm_start) if warm_start else "scratch",
    }
    torch.save(checkpoint, model_path)
    _save_json(history, result_dir / "round_history.json")
    _save_json(best_metrics, result_dir / "final_metrics.json")
    _save_json(
        {
            "scenario": scenario,
            "algorithm": "FedAvg-Anchored Client-Balanced FedProx v3",
            "clients": num_clients,
            "rounds_requested": args.rounds,
            "rounds_completed": len(history),
            "best_round": best_round,
            "local_epochs": args.local_epochs,
            "batch_size": args.batch_size,
            "learning_rate": args.learning_rate,
            "focal_gamma": focal_gamma,
            "class_weight_power": class_weight_power,
            "class_weights": weights_np.tolist(),
            "loss_weight_scope": loss_weight_scope,
            "client_class_weights": client_weights_np.tolist(),
            "sample_weight_power": sample_weight_power,
            "reliability_mix": reliability_mix,
            "class_support_power": class_support_power,
            "class_aware_mix": class_aware_mix,
            "fedprox_mu": fedprox_mu,
            "update_clip_factor": clip_factor,
            "maximum_client_weight": maximum_client_weight,
            "early_stopping_patience": patience,
            "warm_start": str(warm_start) if warm_start else "scratch",
            "model_size_bytes": model_bytes,
            "total_communication_bytes": int(sum(item["communication_bytes"] for item in history)),
            "total_time_seconds": total_seconds,
            "seed": seed,
        },
        result_dir / "metadata.json",
    )
    print("\nTraining complete")
    print(f"Best round: {best_round} | Validation Macro-F1: {best_f1:.4f}")
    print(f"Model: {model_path}")
    print(f"Results: {result_dir}")


if __name__ == "__main__":
    main()
