from pathlib import Path

import yaml


PROJECT_ROOT = Path(__file__).resolve().parents[1]

CONFIG_PATH = (
    PROJECT_ROOT
    / "configs"
    / "config.yaml"
)


def load_config(
    config_path: Path = CONFIG_PATH,
) -> dict:
    """
    Load project configuration from YAML.
    """

    if not config_path.exists():
        raise FileNotFoundError(
            f"Configuration file not found:\n"
            f"{config_path}"
        )

    with open(
        config_path,
        "r",
        encoding="utf-8",
    ) as file:

        config = yaml.safe_load(file)

    if not isinstance(config, dict):
        raise ValueError(
            "Configuration must contain "
            "a YAML dictionary."
        )

    return config


def get_project_root() -> Path:
    """
    Return project root directory.
    """

    return PROJECT_ROOT


def get_dataset_dir() -> Path:
    """
    Return raw CICIoT2023 directory.
    """

    config = load_config()

    relative_path = Path(
        config["dataset"]["raw_dir"]
    )

    return PROJECT_ROOT / relative_path


def get_processed_dir() -> Path:
    """
    Return processed dataset directory.
    """

    config = load_config()

    relative_path = Path(
        config["dataset"]["processed_dir"]
    )

    return PROJECT_ROOT / relative_path


def get_split_dir() -> Path:
    """
    Return split manifest directory.
    """

    config = load_config()

    relative_path = Path(
        config["dataset"]["split_dir"]
    )

    return PROJECT_ROOT / relative_path


def get_experiment_mode() -> str:
    """
    Return current experiment mode.

    Expected values:
        development
        full
    """

    config = load_config()

    mode = config[
        "experiment"
    ]["mode"]

    if mode not in {
        "development",
        "full",
    }:
        raise ValueError(
            f"Unsupported experiment mode: "
            f"{mode}"
        )

    return mode


if __name__ == "__main__":

    config = load_config()

    print("=" * 70)
    print("AEFL-OSIDS CONFIGURATION TEST")
    print("=" * 70)

    print(
        f"\nProject root:"
    )
    print(
        get_project_root()
    )

    print(
        f"\nDataset directory:"
    )
    print(
        get_dataset_dir()
    )

    print(
        f"\nProcessed directory:"
    )
    print(
        get_processed_dir()
    )

    print(
        f"\nSplit directory:"
    )
    print(
        get_split_dir()
    )

    print(
        f"\nExperiment mode:"
    )
    print(
        get_experiment_mode()
    )

    print(
        f"\nOpen-set primary scenario:"
    )
    print(
        config[
            "openset"
        ]["primary_scenario"]
    )

    print(
        f"\nFederated clients:"
    )
    print(
        config[
            "federated"
        ]["num_clients"]
    )

    print("\n")
    print("=" * 70)
    print("CONFIGURATION TEST SUCCESSFUL")
    print("=" * 70)