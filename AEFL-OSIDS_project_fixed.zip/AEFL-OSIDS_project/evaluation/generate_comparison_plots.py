"""
AEFL-OSIDS Publication Comparison Plots

Reads the already-generated classification_comparison.csv.
No training, preprocessing, or model inference is performed.
"""

from pathlib import Path

import matplotlib.pyplot as plt
import pandas as pd


PROJECT_ROOT = Path(__file__).resolve().parents[1]
INPUT_FILE = (
    PROJECT_ROOT
    / "results"
    / "paper_results"
    / "classification_comparison.csv"
)
OUTPUT_DIR = PROJECT_ROOT / "results" / "paper_results"

OUTPUT_DIR.mkdir(parents=True, exist_ok=True)


def load_data():
    if not INPUT_FILE.exists():
        raise FileNotFoundError(
            f"Classification comparison file not found:\n{INPUT_FILE}"
        )

    df = pd.read_csv(INPUT_FILE)

    required = {
        "Method",
        "Accuracy",
        "Macro Precision",
        "Macro Recall",
        "Macro F1",
        "Weighted F1",
    }

    missing = required - set(df.columns)
    if missing:
        raise ValueError(
            "Missing required columns: "
            + ", ".join(sorted(missing))
        )

    return df


def save_publication_csv(df):
    path = OUTPUT_DIR / "publication_classification_comparison.csv"
    df.to_csv(path, index=False, encoding="utf-8-sig")
    return path


def plot_single_metric(df, column, ylabel, title, filename):
    plt.figure(figsize=(9, 5.5))

    plt.bar(df["Method"], df[column])

    plt.ylabel(ylabel)
    plt.xlabel("Method")
    plt.title(title)
    plt.ylim(0, 100)
    plt.xticks(rotation=15, ha="right")
    plt.grid(axis="y", alpha=0.25)

    for i, value in enumerate(df[column]):
        if pd.notna(value):
            plt.text(
                i,
                value + 1.0,
                f"{value:.2f}%",
                ha="center",
                va="bottom",
                fontsize=9,
            )

    plt.tight_layout()

    path = OUTPUT_DIR / filename
    plt.savefig(path, dpi=300, bbox_inches="tight")
    plt.close()

    return path


def plot_precision_recall_f1(df):
    metrics = [
        "Macro Precision",
        "Macro Recall",
        "Macro F1",
    ]

    x = range(len(df))
    width = 0.25

    plt.figure(figsize=(10, 5.8))

    for offset, metric in zip(
        [-width, 0, width],
        metrics,
    ):
        values = df[metric].astype(float)
        positions = [i + offset for i in x]

        plt.bar(
            positions,
            values,
            width=width,
            label=metric,
        )

    plt.ylabel("Score (%)")
    plt.xlabel("Method")
    plt.title("Macro Precision, Recall and F1 Comparison")
    plt.ylim(0, 100)
    plt.xticks(list(x), df["Method"], rotation=15, ha="right")
    plt.grid(axis="y", alpha=0.25)
    plt.legend()

    plt.tight_layout()

    path = OUTPUT_DIR / "classification_precision_recall_f1.png"
    plt.savefig(path, dpi=300, bbox_inches="tight")
    plt.close()

    return path


def save_text_summary(df):
    # Find best values from the actual table.
    best_accuracy = df.loc[df["Accuracy"].idxmax()]
    best_macro_f1 = df.loc[df["Macro F1"].idxmax()]
    best_weighted_f1 = df.loc[df["Weighted F1"].idxmax()]

    lines = [
        "AEFL-OSIDS CLASSIFICATION COMPARISON",
        "=" * 72,
        "",
        "RESULTS",
        "-" * 72,
    ]

    for _, row in df.iterrows():
        lines.append(
            f"{row['Method']}: "
            f"Accuracy={row['Accuracy']:.2f}%, "
            f"Macro Precision={row['Macro Precision']:.2f}%, "
            f"Macro Recall={row['Macro Recall']:.2f}%, "
            f"Macro F1={row['Macro F1']:.2f}%, "
            f"Weighted F1={row['Weighted F1']:.2f}%"
        )

    lines.extend(
        [
            "",
            "BEST VALUES",
            "-" * 72,
            f"Best Accuracy   : {best_accuracy['Method']} "
            f"({best_accuracy['Accuracy']:.2f}%)",
            f"Best Macro-F1   : {best_macro_f1['Method']} "
            f"({best_macro_f1['Macro F1']:.2f}%)",
            f"Best Weighted-F1: {best_weighted_f1['Method']} "
            f"({best_weighted_f1['Weighted F1']:.2f}%)",
            "",
            "NOTE",
            "-" * 72,
            "Values are read directly from the existing "
            "classification_comparison.csv.",
            "No training or inference was performed.",
        ]
    )

    path = OUTPUT_DIR / "classification_comparison_summary.txt"
    path.write_text("\n".join(lines), encoding="utf-8")

    return path


def main():
    print("=" * 70)
    print("AEFL-OSIDS PUBLICATION CLASSIFICATION COMPARISON")
    print("=" * 70)
    print()
    print(f"Input : {INPUT_FILE}")
    print(f"Output: {OUTPUT_DIR}")
    print()

    df = load_data()

    print("Methods found:")
    for method in df["Method"]:
        print(f"  - {method}")

    print()

    csv_path = save_publication_csv(df)

    accuracy_path = plot_single_metric(
        df,
        "Accuracy",
        "Accuracy (%)",
        "Known-Class Accuracy Comparison",
        "classification_accuracy_comparison.png",
    )

    macro_f1_path = plot_single_metric(
        df,
        "Macro F1",
        "Macro-F1 (%)",
        "Known-Class Macro-F1 Comparison",
        "classification_macro_f1_comparison.png",
    )

    weighted_f1_path = plot_single_metric(
        df,
        "Weighted F1",
        "Weighted-F1 (%)",
        "Known-Class Weighted-F1 Comparison",
        "classification_weighted_f1_comparison.png",
    )

    prf_path = plot_precision_recall_f1(df)
    summary_path = save_text_summary(df)

    print("Generated:")
    print(f"  {csv_path}")
    print(f"  {accuracy_path}")
    print(f"  {macro_f1_path}")
    print(f"  {weighted_f1_path}")
    print(f"  {prf_path}")
    print(f"  {summary_path}")

    print()
    print("=" * 70)
    print("COMPARISON PLOTS GENERATED SUCCESSFULLY")
    print("=" * 70)


if __name__ == "__main__":
    main()
