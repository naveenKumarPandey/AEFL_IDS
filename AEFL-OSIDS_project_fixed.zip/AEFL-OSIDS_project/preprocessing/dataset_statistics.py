from collections import defaultdict
from pathlib import Path

import pandas as pd

from preprocessing.data_loader import (
    DATASET_DIR,
    find_csv_files,
    LABEL_COLUMN,
)
from preprocessing.preprocessor import get_attack_family


CHUNK_SIZE = 100_000


def count_csv_rows(csv_path: Path) -> int:
    """
    Count rows in a CSV file using chunks so that
    the complete file is never loaded into memory.
    """

    total_rows = 0

    for chunk in pd.read_csv(
        csv_path,
        chunksize=CHUNK_SIZE,
    ):
        total_rows += len(chunk)

    return total_rows


def analyze_dataset(dataset_dir: Path = DATASET_DIR):
    """
    Calculate exact row counts for every attack folder.
    """

    csv_files = find_csv_files(dataset_dir)

    if not csv_files:
        raise RuntimeError(
            "No CSV files found."
        )

    label_rows = defaultdict(int)
    label_files = defaultdict(int)

    family_rows = defaultdict(int)

    unknown_family_labels = set()

    print("=" * 80)
    print("CICIoT2023 EXACT DATASET STATISTICS")
    print("=" * 80)

    print(f"\nDataset directory:")
    print(dataset_dir)

    print(f"\nCSV files:")
    print(len(csv_files))

    print("\nScanning CSV files...")
    print("This may take some time because the files are being")
    print("read chunk-by-chunk.")

    for index, csv_file in enumerate(csv_files, start=1):

        label = csv_file.parent.name

        if label == "Benign_Final":
            normalized_label = "BENIGN"
        else:
            normalized_label = label

        rows = count_csv_rows(csv_file)

        label_rows[normalized_label] += rows
        label_files[normalized_label] += 1

        family = get_attack_family(
            normalized_label
        )

        family_rows[family] += rows

        if family == "Other":
            unknown_family_labels.add(
                normalized_label
            )

        if index % 10 == 0 or index == len(csv_files):
            print(
                f"Processed {index:>3}/{len(csv_files)} files"
            )

    return (
        label_rows,
        label_files,
        family_rows,
        unknown_family_labels,
    )


def print_results(
    label_rows,
    label_files,
    family_rows,
    unknown_family_labels,
):
    """
    Print final dataset statistics.
    """

    total_rows = sum(
        label_rows.values()
    )

    print("\n")
    print("=" * 80)
    print("DETAILED ATTACK-LABEL DISTRIBUTION")
    print("=" * 80)

    print(
        f"\n{'Attack Label':<35}"
        f"{'Files':>10}"
        f"{'Rows':>15}"
    )

    print("-" * 65)

    for label in sorted(label_rows):

        print(
            f"{label:<35}"
            f"{label_files[label]:>10}"
            f"{label_rows[label]:>15,}"
        )

    print("\n")
    print("=" * 80)
    print("ATTACK-FAMILY DISTRIBUTION")
    print("=" * 80)

    print(
        f"\n{'Attack Family':<25}"
        f"{'Rows':>15}"
        f"{'Percentage':>15}"
    )

    print("-" * 55)

    for family in sorted(family_rows):

        rows = family_rows[family]

        percentage = (
            rows / total_rows * 100
        )

        print(
            f"{family:<25}"
            f"{rows:>15,}"
            f"{percentage:>14.2f}%"
        )

    print("\n")
    print("=" * 80)
    print("DATASET SUMMARY")
    print("=" * 80)

    print(f"\nTotal CSV files : {sum(label_files.values())}")
    print(f"Total rows     : {total_rows:,}")
    print(f"Total labels   : {len(label_rows)}")
    print(f"Total families : {len(family_rows)}")

    print("\n")

    if unknown_family_labels:

        print("=" * 80)
        print("WARNING: UNMAPPED ATTACK LABELS")
        print("=" * 80)

        for label in sorted(
            unknown_family_labels
        ):
            print(f"  - {label}")

        print(
            "\nThese labels must be mapped before "
            "the final preprocessing pipeline."
        )

    else:

        print(
            "All attack labels are mapped "
            "to known families."
        )

    print("\n" + "=" * 80)
    print("STATISTICS ANALYSIS COMPLETE")
    print("=" * 80)


if __name__ == "__main__":

    (
        label_rows,
        label_files,
        family_rows,
        unknown_family_labels,
    ) = analyze_dataset(
        DATASET_DIR
    )

    print_results(
        label_rows,
        label_files,
        family_rows,
        unknown_family_labels,
    )