"""Audit processed CICIoT2023 data for leakage and metadata defects."""

from __future__ import annotations

import argparse
import json
from collections import Counter
from pathlib import Path
from typing import Dict, Tuple

import numpy as np
import pandas as pd

from utils.config import get_processed_dir, load_config


PROJECT_ROOT = Path(__file__).resolve().parents[1]


def _project_reference(path: Path) -> str:
    try:
        return str(path.relative_to(PROJECT_ROOT))
    except ValueError:
        return str(path)


def _feature_hashes(X: np.ndarray) -> np.ndarray:
    frame = pd.DataFrame(np.ascontiguousarray(X))
    return pd.util.hash_pandas_object(frame, index=False).to_numpy(dtype=np.uint64)


def _summarize_split(directory: Path) -> Tuple[dict, np.ndarray, np.ndarray, np.ndarray]:
    hashes = []
    labels = []
    sources = set()
    class_counts: Counter[int] = Counter()
    family_counts: Counter[str] = Counter()
    non_finite = 0
    files = sorted(directory.rglob("*.npz"))
    if not files:
        raise FileNotFoundError(f"No NPZ files found in {directory}")

    for path in files:
        with np.load(path, allow_pickle=True) as data:
            X = np.asarray(data["X"])
            y = np.asarray(data["y"], dtype=np.int64)
            hashes.append(_feature_hashes(X))
            labels.append(y)
            non_finite += int((~np.isfinite(X)).sum())
            unique, counts = np.unique(y, return_counts=True)
            class_counts.update({int(key): int(value) for key, value in zip(unique, counts)})
            if "attack_family" in data.files:
                unique, counts = np.unique(data["attack_family"].astype(str), return_counts=True)
                family_counts.update({str(key): int(value) for key, value in zip(unique, counts)})
            if "source_file" in data.files:
                sources.update(data["source_file"].astype(str).tolist())

    all_hashes = np.concatenate(hashes)
    all_labels = np.concatenate(labels)
    order = np.argsort(all_hashes, kind="stable")
    sorted_hashes = all_hashes[order]
    sorted_labels = all_labels[order]
    unique_hashes, starts, counts = np.unique(
        sorted_hashes, return_index=True, return_counts=True
    )
    minimum_label = np.minimum.reduceat(sorted_labels, starts)
    maximum_label = np.maximum.reduceat(sorted_labels, starts)
    ambiguous = minimum_label != maximum_label

    summary = {
        "directory": _project_reference(directory),
        "npz_files": len(files),
        "samples": int(len(all_hashes)),
        "unique_feature_rows": int(len(unique_hashes)),
        "duplicate_occurrences": int(len(all_hashes) - len(unique_hashes)),
        "ambiguous_unique_feature_rows": int(ambiguous.sum()),
        "non_finite_feature_values": non_finite,
        "label_distribution": {str(key): value for key, value in sorted(class_counts.items())},
        "family_distribution": dict(sorted(family_counts.items())),
        "source_file_values": sorted(sources),
        "source_metadata_suspected_truncated": bool(
            sources and max(len(value) for value in sources) <= 1
        ),
    }
    # Minimum/maximum labels let the cross-split audit identify conflicts
    # without retaining large Python dictionaries.
    return summary, unique_hashes, minimum_label, maximum_label


def _cross_split(
    name_a: str,
    data_a: Tuple[np.ndarray, np.ndarray, np.ndarray],
    name_b: str,
    data_b: Tuple[np.ndarray, np.ndarray, np.ndarray],
) -> dict:
    hashes_a, min_a, max_a = data_a
    hashes_b, min_b, max_b = data_b
    common, index_a, index_b = np.intersect1d(
        hashes_a, hashes_b, assume_unique=True, return_indices=True
    )
    incompatible = (
        (min_a[index_a] != min_b[index_b])
        | (max_a[index_a] != max_b[index_b])
        | (min_a[index_a] != max_a[index_a])
        | (min_b[index_b] != max_b[index_b])
    )
    return {
        "split_a": name_a,
        "split_b": name_b,
        "overlapping_unique_feature_rows": int(len(common)),
        "overlapping_rows_with_label_conflict": int(incompatible.sum()),
    }


def run_audit(scenario: str) -> dict:
    base = get_processed_dir() / scenario
    summaries: Dict[str, dict] = {}
    compact = {}
    for split in ("train", "validation", "test"):
        summary, hashes, minimum, maximum = _summarize_split(base / split)
        summaries[split] = summary
        compact[split] = (hashes, minimum, maximum)

    overlaps = [
        _cross_split("train", compact["train"], "validation", compact["validation"]),
        _cross_split("train", compact["train"], "test", compact["test"]),
        _cross_split("validation", compact["validation"], "test", compact["test"]),
    ]
    overlap_total = sum(item["overlapping_unique_feature_rows"] for item in overlaps)
    truncated = any(item["source_metadata_suspected_truncated"] for item in summaries.values())
    checks = {
        "no_cross_split_exact_duplicates": overlap_total == 0,
        "no_within_split_exact_duplicates": all(
            item["duplicate_occurrences"] == 0 for item in summaries.values()
        ),
        "no_ambiguous_exact_feature_labels": all(
            item["ambiguous_unique_feature_rows"] == 0 for item in summaries.values()
        ),
        "source_file_metadata_preserved": not truncated,
        "all_features_finite": all(
            item["non_finite_feature_values"] == 0 for item in summaries.values()
        ),
    }
    return {
        "scenario": scenario,
        "status": "PASS" if all(checks.values()) else "FAIL",
        "checks": checks,
        "splits": summaries,
        "cross_split_overlap": overlaps,
        "interpretation": (
            "FAIL means reported model scores may be optimistic or source-level analysis is unreliable. "
            "Regenerate processed data after applying the corrected preprocessing code, then rerun this audit."
        ),
    }


def main() -> None:
    config = load_config()
    parser = argparse.ArgumentParser(description="Audit processed dataset integrity")
    parser.add_argument(
        "--scenario", default=config["openset"]["primary_scenario"]
    )
    parser.add_argument(
        "--fail-on-error", action="store_true", help="return a failing exit code when audit status is FAIL"
    )
    args = parser.parse_args()

    report = run_audit(args.scenario)
    output_dir = PROJECT_ROOT / "results" / "data_integrity"
    output_dir.mkdir(parents=True, exist_ok=True)
    output = output_dir / f"{args.scenario}_audit.json"
    output.write_text(json.dumps(report, indent=2), encoding="utf-8")

    print("=" * 78)
    print("AEFL-OSIDS DATASET INTEGRITY AUDIT")
    print("=" * 78)
    print(f"Scenario: {args.scenario} | Status: {report['status']}")
    for item in report["cross_split_overlap"]:
        print(
            f"{item['split_a']} vs {item['split_b']}: "
            f"{item['overlapping_unique_feature_rows']:,} duplicate feature rows, "
            f"{item['overlapping_rows_with_label_conflict']:,} conflicting"
        )
    print(f"Report: {output}")
    if args.fail_on_error and report["status"] != "PASS":
        raise SystemExit(2)


if __name__ == "__main__":
    main()
